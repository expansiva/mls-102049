/// <mls fileReference="_102049_/l4/petShop/workspaces/catalog.defs.ts" enhancement="_blank"/>

export const catalogWorkspace = {
  "workspaceId": "catalog",
  "title": "Catálogo de produtos",
  "actors": [
    "cliente"
  ],
  "kind": "workflow",
  "entity": "Product",
  "workflowId": "reservationLifecycle",
  "bffCalls": [
    {
      "bffId": "featuredProducts",
      "kind": "query",
      "uses": [
        {
          "operationId": "browseFeaturedProducts"
        }
      ],
      "input": [
        {
          "name": "categoryId",
          "from": "browseFeaturedProducts.categoryId",
          "type": "string"
        },
        {
          "name": "petTypeId",
          "from": "browseFeaturedProducts.petTypeId",
          "type": "string"
        },
        {
          "name": "name",
          "from": "browseFeaturedProducts.name",
          "type": "string"
        },
        {
          "name": "priceMin",
          "from": "browseFeaturedProducts.priceMin",
          "type": "number"
        },
        {
          "name": "priceMax",
          "from": "browseFeaturedProducts.priceMax",
          "type": "number"
        },
        {
          "name": "page",
          "type": "number"
        },
        {
          "name": "pageSize",
          "type": "number"
        }
      ],
      "output": {
        "kind": "list",
        "fields": [
          {
            "name": "productId",
            "from": "browseFeaturedProducts.$items.productId",
            "type": "string",
            "required": true
          },
          {
            "name": "name",
            "from": "browseFeaturedProducts.$items.name",
            "type": "string",
            "required": true
          },
          {
            "name": "price",
            "from": "browseFeaturedProducts.$items.price",
            "type": "number",
            "required": true
          },
          {
            "name": "isFeatured",
            "from": "browseFeaturedProducts.$items.isFeatured",
            "type": "boolean",
            "required": true
          },
          {
            "name": "categoryId",
            "from": "browseFeaturedProducts.$items.categoryId",
            "type": "string",
            "required": true
          },
          {
            "name": "petTypeId",
            "from": "browseFeaturedProducts.$items.petTypeId",
            "type": "string",
            "required": true
          }
        ]
      },
      "route": "petShop.catalog.featuredProducts"
    },
    {
      "bffId": "browseCatalog",
      "kind": "query",
      "uses": [
        {
          "operationId": "browseProducts"
        }
      ],
      "input": [
        {
          "name": "searchName",
          "from": "browseProducts.searchName",
          "type": "string"
        },
        {
          "name": "petTypeId",
          "from": "browseProducts.petTypeId",
          "type": "string"
        },
        {
          "name": "categoryId",
          "from": "browseProducts.categoryId",
          "type": "string"
        },
        {
          "name": "minPrice",
          "from": "browseProducts.minPrice",
          "type": "number"
        },
        {
          "name": "maxPrice",
          "from": "browseProducts.maxPrice",
          "type": "number"
        },
        {
          "name": "page",
          "type": "number"
        },
        {
          "name": "pageSize",
          "type": "number"
        }
      ],
      "output": {
        "kind": "paginated",
        "fields": [
          {
            "name": "items",
            "from": "browseProducts.$items",
            "type": "array",
            "required": true,
            "item": {
              "fields": [
                {
                  "name": "productId",
                  "from": "browseProducts.$items.productId",
                  "type": "string",
                  "required": true
                },
                {
                  "name": "name",
                  "from": "browseProducts.$items.name",
                  "type": "string",
                  "required": true
                },
                {
                  "name": "price",
                  "from": "browseProducts.$items.price",
                  "type": "number",
                  "required": true
                },
                {
                  "name": "isFeatured",
                  "from": "browseProducts.$items.isFeatured",
                  "type": "boolean",
                  "required": true
                },
                {
                  "name": "categoryId",
                  "from": "browseProducts.$items.categoryId",
                  "type": "string",
                  "required": true
                },
                {
                  "name": "categoryName",
                  "from": "browseProducts.$items.categoryName",
                  "type": "string",
                  "required": true
                },
                {
                  "name": "petTypeId",
                  "from": "browseProducts.$items.petTypeId",
                  "type": "string",
                  "required": true
                },
                {
                  "name": "petTypeName",
                  "from": "browseProducts.$items.petTypeName",
                  "type": "string",
                  "required": true
                },
                {
                  "name": "createdAt",
                  "from": "browseProducts.$items.createdAt",
                  "type": "string",
                  "required": true
                },
                {
                  "name": "updatedAt",
                  "from": "browseProducts.$items.updatedAt",
                  "type": "string",
                  "required": true
                }
              ]
            }
          },
          {
            "name": "total",
            "from": "browseProducts.total",
            "type": "number",
            "required": true
          },
          {
            "name": "page",
            "from": "browseProducts.page",
            "type": "number",
            "required": true
          },
          {
            "name": "pageSize",
            "from": "browseProducts.pageSize",
            "type": "number",
            "required": true
          }
        ]
      },
      "route": "petShop.catalog.browseCatalog"
    },
    {
      "bffId": "productDetails",
      "kind": "query",
      "uses": [
        {
          "operationId": "viewProductDetails"
        }
      ],
      "input": [
        {
          "name": "productId",
          "from": "viewProductDetails.productId",
          "type": "string",
          "required": true
        }
      ],
      "output": {
        "kind": "object",
        "fields": [
          {
            "name": "productId",
            "from": "viewProductDetails.productId",
            "type": "string",
            "required": true
          },
          {
            "name": "name",
            "from": "viewProductDetails.name",
            "type": "string",
            "required": true
          },
          {
            "name": "price",
            "from": "viewProductDetails.price",
            "type": "number",
            "required": true
          },
          {
            "name": "isFeatured",
            "from": "viewProductDetails.isFeatured",
            "type": "boolean",
            "required": true
          },
          {
            "name": "categoryId",
            "from": "viewProductDetails.categoryId",
            "type": "string",
            "required": true
          },
          {
            "name": "categoryName",
            "from": "viewProductDetails.categoryName",
            "type": "string",
            "required": true
          },
          {
            "name": "petTypeId",
            "from": "viewProductDetails.petTypeId",
            "type": "string",
            "required": true
          },
          {
            "name": "petTypeName",
            "from": "viewProductDetails.petTypeName",
            "type": "string",
            "required": true
          },
          {
            "name": "createdAt",
            "from": "viewProductDetails.createdAt",
            "type": "string",
            "required": true
          },
          {
            "name": "updatedAt",
            "from": "viewProductDetails.updatedAt",
            "type": "string",
            "required": true
          }
        ]
      },
      "route": "petShop.catalog.productDetails"
    },
    {
      "bffId": "reserveProduct",
      "kind": "command",
      "uses": [
        {
          "operationId": "createReservation"
        }
      ],
      "input": [
        {
          "name": "customerName",
          "from": "createReservation.customerName",
          "type": "string",
          "required": true
        },
        {
          "name": "customerPhone",
          "from": "createReservation.customerPhone",
          "type": "string",
          "required": true
        },
        {
          "name": "productId",
          "from": "createReservation.productId",
          "type": "string",
          "required": true
        },
        {
          "name": "quantity",
          "from": "createReservation.quantity",
          "type": "number",
          "required": true
        }
      ],
      "output": {
        "kind": "object",
        "fields": [
          {
            "name": "reservationId",
            "from": "createReservation.reservationId",
            "type": "string",
            "required": true
          },
          {
            "name": "customerName",
            "from": "createReservation.customerName",
            "type": "string",
            "required": true
          },
          {
            "name": "customerPhone",
            "from": "createReservation.customerPhone",
            "type": "string",
            "required": true
          },
          {
            "name": "status",
            "from": "createReservation.status",
            "type": "string",
            "required": true
          },
          {
            "name": "expiresAt",
            "from": "createReservation.expiresAt",
            "type": "string",
            "required": true
          },
          {
            "name": "createdAt",
            "from": "createReservation.createdAt",
            "type": "string",
            "required": true
          },
          {
            "name": "items",
            "from": "createReservation.items",
            "type": "array",
            "required": true,
            "item": {
              "fields": [
                {
                  "name": "productId",
                  "from": "createReservation.$items.productId",
                  "type": "string",
                  "required": true
                },
                {
                  "name": "productName",
                  "from": "createReservation.$items.productName",
                  "type": "string",
                  "required": true
                },
                {
                  "name": "quantity",
                  "from": "createReservation.$items.quantity",
                  "type": "number",
                  "required": true
                }
              ]
            }
          }
        ]
      },
      "route": "petShop.catalog.reserveProduct"
    }
  ],
  "sections": [
    {
      "sectionId": "vitrine",
      "intent": "O cliente visualiza produtos em destaque na vitrine inicial do pet shop",
      "organisms": [
        {
          "role": "primarySurface",
          "dataSource": "featuredProducts"
        },
        {
          "role": "filterControl",
          "attachTo": "featuredProducts"
        }
      ]
    },
    {
      "sectionId": "catalogo",
      "intent": "O cliente pesquisa e filtra todos os produtos disponíveis no catálogo completo",
      "organisms": [
        {
          "role": "primarySurface",
          "dataSource": "browseCatalog"
        },
        {
          "role": "filterControl",
          "attachTo": "browseCatalog"
        }
      ]
    },
    {
      "sectionId": "detalheReserva",
      "intent": "O cliente visualiza os detalhes do produto selecionado e reserva para retirada na loja",
      "organisms": [
        {
          "role": "primarySurface",
          "dataSource": "productDetails"
        },
        {
          "role": "contextualAction",
          "action": "reserveProduct"
        }
      ]
    }
  ],
  "operationIds": [
    "browseFeaturedProducts",
    "browseProducts",
    "viewProductDetails",
    "createReservation"
  ],
  "purpose": "O cliente navega pela vitrine e pelo catálogo, visualiza detalhes dos produtos e reserva itens para retirada na loja",
  "sliceHash": "djb2:0f1ce64b"
} as const;

export default catalogWorkspace;

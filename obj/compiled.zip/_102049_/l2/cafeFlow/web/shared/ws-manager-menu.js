/// <mls fileReference="_102049_/l2/cafeFlow/web/shared/ws-manager-menu.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
/// **collab_i18n_start**
const message_pt = {
    "wsManagerMenu.section.management.title": "Gestão de Cardápio",
    "wsManagerMenu.organism.queryMenuItems.title": "Itens do cardápio",
    "wsManagerMenu.organism.createMenuItem.title": "Novo item",
    "wsManagerMenu.organism.updateMenuItem.title": "Editar item",
    "wsManagerMenu.organism.deleteMenuItem.title": "Remover item",
    "wsManagerMenu.organism.summary.title": "Resumo do cardápio",
    "wsManagerMenu.intent.queryMenuItems.title": "Consultar itens",
    "wsManagerMenu.intent.createMenuItem.title": "Criar item",
    "wsManagerMenu.intent.updateMenuItem.title": "Atualizar item",
    "wsManagerMenu.intent.deleteMenuItem.title": "Excluir item",
    "wsManagerMenu.intent.summary.title": "Resumo",
    "wsManagerMenu.field.menuItemId": "ID do item",
    "wsManagerMenu.field.name": "Nome",
    "wsManagerMenu.field.category": "Categoria",
    "wsManagerMenu.field.price": "Preço",
    "wsManagerMenu.field.description": "Descrição",
    "wsManagerMenu.field.status": "Status",
    "wsManagerMenu.field.createdAt": "Criado em",
    "wsManagerMenu.field.updatedAt": "Atualizado em",
    "wsManagerMenu.action.query": "Buscar",
    "wsManagerMenu.action.saveItem": "Salvar item",
    "wsManagerMenu.action.saveChanges": "Salvar alterações",
    "wsManagerMenu.action.confirmDelete": "Confirmar exclusão"
};
const messages = { pt: message_pt };
export class CafeFlowWsManagerMenuBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.queryMenuItemsState = 'idle';
        this.queryMenuItemsMenuItemId = '';
        this.queryMenuItemsName = '';
        this.queryMenuItemsCategory = '';
        this.queryMenuItemsStatus = '';
        this.queryMenuItemsCreatedAt = '';
        this.queryMenuItemsUpdatedAt = '';
        this.queryMenuItemsData = [];
        this.createMenuItemState = 'idle';
        this.createMenuItemName = '';
        this.createMenuItemCategory = '';
        this.createMenuItemPrice = Number('');
        this.createMenuItemDescription = '';
        this.createMenuItemStatus = '';
        this.updateMenuItemState = 'idle';
        this.updateMenuItemName = '';
        this.updateMenuItemCategory = '';
        this.updateMenuItemPrice = Number('');
        this.updateMenuItemDescription = '';
        this.updateMenuItemStatus = '';
        this.deleteMenuItemState = 'idle';
        this.deleteMenuItemMenuItemId = '';
        this.deleteMenuItemName = '';
        this.deleteMenuItemCategory = '';
        this.deleteMenuItemPrice = Number('');
        this.deleteMenuItemDescription = '';
        this.deleteMenuItemStatus = '';
        this.stateKeys = [
            'ui.ws-manager-menu.status',
            'ui.ws-manager-menu.action.queryMenuItems.status',
            'ui.ws-manager-menu.input.queryMenuItems.menuItemId',
            'ui.ws-manager-menu.input.queryMenuItems.name',
            'ui.ws-manager-menu.input.queryMenuItems.category',
            'ui.ws-manager-menu.input.queryMenuItems.status',
            'ui.ws-manager-menu.input.queryMenuItems.createdAt',
            'ui.ws-manager-menu.input.queryMenuItems.updatedAt',
            'ui.ws-manager-menu.data.queryMenuItems',
            'ui.ws-manager-menu.action.createMenuItem.status',
            'ui.ws-manager-menu.input.createMenuItem.name',
            'ui.ws-manager-menu.input.createMenuItem.category',
            'ui.ws-manager-menu.input.createMenuItem.price',
            'ui.ws-manager-menu.input.createMenuItem.description',
            'ui.ws-manager-menu.input.createMenuItem.status',
            'ui.ws-manager-menu.action.updateMenuItem.status',
            'ui.ws-manager-menu.input.updateMenuItem.name',
            'ui.ws-manager-menu.input.updateMenuItem.category',
            'ui.ws-manager-menu.input.updateMenuItem.price',
            'ui.ws-manager-menu.input.updateMenuItem.description',
            'ui.ws-manager-menu.input.updateMenuItem.status',
            'ui.ws-manager-menu.action.deleteMenuItem.status',
            'ui.ws-manager-menu.input.deleteMenuItem.menuItemId',
            'ui.ws-manager-menu.input.deleteMenuItem.name',
            'ui.ws-manager-menu.input.deleteMenuItem.category',
            'ui.ws-manager-menu.input.deleteMenuItem.price',
            'ui.ws-manager-menu.input.deleteMenuItem.description',
            'ui.ws-manager-menu.input.deleteMenuItem.status',
        ];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = this.initStateValue('ui.ws-manager-menu.status', '');
        this.queryMenuItemsState = this.initStateValue('ui.ws-manager-menu.action.queryMenuItems.status', 'idle');
        this.queryMenuItemsMenuItemId = this.initStateValue('ui.ws-manager-menu.input.queryMenuItems.menuItemId', '');
        this.queryMenuItemsName = this.initStateValue('ui.ws-manager-menu.input.queryMenuItems.name', '');
        this.queryMenuItemsCategory = this.initStateValue('ui.ws-manager-menu.input.queryMenuItems.category', '');
        this.queryMenuItemsStatus = this.initStateValue('ui.ws-manager-menu.input.queryMenuItems.status', '');
        this.queryMenuItemsCreatedAt = this.initStateValue('ui.ws-manager-menu.input.queryMenuItems.createdAt', '');
        this.queryMenuItemsUpdatedAt = this.initStateValue('ui.ws-manager-menu.input.queryMenuItems.updatedAt', '');
        this.queryMenuItemsData = this.initStateValue('ui.ws-manager-menu.data.queryMenuItems', []);
        this.createMenuItemState = this.initStateValue('ui.ws-manager-menu.action.createMenuItem.status', 'idle');
        this.createMenuItemName = this.initStateValue('ui.ws-manager-menu.input.createMenuItem.name', '');
        this.createMenuItemCategory = this.initStateValue('ui.ws-manager-menu.input.createMenuItem.category', '');
        this.createMenuItemPrice = this.initStateValue('ui.ws-manager-menu.input.createMenuItem.price', Number(''));
        this.createMenuItemDescription = this.initStateValue('ui.ws-manager-menu.input.createMenuItem.description', '');
        this.createMenuItemStatus = this.initStateValue('ui.ws-manager-menu.input.createMenuItem.status', '');
        this.updateMenuItemState = this.initStateValue('ui.ws-manager-menu.action.updateMenuItem.status', 'idle');
        this.updateMenuItemName = this.initStateValue('ui.ws-manager-menu.input.updateMenuItem.name', '');
        this.updateMenuItemCategory = this.initStateValue('ui.ws-manager-menu.input.updateMenuItem.category', '');
        this.updateMenuItemPrice = this.initStateValue('ui.ws-manager-menu.input.updateMenuItem.price', Number(''));
        this.updateMenuItemDescription = this.initStateValue('ui.ws-manager-menu.input.updateMenuItem.description', '');
        this.updateMenuItemStatus = this.initStateValue('ui.ws-manager-menu.input.updateMenuItem.status', '');
        this.deleteMenuItemState = this.initStateValue('ui.ws-manager-menu.action.deleteMenuItem.status', 'idle');
        this.deleteMenuItemMenuItemId = this.initStateValue('ui.ws-manager-menu.input.deleteMenuItem.menuItemId', '');
        this.deleteMenuItemName = this.initStateValue('ui.ws-manager-menu.input.deleteMenuItem.name', '');
        this.deleteMenuItemCategory = this.initStateValue('ui.ws-manager-menu.input.deleteMenuItem.category', '');
        this.deleteMenuItemPrice = this.initStateValue('ui.ws-manager-menu.input.deleteMenuItem.price', Number(''));
        this.deleteMenuItemDescription = this.initStateValue('ui.ws-manager-menu.input.deleteMenuItem.description', '');
        this.deleteMenuItemStatus = this.initStateValue('ui.ws-manager-menu.input.deleteMenuItem.status', '');
        subscribe(this.stateKeys, this);
        void this.loadQueryMenuItems();
    }
    disconnectedCallback() {
        unsubscribe(this.stateKeys, this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.ws-manager-menu.status':
                this.status = value;
                break;
            case 'ui.ws-manager-menu.action.queryMenuItems.status':
                this.queryMenuItemsState = value;
                break;
            case 'ui.ws-manager-menu.input.queryMenuItems.menuItemId':
                this.queryMenuItemsMenuItemId = value;
                break;
            case 'ui.ws-manager-menu.input.queryMenuItems.name':
                this.queryMenuItemsName = value;
                break;
            case 'ui.ws-manager-menu.input.queryMenuItems.category':
                this.queryMenuItemsCategory = value;
                break;
            case 'ui.ws-manager-menu.input.queryMenuItems.status':
                this.queryMenuItemsStatus = value;
                break;
            case 'ui.ws-manager-menu.input.queryMenuItems.createdAt':
                this.queryMenuItemsCreatedAt = value;
                break;
            case 'ui.ws-manager-menu.input.queryMenuItems.updatedAt':
                this.queryMenuItemsUpdatedAt = value;
                break;
            case 'ui.ws-manager-menu.data.queryMenuItems':
                this.queryMenuItemsData = value;
                break;
            case 'ui.ws-manager-menu.action.createMenuItem.status':
                this.createMenuItemState = value;
                break;
            case 'ui.ws-manager-menu.input.createMenuItem.name':
                this.createMenuItemName = value;
                break;
            case 'ui.ws-manager-menu.input.createMenuItem.category':
                this.createMenuItemCategory = value;
                break;
            case 'ui.ws-manager-menu.input.createMenuItem.price':
                this.createMenuItemPrice = value;
                break;
            case 'ui.ws-manager-menu.input.createMenuItem.description':
                this.createMenuItemDescription = value;
                break;
            case 'ui.ws-manager-menu.input.createMenuItem.status':
                this.createMenuItemStatus = value;
                break;
            case 'ui.ws-manager-menu.action.updateMenuItem.status':
                this.updateMenuItemState = value;
                break;
            case 'ui.ws-manager-menu.input.updateMenuItem.name':
                this.updateMenuItemName = value;
                break;
            case 'ui.ws-manager-menu.input.updateMenuItem.category':
                this.updateMenuItemCategory = value;
                break;
            case 'ui.ws-manager-menu.input.updateMenuItem.price':
                this.updateMenuItemPrice = value;
                break;
            case 'ui.ws-manager-menu.input.updateMenuItem.description':
                this.updateMenuItemDescription = value;
                break;
            case 'ui.ws-manager-menu.input.updateMenuItem.status':
                this.updateMenuItemStatus = value;
                break;
            case 'ui.ws-manager-menu.action.deleteMenuItem.status':
                this.deleteMenuItemState = value;
                break;
            case 'ui.ws-manager-menu.input.deleteMenuItem.menuItemId':
                this.deleteMenuItemMenuItemId = value;
                break;
            case 'ui.ws-manager-menu.input.deleteMenuItem.name':
                this.deleteMenuItemName = value;
                break;
            case 'ui.ws-manager-menu.input.deleteMenuItem.category':
                this.deleteMenuItemCategory = value;
                break;
            case 'ui.ws-manager-menu.input.deleteMenuItem.price':
                this.deleteMenuItemPrice = value;
                break;
            case 'ui.ws-manager-menu.input.deleteMenuItem.description':
                this.deleteMenuItemDescription = value;
                break;
            case 'ui.ws-manager-menu.input.deleteMenuItem.status':
                this.deleteMenuItemStatus = value;
                break;
            default:
                return;
        }
        this.requestUpdate();
    }
    initStateValue(key, fallback) {
        const stored = getState(key);
        if (stored === undefined) {
            setState(key, fallback);
            return fallback;
        }
        return stored;
    }
    setQueryMenuItemsMenuItemId(value) {
        this.queryMenuItemsMenuItemId = value;
        setState('ui.ws-manager-menu.input.queryMenuItems.menuItemId', value);
        this.requestUpdate();
    }
    handleQueryMenuItemsMenuItemIdChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setQueryMenuItemsMenuItemId(target.value);
    }
    setQueryMenuItemsName(value) {
        this.queryMenuItemsName = value;
        setState('ui.ws-manager-menu.input.queryMenuItems.name', value);
        this.requestUpdate();
    }
    handleQueryMenuItemsNameChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setQueryMenuItemsName(target.value);
    }
    setQueryMenuItemsCategory(value) {
        this.queryMenuItemsCategory = value;
        setState('ui.ws-manager-menu.input.queryMenuItems.category', value);
        this.requestUpdate();
    }
    handleQueryMenuItemsCategoryChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setQueryMenuItemsCategory(target.value);
    }
    setQueryMenuItemsStatus(value) {
        this.queryMenuItemsStatus = value;
        setState('ui.ws-manager-menu.input.queryMenuItems.status', value);
        this.requestUpdate();
    }
    handleQueryMenuItemsStatusChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setQueryMenuItemsStatus(target.value);
    }
    setQueryMenuItemsCreatedAt(value) {
        this.queryMenuItemsCreatedAt = value;
        setState('ui.ws-manager-menu.input.queryMenuItems.createdAt', value);
        this.requestUpdate();
    }
    handleQueryMenuItemsCreatedAtChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setQueryMenuItemsCreatedAt(target.value);
    }
    setQueryMenuItemsUpdatedAt(value) {
        this.queryMenuItemsUpdatedAt = value;
        setState('ui.ws-manager-menu.input.queryMenuItems.updatedAt', value);
        this.requestUpdate();
    }
    handleQueryMenuItemsUpdatedAtChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setQueryMenuItemsUpdatedAt(target.value);
    }
    setCreateMenuItemName(value) {
        this.createMenuItemName = value;
        setState('ui.ws-manager-menu.input.createMenuItem.name', value);
        this.requestUpdate();
    }
    handleCreateMenuItemNameChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setCreateMenuItemName(target.value);
    }
    setCreateMenuItemCategory(value) {
        this.createMenuItemCategory = value;
        setState('ui.ws-manager-menu.input.createMenuItem.category', value);
        this.requestUpdate();
    }
    handleCreateMenuItemCategoryChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setCreateMenuItemCategory(target.value);
    }
    setCreateMenuItemPrice(value) {
        this.createMenuItemPrice = value;
        setState('ui.ws-manager-menu.input.createMenuItem.price', value);
        this.requestUpdate();
    }
    handleCreateMenuItemPriceChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        const numericValue = Number(target.value);
        this.setCreateMenuItemPrice(Number.isNaN(numericValue) ? 0 : numericValue);
    }
    setCreateMenuItemDescription(value) {
        this.createMenuItemDescription = value;
        setState('ui.ws-manager-menu.input.createMenuItem.description', value);
        this.requestUpdate();
    }
    handleCreateMenuItemDescriptionChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setCreateMenuItemDescription(target.value);
    }
    setCreateMenuItemStatus(value) {
        this.createMenuItemStatus = value;
        setState('ui.ws-manager-menu.input.createMenuItem.status', value);
        this.requestUpdate();
    }
    handleCreateMenuItemStatusChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setCreateMenuItemStatus(target.value);
    }
    setUpdateMenuItemName(value) {
        this.updateMenuItemName = value;
        setState('ui.ws-manager-menu.input.updateMenuItem.name', value);
        this.requestUpdate();
    }
    handleUpdateMenuItemNameChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setUpdateMenuItemName(target.value);
    }
    setUpdateMenuItemCategory(value) {
        this.updateMenuItemCategory = value;
        setState('ui.ws-manager-menu.input.updateMenuItem.category', value);
        this.requestUpdate();
    }
    handleUpdateMenuItemCategoryChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setUpdateMenuItemCategory(target.value);
    }
    setUpdateMenuItemPrice(value) {
        this.updateMenuItemPrice = value;
        setState('ui.ws-manager-menu.input.updateMenuItem.price', value);
        this.requestUpdate();
    }
    handleUpdateMenuItemPriceChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        const numericValue = Number(target.value);
        this.setUpdateMenuItemPrice(Number.isNaN(numericValue) ? 0 : numericValue);
    }
    setUpdateMenuItemDescription(value) {
        this.updateMenuItemDescription = value;
        setState('ui.ws-manager-menu.input.updateMenuItem.description', value);
        this.requestUpdate();
    }
    handleUpdateMenuItemDescriptionChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setUpdateMenuItemDescription(target.value);
    }
    setUpdateMenuItemStatus(value) {
        this.updateMenuItemStatus = value;
        setState('ui.ws-manager-menu.input.updateMenuItem.status', value);
        this.requestUpdate();
    }
    handleUpdateMenuItemStatusChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setUpdateMenuItemStatus(target.value);
    }
    setDeleteMenuItemMenuItemId(value) {
        this.deleteMenuItemMenuItemId = value;
        setState('ui.ws-manager-menu.input.deleteMenuItem.menuItemId', value);
        this.requestUpdate();
    }
    handleDeleteMenuItemMenuItemIdChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setDeleteMenuItemMenuItemId(target.value);
    }
    setDeleteMenuItemName(value) {
        this.deleteMenuItemName = value;
        setState('ui.ws-manager-menu.input.deleteMenuItem.name', value);
        this.requestUpdate();
    }
    handleDeleteMenuItemNameChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setDeleteMenuItemName(target.value);
    }
    setDeleteMenuItemCategory(value) {
        this.deleteMenuItemCategory = value;
        setState('ui.ws-manager-menu.input.deleteMenuItem.category', value);
        this.requestUpdate();
    }
    handleDeleteMenuItemCategoryChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setDeleteMenuItemCategory(target.value);
    }
    setDeleteMenuItemPrice(value) {
        this.deleteMenuItemPrice = value;
        setState('ui.ws-manager-menu.input.deleteMenuItem.price', value);
        this.requestUpdate();
    }
    handleDeleteMenuItemPriceChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        const numericValue = Number(target.value);
        this.setDeleteMenuItemPrice(Number.isNaN(numericValue) ? 0 : numericValue);
    }
    setDeleteMenuItemDescription(value) {
        this.deleteMenuItemDescription = value;
        setState('ui.ws-manager-menu.input.deleteMenuItem.description', value);
        this.requestUpdate();
    }
    handleDeleteMenuItemDescriptionChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setDeleteMenuItemDescription(target.value);
    }
    setDeleteMenuItemStatus(value) {
        this.deleteMenuItemStatus = value;
        setState('ui.ws-manager-menu.input.deleteMenuItem.status', value);
        this.requestUpdate();
    }
    handleDeleteMenuItemStatusChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setDeleteMenuItemStatus(target.value);
    }
    async loadQueryMenuItems(options = {}) {
        this.queryMenuItemsState = 'loading';
        setState('ui.ws-manager-menu.action.queryMenuItems.status', 'loading');
        const params = {
            menuItemId: this.queryMenuItemsMenuItemId || undefined,
            name: this.queryMenuItemsName || undefined,
            category: this.queryMenuItemsCategory || undefined,
            status: this.queryMenuItemsStatus || undefined,
            createdAt: this.queryMenuItemsCreatedAt || undefined,
            updatedAt: this.queryMenuItemsUpdatedAt || undefined,
        };
        const response = await execBff('cafeFlow.queryMenuItems.queryMenuItems', params, { ...options, mode: 'silent' });
        if (response.ok) {
            const data = response.data ?? [];
            this.queryMenuItemsData = data;
            setState('ui.ws-manager-menu.data.queryMenuItems', data);
            this.queryMenuItemsState = 'success';
            setState('ui.ws-manager-menu.action.queryMenuItems.status', 'success');
            return;
        }
        this.queryMenuItemsState = 'error';
        setState('ui.ws-manager-menu.action.queryMenuItems.status', 'error');
        const fallback = [];
        this.queryMenuItemsData = fallback;
        setState('ui.ws-manager-menu.data.queryMenuItems', fallback);
    }
    handleQueryMenuItemsClick(event) {
        void this.loadQueryMenuItems();
    }
    async createMenuItem(options = {}) {
        this.createMenuItemState = 'loading';
        setState('ui.ws-manager-menu.action.createMenuItem.status', 'loading');
        const statusValue = this.createMenuItemStatus;
        if (statusValue !== 'active' && statusValue !== 'inactive') {
            this.createMenuItemState = 'error';
            setState('ui.ws-manager-menu.action.createMenuItem.status', 'error');
            throw new Error('Status inválido.');
        }
        const params = {
            name: this.createMenuItemName,
            category: this.createMenuItemCategory,
            price: this.createMenuItemPrice,
            description: this.createMenuItemDescription || undefined,
            status: statusValue,
        };
        const response = await execBff('cafeFlow.createMenuItem.createMenuItem', params, { ...options, mode: 'blocking' });
        if (response.ok) {
            this.createMenuItemState = 'success';
            setState('ui.ws-manager-menu.action.createMenuItem.status', 'success');
            return;
        }
        this.createMenuItemState = 'error';
        setState('ui.ws-manager-menu.action.createMenuItem.status', 'error');
        throw new Error(response.error?.message ?? 'Erro ao criar item do cardápio.');
    }
    handleCreateMenuItemClick(event) {
        void runBlockingUiAction(async (signal) => {
            await this.createMenuItem({ signal });
        }, { mode: 'blocking' });
    }
    async updateMenuItem(options = {}) {
        this.updateMenuItemState = 'loading';
        setState('ui.ws-manager-menu.action.updateMenuItem.status', 'loading');
        const statusValue = this.updateMenuItemStatus;
        if (statusValue !== 'active' && statusValue !== 'inactive') {
            this.updateMenuItemState = 'error';
            setState('ui.ws-manager-menu.action.updateMenuItem.status', 'error');
            throw new Error('Status inválido.');
        }
        const params = {
            name: this.updateMenuItemName,
            category: this.updateMenuItemCategory,
            price: this.updateMenuItemPrice,
            description: this.updateMenuItemDescription || undefined,
            status: statusValue,
        };
        const response = await execBff('cafeFlow.updateMenuItem.updateMenuItem', params, { ...options, mode: 'blocking' });
        if (response.ok) {
            this.updateMenuItemState = 'success';
            setState('ui.ws-manager-menu.action.updateMenuItem.status', 'success');
            return;
        }
        this.updateMenuItemState = 'error';
        setState('ui.ws-manager-menu.action.updateMenuItem.status', 'error');
        throw new Error(response.error?.message ?? 'Erro ao atualizar item do cardápio.');
    }
    handleUpdateMenuItemClick(event) {
        void runBlockingUiAction(async (signal) => {
            await this.updateMenuItem({ signal });
        }, { mode: 'blocking' });
    }
    async deleteMenuItem(options = {}) {
        this.deleteMenuItemState = 'loading';
        setState('ui.ws-manager-menu.action.deleteMenuItem.status', 'loading');
        const statusValue = this.deleteMenuItemStatus;
        if (statusValue !== 'active' && statusValue !== 'inactive') {
            this.deleteMenuItemState = 'error';
            setState('ui.ws-manager-menu.action.deleteMenuItem.status', 'error');
            throw new Error('Status inválido.');
        }
        const params = {
            menuItemId: this.deleteMenuItemMenuItemId || undefined,
            name: this.deleteMenuItemName,
            category: this.deleteMenuItemCategory,
            price: this.deleteMenuItemPrice,
            description: this.deleteMenuItemDescription || undefined,
            status: statusValue,
        };
        const response = await execBff('cafeFlow.deleteMenuItem.deleteMenuItem', params, { ...options, mode: 'blocking' });
        if (response.ok) {
            this.deleteMenuItemState = 'success';
            setState('ui.ws-manager-menu.action.deleteMenuItem.status', 'success');
            return;
        }
        this.deleteMenuItemState = 'error';
        setState('ui.ws-manager-menu.action.deleteMenuItem.status', 'error');
        throw new Error(response.error?.message ?? 'Erro ao remover item do cardápio.');
    }
    handleDeleteMenuItemClick(event) {
        void runBlockingUiAction(async (signal) => {
            await this.deleteMenuItem({ signal });
        }, { mode: 'blocking' });
    }
}
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "queryMenuItemsState", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "queryMenuItemsMenuItemId", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "queryMenuItemsName", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "queryMenuItemsCategory", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "queryMenuItemsStatus", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "queryMenuItemsCreatedAt", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "queryMenuItemsUpdatedAt", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "queryMenuItemsData", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "createMenuItemState", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "createMenuItemName", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "createMenuItemCategory", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "createMenuItemPrice", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "createMenuItemDescription", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "createMenuItemStatus", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "updateMenuItemState", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "updateMenuItemName", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "updateMenuItemCategory", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "updateMenuItemPrice", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "updateMenuItemDescription", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "updateMenuItemStatus", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "deleteMenuItemState", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "deleteMenuItemMenuItemId", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "deleteMenuItemName", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "deleteMenuItemCategory", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "deleteMenuItemPrice", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "deleteMenuItemDescription", void 0);
__decorate([
    property()
], CafeFlowWsManagerMenuBase.prototype, "deleteMenuItemStatus", void 0);

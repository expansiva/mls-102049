/// <mls fileReference="_102049_/l2/petShop/web/contracts/catalog.productDetails.ts" enhancement="_blank"/>
export const productDetailsRoute = 'petShop.catalog.productDetails';

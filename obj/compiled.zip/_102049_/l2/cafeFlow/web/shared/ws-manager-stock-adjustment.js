/// <mls fileReference="_102049_/l2/cafeFlow/web/shared/ws-manager-stock-adjustment.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "ws-manager-stock-adjustment.section.stockAdjustment.title": "Controle e Ajuste de Estoque",
    "ws-manager-stock-adjustment.organism.queryStockLevels.title": "Consultar níveis de estoque",
    "ws-manager-stock-adjustment.organism.adjustStockLevel.title": "Ajustar e repor estoque",
    "ws-manager-stock-adjustment.intention.queryStockLevels.title": "Níveis de estoque",
    "ws-manager-stock-adjustment.intention.adjustStockLevel.title": "Ajuste de estoque",
    "ws-manager-stock-adjustment.intention.review.title": "Resumo do ajuste",
    "ws-manager-stock-adjustment.field.stockItemId.label": "Item de estoque",
    "ws-manager-stock-adjustment.field.stockItemId.filterLabel": "Filtrar por item de estoque",
    "ws-manager-stock-adjustment.field.currentQuantity.label": "Quantidade atual",
    "ws-manager-stock-adjustment.field.lastMovementAt.label": "Última movimentação",
    "ws-manager-stock-adjustment.field.lastMovementAt.filterLabel": "Filtrar por última movimentação",
    "ws-manager-stock-adjustment.action.queryStockLevels.label": "Consultar níveis",
    "ws-manager-stock-adjustment.action.adjustStockLevel.label": "Salvar ajuste"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowWsManagerStockAdjustmentBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.queryStockLevelsState = 'idle';
        this.queryStockLevelsStockItemId = '';
        this.queryStockLevelsLastMovementAt = '';
        this.queryStockLevelsData = [];
        this.adjustStockLevelState = 'idle';
        this.adjustStockLevelCurrentQuantity = '';
        this.adjustStockLevelLastMovementAt = '';
        this._stateKeys = [
            'ui.ws-manager-stock-adjustment.status',
            'ui.ws-manager-stock-adjustment.action.queryStockLevels.status',
            'ui.ws-manager-stock-adjustment.input.queryStockLevels.stockItemId',
            'ui.ws-manager-stock-adjustment.input.queryStockLevels.lastMovementAt',
            'ui.ws-manager-stock-adjustment.data.queryStockLevels',
            'ui.ws-manager-stock-adjustment.action.adjustStockLevel.status',
            'ui.ws-manager-stock-adjustment.input.adjustStockLevel.currentQuantity',
            'ui.ws-manager-stock-adjustment.input.adjustStockLevel.lastMovementAt',
        ];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initializeStateFromStore();
        subscribe(this._stateKeys, this);
        void this.loadQueryStockLevels();
    }
    disconnectedCallback() {
        unsubscribe(this._stateKeys, this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(stateKey, value) {
        switch (stateKey) {
            case 'ui.ws-manager-stock-adjustment.status':
                this.status = (value ?? '');
                break;
            case 'ui.ws-manager-stock-adjustment.action.queryStockLevels.status':
                this.queryStockLevelsState = (value ?? 'idle');
                break;
            case 'ui.ws-manager-stock-adjustment.input.queryStockLevels.stockItemId':
                this.queryStockLevelsStockItemId = (value ?? '');
                break;
            case 'ui.ws-manager-stock-adjustment.input.queryStockLevels.lastMovementAt':
                this.queryStockLevelsLastMovementAt = (value ?? '');
                break;
            case 'ui.ws-manager-stock-adjustment.data.queryStockLevels':
                this.queryStockLevelsData = (value ?? []);
                break;
            case 'ui.ws-manager-stock-adjustment.action.adjustStockLevel.status':
                this.adjustStockLevelState = (value ?? 'idle');
                break;
            case 'ui.ws-manager-stock-adjustment.input.adjustStockLevel.currentQuantity':
                this.adjustStockLevelCurrentQuantity = (value ?? '');
                break;
            case 'ui.ws-manager-stock-adjustment.input.adjustStockLevel.lastMovementAt':
                this.adjustStockLevelLastMovementAt = (value ?? '');
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initializeStateFromStore() {
        this.initStateValue('ui.ws-manager-stock-adjustment.status', 'status', '');
        this.initStateValue('ui.ws-manager-stock-adjustment.action.queryStockLevels.status', 'queryStockLevelsState', 'idle');
        this.initStateValue('ui.ws-manager-stock-adjustment.input.queryStockLevels.stockItemId', 'queryStockLevelsStockItemId', '');
        this.initStateValue('ui.ws-manager-stock-adjustment.input.queryStockLevels.lastMovementAt', 'queryStockLevelsLastMovementAt', '');
        this.initStateValue('ui.ws-manager-stock-adjustment.data.queryStockLevels', 'queryStockLevelsData', []);
        this.initStateValue('ui.ws-manager-stock-adjustment.action.adjustStockLevel.status', 'adjustStockLevelState', 'idle');
        this.initStateValue('ui.ws-manager-stock-adjustment.input.adjustStockLevel.currentQuantity', 'adjustStockLevelCurrentQuantity', '');
        this.initStateValue('ui.ws-manager-stock-adjustment.input.adjustStockLevel.lastMovementAt', 'adjustStockLevelLastMovementAt', '');
    }
    initStateValue(stateKey, propertyName, fallback) {
        const storedValue = getState(stateKey);
        const nextValue = storedValue === undefined ? fallback : storedValue;
        this[propertyName] = nextValue;
        if (storedValue === undefined) {
            setState(stateKey, nextValue);
        }
    }
    setQueryStockLevelsStockItemId(value) {
        this.queryStockLevelsStockItemId = value;
        setState('ui.ws-manager-stock-adjustment.input.queryStockLevels.stockItemId', value);
        this.requestUpdate();
    }
    handleQueryStockLevelsStockItemIdChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setQueryStockLevelsStockItemId(value);
    }
    setQueryStockLevelsLastMovementAt(value) {
        this.queryStockLevelsLastMovementAt = value;
        setState('ui.ws-manager-stock-adjustment.input.queryStockLevels.lastMovementAt', value);
        this.requestUpdate();
    }
    handleQueryStockLevelsLastMovementAtChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setQueryStockLevelsLastMovementAt(value);
    }
    setAdjustStockLevelCurrentQuantity(value) {
        this.adjustStockLevelCurrentQuantity = value;
        setState('ui.ws-manager-stock-adjustment.input.adjustStockLevel.currentQuantity', value);
        this.requestUpdate();
    }
    handleAdjustStockLevelCurrentQuantityChange(event) {
        const target = event.target;
        const rawValue = target?.value ?? '';
        const value = rawValue === '' ? '' : Number(rawValue);
        this.setAdjustStockLevelCurrentQuantity(value);
    }
    setAdjustStockLevelLastMovementAt(value) {
        this.adjustStockLevelLastMovementAt = value;
        setState('ui.ws-manager-stock-adjustment.input.adjustStockLevel.lastMovementAt', value);
        this.requestUpdate();
    }
    handleAdjustStockLevelLastMovementAtChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setAdjustStockLevelLastMovementAt(value);
    }
    async loadQueryStockLevels(signal) {
        this.queryStockLevelsState = 'loading';
        setState('ui.ws-manager-stock-adjustment.action.queryStockLevels.status', 'loading');
        const params = {};
        if (this.queryStockLevelsStockItemId) {
            params.stockItemId = this.queryStockLevelsStockItemId;
        }
        if (this.queryStockLevelsLastMovementAt) {
            params.lastMovementAt = this.queryStockLevelsLastMovementAt;
        }
        const options = { mode: 'silent', signal };
        const response = await execBff('cafeFlow.queryStockLevels.queryStockLevels', params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.queryStockLevelsData = data;
            setState('ui.ws-manager-stock-adjustment.data.queryStockLevels', data);
            this.queryStockLevelsState = 'success';
            setState('ui.ws-manager-stock-adjustment.action.queryStockLevels.status', 'success');
            return;
        }
        this.queryStockLevelsData = [];
        setState('ui.ws-manager-stock-adjustment.data.queryStockLevels', []);
        this.queryStockLevelsState = 'error';
        setState('ui.ws-manager-stock-adjustment.action.queryStockLevels.status', 'error');
    }
    handleQueryStockLevelsClick(event) {
        const _event = event;
        void this.loadQueryStockLevels();
    }
    async adjustStockLevel(signal) {
        this.adjustStockLevelState = 'loading';
        setState('ui.ws-manager-stock-adjustment.action.adjustStockLevel.status', 'loading');
        const currentQuantityValue = typeof this.adjustStockLevelCurrentQuantity === 'number'
            ? this.adjustStockLevelCurrentQuantity
            : Number(this.adjustStockLevelCurrentQuantity || 0);
        const params = {
            currentQuantity: currentQuantityValue,
            lastMovementAt: this.adjustStockLevelLastMovementAt || '',
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('cafeFlow.adjustStockLevel.adjustStockLevel', params, options);
        if (response.ok) {
            this.adjustStockLevelState = 'success';
            setState('ui.ws-manager-stock-adjustment.action.adjustStockLevel.status', 'success');
            return;
        }
        this.adjustStockLevelState = 'error';
        setState('ui.ws-manager-stock-adjustment.action.adjustStockLevel.status', 'error');
        const message = response.error?.message ?? 'Erro ao ajustar estoque.';
        throw new Error(message);
    }
    handleAdjustStockLevelClick(event) {
        const _event = event;
        void runBlockingUiAction((signal) => this.adjustStockLevel(signal));
    }
}
__decorate([
    property()
], CafeFlowWsManagerStockAdjustmentBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowWsManagerStockAdjustmentBase.prototype, "queryStockLevelsState", void 0);
__decorate([
    property()
], CafeFlowWsManagerStockAdjustmentBase.prototype, "queryStockLevelsStockItemId", void 0);
__decorate([
    property()
], CafeFlowWsManagerStockAdjustmentBase.prototype, "queryStockLevelsLastMovementAt", void 0);
__decorate([
    property()
], CafeFlowWsManagerStockAdjustmentBase.prototype, "queryStockLevelsData", void 0);
__decorate([
    property()
], CafeFlowWsManagerStockAdjustmentBase.prototype, "adjustStockLevelState", void 0);
__decorate([
    property()
], CafeFlowWsManagerStockAdjustmentBase.prototype, "adjustStockLevelCurrentQuantity", void 0);
__decorate([
    property()
], CafeFlowWsManagerStockAdjustmentBase.prototype, "adjustStockLevelLastMovementAt", void 0);

/// <mls fileReference="_102049_/l4/operations/updateShift.defs.ts" enhancement="_blank"/>

export const operationUpdateShift = {
  "operationId": "updateShift",
  "title": "Editar turno de trabalho",
  "actor": "admin",
  "entity": "Shift",
  "kind": "update",
  "reads": [
    "Shift"
  ],
  "writes": [
    "Shift"
  ],
  "rulesApplied": [
    "businessHoursForScheduling",
    "operatorMultipleShiftsAllowed"
  ],
  "story": {
    "actor": "admin",
    "goal": "Editar um turno de trabalho existente ajustando nome, horários, dias da semana e status de ativação.",
    "steps": [
      "O administrador seleciona um turno existente na lista de turnos.",
      "O sistema carrega os dados atuais do turno para edição.",
      "O administrador modifica os campos desejados (nome, horário de início, horário de fim, dias da semana, ativo).",
      "O sistema valida que pelo menos um dia da semana está selecionado e que os horários estão no formato HH:mm.",
      "O sistema atualiza o turno e registra a data/hora da última atualização."
    ],
    "outcome": "O turno de trabalho é atualizado com os novos dados e permanece disponível para alocação de operadores e cálculo de capacidade de agendamento."
  },
  "accessPattern": {
    "kind": "commandInput",
    "entity": "Shift",
    "keyField": "Shift.shiftId",
    "pagination": "none",
    "selection": "single",
    "output": [
      "Shift.shiftId",
      "Shift.name",
      "Shift.startTime",
      "Shift.endTime",
      "Shift.monday",
      "Shift.tuesday",
      "Shift.wednesday",
      "Shift.thursday",
      "Shift.friday",
      "Shift.saturday",
      "Shift.sunday",
      "Shift.active"
    ]
  },
  "inputs": [
    {
      "inputId": "shiftId",
      "fieldRef": "Shift.shiftId",
      "required": true,
      "source": "selectedEntity",
      "description": "Identificador do turno selecionado para edição."
    },
    {
      "inputId": "name",
      "fieldRef": "Shift.name",
      "required": true,
      "source": "userInput",
      "description": "Nome do turno informado pelo administrador (ex.: Manhã, Tarde, Dia Inteiro)."
    },
    {
      "inputId": "startTime",
      "fieldRef": "Shift.startTime",
      "required": true,
      "source": "userInput",
      "description": "Horário de início do turno no formato HH:mm."
    },
    {
      "inputId": "endTime",
      "fieldRef": "Shift.endTime",
      "required": true,
      "source": "userInput",
      "description": "Horário de fim do turno no formato HH:mm."
    },
    {
      "inputId": "monday",
      "fieldRef": "Shift.monday",
      "required": true,
      "source": "userInput",
      "description": "Indica se o turno ocorre às segundas-feiras."
    },
    {
      "inputId": "tuesday",
      "fieldRef": "Shift.tuesday",
      "required": true,
      "source": "userInput",
      "description": "Indica se o turno ocorre às terças-feiras."
    },
    {
      "inputId": "wednesday",
      "fieldRef": "Shift.wednesday",
      "required": true,
      "source": "userInput",
      "description": "Indica se o turno ocorre às quartas-feiras."
    },
    {
      "inputId": "thursday",
      "fieldRef": "Shift.thursday",
      "required": true,
      "source": "userInput",
      "description": "Indica se o turno ocorre às quintas-feiras."
    },
    {
      "inputId": "friday",
      "fieldRef": "Shift.friday",
      "required": true,
      "source": "userInput",
      "description": "Indica se o turno ocorre às sextas-feiras."
    },
    {
      "inputId": "saturday",
      "fieldRef": "Shift.saturday",
      "required": true,
      "source": "userInput",
      "description": "Indica se o turno ocorre aos sábados."
    },
    {
      "inputId": "sunday",
      "fieldRef": "Shift.sunday",
      "required": true,
      "source": "userInput",
      "description": "Indica se o turno ocorre aos domingos."
    },
    {
      "inputId": "active",
      "fieldRef": "Shift.active",
      "required": true,
      "source": "userInput",
      "description": "Indica se o turno está ativo e disponível para alocação."
    },
    {
      "inputId": "updatedAt",
      "fieldRef": "Shift.updatedAt",
      "required": true,
      "source": "systemDefault",
      "description": "Data e hora da última atualização, gerada automaticamente pelo sistema."
    },
    {
      "inputId": "actorId",
      "fieldRef": "Shift.shiftId",
      "required": true,
      "source": "actorSession",
      "description": "Identificador do administrador autenticado que realiza a edição, para auditoria."
    }
  ],
  "contextResolution": [
    {
      "targetRef": "Shift.shiftId",
      "source": "selectedEntity",
      "originRef": "Shift.shiftId",
      "description": "O backend obtém o shiftId a partir do turno atualmente selecionado na tela de listagem de turnos."
    },
    {
      "targetRef": "Shift.updatedAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "O backend define updatedAt com o timestamp atual no momento da execução da atualização."
    },
    {
      "targetRef": "actorSession.actorId",
      "source": "actorSession",
      "originRef": "actorSession.actorId",
      "description": "O backend extrai o actorId da sessão autenticada do administrador para registro de auditoria."
    }
  ],
  "acceptanceAssertions": [
    "Após a confirmação, o turno existe com os campos name, startTime, endTime e dias da semana atualizados conforme os valores informados.",
    "Após a atualização, o campo updatedAt reflete a data e hora da última modificação.",
    "O turno atualizado permanece disponível para alocação de operadores e cálculo de capacidade de agendamento.",
    "Se o turno editado tiver horários fora do padrão 09:00 às 18:00, ele representa uma configuração diferente definida pelo administrador conforme a regra de horário de funcionamento.",
    "Turnos sobrepostos no mesmo dia continuam permitidos após a edição, conforme a regra de múltiplos turnos por operador."
  ],
  "pageId": "updateShift",
  "commandName": "updateShift",
  "bffName": "petShop.updateShift.updateShift",
  "capability": {
    "capabilityId": "updateShift",
    "title": "Editar turno de trabalho",
    "actor": "admin",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationUpdateShift;

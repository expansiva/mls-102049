/// <mls fileReference="_102049_/l4/operations/updateProduct.defs.ts" enhancement="_blank"/>

export const operationUpdateProduct = {
  "operationId": "updateProduct",
  "title": "Editar produto",
  "actor": "loja",
  "entity": "Product",
  "kind": "update",
  "reads": [
    "Product",
    "PetType",
    "Category"
  ],
  "writes": [
    "Product"
  ],
  "rulesApplied": [
    "highlightRequiresAvailableProduct",
    "productRequiresMinimumFields",
    "highlightsAreManualOnly"
  ],
  "story": {
    "actor": "loja",
    "goal": "Atualizar preço, descrição, destaque, disponibilidade ou outros dados de um produto já cadastrado no catálogo",
    "steps": [
      "A loja seleciona um produto existente no catálogo",
      "A loja modifica campos como nome, descrição, preço, tipo de pet, categoria, destaque ou disponibilidade",
      "O sistema valida que um produto só pode ser marcado como destaque se estiver disponível",
      "O sistema valida que os campos mínimos obrigatórios (nome, preço, tipo de pet e categoria) permaneçam preenchidos",
      "O sistema persiste as alterações e atualiza o campo updatedAt com a data e hora atuais"
    ],
    "outcome": "O produto é atualizado com os novos dados e permanece visível na vitrine conforme sua disponibilidade"
  },
  "accessPattern": {
    "kind": "commandInput",
    "entity": "Product",
    "keyField": "Product.productId",
    "pagination": "none",
    "selection": "single",
    "output": [
      "Product.productId",
      "Product.name",
      "Product.description",
      "Product.price",
      "Product.petTypeId",
      "Product.categoryId",
      "Product.highlighted",
      "Product.status",
      "Product.createdAt",
      "Product.updatedAt"
    ]
  },
  "outputShape": {
    "kind": "object",
    "fields": [
      {
        "name": "productId",
        "type": "string",
        "required": true,
        "fieldRef": "Product.productId"
      },
      {
        "name": "name",
        "type": "string",
        "required": true,
        "fieldRef": "Product.name"
      },
      {
        "name": "description",
        "type": "string",
        "required": false,
        "fieldRef": "Product.description"
      },
      {
        "name": "price",
        "type": "number",
        "required": true,
        "fieldRef": "Product.price"
      },
      {
        "name": "petTypeId",
        "type": "string",
        "required": true,
        "fieldRef": "Product.petTypeId"
      },
      {
        "name": "categoryId",
        "type": "string",
        "required": true,
        "fieldRef": "Product.categoryId"
      },
      {
        "name": "highlighted",
        "type": "boolean",
        "required": true,
        "fieldRef": "Product.highlighted"
      },
      {
        "name": "status",
        "type": "string",
        "required": true,
        "fieldRef": "Product.status"
      },
      {
        "name": "createdAt",
        "type": "string",
        "required": true,
        "fieldRef": "Product.createdAt"
      },
      {
        "name": "updatedAt",
        "type": "string",
        "required": true,
        "fieldRef": "Product.updatedAt"
      }
    ]
  },
  "inputs": [
    {
      "inputId": "productId",
      "fieldRef": "Product.productId",
      "required": true,
      "source": "selectedEntity",
      "description": "Identificador do produto que está sendo editado"
    },
    {
      "inputId": "name",
      "fieldRef": "Product.name",
      "required": false,
      "source": "userInput",
      "description": "Novo nome do produto, se alterado"
    },
    {
      "inputId": "description",
      "fieldRef": "Product.description",
      "required": false,
      "source": "userInput",
      "description": "Nova descrição do produto, se alterada"
    },
    {
      "inputId": "price",
      "fieldRef": "Product.price",
      "required": false,
      "source": "userInput",
      "description": "Novo preço do produto, se alterado"
    },
    {
      "inputId": "petTypeId",
      "fieldRef": "Product.petTypeId",
      "required": false,
      "source": "userInput",
      "description": "Novo tipo de pet indicado para o produto, se alterado"
    },
    {
      "inputId": "categoryId",
      "fieldRef": "Product.categoryId",
      "required": false,
      "source": "userInput",
      "description": "Nova categoria do produto, se alterada"
    },
    {
      "inputId": "highlighted",
      "fieldRef": "Product.highlighted",
      "required": false,
      "source": "userInput",
      "description": "Nova flag de destaque do produto, se alterada"
    },
    {
      "inputId": "status",
      "fieldRef": "Product.status",
      "required": false,
      "source": "userInput",
      "description": "Nova disponibilidade do produto (available ou unavailable), se alterada"
    }
  ],
  "contextResolution": [
    {
      "targetRef": "Product.productId",
      "source": "selectedEntity",
      "originRef": "Product.productId",
      "description": "O productId é obtido do produto atualmente selecionado pela loja na tela de edição do catálogo"
    },
    {
      "targetRef": "Product.updatedAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "O campo updatedAt é preenchido automaticamente com a data e hora atuais no momento da persistência da alteração"
    }
  ],
  "acceptanceAssertions": [
    "Após a atualização, o produto existe com os campos modificados refletindo os valores enviados pela loja",
    "Se highlighted for definido como true enquanto status for unavailable, a operação é rejeitada",
    "O campo updatedAt é atualizado para a data e hora atuais após a persistência",
    "Os campos productId e createdAt permanecem inalterados após a edição",
    "Se qualquer campo obrigatório mínimo (nome, preço, petTypeId ou categoryId) for fornecido, seu valor não pode ser vazio",
    "O produto atualizado aparece na vitrine pública apenas se seu status for available"
  ],
  "pageId": "updateProduct",
  "commandName": "updateProduct",
  "bffName": "petShop.updateProduct.updateProduct",
  "capability": {
    "capabilityId": "updateProduct",
    "title": "Editar produto",
    "actor": "loja",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationUpdateProduct;

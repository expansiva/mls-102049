/// <mls fileReference="_102049_/l2/petShop/web/contracts/productCatalog.test.ts" enhancement="_blank"/>
export {};

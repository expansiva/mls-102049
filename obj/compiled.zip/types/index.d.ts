declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/adjustStockLevel.defs" {
    export const adjustStockLevelController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "adjustStockLevel";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "adjustStockLevel";
            readonly controllerName: "AdjustStockLevelController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowAdjustStockLevelHandler";
                readonly command: "adjustStockLevel";
                readonly usecaseRef: "adjustStockLevel";
                readonly inputTypeName: "AdjustStockLevelInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "stockLevelId";
                    readonly fieldRef: "StockLevel.stockLevelId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador do nível de estoque selecionado para ajuste";
                }, {
                    readonly inputId: "movement";
                    readonly fieldRef: "StockMovementEvent";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Dados da movimentação de ajuste ou reposição (quantidade, motivo e tipo)";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "input.stockLevelId";
                    readonly source: "selectedEntity";
                    readonly originRef: "StockLevel.stockLevelId";
                    readonly description: "Identificador do nível de estoque obtido da entidade selecionada na jornada";
                }, {
                    readonly targetRef: "StockLevel.lastMovementAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Timestamp da última movimentação definido automaticamente pelo sistema";
                }, {
                    readonly targetRef: "StockLevel.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Timestamp da última atualização definido automaticamente pelo sistema";
                }, {
                    readonly targetRef: "StockMovementEvent.stockItemId";
                    readonly source: "selectedEntity";
                    readonly originRef: "StockLevel.stockItemId";
                    readonly description: "Item de estoque referenciado obtido do nível de estoque selecionado";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Comando para ajustar ou repor a quantidade de um nível de estoque específico, registrando a movimentação correspondente";
                    readonly entity: "StockLevel";
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.adjustStockLevel.adjustStockLevel";
                readonly handlerName: "cafeFlowAdjustStockLevelHandler";
            }];
        };
    };
    export default adjustStockLevelController;
    export const pipeline: readonly [{
        readonly id: "adjustStockLevel__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/adjustStockLevel.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/adjustStockLevel.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/adjustStockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_3_domain/entities/stockLevel" {
    export interface StockLevel {
        stockLevelId: string;
        stockItemId: string;
        currentQuantity: number;
        lastMovementAt: string;
        createdAt: string;
        updatedAt: string;
    }
    export function stockLevelQuantityIsNonNegative(stockLevel: Pick<StockLevel, 'currentQuantity'>): boolean;
    export function stockLevelLastMovementAfterCreation(stockLevel: Pick<StockLevel, 'lastMovementAt' | 'createdAt'>): boolean;
    export function validateStockLevelInvariants(stockLevel: StockLevel): string[];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository" {
    import type { StockLevel } from "_102049_/l1/cafeFlow/layer_3_domain/entities/stockLevel";
    /** Branded alias for the stock level identifier (string). */
    export type StockLevelId = string;
    /** Branded alias for a product identifier (string). */
    export type ProductId = string;
    /** Branded alias for a quantity value (non-negative number). */
    export type Quantity = number;
    /** Filter for querying stock levels — only indexed/queryable fields. */
    export interface StockLevelFilter {
        stockLevelId?: StockLevelId;
        stockItemId?: ProductId;
    }
    export interface IStockLevelRepository {
        /** Retrieve a stock level by its unique identifier. Throws NOT_FOUND when absent. */
        getById(id: StockLevelId): Promise<StockLevel>;
        /** List stock levels matching the given filter. */
        list(filter?: StockLevelFilter): Promise<StockLevel[]>;
        /** Persist the given stock level aggregate (upsert). */
        save(stockLevel: StockLevel): Promise<void>;
        /** Domain finder: retrieve stock level for a product. Throws NOT_FOUND when absent. */
        findByProductId(productId: ProductId): Promise<StockLevel>;
        /** Domain finder: retrieve stock levels whose current quantity is below the given threshold. */
        findBelowThreshold(threshold: Quantity): Promise<StockLevel[]>;
    }
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/adjustStockLevel" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface AdjustStockLevelInput {
        stockLevelId: string;
        movementType: string;
        quantity: number;
        reason: string;
    }
    export interface AdjustStockLevelOutput {
        stockLevelId: string;
        stockItemId: string;
        currentQuantity: number;
        lowStockAlert: boolean;
        stockMovementEventId: string;
    }
    export function adjustStockLevel(ctx: RequestContext, input: AdjustStockLevelInput): Promise<AdjustStockLevelOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/adjustStockLevel" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowAdjustStockLevelHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeShift.defs" {
    export const closeShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "closeShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "dailyShiftLifecycle";
            readonly controllerName: "CloseShiftController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCloseShiftHandler";
                readonly command: "closeShift";
                readonly usecaseRef: "closeShift";
                readonly inputTypeName: "CloseShiftInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Shift.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Identificador único do turno ativo a ser fechado";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "input.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "O identificador do turno é resolvido a partir da instância ativa do ciclo de vida de turno";
                }, {
                    readonly targetRef: "Shift.closedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "A data/hora de fechamento é definida automaticamente pelo sistema no momento da execução";
                }, {
                    readonly targetRef: "Shift.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "A data/hora da última atualização é definida automaticamente pelo sistema no momento da execução";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Comando para fechar o turno diário ativo, atualizando seu status para fechado, registrando a data/hora de fechamento e gerando o evento de status correspondente";
                    readonly entity: "Shift";
                    readonly selection: "single";
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.dailyShiftLifecycle.closeShift";
                readonly handlerName: "cafeFlowCloseShiftHandler";
            }];
        };
    };
    export default closeShiftController;
    export const pipeline: readonly [{
        readonly id: "closeShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeShift.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeShift.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/closeShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_3_domain/entities/shift" {
    export type ShiftStatus = 'open' | 'closed';
    export interface Shift {
        shiftId: string;
        status: ShiftStatus;
        openedAt: string;
        closedAt: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export const SHIFT_STATUS_TRANSITIONS: Record<ShiftStatus, ShiftStatus[]>;
    export function canTransitionShift(from: ShiftStatus, to: ShiftStatus): boolean;
    /** If status is closed then closedAt must be non-null. */
    export function shiftClosedRequiresClosedAt(shift: Pick<Shift, 'status' | 'closedAt'>): boolean;
    /** If status is open then closedAt must be null. */
    export function shiftOpenRequiresNullClosedAt(shift: Pick<Shift, 'status' | 'closedAt'>): boolean;
    /** closedAt must be after openedAt when present. */
    export function shiftClosedAtAfterOpenedAt(shift: Pick<Shift, 'openedAt' | 'closedAt'>): boolean;
    /** Only one Shift may be open at any given time. */
    export function hasSingleOpenShift(shifts: Pick<Shift, 'status'>[]): boolean;
    /** Validates all invariants for a single shift record. */
    export function validateShiftInvariants(shift: Pick<Shift, 'status' | 'openedAt' | 'closedAt'>): boolean;
}
declare module "_102049_/l1/cafeFlow/layer_2_application/ports/shiftRepository" {
    import type { Shift, ShiftStatus } from "_102049_/l1/cafeFlow/layer_3_domain/entities/shift";
    export type ShiftId = string;
    export type EmployeeId = string;
    export interface DateRange {
        from: string;
        to: string;
    }
    export interface ShiftFilter {
        status?: ShiftStatus;
        openedFrom?: string;
        openedTo?: string;
    }
    export interface IShiftRepository {
        /** Retrieve a shift by its unique identifier. Throws NOT_FOUND when absent. */
        getById(id: ShiftId): Promise<Shift>;
        /** List shifts matching the given filter. */
        list(filter?: ShiftFilter): Promise<Shift[]>;
        /** Persist the given shift aggregate (upsert). */
        save(shift: Shift): Promise<void>;
        /** Domain finder: retrieve shifts for an employee. */
        findByEmployeeId(employeeId: EmployeeId): Promise<Shift[]>;
        /** Domain finder: retrieve shifts within a period. */
        findByPeriod(period: DateRange): Promise<Shift[]>;
    }
}
declare module "_102049_/l1/cafeFlow/layer_3_domain/entities/order" {
    export type OrderType = 'dineIn' | 'takeout';
    export type OrderStatus = 'pending' | 'inKitchen' | 'preparing' | 'ready' | 'delivered' | 'cancelled';
    export interface Order {
        id: string;
        orderType: OrderType;
        tableId: string | null;
        shiftId: string;
        status: OrderStatus;
        total: number;
        createdAt: string;
        updatedAt: string;
    }
    /**
     * Valid status transitions for an Order.
     * pending → inKitchen → preparing → ready → delivered
     * cancelled can be reached from any non-delivered, non-cancelled state.
     */
    export const ORDER_STATUS_TRANSITIONS: Record<OrderStatus, OrderStatus[]>;
    /** Returns true when the transition from `from` to `to` is allowed. */
    export function canTransitionOrder(from: OrderStatus, to: OrderStatus): boolean;
    /**
     * Invariant: If orderType is dineIn then tableId must be non-null.
     * If orderType is takeout then tableId must be null.
     */
    export function validateOrderTableAssignment(order: Pick<Order, 'orderType' | 'tableId'>): boolean;
    /** Invariant: total must be greater than or equal to zero. */
    export function validateOrderTotal(order: Pick<Order, 'total'>): boolean;
    /**
     * Invariant: shiftId must reference an open Shift at the time of order creation.
     * This is a cross-entity invariant — the pure domain entity cannot verify the Shift state,
     * so this helper only checks that a shiftId is present. The application layer must
     * additionally confirm the Shift is open.
     */
    export function validateOrderShiftReference(order: Pick<Order, 'shiftId'>): boolean;
    /** Runs all pure invariants for the Order aggregate and returns the first violation message, or null. */
    export function validateOrderInvariants(order: Pick<Order, 'orderType' | 'tableId' | 'total' | 'shiftId'>): string | null;
}
declare module "_102049_/l1/cafeFlow/layer_2_application/ports/orderRepository" {
    import type { Order, OrderStatus, OrderType } from "_102049_/l1/cafeFlow/layer_3_domain/entities/order";
    /** Branded alias for the Order aggregate identifier. */
    export type OrderId = string;
    /** Branded alias for a Customer identifier (indexed FK on the order table). */
    export type CustomerId = string;
    /** Filter for listing orders — carries only indexed / queryable fields. */
    export interface OrderFilter {
        shiftId?: string;
        status?: OrderStatus;
        tableId?: string | null;
        orderType?: OrderType;
        customerId?: string;
    }
    export interface IOrderRepository {
        /** Retrieve an order by its unique identifier; throws NOT_FOUND when absent. */
        getById(id: OrderId): Promise<Order>;
        /** List orders matching the given filter. */
        list(filter?: OrderFilter): Promise<Order[]>;
        /** Persist the given order aggregate (upsert root + embedded members). */
        save(order: Order): Promise<void>;
        /** Domain finder: retrieve orders by customer. */
        findByCustomerId(customerId: CustomerId): Promise<Order[]>;
        /** Domain finder: retrieve orders by status. */
        findByStatus(status: OrderStatus): Promise<Order[]>;
    }
}
declare module "_102049_/l1/cafeFlow/layer_3_domain/entities/shiftStatusEvent" {
    export type ShiftStatusEventType = 'abertura' | 'fechamento';
    export interface ShiftStatusEvent {
        shiftStatusEventId: string;
        shiftId: string;
        eventType: ShiftStatusEventType;
        consolidatedTotal: number;
        recordedAt: string;
        createdAt: string;
        updatedAt: string;
    }
}
declare module "_102049_/l1/cafeFlow/layer_2_application/ports/shiftStatusEventRepository" {
    import type { ShiftStatusEvent } from "_102049_/l1/cafeFlow/layer_3_domain/entities/shiftStatusEvent";
    export interface DateRange {
        from: string;
        to: string;
    }
    export interface IShiftStatusEventRepository {
        /** Append a shift status event (immutable — no update or delete). */
        append(event: ShiftStatusEvent): Promise<void>;
        /** Read finder: list events by shift. */
        listByOwnerId(ownerId: string): Promise<ShiftStatusEvent[]>;
        /** Read finder: list events within a period. */
        listByPeriod(period: DateRange): Promise<ShiftStatusEvent[]>;
    }
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/closeShift" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CloseShiftInput {
        shiftId: string;
    }
    export interface CloseShiftOutput {
        shiftId: string;
        status: string;
        closedAt: string;
    }
    export function closeShift(ctx: RequestContext, input: CloseShiftInput): Promise<CloseShiftOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeShift" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowCloseShiftHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createComboRule.defs" {
    export const createComboRuleController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createComboRule";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createComboRule";
            readonly controllerName: "CreateComboRuleController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateComboRuleHandler";
                readonly command: "createComboRule";
                readonly usecaseRef: "createComboRule";
                readonly inputTypeName: "CreateComboRuleInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "menuItemId";
                    readonly fieldRef: "ComboRule.menuItemId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Item do cardápio ao qual a regra se aplica";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "ComboRule.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome descritivo da regra";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "ComboRule.description";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Detalhamento da regra e condições de aplicação";
                }, {
                    readonly inputId: "priceDifference";
                    readonly fieldRef: "ComboRule.priceDifference";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Diferença de preço aplicada no combo ou substituição";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "ComboRule.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Situação da regra no ciclo de vida (active/inactive)";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "ComboRule.comboRuleId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "Identificador único gerado automaticamente para a regra";
                }, {
                    readonly targetRef: "ComboRule.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Data e hora de criação atribuída pelo sistema";
                }, {
                    readonly targetRef: "ComboRule.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Data e hora da última atualização atribuída pelo sistema";
                }, {
                    readonly targetRef: "input.menuItemId";
                    readonly source: "selectedEntity";
                    readonly originRef: "MenuItem.menuItemId";
                    readonly description: "Identificador do item do cardápio selecionado na jornada";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Criação de uma nova regra de combo/substituição vinculada a um item do cardápio";
                    readonly entity: "ComboRule";
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createComboRule.createComboRule";
                readonly handlerName: "cafeFlowCreateComboRuleHandler";
            }];
        };
    };
    export default createComboRuleController;
    export const pipeline: readonly [{
        readonly id: "createComboRule__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createComboRule.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createComboRule.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/createComboRule.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/createComboRule" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateComboRuleInput {
        menuItemId: string;
        name: string;
        description?: string;
        priceDifference: number;
        status: string;
    }
    export interface CreateComboRuleOutput {
        comboRuleId: string;
        status: string;
    }
    export function createComboRule(ctx: RequestContext, input: CreateComboRuleInput): Promise<CreateComboRuleOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createComboRule" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowCreateComboRuleHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createMenuItem.defs" {
    export const createMenuItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createMenuItem";
            readonly controllerName: "CreateMenuItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateMenuItemHandler";
                readonly command: "createMenuItem";
                readonly usecaseRef: "createMenuItem";
                readonly inputTypeName: "CreateMenuItemInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "name";
                    readonly fieldRef: "MenuItem.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do item do cardápio";
                }, {
                    readonly inputId: "category";
                    readonly fieldRef: "MenuItem.category";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Categoria do item (ex: entradas, pratos principais, bebidas, sobremesas)";
                }, {
                    readonly inputId: "price";
                    readonly fieldRef: "MenuItem.price";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Preço de venda do item";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "MenuItem.description";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Descrição detalhada do item";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "MenuItem.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Status do ciclo de vida do item (active/inactive)";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "MenuItem.menuItemId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "Identificador único do item gerado automaticamente pelo sistema";
                }, {
                    readonly targetRef: "MenuItem.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Data e hora de criação atribuída automaticamente pelo sistema";
                }, {
                    readonly targetRef: "MenuItem.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Data e hora da última atualização atribuída automaticamente pelo sistema";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Command to create a new menu item reference with name, category, price, description and lifecycle status";
                    readonly entity: "MenuItem";
                    readonly pagination: "none";
                    readonly selection: "none";
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createMenuItem.createMenuItem";
                readonly handlerName: "cafeFlowCreateMenuItemHandler";
            }];
        };
    };
    export default createMenuItemController;
    export const pipeline: readonly [{
        readonly id: "createMenuItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createMenuItem.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/createMenuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/createMenuItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateMenuItemInput {
        name: string;
        category: string;
        price: number;
        description?: string;
        status: string;
    }
    export interface CreateMenuItemOutput {
        menuItemId: string;
        name: string;
        category: string;
        price: number;
        status: string;
        createdAt: string;
        updatedAt: string;
    }
    export function createMenuItem(ctx: RequestContext, input: CreateMenuItemInput): Promise<CreateMenuItemOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createMenuItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowCreateMenuItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.defs" {
    export const createOrderController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "CreateOrderController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateOrderHandler";
                readonly command: "createOrder";
                readonly usecaseRef: "createOrder";
                readonly inputTypeName: "CreateOrderInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "orderType";
                    readonly fieldRef: "Order.orderType";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Modalidade do pedido: dine-in (mesa) ou takeout";
                }, {
                    readonly inputId: "tableId";
                    readonly fieldRef: "Order.tableId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Mesa selecionada para pedidos dine-in; omitido para takeout";
                }, {
                    readonly inputId: "items";
                    readonly fieldRef: "OrderItem";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Lista de itens do cardápio que compõem o pedido, com quantidade e substituições aplicadas";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.shiftId";
                    readonly source: "currentWorkspace";
                    readonly originRef: "currentWorkspace.workspaceId";
                    readonly description: "Sistema vincula o pedido ao turno aberto do workspace atual";
                }, {
                    readonly targetRef: "Order.id";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "Identificador único do pedido gerado pelo sistema";
                }, {
                    readonly targetRef: "Order.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Data e hora de criação atribuída automaticamente";
                }, {
                    readonly targetRef: "Order.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Data e hora da última atualização atribuída automaticamente";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Criação de pedido no POS com itens compostos e vinculação automática ao turno aberto";
                    readonly entity: "Order";
                    readonly pagination: "none";
                    readonly selection: "none";
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.createOrder";
                readonly handlerName: "cafeFlowCreateOrderHandler";
            }];
        };
    };
    export default createOrderController;
    export const pipeline: readonly [{
        readonly id: "createOrder__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/createOrder.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_3_domain/entities/orderItem" {
    export type OrderItemStatus = 'pending' | 'preparing' | 'ready' | 'delivered';
    export interface OrderItem {
        orderItemId: string;
        orderId: string;
        menuItemId: string;
        quantity: number;
        unitPrice: number;
        itemTotal: number;
        substitutionsApplied: string | null;
        status: OrderItemStatus;
        createdAt: string;
        updatedAt: string;
    }
    export const ORDER_ITEM_STATUS_TRANSITIONS: Record<OrderItemStatus, OrderItemStatus[]>;
    export function canTransitionOrderItemStatus(from: OrderItemStatus, to: OrderItemStatus): boolean;
    export function orderItemQuantityIsValid(quantity: number): boolean;
    export function orderItemUnitPriceIsValid(unitPrice: number): boolean;
    export function orderItemTotalIsConsistent(quantity: number, unitPrice: number, itemTotal: number): boolean;
    export function validateOrderItem(item: Pick<OrderItem, 'quantity' | 'unitPrice' | 'itemTotal'>): boolean;
    export function computeOrderItemTotal(quantity: number, unitPrice: number): number;
}
declare module "_102049_/l1/cafeFlow/layer_2_application/ports/orderItemRepository" {
    import type { OrderItem, OrderItemStatus } from "_102049_/l1/cafeFlow/layer_3_domain/entities/orderItem";
    export interface OrderItemFilter {
        orderId?: string;
        menuItemId?: string;
        status?: OrderItemStatus;
    }
    export interface IOrderItemRepository {
        /** Retrieve an order item by its unique identifier. Throws NOT_FOUND when absent. */
        getById(id: string): Promise<OrderItem>;
        /** List order items matching the given filter. */
        list(filter?: OrderItemFilter): Promise<OrderItem[]>;
        /** Persist the given order item aggregate (upsert). */
        save(orderItem: OrderItem): Promise<void>;
        /** Domain finder: retrieve items belonging to an order. */
        findByOrderId(orderId: string): Promise<OrderItem[]>;
    }
}
declare module "_102049_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent" {
    export type OrderStatusEventStatus = 'criado' | 'em preparo' | 'pronto' | 'entregue' | 'cancelado';
    export interface OrderStatusEvent {
        orderStatusEventId: string;
        orderId: string;
        status: OrderStatusEventStatus;
        previousStatus: OrderStatusEventStatus | null;
        createdAt: string;
        updatedAt: string;
    }
}
declare module "_102049_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository" {
    import type { OrderStatusEvent } from "_102049_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent";
    export interface DateRange {
        from: string;
        to: string;
    }
    export interface IOrderStatusEventRepository {
        /** Append an order status event (immutable — no update or delete). */
        append(event: OrderStatusEvent): Promise<void>;
        /** Read finder: list events by order. */
        listByOwnerId(ownerId: string): Promise<OrderStatusEvent[]>;
        /** Read finder: list events within a period. */
        listByPeriod(period: DateRange): Promise<OrderStatusEvent[]>;
    }
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/createOrder" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface OrderItemInput {
        menuItemId: string;
        quantity: number;
        substitutionsApplied?: string;
    }
    export interface CreateOrderInput {
        orderType: string;
        tableId?: string;
        items: OrderItemInput[];
    }
    export interface CreateOrderOutput {
        orderId: string;
        status: string;
        total: number;
    }
    export function createOrder(ctx: RequestContext, input: CreateOrderInput): Promise<CreateOrderOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowCreateOrderHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockItem.defs" {
    export const createStockItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createStockItem";
            readonly controllerName: "CreateStockItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateStockItemHandler";
                readonly command: "createStockItem";
                readonly usecaseRef: "createStockItem";
                readonly inputTypeName: "CreateStockItemInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "name";
                    readonly fieldRef: "StockItem.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do insumo";
                }, {
                    readonly inputId: "unitOfMeasure";
                    readonly fieldRef: "StockItem.unitOfMeasure";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Unidade de medida do insumo (ex: kg, unidade, litro)";
                }, {
                    readonly inputId: "minimumQuantity";
                    readonly fieldRef: "StockItem.minimumQuantity";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Quantidade mínima para alerta de estoque baixo";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "StockItem.stockItemId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "Identificador único gerado automaticamente pelo sistema";
                }, {
                    readonly targetRef: "StockItem.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly targetRef: "StockItem.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Criação de um novo item de estoque (insumo) com nome, unidade de medida e quantidade mínima";
                    readonly entity: "StockItem";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["StockItem.stockItemId", "StockItem.name", "StockItem.unitOfMeasure", "StockItem.minimumQuantity", "StockItem.status"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createStockItem.createStockItem";
                readonly handlerName: "cafeFlowCreateStockItemHandler";
            }];
        };
    };
    export default createStockItemController;
    export const pipeline: readonly [{
        readonly id: "createStockItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockItem.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockItem.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/createStockItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/createStockItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateStockItemInput {
        name: string;
        unitOfMeasure: string;
        minimumQuantity: number;
    }
    export interface CreateStockItemOutput {
        stockItemId: string;
        name: string;
        unitOfMeasure: string;
        minimumQuantity: number;
        status: string;
    }
    export function createStockItem(ctx: RequestContext, input: CreateStockItemInput): Promise<CreateStockItemOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowCreateStockItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockMovement.defs" {
    export const createStockMovementController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createStockMovement";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "CreateStockMovementController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateStockMovementHandler";
                readonly command: "createStockMovement";
                readonly usecaseRef: "createStockMovement";
                readonly inputTypeName: "CreateStockMovementInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "stockItemId";
                    readonly fieldRef: "StockMovementEvent.stockItemId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Item de estoque (insumo) selecionado para baixa";
                }, {
                    readonly inputId: "quantity";
                    readonly fieldRef: "StockMovementEvent.quantity";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Quantidade consumida do insumo";
                }, {
                    readonly inputId: "reason";
                    readonly fieldRef: "StockMovementEvent.reason";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Motivo da movimentação de estoque";
                }, {
                    readonly inputId: "movementType";
                    readonly fieldRef: "StockMovementEvent.movementType";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Tipo da movimentação (baixa ou reposição)";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "input.stockItemId";
                    readonly source: "selectedEntity";
                    readonly originRef: "StockItem.stockItemId";
                    readonly description: "Identificador do item de estoque selecionado na interface pelo cook";
                }, {
                    readonly targetRef: "StockMovementEvent.stockMovementEventId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "UUID gerado automaticamente pelo sistema para o evento";
                }, {
                    readonly targetRef: "StockMovementEvent.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Data/hora de criação atribuída automaticamente";
                }, {
                    readonly targetRef: "StockMovementEvent.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Data/hora de atualização atribuída automaticamente";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Comando para registrar um evento de baixa de estoque de um insumo consumido durante o preparo";
                    readonly entity: "StockMovementEvent";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["StockMovementEvent"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.createStockMovement";
                readonly handlerName: "cafeFlowCreateStockMovementHandler";
            }];
        };
    };
    export default createStockMovementController;
    export const pipeline: readonly [{
        readonly id: "createStockMovement__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockMovement.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockMovement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/createStockMovement.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/createStockMovement" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateStockMovementInput {
        stockItemId: string;
        quantity: number;
        reason: string;
        movementType: string;
    }
    export interface CreateStockMovementOutput {
        stockMovementEventId: string;
        stockItemId: string;
        movementType: string;
        quantity: number;
        reason: string;
        createdAt: string;
        updatedAt: string;
        currentQuantity: number;
    }
    export function createStockMovement(ctx: RequestContext, input: CreateStockMovementInput): Promise<CreateStockMovementOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createStockMovement" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowCreateStockMovementHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createTable.defs" {
    export const createTableController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createTable";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createTable";
            readonly controllerName: "CreateTableController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateTableHandler";
                readonly command: "createTable";
                readonly usecaseRef: "createTable";
                readonly inputTypeName: "CreateTableInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "number";
                    readonly fieldRef: "Table.number";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Número ou código de identificação visual da mesa (ex: 01, 12, A3)";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "Table.name";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Nome ou descrição opcional da mesa (ex: 'Mesa da Janela')";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Table.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Situação da mesa no sistema (active ou inactive)";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Table.tableId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "Identificador único da mesa gerado pelo sistema";
                }, {
                    readonly targetRef: "Table.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Data e hora de criação do registro definida pelo sistema";
                }, {
                    readonly targetRef: "Table.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Data e hora da última atualização do registro definida pelo sistema";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Comando para cadastrar uma nova mesa no sistema";
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.createTable.createTable";
                readonly handlerName: "cafeFlowCreateTableHandler";
            }];
        };
    };
    export default createTableController;
    export const pipeline: readonly [{
        readonly id: "createTable__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createTable.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createTable.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/createTable.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/createTable" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateTableInput {
        number: string;
        name?: string;
        status: string;
    }
    export interface CreateTableOutput {
        tableId: string;
        number: string;
        name: string | null;
        status: string;
        createdAt: string;
        updatedAt: string;
    }
    export function createTable(ctx: RequestContext, input: CreateTableInput): Promise<CreateTableOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createTable" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowCreateTableHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteComboRule.defs" {
    export const deleteComboRuleController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "deleteComboRule";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "deleteComboRule";
            readonly controllerName: "DeleteComboRuleController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowDeleteComboRuleHandler";
                readonly command: "deleteComboRule";
                readonly usecaseRef: "deleteComboRule";
                readonly inputTypeName: "DeleteComboRuleInput";
                readonly kind: "delete";
                readonly inputContract: readonly [{
                    readonly inputId: "comboRuleId";
                    readonly fieldRef: "ComboRule.comboRuleId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador único da regra de combo selecionada para exclusão";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "input.comboRuleId";
                    readonly source: "selectedEntity";
                    readonly originRef: "ComboRule.comboRuleId";
                    readonly description: "Resolve o identificador da regra de combo a partir da entidade selecionada no fluxo";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Exclusão de uma regra de combo previamente selecionada";
                    readonly entity: "ComboRule";
                    readonly pagination: "none";
                    readonly selection: "single";
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.deleteComboRule.deleteComboRule";
                readonly handlerName: "cafeFlowDeleteComboRuleHandler";
            }];
        };
    };
    export default deleteComboRuleController;
    export const pipeline: readonly [{
        readonly id: "deleteComboRule__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteComboRule.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteComboRule.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/deleteComboRule.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/deleteComboRule" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface DeleteComboRuleInput {
        comboRuleId: string;
    }
    export interface DeleteComboRuleOutput {
        comboRuleId: string;
        status: string;
    }
    export function deleteComboRule(ctx: RequestContext, input: DeleteComboRuleInput): Promise<DeleteComboRuleOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteComboRule" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowDeleteComboRuleHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteMenuItem.defs" {
    export const deleteMenuItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "deleteMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "deleteMenuItem";
            readonly controllerName: "DeleteMenuItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowDeleteMenuItemHandler";
                readonly command: "deleteMenuItem";
                readonly usecaseRef: "deleteMenuItem";
                readonly inputTypeName: "DeleteMenuItemInput";
                readonly kind: "delete";
                readonly inputContract: readonly [{
                    readonly inputId: "menuItemId";
                    readonly fieldRef: "MenuItem.menuItemId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador único do item do cardápio a ser removido";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "input.menuItemId";
                    readonly source: "selectedEntity";
                    readonly originRef: "MenuItem.menuItemId";
                    readonly description: "Id do item selecionado na lista para remoção";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Remove um item do cardápio previamente selecionado";
                    readonly entity: "MenuItem";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["MenuItem.menuItemId"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.deleteMenuItem.deleteMenuItem";
                readonly handlerName: "cafeFlowDeleteMenuItemHandler";
            }];
        };
    };
    export default deleteMenuItemController;
    export const pipeline: readonly [{
        readonly id: "deleteMenuItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteMenuItem.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/deleteMenuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/deleteMenuItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface DeleteMenuItemInput {
        menuItemId: string;
    }
    export interface DeleteMenuItemOutput {
        menuItemId: string;
        status: string;
    }
    export function deleteMenuItem(ctx: RequestContext, input: DeleteMenuItemInput): Promise<DeleteMenuItemOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteMenuItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowDeleteMenuItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteStockItem.defs" {
    export const deleteStockItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "deleteStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "deleteStockItem";
            readonly controllerName: "DeleteStockItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowDeleteStockItemHandler";
                readonly command: "deleteStockItem";
                readonly usecaseRef: "deleteStockItem";
                readonly inputTypeName: "DeleteStockItemInput";
                readonly kind: "delete";
                readonly inputContract: readonly [{
                    readonly inputId: "stockItemId";
                    readonly fieldRef: "StockItem.stockItemId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador único do item de estoque a ser removido";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "input.stockItemId";
                    readonly source: "selectedEntity";
                    readonly originRef: "StockItem.stockItemId";
                    readonly description: "O id do item de estoque é obtido da entidade selecionada na jornada de localização";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Exclui um item de estoque previamente selecionado do cadastro";
                    readonly entity: "StockItem";
                    readonly selection: "none";
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.deleteStockItem.deleteStockItem";
                readonly handlerName: "cafeFlowDeleteStockItemHandler";
            }];
        };
    };
    export default deleteStockItemController;
    export const pipeline: readonly [{
        readonly id: "deleteStockItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteStockItem.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteStockItem.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/deleteStockItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/deleteStockItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface DeleteStockItemInput {
        stockItemId: string;
    }
    export interface DeleteStockItemOutput {
        stockItemId: string;
        status: string;
    }
    export function deleteStockItem(ctx: RequestContext, input: DeleteStockItemInput): Promise<DeleteStockItemOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteStockItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowDeleteStockItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteTable.defs" {
    export const deleteTableController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "deleteTable";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "deleteTable";
            readonly controllerName: "DeleteTableController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowDeleteTableHandler";
                readonly command: "deleteTable";
                readonly usecaseRef: "deleteTable";
                readonly inputTypeName: "DeleteTableInput";
                readonly kind: "delete";
                readonly inputContract: readonly [{
                    readonly inputId: "tableId";
                    readonly fieldRef: "Table.tableId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador único da mesa a ser removida";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "input.tableId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Table.tableId";
                    readonly description: "Identificador da mesa obtido da seleção prévia no fluxo";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Comando de exclusão de uma mesa previamente selecionada no fluxo";
                    readonly entity: "Table";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Table.tableId"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.deleteTable.deleteTable";
                readonly handlerName: "cafeFlowDeleteTableHandler";
            }];
        };
    };
    export default deleteTableController;
    export const pipeline: readonly [{
        readonly id: "deleteTable__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteTable.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteTable.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/deleteTable.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/deleteTable" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface DeleteTableInput {
        tableId: string;
    }
    export interface DeleteTableOutput {
        tableId: string;
        status: string;
    }
    export function deleteTable(ctx: RequestContext, input: DeleteTableInput): Promise<DeleteTableOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deleteTable" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowDeleteTableHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftClosingReport.defs" {
    export const generateShiftClosingReportController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "generateShiftClosingReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "dailyShiftLifecycle";
            readonly controllerName: "GenerateShiftClosingReportController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowGenerateShiftClosingReportHandler";
                readonly command: "generateShiftClosingReport";
                readonly usecaseRef: "generateShiftClosingReport";
                readonly inputTypeName: "GenerateShiftClosingReportInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Shift.shiftId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador do turno selecionado para geração do relatório de fechamento";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "input.shiftId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "Resolve o identificador do turno a partir da entidade selecionada no fluxo de trabalho";
                }];
                readonly accessPattern: {
                    readonly kind: "getById";
                    readonly description: "Recupera um turno fechado pelo identificador e agrega pedidos, faturamento e movimentações de estoque em um relatório consolidado de fechamento";
                    readonly entity: "Shift";
                    readonly keyField: "Shift.shiftId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["shiftSummary", "ordersAggregation", "revenueTotals", "stockMovements"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.dailyShiftLifecycle.generateShiftClosingReport";
                readonly handlerName: "cafeFlowGenerateShiftClosingReportHandler";
            }];
        };
    };
    export default generateShiftClosingReportController;
    export const pipeline: readonly [{
        readonly id: "generateShiftClosingReport__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftClosingReport.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftClosingReport.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/generateShiftClosingReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/generateShiftClosingReport" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface GenerateShiftClosingReportInput {
        shiftId: string;
    }
    export interface GenerateShiftClosingReportOutput {
        shiftId: string;
        status: string;
        openedAt: string;
        closedAt: string;
        totalOrders: number;
        dineInOrders: number;
        takeoutOrders: number;
        deliveredOrders: number;
        cancelledOrders: number;
        grossRevenue: number;
        netRevenue: number;
        totalOrderItems: number;
    }
    export function generateShiftClosingReport(ctx: RequestContext, input: GenerateShiftClosingReportInput): Promise<GenerateShiftClosingReportOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/generateShiftClosingReport" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowGenerateShiftClosingReportHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openShift.defs" {
    export const openShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "openShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "dailyShiftLifecycle";
            readonly controllerName: "OpenShiftController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowOpenShiftHandler";
                readonly command: "openShift";
                readonly usecaseRef: "openShift";
                readonly inputTypeName: "OpenShiftInput";
                readonly kind: "create";
                readonly inputContract: readonly [];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Shift.shiftId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "System generates UUID for the new shift";
                }, {
                    readonly targetRef: "Shift.status";
                    readonly source: "workflowState";
                    readonly originRef: "Shift.status";
                    readonly description: "Workflow state sets the shift status to open";
                }, {
                    readonly targetRef: "Shift.openedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Current timestamp for shift opening";
                }, {
                    readonly targetRef: "Shift.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Current timestamp for record creation";
                }, {
                    readonly targetRef: "Shift.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Current timestamp for record update";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Command to create and open a new daily shift";
                    readonly entity: "Shift";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["Shift.shiftId", "Shift.status", "Shift.openedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.dailyShiftLifecycle.openShift";
                readonly handlerName: "cafeFlowOpenShiftHandler";
            }];
        };
    };
    export default openShiftController;
    export const pipeline: readonly [{
        readonly id: "openShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openShift.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openShift.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/openShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/openShift" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface OpenShiftInput {
    }
    export interface OpenShiftOutput {
        shiftId: string;
        status: string;
        openedAt: string;
    }
    export function openShift(ctx: RequestContext, _input: OpenShiftInput): Promise<OpenShiftOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openShift" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowOpenShiftHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryComboRules.defs" {
    export const queryComboRulesController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "queryComboRules";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "queryComboRules";
            readonly controllerName: "QueryComboRulesController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowQueryComboRulesHandler";
                readonly command: "queryComboRules";
                readonly usecaseRef: "queryComboRules";
                readonly inputTypeName: "QueryComboRulesInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "status";
                    readonly fieldRef: "ComboRule.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional pela situação da regra (active ou inactive)";
                }, {
                    readonly inputId: "nameContains";
                    readonly fieldRef: "ComboRule.name";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Termo de busca opcional pelo nome da regra";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "filter.workspaceId";
                    readonly source: "currentWorkspace";
                    readonly originRef: "currentWorkspace.workspaceId";
                    readonly description: "Escopo da consulta restrito ao workspace atual do gerente";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "Lista navegável de regras de combo e substituição com filtro opcional por situação e busca por nome";
                    readonly entity: "ComboRule";
                    readonly filters: readonly ["status", "nameContains"];
                    readonly sort: readonly ["ComboRule.createdAt"];
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["ComboRule.comboRuleId", "ComboRule.name", "ComboRule.menuItemId", "ComboRule.description", "ComboRule.priceDifference", "ComboRule.status", "ComboRule.createdAt", "ComboRule.updatedAt", "MenuItem.name"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.queryComboRules.queryComboRules";
                readonly handlerName: "cafeFlowQueryComboRulesHandler";
            }];
        };
    };
    export default queryComboRulesController;
    export const pipeline: readonly [{
        readonly id: "queryComboRules__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryComboRules.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryComboRules.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/queryComboRules.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/queryComboRules" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface QueryComboRulesInput {
        /** Filtro opcional pela situação da regra (active ou inactive) */
        status?: string;
        /** Termo de busca opcional pelo nome da regra */
        nameContains?: string;
    }
    export interface QueryComboRulesOutputItem {
        comboRuleId: string;
        name: string;
        menuItemId: string;
        description?: string;
        priceDifference: number;
        status: string;
        createdAt: string;
        updatedAt: string;
        menuItemName: string;
    }
    export interface QueryComboRulesOutput {
        rules: QueryComboRulesOutputItem[];
    }
    /**
     * queryComboRules — Query ComboRule records from the MDM store with optional
     * status and nameContains filters, joining each rule with its referenced
     * MenuItem to surface menuItemName.
     *
     * Both ComboRule and MenuItem are MDM master-data entities (no local table or
     * repository port). Reads go through ctx.data.mdmEntityIndex (to discover
     * ComboRule mdmIds) and ctx.data.mdmDocument (to fetch full records).
     */
    export function queryComboRules(ctx: RequestContext, input: QueryComboRulesInput): Promise<QueryComboRulesOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryComboRules" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowQueryComboRulesHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryDashboard.defs" {
    export const queryDashboardController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "queryDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "dailyShiftLifecycle";
            readonly controllerName: "QueryDashboardController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowQueryDashboardHandler";
                readonly command: "queryDashboard";
                readonly usecaseRef: "queryDashboard";
                readonly inputTypeName: "QueryDashboardInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Shift.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Identificador do turno ativo cujos dados serão agregados no dashboard";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "input.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "O ID do turno é resolvido automaticamente a partir da instância ativa do ciclo de vida de turno diário";
                }];
                readonly accessPattern: {
                    readonly kind: "getById";
                    readonly description: "Recupera a visão agregada do dashboard para o turno ativo, consolidando pedidos, status de cozinha e níveis de estoque em tempo real";
                    readonly entity: "Shift";
                    readonly keyField: "Shift.shiftId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["shiftDashboardAggregation"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.dailyShiftLifecycle.queryDashboard";
                readonly handlerName: "cafeFlowQueryDashboardHandler";
            }];
        };
    };
    export default queryDashboardController;
    export const pipeline: readonly [{
        readonly id: "queryDashboard__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryDashboard.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/queryDashboard.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/queryDashboard" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface QueryDashboardInput {
        shiftId: string;
    }
    export interface ShiftDashboardAggregation {
        shiftId: string;
        shiftStatus: string;
        openedAt: string;
        closedAt: string;
        totalOrders: number;
        totalRevenue: number;
        pendingOrdersCount: number;
        preparingOrdersCount: number;
        readyOrdersCount: number;
        deliveredOrdersCount: number;
        cancelledOrdersCount: number;
        lowStockCount: number;
    }
    export function queryDashboard(ctx: RequestContext, input: QueryDashboardInput): Promise<ShiftDashboardAggregation>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryDashboard" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowQueryDashboardHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryMenuItems.defs" {
    export const queryMenuItemsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "queryMenuItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "queryMenuItems";
            readonly controllerName: "QueryMenuItemsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowQueryMenuItemsHandler";
                readonly command: "queryMenuItems";
                readonly usecaseRef: "queryMenuItems";
                readonly inputTypeName: "QueryMenuItemsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "categoryFilter";
                    readonly fieldRef: "MenuItem.category";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Categoria do item para filtrar a lista";
                }, {
                    readonly inputId: "nameFilter";
                    readonly fieldRef: "MenuItem.name";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Termo de busca pelo nome do item";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "filter.workspaceId";
                    readonly source: "currentWorkspace";
                    readonly originRef: "currentWorkspace.workspaceId";
                    readonly description: "Escopo do workspace atual para filtrar os itens do cardápio";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "Lista paginada de itens do cardápio com filtros por categoria e nome, ordenada por nome";
                    readonly entity: "MenuItem";
                    readonly filters: readonly ["MenuItem.category", "MenuItem.name"];
                    readonly sort: readonly ["MenuItem.name"];
                    readonly pagination: "optional";
                    readonly selection: "single";
                    readonly output: readonly ["MenuItem.menuItemId", "MenuItem.name", "MenuItem.category", "MenuItem.price", "MenuItem.description", "MenuItem.status", "MenuItem.createdAt", "MenuItem.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.queryMenuItems.queryMenuItems";
                readonly handlerName: "cafeFlowQueryMenuItemsHandler";
            }];
        };
    };
    export default queryMenuItemsController;
    export const pipeline: readonly [{
        readonly id: "queryMenuItems__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryMenuItems.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/queryMenuItems.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/queryMenuItems" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface QueryMenuItemsInput {
        categoryFilter?: string;
        nameFilter?: string;
        workspaceId?: string;
        page?: number;
        pageSize?: number;
    }
    export interface MenuItem {
        menuItemId: string;
        name: string;
        category: string;
        price: number;
        description: string | null;
        status: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface QueryMenuItemsOutput {
        items: MenuItem[];
        total: number;
    }
    export function queryMenuItems(ctx: RequestContext, input: QueryMenuItemsInput): Promise<QueryMenuItemsOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryMenuItems" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowQueryMenuItemsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryStockItems.defs" {
    export const queryStockItemsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "queryStockItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "queryStockItems";
            readonly controllerName: "QueryStockItemsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowQueryStockItemsHandler";
                readonly command: "queryStockItems";
                readonly usecaseRef: "queryStockItems";
                readonly inputTypeName: "QueryStockItemsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "nameFilter";
                    readonly fieldRef: "StockItem.name";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Termo para filtrar pelo nome do insumo";
                }, {
                    readonly inputId: "statusFilter";
                    readonly fieldRef: "StockItem.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Status para filtrar os itens de estoque";
                }];
                readonly contextResolution: readonly [];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "Lista paginada de itens de estoque com filtros opcionais por nome e status para consulta e seleção de insumos";
                    readonly entity: "StockItem";
                    readonly keyField: "StockItem.stockItemId";
                    readonly filters: readonly ["StockItem.name", "StockItem.status"];
                    readonly sort: readonly ["StockItem.name", "StockItem.createdAt"];
                    readonly pagination: "optional";
                    readonly selection: "single";
                    readonly output: readonly ["StockItem.stockItemId", "StockItem.name", "StockItem.unitOfMeasure", "StockItem.minimumQuantity", "StockItem.status", "StockItem.createdAt", "StockItem.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.queryStockItems.queryStockItems";
                readonly handlerName: "cafeFlowQueryStockItemsHandler";
            }];
        };
    };
    export default queryStockItemsController;
    export const pipeline: readonly [{
        readonly id: "queryStockItems__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryStockItems.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryStockItems.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/queryStockItems.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/queryStockItems" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface QueryStockItemsInput {
        nameFilter?: string;
        statusFilter?: string;
        page?: number;
        pageSize?: number;
    }
    export interface QueryStockItemsResultItem {
        stockItemId: string;
        name: string;
        unitOfMeasure: string;
        minimumQuantity: number;
        status: string;
        createdAt: string;
        updatedAt: string;
        lowStockAlert: boolean;
    }
    export interface QueryStockItemsOutput {
        items: QueryStockItemsResultItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    /**
     * Query StockItem master-data records from the shared MDM store.
     *
     * StockItem is an MDM entity (no local table/port). The usecase reads
     * via `ctx.data.mdmEntityIndex` + `ctx.data.mdmDocument`, applies optional
     * name/status filters, sorts by name, applies optional pagination, and
     * computes the `lowStockAlert` flag from the domain rule.
     */
    export function queryStockItems(ctx: RequestContext, input: QueryStockItemsInput): Promise<QueryStockItemsOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryStockItems" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowQueryStockItemsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryStockLevels.defs" {
    export const queryStockLevelsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "queryStockLevels";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "queryStockLevels";
            readonly controllerName: "QueryStockLevelsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowQueryStockLevelsHandler";
                readonly command: "queryStockLevels";
                readonly usecaseRef: "queryStockLevels";
                readonly inputTypeName: "QueryStockLevelsInput";
                readonly kind: "query";
                readonly inputContract: readonly [];
                readonly contextResolution: readonly [];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "Lista paginada dos níveis atuais de estoque, incluindo alertas de estoque baixo para reposição";
                    readonly entity: "StockLevel";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["StockLevel.stockLevelId", "StockLevel.stockItemId", "StockLevel.currentQuantity", "StockLevel.lastMovementAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.queryStockLevels.queryStockLevels";
                readonly handlerName: "cafeFlowQueryStockLevelsHandler";
            }];
        };
    };
    export default queryStockLevelsController;
    export const pipeline: readonly [{
        readonly id: "queryStockLevels__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryStockLevels.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryStockLevels.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/queryStockLevels.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/queryStockLevels" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    /** Enriched stock level projection with master-data fields and computed low-stock flag. */
    export interface StockLevelProjection {
        /** Unique identifier of the stock level record */
        stockLevelId: string;
        /** Reference to the StockItem master data entity */
        stockItemId: string;
        /** Name of the stock item resolved from MDM */
        itemName: string;
        /** Unit of measure of the stock item resolved from MDM */
        unitOfMeasure: string;
        /** Current quantity available in stock */
        currentQuantity: number;
        /** Minimum quantity threshold for low stock alert, resolved from MDM */
        minimumQuantity: number;
        /** Timestamp of the last stock movement */
        lastMovementAt: string;
        /** Computed flag: true when currentQuantity is below minimumQuantity (lowStockAlert rule) */
        isLowStock: boolean;
    }
    export interface QueryStockLevelsInput {
    }
    export interface QueryStockLevelsOutput {
        stockLevels: StockLevelProjection[];
    }
    /**
     * Query all stock levels, enrich each with its StockItem master-data fields
     * (name, unitOfMeasure, minimumQuantity), and compute the `isLowStock` flag
     * via the lowStockAlert rule (currentQuantity < minimumQuantity).
     *
     * This operation is read-only and does not alter stock state.
     */
    export function queryStockLevels(ctx: RequestContext, _input: QueryStockLevelsInput): Promise<QueryStockLevelsOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryStockLevels" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowQueryStockLevelsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryTables.defs" {
    export const queryTablesController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "queryTables";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "queryTables";
            readonly controllerName: "QueryTablesController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowQueryTablesHandler";
                readonly command: "queryTables";
                readonly usecaseRef: "queryTables";
                readonly inputTypeName: "QueryTablesInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "statusFilter";
                    readonly fieldRef: "Table.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional por situação da mesa (active ou inactive)";
                }, {
                    readonly inputId: "numberFilter";
                    readonly fieldRef: "Table.number";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional pelo número ou código visual da mesa";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "filter.workspaceId";
                    readonly source: "currentWorkspace";
                    readonly originRef: "currentWorkspace.workspaceId";
                    readonly description: "Workspace atual aplicado como filtro de escopo e segurança na listagem de mesas";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "Lista paginada de mesas cadastradas, com filtros opcionais por situação e número, ordenação e seleção individual para ações subsequentes.";
                    readonly entity: "Table";
                    readonly keyField: "Table.tableId";
                    readonly filters: readonly ["Table.status", "Table.number"];
                    readonly sort: readonly ["Table.number", "Table.createdAt"];
                    readonly pagination: "optional";
                    readonly selection: "single";
                    readonly output: readonly ["Table.tableId", "Table.number", "Table.name", "Table.status", "Table.createdAt", "Table.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.queryTables.queryTables";
                readonly handlerName: "cafeFlowQueryTablesHandler";
            }];
        };
    };
    export default queryTablesController;
    export const pipeline: readonly [{
        readonly id: "queryTables__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryTables.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryTables.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/queryTables.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/queryTables" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface QueryTablesInput {
        /** Filtro opcional por situação da mesa (active ou inactive). */
        statusFilter?: string;
        /** Filtro opcional pelo número ou código visual da mesa. */
        numberFilter?: string;
    }
    export interface QueryTablesItem {
        /** Identificador único da mesa. */
        tableId: string;
        /** Número ou código visual da mesa. */
        number: string;
        /** Nome descritivo da mesa, se definido. */
        name?: string;
        /** Situação da mesa (active ou inactive). */
        status: string;
        /** Data e hora de criação da mesa. */
        createdAt: string;
        /** Data e hora da última atualização da mesa. */
        updatedAt: string;
    }
    export interface QueryTablesOutput {
        tables: QueryTablesItem[];
        /** Total de registros correspondentes aos filtros (para paginação). */
        total?: number;
    }
    /**
     * Query tables (mesas) from the shared MDM store.
     *
     * `Table` is an MDM master-data entity — there is no local port or table.
     * Records are read via `ctx.data.mdmEntityIndex` (index) and `ctx.data.mdmDocument`
     * (full details). The module-specific `number` field lives in the `cafeFlow`
     * namespace inside the document `details`.
     */
    export function queryTables(ctx: RequestContext, input: QueryTablesInput): Promise<QueryTablesOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/queryTables" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowQueryTablesHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/settleOrder.defs" {
    export const settleOrderController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "settleOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "SettleOrderController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowSettleOrderHandler";
                readonly command: "settleOrder";
                readonly usecaseRef: "settleOrder";
                readonly inputTypeName: "SettleOrderInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "orderId";
                    readonly fieldRef: "Order.id";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador do pedido selecionado para finalização";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "input.orderId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Order.id";
                    readonly description: "Id do pedido obtido da entidade selecionada na jornada do atendente";
                }, {
                    readonly targetRef: "Order.status";
                    readonly source: "workflowState";
                    readonly originRef: "Order.status";
                    readonly description: "Novo status do pedido definido pela transição de workflow para finalizado";
                }, {
                    readonly targetRef: "Order.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Data/hora da última atualização atribuída automaticamente pelo sistema";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Comando para finalizar um único pedido, transicionando seu status para entregue e registrando o evento de transição no histórico.";
                    readonly entity: "Order";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Order", "OrderStatusEvent"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.settleOrder";
                readonly handlerName: "cafeFlowSettleOrderHandler";
            }];
        };
    };
    export default settleOrderController;
    export const pipeline: readonly [{
        readonly id: "settleOrder__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/settleOrder.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/settleOrder.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/settleOrder.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/settleOrder" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface SettleOrderInput {
        orderId: string;
    }
    export interface SettleOrderOutput {
        orderId: string;
        status: string;
        updatedAt: string;
        orderStatusEventId: string;
    }
    export function settleOrder(ctx: RequestContext, input: SettleOrderInput): Promise<SettleOrderOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/settleOrder" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowSettleOrderHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateComboRule.defs" {
    export const updateComboRuleController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateComboRule";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateComboRule";
            readonly controllerName: "UpdateComboRuleController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateComboRuleHandler";
                readonly command: "updateComboRule";
                readonly usecaseRef: "updateComboRule";
                readonly inputTypeName: "UpdateComboRuleInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "name";
                    readonly fieldRef: "ComboRule.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome descritivo da regra";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "ComboRule.description";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Detalhamento da regra e condições de aplicação";
                }, {
                    readonly inputId: "priceDifference";
                    readonly fieldRef: "ComboRule.priceDifference";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Diferença de preço aplicada no combo ou substituição";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "ComboRule.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Situação da regra no ciclo de vida";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "ComboRule.comboRuleId";
                    readonly source: "selectedEntity";
                    readonly originRef: "ComboRule.comboRuleId";
                    readonly description: "Identificador único da regra de combo sendo editada, resolvido da entidade selecionada na jornada";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Comando de atualização dos campos editáveis de uma regra de combo existente";
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateComboRule.updateComboRule";
                readonly handlerName: "cafeFlowUpdateComboRuleHandler";
            }];
        };
    };
    export default updateComboRuleController;
    export const pipeline: readonly [{
        readonly id: "updateComboRule__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateComboRule.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateComboRule.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/updateComboRule.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/updateComboRule" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateComboRuleInput {
        comboRuleId: string;
        name: string;
        description?: string;
        priceDifference: number;
        status: string;
    }
    export interface UpdateComboRuleOutput {
        comboRuleId: string;
        name: string;
        priceDifference: number;
        status: string;
        updatedAt: string;
    }
    export function updateComboRule(ctx: RequestContext, input: UpdateComboRuleInput): Promise<UpdateComboRuleOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateComboRule" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowUpdateComboRuleHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateKitchenStatus.defs" {
    export const updateKitchenStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateKitchenStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "UpdateKitchenStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateKitchenStatusHandler";
                readonly command: "updateKitchenStatus";
                readonly usecaseRef: "updateKitchenStatus";
                readonly inputTypeName: "UpdateKitchenStatusInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "orderId";
                    readonly fieldRef: "OrderStatusEvent.orderId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Referência ao pedido cujo status será atualizado, obtido do ticket selecionado na fila de cozinha.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "OrderStatusEvent.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Novo status de preparo informado pelo cozinheiro (ex.: em preparo, pronto).";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "OrderStatusEvent.orderStatusEventId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "Identificador único do evento gerado automaticamente pelo sistema.";
                }, {
                    readonly targetRef: "OrderStatusEvent.previousStatus";
                    readonly source: "selectedEntity";
                    readonly originRef: "Order.status";
                    readonly description: "Status atual do pedido antes da transição, resolvido a partir da entidade selecionada.";
                }, {
                    readonly targetRef: "OrderStatusEvent.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Data/hora de criação do evento atribuída automaticamente.";
                }, {
                    readonly targetRef: "OrderStatusEvent.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Data/hora de atualização do evento atribuída automaticamente.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Cozinheiro seleciona um ticket da fila de cozinha e informa o novo status de preparo, criando um evento de transição.";
                    readonly entity: "OrderStatusEvent";
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.updateKitchenStatus";
                readonly handlerName: "cafeFlowUpdateKitchenStatusHandler";
            }];
        };
    };
    export default updateKitchenStatusController;
    export const pipeline: readonly [{
        readonly id: "updateKitchenStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateKitchenStatus.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateKitchenStatus.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/updateKitchenStatus.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/updateKitchenStatus" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateKitchenStatusInput {
        orderId: string;
        status: string;
    }
    export interface UpdateKitchenStatusOutput {
        orderStatusEventId: string;
        orderId: string;
        previousStatus: string | null;
        status: string;
        createdAt: string;
    }
    export function updateKitchenStatus(ctx: RequestContext, input: UpdateKitchenStatusInput): Promise<UpdateKitchenStatusOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateKitchenStatus" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowUpdateKitchenStatusHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateMenuItem.defs" {
    export const updateMenuItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateMenuItem";
            readonly controllerName: "UpdateMenuItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateMenuItemHandler";
                readonly command: "updateMenuItem";
                readonly usecaseRef: "updateMenuItem";
                readonly inputTypeName: "UpdateMenuItemInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "menuItemId";
                    readonly fieldRef: "MenuItem.menuItemId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador único do item a ser editado";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "MenuItem.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do item do cardápio";
                }, {
                    readonly inputId: "category";
                    readonly fieldRef: "MenuItem.category";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Categoria do item (ex: entradas, pratos principais, bebidas, sobremesas)";
                }, {
                    readonly inputId: "price";
                    readonly fieldRef: "MenuItem.price";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Preço de venda do item";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "MenuItem.description";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Descrição detalhada do item";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "MenuItem.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Status do ciclo de vida do item (active/inactive)";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "input.menuItemId";
                    readonly source: "selectedEntity";
                    readonly originRef: "MenuItem.menuItemId";
                    readonly description: "Id do item selecionado na lista do cardápio no passo anterior";
                }, {
                    readonly targetRef: "MenuItem.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Data e hora da última atualização definida automaticamente pelo sistema";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Atualiza um item existente do cardápio com novos dados de nome, categoria, preço, descrição e status";
                    readonly entity: "MenuItem";
                    readonly keyField: "MenuItem.menuItemId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["MenuItem"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateMenuItem.updateMenuItem";
                readonly handlerName: "cafeFlowUpdateMenuItemHandler";
            }];
        };
    };
    export default updateMenuItemController;
    export const pipeline: readonly [{
        readonly id: "updateMenuItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateMenuItem.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/updateMenuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/updateMenuItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateMenuItemInput {
        menuItemId: string;
        name: string;
        category: string;
        price: number;
        description?: string;
        status: string;
    }
    export interface UpdateMenuItemOutput {
        menuItemId: string;
        name: string;
        category: string;
        price: number;
        description?: string;
        status: string;
        updatedAt: string;
    }
    export function updateMenuItem(ctx: RequestContext, input: UpdateMenuItemInput): Promise<UpdateMenuItemOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateMenuItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowUpdateMenuItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateStockItem.defs" {
    export const updateStockItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateStockItem";
            readonly controllerName: "UpdateStockItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateStockItemHandler";
                readonly command: "updateStockItem";
                readonly usecaseRef: "updateStockItem";
                readonly inputTypeName: "UpdateStockItemInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "stockItemId";
                    readonly fieldRef: "StockItem.stockItemId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador único do item de estoque a ser editado";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "StockItem.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do insumo";
                }, {
                    readonly inputId: "unitOfMeasure";
                    readonly fieldRef: "StockItem.unitOfMeasure";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Unidade de medida do insumo (ex: kg, unidade, litro)";
                }, {
                    readonly inputId: "minimumQuantity";
                    readonly fieldRef: "StockItem.minimumQuantity";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Quantidade mínima para alerta de estoque baixo";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "StockItem.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Status do item de estoque (active ou inactive)";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "input.stockItemId";
                    readonly source: "selectedEntity";
                    readonly originRef: "StockItem.stockItemId";
                    readonly description: "ID do item de estoque obtido da entidade selecionada no journey";
                }, {
                    readonly targetRef: "StockItem.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Data e hora da última atualização definida automaticamente pelo sistema";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Atualiza os dados cadastrais de um item de estoque previamente selecionado";
                    readonly entity: "StockItem";
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateStockItem.updateStockItem";
                readonly handlerName: "cafeFlowUpdateStockItemHandler";
            }];
        };
    };
    export default updateStockItemController;
    export const pipeline: readonly [{
        readonly id: "updateStockItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateStockItem.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateStockItem.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/updateStockItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/updateStockItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateStockItemInput {
        stockItemId: string;
        name: string;
        unitOfMeasure: string;
        minimumQuantity: number;
        status: string;
    }
    export interface UpdateStockItemOutput {
        stockItemId: string;
        name: string;
        unitOfMeasure: string;
        minimumQuantity: number;
        status: string;
        updatedAt: string;
    }
    export function updateStockItem(ctx: RequestContext, input: UpdateStockItemInput): Promise<UpdateStockItemOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateStockItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowUpdateStockItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateTable.defs" {
    export const updateTableController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateTable";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateTable";
            readonly controllerName: "UpdateTableController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateTableHandler";
                readonly command: "updateTable";
                readonly usecaseRef: "updateTable";
                readonly inputTypeName: "UpdateTableInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "tableId";
                    readonly fieldRef: "Table.tableId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador único da mesa a ser editada";
                }, {
                    readonly inputId: "number";
                    readonly fieldRef: "Table.number";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Número ou código de identificação visual da mesa";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "Table.name";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Nome ou descrição opcional da mesa";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Table.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Situação da mesa no sistema (active ou inactive)";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "input.tableId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Table.tableId";
                    readonly description: "Identificador da mesa selecionada na lista para edição";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "Comando para atualizar os dados cadastrais de uma mesa existente selecionada previamente";
                    readonly entity: "Table";
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.updateTable.updateTable";
                readonly handlerName: "cafeFlowUpdateTableHandler";
            }];
        };
    };
    export default updateTableController;
    export const pipeline: readonly [{
        readonly id: "updateTable__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateTable.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateTable.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/usecases/updateTable.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/updateTable" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateTableInput {
        tableId: string;
        number: string;
        name?: string;
        status: string;
    }
    export interface UpdateTableOutput {
        tableId: string;
        number: string;
        name: string | null;
        status: string;
        updatedAt: string;
    }
    export function updateTable(ctx: RequestContext, input: UpdateTableInput): Promise<UpdateTableOutput>;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateTable" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowUpdateTableHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Order";
            readonly tableName: "order";
            readonly columns: readonly [{
                readonly name: "id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "Primary key";
            }, {
                readonly name: "order_type";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "Order type (e.g. dine-in, takeaway)";
            }, {
                readonly name: "table_id";
                readonly type: "string";
                readonly nullable: true;
                readonly description: "FK to restaurant table";
            }, {
                readonly name: "shift_id";
                readonly type: "string";
                readonly nullable: true;
                readonly description: "FK to shift";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "Order status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "total, updatedAt and other non-indexed fields";
            }];
            readonly primaryKey: readonly ["id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_order_order_type";
                readonly columns: readonly ["order_type"];
            }, {
                readonly indexName: "idx_order_table_id";
                readonly columns: readonly ["table_id"];
            }, {
                readonly indexName: "idx_order_shift_id";
                readonly columns: readonly ["shift_id"];
            }, {
                readonly indexName: "idx_order_status";
                readonly columns: readonly ["status"];
            }, {
                readonly indexName: "idx_order_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
        };
    };
    export default orderTableDefinition;
    export const pipeline: readonly [{
        readonly id: "order__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/order.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/order" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const orderTableDef: TableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderItem.defs" {
    export const orderItemTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "OrderItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "OrderItem";
            readonly tableName: "order_item";
            readonly columns: readonly [{
                readonly name: "order_item_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "Primary key";
            }, {
                readonly name: "order_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "FK to order";
            }, {
                readonly name: "menu_item_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "FK to menu item";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "Order item status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "quantity, unitPrice, itemTotal, substitutionsApplied, updatedAt and other non-indexed fields";
            }];
            readonly primaryKey: readonly ["order_item_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_order_item_order_id";
                readonly columns: readonly ["order_id"];
            }, {
                readonly indexName: "idx_order_item_menu_item_id";
                readonly columns: readonly ["menu_item_id"];
            }, {
                readonly indexName: "idx_order_item_status";
                readonly columns: readonly ["status"];
            }, {
                readonly indexName: "idx_order_item_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
        };
    };
    export default orderItemTableDefinition;
    export const pipeline: readonly [{
        readonly id: "orderItem__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderItem.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderItem.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_3_domain/entities/orderItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderItem" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const orderItemTableDef: TableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderItemRepositoryAdapter.defs" {
    export const orderItemRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "OrderItemRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "OrderItemRepositoryAdapter";
            readonly entityId: "OrderItem";
            readonly portRef: "IOrderItemRepository";
            readonly tableRef: "order_items";
            readonly mdmReads: readonly ["MenuItem"];
            readonly notes: readonly ["Real columns: order_item_id, order_id, menu_item_id, status, created_at", "Details JSONB: quantity, unit_price, item_total, substitutions_applied, updated_at", "Resolves MenuItem mdmRef via 102034 MDM runtime (MdmEntityIndexRecord shape)", "ctx.data used for OrderItem <-> order_items row mapping"];
        };
    };
    export default orderItemRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "orderItemRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderItemRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderItemRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/ports/orderItemRepository.d.ts", "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderItem.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/orderItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderItemRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IOrderItemRepository } from "_102049_/l1/cafeFlow/layer_2_application/ports/orderItemRepository";
    export function createOrderItemRepositoryAdapter(ctx: RequestContext): IOrderItemRepository;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs" {
    export const orderRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "OrderRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "OrderRepositoryAdapter";
            readonly entityId: "Order";
            readonly portRef: "IOrderRepository";
            readonly tableRef: "orders";
            readonly mdmReads: readonly ["Table"];
            readonly notes: readonly ["Real columns: id, order_type, table_id, shift_id, status, created_at", "Details JSONB: total, updated_at", "Resolves Table mdmRef via 102034 MDM runtime (MdmEntityIndexRecord shape)", "ctx.data used for Order <-> orders row mapping"];
        };
    };
    export default orderRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "orderRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/order.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IOrderRepository } from "_102049_/l1/cafeFlow/layer_2_application/ports/orderRepository";
    export function createOrderRepositoryAdapter(ctx: RequestContext): IOrderRepository;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderStatusEvent.defs" {
    export const orderStatusEventTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "OrderStatusEvent";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "OrderStatusEvent";
            readonly tableName: "order_status_event";
            readonly columns: readonly [{
                readonly name: "order_status_event_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "Primary key";
            }, {
                readonly name: "order_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "FK to order";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "New status";
            }, {
                readonly name: "previous_status";
                readonly type: "string";
                readonly nullable: true;
                readonly description: "Previous status before transition";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Event timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "updatedAt and other non-indexed fields";
            }];
            readonly primaryKey: readonly ["order_status_event_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_order_status_event_order_id";
                readonly columns: readonly ["order_id"];
            }, {
                readonly indexName: "idx_order_status_event_status";
                readonly columns: readonly ["status"];
            }, {
                readonly indexName: "idx_order_status_event_previous_status";
                readonly columns: readonly ["previous_status"];
            }, {
                readonly indexName: "idx_order_status_event_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
            readonly appendOnly: true;
            readonly purpose: "controle";
            readonly retentionDays: 365;
        };
    };
    export default orderStatusEventTableDefinition;
    export const pipeline: readonly [{
        readonly id: "orderStatusEvent__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderStatusEvent.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderStatusEvent.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderStatusEvent" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const orderStatusEventTableDef: TableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderStatusEventRepositoryAdapter.defs" {
    export const orderStatusEventRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "OrderStatusEventRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "OrderStatusEventRepositoryAdapter";
            readonly entityId: "OrderStatusEvent";
            readonly portRef: "IOrderStatusEventRepository";
            readonly tableRef: "order_status_events";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Append-only event adapter: insert row only, no update/delete", "Real columns: order_status_event_id, order_id, status, previous_status, created_at", "Details JSONB: updated_at", "Implements append + read finders", "ctx.data used for OrderStatusEvent <-> order_status_events row mapping"];
        };
    };
    export default orderStatusEventRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "orderStatusEventRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderStatusEventRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderStatusEventRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository.d.ts", "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderStatusEvent.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/orderStatusEventRepositoryAdapter" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IOrderStatusEventRepository } from "_102049_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository";
    export function createOrderStatusEventRepositoryAdapter(ctx: RequestContext): IOrderStatusEventRepository;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/shift.defs" {
    export const shiftTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Shift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Shift";
            readonly tableName: "shift";
            readonly columns: readonly [{
                readonly name: "shift_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "Primary key";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "Shift status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "openedAt, closedAt, updatedAt and other non-indexed fields";
            }];
            readonly primaryKey: readonly ["shift_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_shift_status";
                readonly columns: readonly ["status"];
            }, {
                readonly indexName: "idx_shift_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
        };
    };
    export default shiftTableDefinition;
    export const pipeline: readonly [{
        readonly id: "shift__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/shift.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/shift.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/shift" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const shiftTableDef: TableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftRepositoryAdapter.defs" {
    export const shiftRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ShiftRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ShiftRepositoryAdapter";
            readonly entityId: "Shift";
            readonly portRef: "IShiftRepository";
            readonly tableRef: "shifts";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns: shift_id, status, created_at", "Details JSONB: opened_at, closed_at, updated_at", "No MDM refs", "ctx.data used for Shift <-> shifts row mapping"];
        };
    };
    export default shiftRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "shiftRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/shift.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IShiftRepository } from "_102049_/l1/cafeFlow/layer_2_application/ports/shiftRepository";
    export function createShiftRepositoryAdapter(ctx: RequestContext): IShiftRepository;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftStatusEvent.defs" {
    export const shiftStatusEventTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "ShiftStatusEvent";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "ShiftStatusEvent";
            readonly tableName: "shift_status_event";
            readonly columns: readonly [{
                readonly name: "shift_status_event_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "Primary key";
            }, {
                readonly name: "shift_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "FK to shift";
            }, {
                readonly name: "event_type";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "Event type (e.g. open, close)";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Event timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "consolidatedTotal, recordedAt, updatedAt and other non-indexed fields";
            }];
            readonly primaryKey: readonly ["shift_status_event_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_shift_status_event_shift_id";
                readonly columns: readonly ["shift_id"];
            }, {
                readonly indexName: "idx_shift_status_event_event_type";
                readonly columns: readonly ["event_type"];
            }, {
                readonly indexName: "idx_shift_status_event_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
            readonly appendOnly: true;
            readonly purpose: "controle";
            readonly retentionDays: 365;
        };
    };
    export default shiftStatusEventTableDefinition;
    export const pipeline: readonly [{
        readonly id: "shiftStatusEvent__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftStatusEvent.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftStatusEvent.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_3_domain/entities/shiftStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftStatusEvent" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const shiftStatusEventTableDef: TableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftStatusEventRepositoryAdapter.defs" {
    export const shiftStatusEventRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ShiftStatusEventRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ShiftStatusEventRepositoryAdapter";
            readonly entityId: "ShiftStatusEvent";
            readonly portRef: "IShiftStatusEventRepository";
            readonly tableRef: "shift_status_events";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Append-only event adapter: insert row only, no update/delete", "Real columns: shift_status_event_id, shift_id, event_type, created_at", "Details JSONB: consolidated_total, recorded_at, updated_at", "Implements append + read finders", "ctx.data used for ShiftStatusEvent <-> shift_status_events row mapping"];
        };
    };
    export default shiftStatusEventRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "shiftStatusEventRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftStatusEventRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftStatusEventRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/ports/shiftStatusEventRepository.d.ts", "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftStatusEvent.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/shiftStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftStatusEventRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IShiftStatusEventRepository } from "_102049_/l1/cafeFlow/layer_2_application/ports/shiftStatusEventRepository";
    export function createShiftStatusEventRepositoryAdapter(ctx: RequestContext): IShiftStatusEventRepository;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.defs" {
    export const stockLevelTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "StockLevel";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "StockLevel";
            readonly tableName: "stock_level";
            readonly columns: readonly [{
                readonly name: "stock_level_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "Primary key";
            }, {
                readonly name: "stock_item_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "FK to stock item";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "currentQuantity, lastMovementAt, updatedAt and other non-indexed fields";
            }];
            readonly primaryKey: readonly ["stock_level_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_stock_level_stock_item_id";
                readonly columns: readonly ["stock_item_id"];
            }, {
                readonly indexName: "idx_stock_level_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
        };
    };
    export default stockLevelTableDefinition;
    export const pipeline: readonly [{
        readonly id: "stockLevel__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const stockLevelTableDef: TableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter.defs" {
    export const stockLevelRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "StockLevelRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "StockLevelRepositoryAdapter";
            readonly entityId: "StockLevel";
            readonly portRef: "IStockLevelRepository";
            readonly tableRef: "stock_levels";
            readonly mdmReads: readonly ["StockItem"];
            readonly notes: readonly ["Real columns: stock_level_id, stock_item_id, created_at", "Details JSONB: current_quantity, last_movement_at, updated_at", "Resolves StockItem mdmRef via 102034 MDM runtime (MdmEntityIndexRecord shape)", "ctx.data used for StockLevel <-> stock_levels row mapping"];
        };
    };
    export default stockLevelRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "stockLevelRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IStockLevelRepository } from "_102049_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository";
    export function createStockLevelRepositoryAdapter(ctx: RequestContext): IStockLevelRepository;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/stockMovementEvent.defs" {
    export const stockMovementEventTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "StockMovementEvent";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "StockMovementEvent";
            readonly tableName: "stock_movement_event";
            readonly columns: readonly [{
                readonly name: "stock_movement_event_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "Primary key";
            }, {
                readonly name: "stock_item_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "FK to stock item";
            }, {
                readonly name: "movement_type";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "Movement type (e.g. in, out, adjustment)";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Event timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "quantity, reason, updatedAt and other non-indexed fields";
            }];
            readonly primaryKey: readonly ["stock_movement_event_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_stock_movement_event_stock_item_id";
                readonly columns: readonly ["stock_item_id"];
            }, {
                readonly indexName: "idx_stock_movement_event_movement_type";
                readonly columns: readonly ["movement_type"];
            }, {
                readonly indexName: "idx_stock_movement_event_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
            readonly appendOnly: true;
            readonly purpose: "controle";
            readonly retentionDays: 90;
        };
    };
    export default stockMovementEventTableDefinition;
    export const pipeline: readonly [{
        readonly id: "stockMovementEvent__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/stockMovementEvent.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/stockMovementEvent.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_3_domain/entities/stockMovementEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/stockMovementEvent" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const stockMovementEventTableDef: TableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/stockMovementEventRepositoryAdapter.defs" {
    export const stockMovementEventRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "StockMovementEventRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "StockMovementEventRepositoryAdapter";
            readonly entityId: "StockMovementEvent";
            readonly portRef: "IStockMovementEventRepository";
            readonly tableRef: "stock_movement_events";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Append-only event adapter: insert row only, no update/delete", "Real columns: stock_movement_event_id, stock_item_id, movement_type, created_at", "Details JSONB: quantity, reason, updated_at", "Implements append + read finders", "ctx.data used for StockMovementEvent <-> stock_movement_events row mapping"];
        };
    };
    export default stockMovementEventRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "stockMovementEventRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/stockMovementEventRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/stockMovementEventRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/ports/stockMovementEventRepository.d.ts", "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/stockMovementEvent.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/stockMovementEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_3_domain/entities/stockMovementEvent" {
    export type StockMovementType = 'baixa' | 'reposicao';
    export interface StockMovementEvent {
        stockMovementEventId: string;
        stockItemId: string;
        movementType: StockMovementType;
        quantity: number;
        reason: string;
        createdAt: string;
        updatedAt: string;
    }
}
declare module "_102049_/l1/cafeFlow/layer_2_application/ports/stockMovementEventRepository" {
    import type { StockMovementEvent } from "_102049_/l1/cafeFlow/layer_3_domain/entities/stockMovementEvent";
    /** Branded primitive for stock-level identity. */
    export type StockLevelId = string;
    /** Inclusive date range used for period-based event queries. */
    export interface DateRange {
        from: string;
        to: string;
    }
    /**
     * Append-only repository port for {@link StockMovementEvent}.
     *
     * Events are immutable once recorded — the port exposes only `append` for
     * writes and read finders for queries. No `save`, `update`, or `delete`.
     */
    export interface IStockMovementEventRepository {
        /** Append a stock movement event. */
        append(event: StockMovementEvent): Promise<void>;
        /** Read finder: list events within a period. */
        listByPeriod(period: DateRange): Promise<StockMovementEvent[]>;
        /** Read finder: list events by stock level. */
        listByStockLevelId(stockLevelId: StockLevelId): Promise<StockMovementEvent[]>;
    }
}
declare module "_102049_/l1/cafeFlow/layer_1_external/adapters/persistence/stockMovementEventRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IStockMovementEventRepository } from "_102049_/l1/cafeFlow/layer_2_application/ports/stockMovementEventRepository";
    export function createStockMovementEventRepositoryAdapter(ctx: RequestContext): IStockMovementEventRepository;
}
declare module "_102049_/l1/cafeFlow/layer_2_application/ports/orderItemRepository.defs" {
    export const orderItemRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "OrderItemRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "OrderItem";
            readonly interfaceName: "IOrderItemRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "OrderItem";
                readonly params: readonly ["id: OrderItemId"];
                readonly description: "Retrieve an order item by its unique identifier";
            }, {
                readonly name: "list";
                readonly returns: "OrderItem[]";
                readonly params: readonly ["filter: OrderItemFilter"];
                readonly description: "List order items matching the given filter";
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["orderItem: OrderItem"];
                readonly description: "Persist the given order item aggregate";
            }, {
                readonly name: "findByOrderId";
                readonly returns: "OrderItem[]";
                readonly params: readonly ["orderId: OrderId"];
                readonly description: "Domain finder: retrieve items belonging to an order";
            }];
        };
    };
    export default orderItemRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "orderItemRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/ports/orderItemRepository.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/ports/orderItemRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_3_domain/entities/orderItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs" {
    export const orderRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "OrderRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly interfaceName: "IOrderRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "Order";
                readonly params: readonly ["id: OrderId"];
                readonly description: "Retrieve an order by its unique identifier";
            }, {
                readonly name: "list";
                readonly returns: "Order[]";
                readonly params: readonly ["filter: OrderFilter"];
                readonly description: "List orders matching the given filter";
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["order: Order"];
                readonly description: "Persist the given order aggregate";
            }, {
                readonly name: "findByCustomerId";
                readonly returns: "Order[]";
                readonly params: readonly ["customerId: CustomerId"];
                readonly description: "Domain finder: retrieve orders by customer";
            }, {
                readonly name: "findByStatus";
                readonly returns: "Order[]";
                readonly params: readonly ["status: OrderStatus"];
                readonly description: "Domain finder: retrieve orders by status";
            }];
        };
    };
    export default orderRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "orderRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/ports/orderRepository.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository.defs" {
    export const orderStatusEventRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "OrderStatusEventRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "OrderStatusEvent";
            readonly interfaceName: "IOrderStatusEventRepository";
            readonly methods: readonly [{
                readonly name: "append";
                readonly returns: "void";
                readonly params: readonly ["event: OrderStatusEvent"];
                readonly description: "Append an order status event";
            }, {
                readonly name: "listByOwnerId";
                readonly returns: "OrderStatusEvent[]";
                readonly params: readonly ["ownerId: OrderId"];
                readonly description: "Read finder: list events by order";
            }, {
                readonly name: "listByPeriod";
                readonly returns: "OrderStatusEvent[]";
                readonly params: readonly ["period: DateRange"];
                readonly description: "Read finder: list events within a period";
            }];
        };
    };
    export default orderStatusEventRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "orderStatusEventRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/ports/shiftRepository.defs" {
    export const shiftRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ShiftRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Shift";
            readonly interfaceName: "IShiftRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "Shift";
                readonly params: readonly ["id: ShiftId"];
                readonly description: "Retrieve a shift by its unique identifier";
            }, {
                readonly name: "list";
                readonly returns: "Shift[]";
                readonly params: readonly ["filter: ShiftFilter"];
                readonly description: "List shifts matching the given filter";
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["shift: Shift"];
                readonly description: "Persist the given shift aggregate";
            }, {
                readonly name: "findByEmployeeId";
                readonly returns: "Shift[]";
                readonly params: readonly ["employeeId: EmployeeId"];
                readonly description: "Domain finder: retrieve shifts for an employee";
            }, {
                readonly name: "findByPeriod";
                readonly returns: "Shift[]";
                readonly params: readonly ["period: DateRange"];
                readonly description: "Domain finder: retrieve shifts within a period";
            }];
        };
    };
    export default shiftRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "shiftRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/ports/shiftRepository.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/ports/shiftRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/ports/shiftStatusEventRepository.defs" {
    export const shiftStatusEventRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ShiftStatusEventRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "ShiftStatusEvent";
            readonly interfaceName: "IShiftStatusEventRepository";
            readonly methods: readonly [{
                readonly name: "append";
                readonly returns: "void";
                readonly params: readonly ["event: ShiftStatusEvent"];
                readonly description: "Append a shift status event";
            }, {
                readonly name: "listByOwnerId";
                readonly returns: "ShiftStatusEvent[]";
                readonly params: readonly ["ownerId: ShiftId"];
                readonly description: "Read finder: list events by shift";
            }, {
                readonly name: "listByPeriod";
                readonly returns: "ShiftStatusEvent[]";
                readonly params: readonly ["period: DateRange"];
                readonly description: "Read finder: list events within a period";
            }];
        };
    };
    export default shiftStatusEventRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "shiftStatusEventRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/ports/shiftStatusEventRepository.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/ports/shiftStatusEventRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_3_domain/entities/shiftStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.defs" {
    export const stockLevelRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "StockLevelRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockLevel";
            readonly interfaceName: "IStockLevelRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "StockLevel";
                readonly params: readonly ["id: StockLevelId"];
                readonly description: "Retrieve a stock level by its unique identifier";
            }, {
                readonly name: "list";
                readonly returns: "StockLevel[]";
                readonly params: readonly ["filter: StockLevelFilter"];
                readonly description: "List stock levels matching the given filter";
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["stockLevel: StockLevel"];
                readonly description: "Persist the given stock level aggregate";
            }, {
                readonly name: "findByProductId";
                readonly returns: "StockLevel";
                readonly params: readonly ["productId: ProductId"];
                readonly description: "Domain finder: retrieve stock level for a product";
            }, {
                readonly name: "findBelowThreshold";
                readonly returns: "StockLevel[]";
                readonly params: readonly ["threshold: Quantity"];
                readonly description: "Domain finder: retrieve stock levels below threshold";
            }];
        };
    };
    export default stockLevelRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "stockLevelRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/ports/stockMovementEventRepository.defs" {
    export const stockMovementEventRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "StockMovementEventRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockMovementEvent";
            readonly interfaceName: "IStockMovementEventRepository";
            readonly methods: readonly [{
                readonly name: "append";
                readonly returns: "void";
                readonly params: readonly ["event: StockMovementEvent"];
                readonly description: "Append a stock movement event";
            }, {
                readonly name: "listByPeriod";
                readonly returns: "StockMovementEvent[]";
                readonly params: readonly ["period: DateRange"];
                readonly description: "Read finder: list events within a period";
            }, {
                readonly name: "listByStockLevelId";
                readonly returns: "StockMovementEvent[]";
                readonly params: readonly ["stockLevelId: StockLevelId"];
                readonly description: "Read finder: list events by stock level";
            }];
        };
    };
    export default stockMovementEventRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "stockMovementEventRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/ports/stockMovementEventRepository.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/ports/stockMovementEventRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_3_domain/entities/stockMovementEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/adjustStockLevel.defs" {
    export const adjustStockLevelUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "adjustStockLevel";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "adjustStockLevel";
            readonly ports: readonly ["StockLevel"];
            readonly functions: readonly [{
                readonly functionName: "adjustStockLevel";
                readonly inputTypeName: "AdjustStockLevelInput";
                readonly outputTypeName: "AdjustStockLevelOutput";
                readonly input: readonly [{
                    readonly name: "stockLevelId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockLevel";
                    readonly description: "Identificador do nível de estoque selecionado para ajuste";
                }, {
                    readonly name: "movementType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockMovementEvent";
                    readonly description: "Tipo da movimentação: baixa (decremento) ou reposicao (incremento)";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockMovementEvent";
                    readonly description: "Quantidade movimentada no ajuste";
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockMovementEvent";
                    readonly description: "Motivo do ajuste de estoque";
                }];
                readonly output: readonly [{
                    readonly name: "stockLevelId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockLevel";
                    readonly description: "Identificador do nível de estoque ajustado";
                }, {
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockLevel";
                    readonly description: "Identificador do item de estoque vinculado";
                }, {
                    readonly name: "currentQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockLevel";
                    readonly description: "Quantidade atual após o ajuste";
                }, {
                    readonly name: "lowStockAlert";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly description: "Indica se a quantidade atual ficou abaixo do mínimo do item";
                }, {
                    readonly name: "stockMovementEventId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockMovementEvent";
                    readonly description: "Identificador do registro de movimentação gerado";
                }];
                readonly ports: readonly ["StockLevel"];
                readonly rulesApplied: readonly ["stockDecrementOnPreparing", "lowStockAlert"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolver stockLevelId a partir da entidade selecionada (contextResolution.selectedEntity)", "2. Carregar StockLevel pelo stockLevelId através do port StockLevel.getById", "3. Ler StockItem do MDM via ctx.data.mdmDocument.get({ mdmId: stockLevel.stockItemId }) para obter minimumQuantity e validar status ativo", "4. Validar que o StockItem está ativo (status === 'active'); se inativo, rejeitar operação", "5. Aplicar regra stockDecrementOnPreparing: se movementType === 'baixa', decrementar currentQuantity pela quantity informada; se movementType === 'reposicao', incrementar currentQuantity pela quantity", "6. Validar que currentQuantity resultante não é negativo (baixa não pode exceder o saldo disponível)", "7. Gerar stockMovementEventId via ctx.idGenerator e createdAt via ctx.clock.now", "8. Construir registro StockMovementEvent { stockMovementEventId, stockItemId: stockLevel.stockItemId, movementType, quantity, reason, createdAt, updatedAt } e anexá-lo ao aggregate StockLevel através do port na mesma transação", "9. Atualizar StockLevel: currentQuantity (novo saldo), lastMovementAt = ctx.clock.now, updatedAt = ctx.clock.now", "10. Aplicar regra lowStockAlert: comparar currentQuantity com StockItem.minimumQuantity; se currentQuantity < minimumQuantity, marcar lowStockAlert = true", "11. Salvar StockLevel (com o evento de movimentação anexado) através do port StockLevel.save dentro da mesma transação", "12. Retornar { stockLevelId, stockItemId, currentQuantity, lowStockAlert, stockMovementEventId }"];
            }];
            readonly mdmRefs: readonly ["StockItem"];
        };
    };
    export default adjustStockLevelUsecase;
    export const pipeline: readonly [{
        readonly id: "adjustStockLevel__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/adjustStockLevel.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/adjustStockLevel.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/closeShift.defs" {
    export const closeShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "closeShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "closeShift";
            readonly ports: readonly ["Shift", "Order", "OrderStatusEvent", "ShiftStatusEvent"];
            readonly functions: readonly [{
                readonly functionName: "closeShift";
                readonly inputTypeName: "CloseShiftInput";
                readonly outputTypeName: "CloseShiftOutput";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Identificador único do turno ativo a ser fechado, resolvido a partir da instância ativa do ciclo de vida";
                }];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Identificador do turno fechado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Status final do turno (closed)";
                }, {
                    readonly name: "closedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Data e hora de fechamento atribuída pelo sistema";
                }];
                readonly ports: readonly ["Shift", "Order", "ShiftStatusEvent"];
                readonly rulesApplied: readonly ["orderRequiresOpenShift", "shiftClosingRequiresSettledOrders"];
                readonly transactional: true;
                readonly steps: readonly ["1. Carregar o Shift pelo shiftId informado através da porta Shift (getById)", "2. Validar que o turno existe e seu status atual é 'open' (regra orderRequiresOpenShift — apenas turnos abertos podem ser fechados)", "3. Consultar todos os Orders associados ao shiftId através da porta Order (list por shiftId)", "4. Validar que todos os pedidos do turno estão finalizados (status 'delivered' ou 'cancelled') — regra shiftClosingRequiresSettledOrders; se houver pedidos pendentes/inKitchen/preparing/ready, rejeitar o fechamento", "5. Calcular o consolidatedTotal somando o total de todos os pedidos do turno", "6. Atualizar o Shift: status = 'closed', closedAt = ctx.clock.now(), updatedAt = ctx.clock.now()", "7. Salvar o Shift atualizado através da porta Shift (update) dentro da transação", "8. Criar o ShiftStatusEvent: shiftStatusEventId = ctx.idGenerator.generate(), shiftId, eventType = 'fechamento', consolidatedTotal, recordedAt = ctx.clock.now(), createdAt = ctx.clock.now(), updatedAt = ctx.clock.now()", "9. Anexar o ShiftStatusEvent através da porta ShiftStatusEvent (create) dentro da mesma transação", "10. Retornar shiftId, status e closedAt do turno fechado"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default closeShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "closeShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/closeShift.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/closeShift.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/shiftStatusEventRepository.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/shiftStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/createComboRule.defs" {
    export const createComboRuleUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createComboRule";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createComboRule";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "createComboRule";
                readonly inputTypeName: "CreateComboRuleInput";
                readonly outputTypeName: "CreateComboRuleOutput";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Item do cardápio ao qual a regra se aplica, resolvido a partir da entidade selecionada na jornada";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                    readonly description: "Nome descritivo da regra";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "ComboRule";
                    readonly description: "Detalhamento da regra e condições de aplicação";
                }, {
                    readonly name: "priceDifference";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                    readonly description: "Diferença de preço aplicada no combo ou substituição";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                    readonly description: "Situação da regra no ciclo de vida (active/inactive)";
                }];
                readonly output: readonly [{
                    readonly name: "comboRuleId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                    readonly description: "Identificador único da regra criada";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                    readonly description: "Situação da regra após criação";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["comboPriceDifference"];
                readonly transactional: true;
                readonly steps: readonly ["Resolve menuItemId from the selected entity context (MenuItem selected in the journey)", "Read MenuItem by id via ctx.data.mdmDocument.get({ mdmId: menuItemId }) to validate it exists and is active", "Generate comboRuleId using ctx.idGenerator", "Apply comboPriceDifference rule: validate that priceDifference is a non-negative monetary value consistent with the combo/substitution semantics", "Set createdAt and updatedAt from ctx.clock", "Build ComboRule aggregate with comboRuleId, menuItemId, name, description, priceDifference, status, createdAt, updatedAt", "Persist ComboRule through comboRuleRepository.save() inside a single transaction", "Return comboRuleId and status"];
            }];
            readonly mdmRefs: readonly ["ComboRule", "MenuItem"];
        };
    };
    export default createComboRuleUsecase;
    export const pipeline: readonly [{
        readonly id: "createComboRule__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/createComboRule.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/createComboRule.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/createMenuItem.defs" {
    export const createMenuItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createMenuItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "createMenuItem";
                readonly inputTypeName: "CreateMenuItemInput";
                readonly outputTypeName: "CreateMenuItemOutput";
                readonly input: readonly [{
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Nome do item do cardápio";
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "category";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Categoria do item (ex: entradas, pratos principais, bebidas, sobremesas)";
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Preço de venda do item";
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Descrição detalhada do item";
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status do ciclo de vida do item (active/inactive)";
                    readonly ofEntity: "MenuItem";
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador único do item gerado automaticamente";
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "category";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["comboPriceDifference"];
                readonly transactional: true;
                readonly steps: readonly ["Generate menuItemId via ctx.idGenerator.uuid()", "Resolve createdAt and updatedAt from ctx.clock.now()", "Validate required fields: name, category, price, status", "Validate status enum is 'active' or 'inactive'", "Apply comboPriceDifference rule to validate price against category and combo constraints", "Construct MenuItem aggregate root with generated menuItemId, provided fields, and system timestamps", "Persist MenuItem through menuItemPort.save() inside a transaction", "Return created MenuItem projection with menuItemId, name, category, price, status, createdAt, updatedAt"];
            }];
            readonly mdmRefs: readonly ["MenuItem"];
        };
    };
    export default createMenuItemUsecase;
    export const pipeline: readonly [{
        readonly id: "createMenuItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/createMenuItem.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/createMenuItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs" {
    export const createOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createOrder";
            readonly ports: readonly ["Order", "Shift", "OrderItem", "OrderStatusEvent", "ShiftStatusEvent"];
            readonly functions: readonly [{
                readonly functionName: "createOrder";
                readonly inputTypeName: "CreateOrderInput";
                readonly outputTypeName: "CreateOrderOutput";
                readonly input: readonly [{
                    readonly name: "orderType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Modalidade do pedido: dineIn ou takeout";
                }, {
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Mesa selecionada para pedidos dine-in; omitido para takeout";
                }, {
                    readonly name: "items";
                    readonly type: "OrderItemInput[]";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "Lista de itens do cardápio com quantidade e substituições aplicadas";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Identificador único do pedido criado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Status inicial do pedido (pending)";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Total calculado do pedido somando todos os itens";
                }];
                readonly ports: readonly ["Order", "Shift", "OrderItem", "OrderStatusEvent"];
                readonly rulesApplied: readonly ["orderRequiresOpenShift"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolver workspaceId do contexto de requisição (RequestContext metadata)", "2. Buscar turno aberto (status=open) para o workspace via Shift port — regra orderRequiresOpenShift", "3. Se nenhum turno aberto encontrado, rejeitar a operação com erro de validação", "4. Se orderType=dineIn, validar que tableId foi informado e que a mesa existe e está ativa (MDM Table ref por id via ctx.data.mdmDocument.get)", "5. Para cada item em items, validar que menuItemId existe e está ativo (MDM MenuItem ref por id via ctx.data.mdmDocument.get)", "6. Aplicar ComboRules aplicáveis (MDM ComboRule ref por id) para calcular ajustes de preço nos itens compostos", "7. Calcular unitPrice a partir do preço do MenuItem e itemTotal = unitPrice * quantity para cada OrderItem", "8. Calcular total do pedido como soma de todos os itemTotals", "9. Gerar Order.id via ctx.idGenerator, definir status=pending, shiftId do turno aberto, createdAt/updatedAt via ctx.clock", "10. Gerar OrderItem.orderItemId via ctx.idGenerator para cada item, definir orderId=Order.id, status=pending, createdAt/updatedAt via ctx.clock", "11. Persistir Order (com OrderItems embutidos) via Order port dentro da transação", "12. Construir OrderStatusEvent (orderId, status=pending, timestamp) e persistir via OrderStatusEvent port dentro da mesma transação", "13. Retornar orderId, status e total"];
            }];
            readonly mdmRefs: readonly ["MenuItem", "Table", "ComboRule"];
        };
    };
    export default createOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "createOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/createOrder.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/orderItemRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/shiftStatusEventRepository.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/orderItem.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/shiftStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/createStockItem.defs" {
    export const createStockItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createStockItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "createStockItem";
                readonly inputTypeName: "CreateStockItemInput";
                readonly outputTypeName: "CreateStockItemOutput";
                readonly input: readonly [{
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Nome do insumo";
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "unitOfMeasure";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Unidade de medida do insumo (ex: kg, unidade, litro)";
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "minimumQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade mínima para alerta de estoque baixo";
                    readonly ofEntity: "StockItem";
                }];
                readonly output: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador único gerado automaticamente";
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "unitOfMeasure";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "minimumQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status do item de estoque (active/inactive)";
                    readonly ofEntity: "StockItem";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["lowStockAlert"];
                readonly transactional: true;
                readonly steps: readonly ["1. Validate that name, unitOfMeasure and minimumQuantity are provided and non-empty", "2. Generate stockItemId via ctx.idGenerator.uuid()", "3. Resolve createdAt and updatedAt from ctx.clock.now()", "4. Set status to 'active' for newly created stock items", "5. Instantiate StockItem aggregate with provided name, unitOfMeasure, minimumQuantity and generated stockItemId, createdAt, updatedAt, status", "6. Apply lowStockAlert rule: evaluate whether the item's minimumQuantity threshold is configured for low-stock alerting", "7. Persist StockItem through its repository port inside a transaction", "8. Return projected output: stockItemId, name, unitOfMeasure, minimumQuantity, status"];
            }];
            readonly mdmRefs: readonly ["StockItem"];
        };
    };
    export default createStockItemUsecase;
    export const pipeline: readonly [{
        readonly id: "createStockItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/createStockItem.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/createStockItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/createStockMovement.defs" {
    export const createStockMovementUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createStockMovement";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createStockMovement";
            readonly ports: readonly ["StockLevel"];
            readonly functions: readonly [{
                readonly functionName: "createStockMovement";
                readonly inputTypeName: "CreateStockMovementInput";
                readonly outputTypeName: "CreateStockMovementOutput";
                readonly input: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Identificador do item de estoque (insumo) selecionado para baixa";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade consumida do insumo";
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Motivo da movimentação de estoque";
                }, {
                    readonly name: "movementType";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Tipo da movimentação: baixa ou reposicao";
                }];
                readonly output: readonly [{
                    readonly name: "stockMovementEventId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockMovementEvent";
                    readonly description: "UUID gerado para o evento de movimentação";
                }, {
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Item de estoque associado ao evento";
                }, {
                    readonly name: "movementType";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Tipo da movimentação registrada";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade movimentada";
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Motivo da movimentação";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Data/hora de criação do evento";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Data/hora de atualização do evento";
                }, {
                    readonly name: "currentQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockLevel";
                    readonly description: "Quantidade atual do nível de estoque após a movimentação";
                }];
                readonly ports: readonly ["StockLevel"];
                readonly rulesApplied: readonly ["stockDecrementOnPreparing"];
                readonly transactional: true;
                readonly steps: readonly ["1. Gerar stockMovementEventId via ctx.idGenerator e timestamps createdAt/updatedAt via ctx.clock", "2. Validar que quantity > 0 e movementType pertence ao enum [baixa, reposicao]", "3. Carregar StockLevel pelo stockItemId através da porta StockLevel (lookup por stockItemId)", "4. Aplicar regra stockDecrementOnPreparing: se movementType = 'baixa', decrementar currentQuantity pela quantity; se 'reposicao', incrementar currentQuantity pela quantity", "5. Validar que o novo currentQuantity não fica negativo quando movementType = 'baixa'", "6. Atualizar StockLevel: currentQuantity recalculado, lastMovementAt = now, updatedAt = now — salvar via porta StockLevel", "7. Criar registro StockMovementEvent com stockMovementEventId, stockItemId, movementType, quantity, reason, createdAt, updatedAt — salvar via porta StockMovementEvent", "8. Retornar o evento criado e o currentQuantity atualizado do StockLevel"];
            }];
            readonly mdmRefs: readonly ["StockItem"];
        };
    };
    export default createStockMovementUsecase;
    export const pipeline: readonly [{
        readonly id: "createStockMovement__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/createStockMovement.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/createStockMovement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/createTable.defs" {
    export const createTableUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createTable";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createTable";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "createTable";
                readonly inputTypeName: "CreateTableInput";
                readonly outputTypeName: "CreateTableOutput";
                readonly input: readonly [{
                    readonly name: "number";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Número ou código de identificação visual da mesa (ex: 01, 12, A3)";
                    readonly ofEntity: "Table";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Nome ou descrição opcional da mesa (ex: 'Mesa da Janela')";
                    readonly ofEntity: "Table";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Situação da mesa no sistema (active ou inactive)";
                    readonly ofEntity: "Table";
                }];
                readonly output: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador único da mesa gerado pelo sistema";
                    readonly ofEntity: "Table";
                }, {
                    readonly name: "number";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Número ou código de identificação visual da mesa";
                    readonly ofEntity: "Table";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Nome ou descrição da mesa";
                    readonly ofEntity: "Table";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Situação da mesa no sistema";
                    readonly ofEntity: "Table";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Data e hora de criação do registro";
                    readonly ofEntity: "Table";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do registro";
                    readonly ofEntity: "Table";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["tableId gerado automaticamente via ctx.idGenerator", "createdAt e updatedAt definidos automaticamente via ctx.clock", "status deve ser um dos valores permitidos: active | inactive", "number é obrigatório e informado pelo gerente"];
                readonly transactional: true;
                readonly steps: readonly ["1. Validar que number não é vazio e status é 'active' ou 'inactive'", "2. Gerar tableId automaticamente via ctx.idGenerator", "3. Definir createdAt e updatedAt com o timestamp atual via ctx.clock", "4. Construir a entidade Table com os dados de entrada e os valores gerados pelo sistema", "5. Persistir a nova mesa através do TablePort dentro de uma transação", "6. Retornar os dados da mesa criada (tableId, number, name, status, createdAt, updatedAt)"];
            }];
            readonly mdmRefs: readonly ["Table"];
        };
    };
    export default createTableUsecase;
    export const pipeline: readonly [{
        readonly id: "createTable__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/createTable.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/createTable.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/deleteComboRule.defs" {
    export const deleteComboRuleUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "deleteComboRule";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "deleteComboRule";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "deleteComboRule";
                readonly inputTypeName: "DeleteComboRuleInput";
                readonly outputTypeName: "DeleteComboRuleOutput";
                readonly input: readonly [{
                    readonly name: "comboRuleId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                    readonly description: "Identificador único da regra de combo selecionada para exclusão, resolvido a partir da entidade selecionada no fluxo";
                }];
                readonly output: readonly [{
                    readonly name: "comboRuleId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                    readonly description: "Identificador da regra de combo excluída";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status da operação de exclusão";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["comboPriceDifference"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolver comboRuleId a partir da entidade selecionada no fluxo (contextResolution: selectedEntity)", "2. Carregar o ComboRule pelo comboRuleId via ctx.data.mdmDocument.get({ mdmId: comboRuleId })", "3. Validar que o ComboRule existe; se não existir, retornar erro de não encontrado", "4. Aplicar regra comboPriceDifference: validar que não há pedidos ativos referenciando esta regra de combo antes de permitir a exclusão", "5. Excluir o ComboRule via ctx.data.mdmDocument.delete({ mdmId: comboRuleId }) dentro da transação", "6. Retornar comboRuleId e status 'deleted' confirmando a exclusão"];
            }];
            readonly rulesApplied: readonly ["comboPriceDifference"];
            readonly mdmRefs: readonly ["ComboRule"];
        };
    };
    export default deleteComboRuleUsecase;
    export const pipeline: readonly [{
        readonly id: "deleteComboRule__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/deleteComboRule.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/deleteComboRule.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["comboPriceDifference"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/deleteMenuItem.defs" {
    export const deleteMenuItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "deleteMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "deleteMenuItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "deleteMenuItem";
                readonly inputTypeName: "DeleteMenuItemInput";
                readonly outputTypeName: "DeleteMenuItemOutput";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Identificador único do item do cardápio a ser removido, resolvido a partir da entidade previamente selecionada na jornada";
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Identificador do item removido";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Status final do item após a remoção (inactive)";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["comboPriceDifference"];
                readonly transactional: true;
                readonly steps: readonly ["Resolver menuItemId a partir do contexto selectedEntity (entidade previamente selecionada na jornada)", "Carregar o MenuItem via ctx.data.mdmDocument.get({ mdmId: menuItemId }) — MenuItem é master data no store compartilhado, sem port dedicado", "Validar que o item existe e está atualmente ativo (status = active); se não existir, lançar erro de não encontrado", "Aplicar regra comboPriceDifference: verificar se o item participa de algum combo ativo e, em caso afirmativo, avaliar o impacto de preço nos combos relacionados antes de prosseguir com a remoção", "Executar soft-delete: definir status do item para 'inactive', tornando-o indisponível para novos pedidos", "Persistir o MenuItem atualizado via ctx.data.mdmDocument dentro da mesma transação", "Retornar menuItemId e status confirmando a remoção lógica"];
            }];
            readonly rulesApplied: readonly ["comboPriceDifference"];
            readonly mdmRefs: readonly ["MenuItem"];
        };
    };
    export default deleteMenuItemUsecase;
    export const pipeline: readonly [{
        readonly id: "deleteMenuItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/deleteMenuItem.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/deleteMenuItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["comboPriceDifference"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/deleteStockItem.defs" {
    export const deleteStockItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "deleteStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "deleteStockItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "deleteStockItem";
                readonly inputTypeName: "DeleteStockItemInput";
                readonly outputTypeName: "DeleteStockItemOutput";
                readonly input: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Identificador único do item de estoque a ser removido, resolvido da entidade selecionada na jornada";
                }];
                readonly output: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Id do item de estoque removido";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status da operação de exclusão";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["lowStockAlert"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolver stockItemId a partir da entidade selecionada no contexto de navegação (selectedEntity)", "2. Carregar o StockItem pelo stockItemId através do port StockItem.getById", "3. Validar que o item existe; se não existir, retornar erro de não encontrado", "4. Aplicar regra lowStockAlert: verificar se o item possuía quantidade abaixo do mínimo e registrar alerta de remoção de item crítico", "5. Excluir permanentemente o StockItem através do port StockItem.delete dentro da mesma transação", "6. Retornar stockItemId e status confirmando a remoção"];
            }];
            readonly mdmRefs: readonly ["StockItem"];
        };
    };
    export default deleteStockItemUsecase;
    export const pipeline: readonly [{
        readonly id: "deleteStockItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/deleteStockItem.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/deleteStockItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/deleteTable.defs" {
    export const deleteTableUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "deleteTable";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "deleteTable";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "deleteTable";
                readonly inputTypeName: "DeleteTableInput";
                readonly outputTypeName: "DeleteTableOutput";
                readonly input: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Identificador único da mesa a ser removida, obtido da seleção prévia no fluxo";
                }];
                readonly output: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Identificador da mesa removida";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status da operação de exclusão";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["1. Receber tableId resolvido da seleção prévia no fluxo (contextResolution: selectedEntity)", "2. Carregar o aggregate Table pelo tableId através do port Table", "3. Validar que a mesa existe; se não existir, retornar erro de não encontrado", "4. Verificar pré-condição de confirmação do gerente (garantida pela camada de apresentação antes da chamada)", "5. Executar a remoção do registro da mesa no aggregate Table", "6. Persistir a exclusão através do port Table dentro da mesma transação", "7. Retornar tableId e status indicando sucesso da exclusão"];
            }];
            readonly rulesApplied: readonly [];
            readonly mdmRefs: readonly ["Table"];
        };
    };
    export default deleteTableUsecase;
    export const pipeline: readonly [{
        readonly id: "deleteTable__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/deleteTable.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/deleteTable.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/generateShiftClosingReport.defs" {
    export const generateShiftClosingReportUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "generateShiftClosingReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "generateShiftClosingReport";
            readonly ports: readonly ["Shift", "Order", "OrderItem", "OrderStatusEvent", "ShiftStatusEvent"];
            readonly functions: readonly [{
                readonly functionName: "generateShiftClosingReport";
                readonly inputTypeName: "GenerateShiftClosingReportInput";
                readonly outputTypeName: "GenerateShiftClosingReportOutput";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Identificador do turno selecionado para geração do relatório de fechamento";
                }];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Identificador do turno";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Status final do turno (closed)";
                }, {
                    readonly name: "openedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Data e hora de abertura do turno";
                }, {
                    readonly name: "closedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Data e hora de fechamento do turno";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Número total de pedidos do turno";
                }, {
                    readonly name: "dineInOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade de pedidos do tipo dineIn";
                }, {
                    readonly name: "takeoutOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade de pedidos do tipo takeout";
                }, {
                    readonly name: "deliveredOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade de pedidos entregues (delivered)";
                }, {
                    readonly name: "cancelledOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade de pedidos cancelados";
                }, {
                    readonly name: "grossRevenue";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Faturamento bruto — soma dos totais dos pedidos entregues";
                }, {
                    readonly name: "netRevenue";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Faturamento líquido — faturamento bruto descontando pedidos cancelados";
                }, {
                    readonly name: "totalOrderItems";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Número total de itens de pedido processados no turno";
                }];
                readonly ports: readonly ["Shift", "Order", "OrderItem"];
                readonly rulesApplied: readonly ["shiftClosingRequiresSettledOrders"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolver shiftId a partir da entidade selecionada no contexto do fluxo de trabalho", "2. Carregar o Shift pelo shiftId através da porta Shift (getById)", "3. Validar que o turno existe e possui status = 'closed'; caso contrário, lançar erro de turno não fechado", "4. Carregar todos os Orders associados ao shiftId através da porta Order (list por shiftId)", "5. Aplicar regra shiftClosingRequiresSettledOrders: verificar que todos os pedidos estão em status terminal (delivered ou cancelled); se houver pedidos pendentes/inKitchen/preparing/ready, lançar erro indicando pedidos não finalizados", "6. Para cada pedido, carregar os OrderItems correspondentes através da porta OrderItem (list por orderId)", "7. Agregar pedidos por tipo (dineIn/takeout) e por status (delivered/cancelled)", "8. Calcular faturamento bruto somando o total dos pedidos delivered", "9. Calcular faturamento líquido subtraindo o total dos pedidos cancelled do faturamento bruto", "10. Contar o número total de OrderItems processados", "11. Retornar relatório consolidado com shiftSummary, ordersAggregation e revenueTotals"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default generateShiftClosingReportUsecase;
    export const pipeline: readonly [{
        readonly id: "generateShiftClosingReport__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/generateShiftClosingReport.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/generateShiftClosingReport.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/orderItemRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/shiftStatusEventRepository.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/orderItem.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/shiftStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/openShift.defs" {
    export const openShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "openShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "openShift";
            readonly ports: readonly ["Shift", "ShiftStatusEvent"];
            readonly functions: readonly [{
                readonly functionName: "openShift";
                readonly inputTypeName: "OpenShiftInput";
                readonly outputTypeName: "OpenShiftOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "System-generated UUID for the new shift";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Shift status set to 'open' by workflow state";
                }, {
                    readonly name: "openedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Timestamp when the shift was opened";
                }];
                readonly ports: readonly ["Shift", "ShiftStatusEvent"];
                readonly rulesApplied: readonly ["orderRequiresOpenShift", "shiftClosingRequiresSettledOrders"];
                readonly transactional: true;
                readonly steps: readonly ["Resolve shiftId from ctx.idGenerator (systemDefault.uuid)", "Set status to 'open' per workflow state", "Resolve openedAt, createdAt, updatedAt from ctx.clock (systemDefault.now)", "Create Shift aggregate via Shift port inside transaction", "Build ShiftStatusEvent record: shiftStatusEventId from ctx.idGenerator, shiftId referencing the new shift, eventType 'abertura', consolidatedTotal 0, recordedAt/createdAt/updatedAt from ctx.clock", "Append ShiftStatusEvent via ShiftStatusEvent port inside the same transaction", "Return shiftId, status, openedAt"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default openShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "openShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/openShift.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/openShift.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/shiftStatusEventRepository.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/shiftStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/queryComboRules.defs" {
    export const queryComboRulesUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "queryComboRules";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "queryComboRules";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "queryComboRules";
                readonly inputTypeName: "QueryComboRulesInput";
                readonly outputTypeName: "QueryComboRulesOutput";
                readonly input: readonly [{
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Filtro opcional pela situação da regra (active ou inactive)";
                    readonly ofEntity: "ComboRule";
                }, {
                    readonly name: "nameContains";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Termo de busca opcional pelo nome da regra";
                    readonly ofEntity: "ComboRule";
                }];
                readonly output: readonly [{
                    readonly name: "comboRuleId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                }, {
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "ComboRule";
                }, {
                    readonly name: "priceDifference";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                }, {
                    readonly name: "menuItemName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["comboPriceDifference"];
                readonly transactional: false;
                readonly steps: readonly ["Resolve workspaceId from current workspace context (RequestContext metadata) — not user input", "Query ComboRule records from MDM store (ctx.data.mdmDocument) filtered by workspaceId, optional status filter, optional nameContains search", "For each ComboRule result, fetch referenced MenuItem by menuItemId via ctx.data.mdmDocument.get to obtain MenuItem.name", "Apply comboPriceDifference rule to validate priceDifference is surfaced correctly for each returned rule", "Return results sorted by ComboRule.createdAt ascending with joined MenuItem.name as menuItemName"];
            }];
            readonly mdmRefs: readonly ["ComboRule", "MenuItem"];
        };
    };
    export default queryComboRulesUsecase;
    export const pipeline: readonly [{
        readonly id: "queryComboRules__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/queryComboRules.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/queryComboRules.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/queryDashboard.defs" {
    export const queryDashboardUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "queryDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "queryDashboard";
            readonly ports: readonly ["Shift", "Order", "OrderItem", "StockLevel", "OrderStatusEvent", "ShiftStatusEvent"];
            readonly functions: readonly [{
                readonly functionName: "queryDashboard";
                readonly inputTypeName: "QueryDashboardInput";
                readonly outputTypeName: "ShiftDashboardAggregation";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Identificador do turno ativo cujos dados serão agregados no dashboard, resolvido a partir da instância ativa do ciclo de vida de turno diário";
                }];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly ofEntity: "Shift";
                    readonly description: "ID do turno agregado";
                }, {
                    readonly name: "shiftStatus";
                    readonly type: "string";
                    readonly ofEntity: "Shift";
                    readonly description: "Status atual do turno (open ou closed)";
                }, {
                    readonly name: "openedAt";
                    readonly type: "string";
                    readonly ofEntity: "Shift";
                    readonly description: "Data e hora de abertura do turno";
                }, {
                    readonly name: "closedAt";
                    readonly type: "string";
                    readonly ofEntity: "Shift";
                    readonly description: "Data e hora de fechamento do turno, se aplicável";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                    readonly description: "Número total de pedidos do turno";
                }, {
                    readonly name: "totalRevenue";
                    readonly type: "number";
                    readonly description: "Receita total consolidada do turno (soma dos totais de pedidos entregues e prontos)";
                }, {
                    readonly name: "pendingOrdersCount";
                    readonly type: "number";
                    readonly description: "Quantidade de pedidos pendentes";
                }, {
                    readonly name: "preparingOrdersCount";
                    readonly type: "number";
                    readonly description: "Quantidade de pedidos em preparo (inKitchen ou preparing)";
                }, {
                    readonly name: "readyOrdersCount";
                    readonly type: "number";
                    readonly description: "Quantidade de pedidos prontos para entrega";
                }, {
                    readonly name: "deliveredOrdersCount";
                    readonly type: "number";
                    readonly description: "Quantidade de pedidos entregues";
                }, {
                    readonly name: "cancelledOrdersCount";
                    readonly type: "number";
                    readonly description: "Quantidade de pedidos cancelados";
                }, {
                    readonly name: "lowStockCount";
                    readonly type: "number";
                    readonly description: "Quantidade de itens de estoque abaixo do nível mínimo";
                }];
                readonly ports: readonly ["Shift", "Order", "OrderItem", "StockLevel"];
                readonly rulesApplied: readonly ["orderRequiresOpenShift", "shiftClosingRequiresSettledOrders"];
                readonly transactional: false;
                readonly steps: readonly ["Resolver shiftId a partir da instância ativa do ciclo de vida de turno diário (contextResolution: activeLifecycleInstance)", "Carregar o Shift pelo shiftId via porta Shift (getById); validar que o turno existe", "Validar regra orderRequiresOpenShift: o turno deve estar com status 'open' para que o dashboard exiba dados em tempo real", "Carregar todos os Orders do turno via porta Order, filtrando por shiftId", "Carregar os OrderItems dos pedidos via porta OrderItem para detalhamento de itens", "Agrupar pedidos por status (pending, inKitchen, preparing, ready, delivered, cancelled) e calcular contadores", "Calcular totalRevenue somando o campo total dos pedidos com status delivered ou ready", "Carregar StockLevels via porta StockLevel e, para cada stockItemId, ler o StockItem correspondente no MDM (ctx.data.mdmDocument.get) para obter minimumQuantity", "Contar quantos StockLevels possuem currentQuantity abaixo do minimumQuantity do StockItem referenciado (lowStockCount)", "Montar e retornar o ShiftDashboardAggregation com todas as métricas consolidadas"];
            }];
            readonly mdmRefs: readonly ["StockItem", "MenuItem"];
        };
    };
    export default queryDashboardUsecase;
    export const pipeline: readonly [{
        readonly id: "queryDashboard__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/queryDashboard.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/queryDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/orderItemRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/shiftStatusEventRepository.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/orderItem.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/shiftStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/queryMenuItems.defs" {
    export const queryMenuItemsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "queryMenuItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "queryMenuItems";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "queryMenuItems";
                readonly inputTypeName: "QueryMenuItemsInput";
                readonly outputTypeName: "QueryMenuItemsOutput";
                readonly input: readonly [{
                    readonly name: "categoryFilter";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Categoria do item para filtrar a lista";
                }, {
                    readonly name: "nameFilter";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Termo de busca pelo nome do item";
                }, {
                    readonly name: "workspaceId";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Escopo do workspace atual, resolvido do RequestContext (currentWorkspace)";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Número da página para paginação opcional";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Tamanho da página para paginação opcional";
                }];
                readonly output: readonly [{
                    readonly name: "items";
                    readonly type: "MenuItem[]";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Lista paginada de itens do cardápio projetados";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Total de itens encontrados conforme os filtros aplicados";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["comboPriceDifference"];
                readonly transactional: false;
                readonly steps: readonly ["Resolver workspaceId a partir do RequestContext (currentWorkspace.workspaceId)", "Consultar MenuItem no mdm store via ctx.data.mdmDocument aplicando filtro opcional por category (categoryFilter) e por name (nameFilter, busca parcial) dentro do escopo do workspaceId", "Aplicar regra comboPriceDifference para calcular diferenças de preço em itens de combo durante a projeção", "Ordenar resultados por MenuItem.name em ordem ascendente", "Aplicar paginação opcional (page/pageSize) quando fornecida", "Projetar campos: menuItemId, name, category, price, description, status, createdAt, updatedAt", "Retornar lista projetada e total de itens encontrados"];
            }];
            readonly mdmRefs: readonly ["MenuItem"];
        };
    };
    export default queryMenuItemsUsecase;
    export const pipeline: readonly [{
        readonly id: "queryMenuItems__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/queryMenuItems.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/queryMenuItems.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/queryStockItems.defs" {
    export const queryStockItemsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "queryStockItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "queryStockItems";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "queryStockItems";
                readonly inputTypeName: "QueryStockItemsInput";
                readonly outputTypeName: "QueryStockItemsOutput";
                readonly input: readonly [{
                    readonly name: "nameFilter";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Termo para filtrar pelo nome do insumo";
                }, {
                    readonly name: "statusFilter";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Status para filtrar os itens de estoque (active | inactive)";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Número da página para paginação opcional";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Tamanho da página para paginação opcional";
                }];
                readonly output: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Identificador do item de estoque";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Nome do insumo";
                }, {
                    readonly name: "unitOfMeasure";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Unidade de medida do insumo";
                }, {
                    readonly name: "minimumQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Quantidade mínima de estoque";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Status do item (active | inactive)";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Data de criação do item";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Data de atualização do item";
                }, {
                    readonly name: "lowStockAlert";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly description: "Indicador computado pela regra lowStockAlert sinalizando itens em nível crítico";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Total de itens correspondentes aos filtros";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Página atual retornada";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Tamanho da página retornada";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["lowStockAlert"];
                readonly transactional: false;
                readonly steps: readonly ["1. Receber filtros opcionais nameFilter e statusFilter do gerente", "2. Consultar documentos MDM de StockItem via ctx.data.mdmDocument aplicando filtros de nome (contains) e status (equals) quando informados", "3. Aplicar paginação opcional quando page e pageSize forem fornecidos; caso contrário retornar todos os resultados", "4. Aplicar regra lowStockAlert: marcar lowStockAlert=true para itens cuja quantidade atual esteja abaixo de minimumQuantity", "5. Ordenar resultados por name (asc) como ordenação padrão", "6. Projetar campos stockItemId, name, unitOfMeasure, minimumQuantity, status, createdAt, updatedAt e o flag computado lowStockAlert", "7. Retornar lista paginada com metadados total, page e pageSize"];
            }];
            readonly mdmRefs: readonly ["StockItem"];
        };
    };
    export default queryStockItemsUsecase;
    export const pipeline: readonly [{
        readonly id: "queryStockItems__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/queryStockItems.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/queryStockItems.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/queryStockLevels.defs" {
    export const queryStockLevelsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "queryStockLevels";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "queryStockLevels";
            readonly ports: readonly ["StockLevel"];
            readonly functions: readonly [{
                readonly functionName: "queryStockLevels";
                readonly inputTypeName: "QueryStockLevelsInput";
                readonly outputTypeName: "QueryStockLevelsOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "stockLevelId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockLevel";
                    readonly description: "Unique identifier of the stock level record";
                }, {
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockLevel";
                    readonly description: "Reference to the StockItem master data entity";
                }, {
                    readonly name: "itemName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Name of the stock item resolved from MDM";
                }, {
                    readonly name: "unitOfMeasure";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Unit of measure of the stock item resolved from MDM";
                }, {
                    readonly name: "currentQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockLevel";
                    readonly description: "Current quantity available in stock";
                }, {
                    readonly name: "minimumQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Minimum quantity threshold for low stock alert, resolved from MDM";
                }, {
                    readonly name: "lastMovementAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockLevel";
                    readonly description: "Timestamp of the last stock movement";
                }, {
                    readonly name: "isLowStock";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly description: "Computed flag: true when currentQuantity is below minimumQuantity (lowStockAlert rule)";
                }];
                readonly ports: readonly ["StockLevel"];
                readonly rulesApplied: readonly ["stockDecrementOnPreparing", "lowStockAlert"];
                readonly transactional: false;
                readonly steps: readonly ["Load all StockLevel records via the StockLevel port (list operation)", "For each StockLevel, resolve the referenced StockItem master data by id via ctx.data.mdmDocument.get({ mdmId: stockItemId })", "Enrich each StockLevel projection with StockItem.name, StockItem.unitOfMeasure, and StockItem.minimumQuantity", "Apply the lowStockAlert rule: compute isLowStock = (currentQuantity < minimumQuantity) for each item", "Return the enriched list of stock levels including the isLowStock flag so items below minimum are identifiable", "This operation is read-only and does not alter stock state"];
            }];
            readonly mdmRefs: readonly ["StockItem"];
        };
    };
    export default queryStockLevelsUsecase;
    export const pipeline: readonly [{
        readonly id: "queryStockLevels__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/queryStockLevels.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/queryStockLevels.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/queryTables.defs" {
    export const queryTablesUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "queryTables";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "queryTables";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "queryTables";
                readonly inputTypeName: "QueryTablesInput";
                readonly outputTypeName: "QueryTablesOutput";
                readonly input: readonly [{
                    readonly name: "statusFilter";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                    readonly description: "Filtro opcional por situação da mesa (active ou inactive)";
                }, {
                    readonly name: "numberFilter";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                    readonly description: "Filtro opcional pelo número ou código visual da mesa";
                }];
                readonly output: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Identificador único da mesa, chave primária para seleção";
                }, {
                    readonly name: "number";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Número ou código visual da mesa";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                    readonly description: "Nome descritivo da mesa, se definido";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Situação da mesa (active ou inactive)";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Data e hora de criação da mesa";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Data e hora da última atualização da mesa";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Total de registros correspondentes aos filtros (para paginação)";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Resolver workspaceId a partir do RequestContext (currentWorkspace) para escopo e segurança", "Construir critério de filtro com statusFilter e numberFilter opcionais, sempre escopado por workspaceId", "Consultar TableRepository aplicando filtros, ordenação por number e createdAt, e paginação opcional", "Projetar resultado em lista de mesas com tableId, number, name, status, createdAt, updatedAt", "Retornar coleção paginada com total de registros correspondentes"];
            }];
            readonly mdmRefs: readonly ["Table"];
        };
    };
    export default queryTablesUsecase;
    export const pipeline: readonly [{
        readonly id: "queryTables__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/queryTables.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/queryTables.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/settleOrder.defs" {
    export const settleOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "settleOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "settleOrder";
            readonly ports: readonly ["Order", "OrderStatusEvent"];
            readonly functions: readonly [{
                readonly functionName: "settleOrder";
                readonly inputTypeName: "SettleOrderInput";
                readonly outputTypeName: "SettleOrderOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Identificador do pedido selecionado para finalização, resolvido a partir da entidade selecionada na jornada do atendente";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Identificador do pedido finalizado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Status final do pedido após a transição (delivered)";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Data/hora da última atualização do pedido";
                }, {
                    readonly name: "orderStatusEventId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderStatusEvent";
                    readonly description: "Identificador do evento de transição de status registrado no histórico";
                }];
                readonly ports: readonly ["Order", "OrderStatusEvent"];
                readonly rulesApplied: readonly ["orderRequiresOpenShift", "shiftClosingRequiresSettledOrders"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolver orderId a partir da entidade selecionada (selectedEntity) no contexto da jornada do atendente", "2. Carregar o aggregate Order pelo orderId através do port Order", "3. Validar regra orderRequiresOpenShift: verificar que o turno vinculado ao pedido (Order.shiftId) está em aberto; se não estiver, abortar com erro de domínio", "4. Capturar o status atual do pedido (previousStatus) para registro no evento de histórico", "5. Transicionar Order.status para 'delivered' (resolvido via workflowState)", "6. Atribuir Order.updatedAt com ctx.clock.now()", "7. Gerar orderStatusEventId via ctx.idGenerator para o novo OrderStatusEvent", "8. Construir registro OrderStatusEvent com orderId, status='entregue', previousStatus mapeado do status anterior, createdAt=now, updatedAt=now", "9. Persistir o Order atualizado através do port Order dentro da transação", "10. Anexar o OrderStatusEvent através do port OrderStatusEvent dentro da mesma transação (evento imutável de auditoria)", "11. Retornar orderId, status, updatedAt e orderStatusEventId como confirmação da operação"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default settleOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "settleOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/settleOrder.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/settleOrder.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/updateComboRule.defs" {
    export const updateComboRuleUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateComboRule";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateComboRule";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateComboRule";
                readonly inputTypeName: "UpdateComboRuleInput";
                readonly outputTypeName: "UpdateComboRuleOutput";
                readonly input: readonly [{
                    readonly name: "comboRuleId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                    readonly description: "Identificador único da regra de combo, resolvido da entidade selecionada no contexto da jornada";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                    readonly description: "Nome descritivo da regra";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "ComboRule";
                    readonly description: "Detalhamento da regra e condições de aplicação";
                }, {
                    readonly name: "priceDifference";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                    readonly description: "Diferença de preço aplicada no combo ou substituição";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                    readonly description: "Situação da regra no ciclo de vida (active | inactive)";
                }];
                readonly output: readonly [{
                    readonly name: "comboRuleId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                    readonly description: "Identificador da regra atualizada";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                    readonly description: "Nome atualizado da regra";
                }, {
                    readonly name: "priceDifference";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                    readonly description: "Diferença de preço atualizada";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                    readonly description: "Situação atualizada da regra";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ComboRule";
                    readonly description: "Data e hora da última atualização";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["comboPriceDifference"];
                readonly transactional: true;
                readonly steps: readonly ["1. Carregar ComboRule pelo comboRuleId (resolvido do contexto de entidade selecionada) através do ComboRulePort.getById", "2. Validar que a ComboRule existe; se não existir, lançar erro de não encontrado", "3. Ler o MenuItem referenciado pela ComboRule.menuItemId via ctx.data.mdmDocument.get({ mdmId: comboRule.menuItemId }) para obter o preço base", "4. Aplicar a regra comboPriceDifference: validar que o priceDifference informado é consistente com o preço do MenuItem (não negativo, dentro de limites aceitáveis)", "5. Atualizar os campos name, description, priceDifference e status na entidade ComboRule carregada", "6. Definir updatedAt = ctx.clock.now()", "7. Salvar a ComboRule atualizada através do ComboRulePort.save dentro da mesma transação", "8. Retornar comboRuleId, name, priceDifference, status e updatedAt"];
            }];
            readonly mdmRefs: readonly ["ComboRule", "MenuItem"];
        };
    };
    export default updateComboRuleUsecase;
    export const pipeline: readonly [{
        readonly id: "updateComboRule__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/updateComboRule.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/updateComboRule.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/updateKitchenStatus.defs" {
    export const updateKitchenStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateKitchenStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateKitchenStatus";
            readonly ports: readonly ["Order", "OrderStatusEvent"];
            readonly functions: readonly [{
                readonly functionName: "updateKitchenStatus";
                readonly inputTypeName: "UpdateKitchenStatusInput";
                readonly outputTypeName: "UpdateKitchenStatusOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderStatusEvent";
                    readonly description: "Referência ao pedido cujo status será atualizado, obtido do ticket selecionado na fila de cozinha.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderStatusEvent";
                    readonly description: "Novo status de preparo informado pelo cozinheiro (criado, em preparo, pronto, entregue, cancelado).";
                }];
                readonly output: readonly [{
                    readonly name: "orderStatusEventId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderStatusEvent";
                    readonly description: "Identificador único do evento de transição criado.";
                }, {
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderStatusEvent";
                    readonly description: "Pedido cujo status foi atualizado.";
                }, {
                    readonly name: "previousStatus";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "OrderStatusEvent";
                    readonly description: "Status anterior do pedido antes da transição.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderStatusEvent";
                    readonly description: "Novo status aplicado ao pedido.";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "OrderStatusEvent";
                    readonly description: "Data/hora de criação do evento.";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["validate-status-enum: o status informado deve ser um dos valores permitidos (criado, em preparo, pronto, entregue, cancelado)", "resolve-previous-status: o status anterior é obtido automaticamente do estado atual do pedido carregado via porta Order", "generate-event-id: orderStatusEventId é gerado automaticamente pelo sistema via uuid", "auto-timestamps: createdAt e updatedAt são atribuídos automaticamente com o relógio do sistema", "validate-order-exists: o pedido referenciado por orderId deve existir e estar carregado antes de criar o evento"];
                readonly transactional: true;
                readonly steps: readonly ["1. Receber orderId (do ticket selecionado) e status (informado pelo cozinheiro) como entrada", "2. Validar que status é um valor permitido do enum (criado, em preparo, pronto, entregue, cancelado)", "3. Carregar o Order pelo orderId através da porta Order para obter o status atual", "4. Extrair previousStatus a partir de Order.status carregado", "5. Gerar orderStatusEventId via ctx.idGenerator.uuid()", "6. Obter createdAt e updatedAt via ctx.clock.now()", "7. Construir o OrderStatusEvent com orderId, status, previousStatus, orderStatusEventId, createdAt e updatedAt", "8. Persistir o OrderStatusEvent através da porta Order (mesma transação)", "9. Retornar orderStatusEventId, orderId, previousStatus, status e createdAt"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateKitchenStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateKitchenStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/updateKitchenStatus.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/updateKitchenStatus.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102049_/l1/cafeFlow/layer_2_application/ports/orderStatusEventRepository.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102049_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/updateMenuItem.defs" {
    export const updateMenuItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateMenuItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateMenuItem";
                readonly inputTypeName: "UpdateMenuItemInput";
                readonly outputTypeName: "UpdateMenuItemOutput";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Identificador único do item a ser editado, resolvido a partir da seleção prévia no fluxo";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Nome do item do cardápio";
                }, {
                    readonly name: "category";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Categoria do item (entradas, pratos principais, bebidas, sobremesas)";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Preço de venda do item";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Descrição detalhada do item";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Status do ciclo de vida do item (active/inactive)";
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Identificador do item atualizado";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Nome atualizado do item";
                }, {
                    readonly name: "category";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Categoria atualizada do item";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Preço atualizado do item";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Descrição atualizada do item";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Status atualizado do item";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Data e hora da última atualização definida automaticamente pelo sistema";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["comboPriceDifference"];
                readonly transactional: true;
                readonly steps: readonly ["1. Carregar o MenuItem existente pelo menuItemId fornecido (resolvido da seleção prévia) através do port MenuItem", "2. Validar que o item existe; se não existir, lançar erro de entidade não encontrada", "3. Aplicar a regra comboPriceDifference: se o item pertence a um combo, verificar se a alteração de preço não viola a diferença mínima/máxima permitida em relação ao preço do combo pai", "4. Atualizar os campos name, category, price, description e status com os valores recebidos na entrada", "5. Definir updatedAt automaticamente com ctx.clock.now() — nunca aceitar updatedAt do usuário", "6. Preservar menuItemId e createdAt originais (campos de controle não fornecidos pelo usuário)", "7. Salvar o MenuItem atualizado através do port MenuItem dentro da mesma transação", "8. Retornar o MenuItem atualizado com todos os campos persistidos"];
            }];
            readonly mdmRefs: readonly ["MenuItem"];
        };
    };
    export default updateMenuItemUsecase;
    export const pipeline: readonly [{
        readonly id: "updateMenuItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/updateMenuItem.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/updateMenuItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/updateStockItem.defs" {
    export const updateStockItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateStockItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateStockItem";
                readonly inputTypeName: "UpdateStockItemInput";
                readonly outputTypeName: "UpdateStockItemOutput";
                readonly input: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Identificador único do item de estoque a ser editado, obtido da entidade selecionada no journey";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Nome do insumo";
                }, {
                    readonly name: "unitOfMeasure";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Unidade de medida do insumo (ex: kg, unidade, litro)";
                }, {
                    readonly name: "minimumQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Quantidade mínima para alerta de estoque baixo";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Status do item de estoque (active ou inactive)";
                }];
                readonly output: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Identificador do item de estoque atualizado";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Nome atualizado do insumo";
                }, {
                    readonly name: "unitOfMeasure";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Unidade de medida atualizada";
                }, {
                    readonly name: "minimumQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Quantidade mínima atualizada";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Status atualizado do item de estoque";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Data e hora da última atualização gerada automaticamente pelo sistema";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["lowStockAlert"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load StockItem aggregate by stockItemId via StockItem port (getById)", "2. Validate that the StockItem exists; throw not-found error if absent", "3. Validate that status is one of 'active' or 'inactive'", "4. Validate that minimumQuantity is a non-negative number", "5. Apply updated fields (name, unitOfMeasure, minimumQuantity, status) to the StockItem aggregate", "6. Set updatedAt to ctx.clock.now() (system-generated, not user input)", "7. Evaluate lowStockAlert rule: if the item's current quantity is at or below the new minimumQuantity threshold and status is 'active', flag the item for low-stock alert", "8. Save the StockItem aggregate via StockItem port within the transaction", "9. Return the updated StockItem projection (stockItemId, name, unitOfMeasure, minimumQuantity, status, updatedAt)"];
            }];
            readonly mdmRefs: readonly ["StockItem"];
        };
    };
    export default updateStockItemUsecase;
    export const pipeline: readonly [{
        readonly id: "updateStockItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/updateStockItem.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/updateStockItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_2_application/usecases/updateTable.defs" {
    export const updateTableUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateTable";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateTable";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateTable";
                readonly inputTypeName: "UpdateTableInput";
                readonly outputTypeName: "UpdateTableOutput";
                readonly input: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Identificador único da mesa a ser editada, resolvido a partir da entidade selecionada na jornada";
                }, {
                    readonly name: "number";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Número ou código de identificação visual da mesa";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                    readonly description: "Nome ou descrição opcional da mesa";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Situação da mesa no sistema (active ou inactive)";
                }];
                readonly output: readonly [{
                    readonly name: "tableId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Identificador único da mesa atualizada";
                }, {
                    readonly name: "number";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Número da mesa após atualização";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Table";
                    readonly description: "Nome da mesa após atualização";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Status da mesa após atualização";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Table";
                    readonly description: "Timestamp de atualização ajustado pelo sistema";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["tableId é resolvido a partir da entidade selecionada na jornada, nunca digitado manualmente", "A mesa deve existir no cadastro para ser atualizada — caso contrário a operação falha", "updatedAt é definido pelo sistema via ctx.clock.now(), nunca informado pelo usuário", "status deve ser um dos valores permitidos: active ou inactive", "createdAt é preservado e nunca sobrescrito durante a atualização"];
                readonly transactional: true;
                readonly steps: readonly ["Resolver tableId a partir do contexto da entidade selecionada (selectedEntity)", "Carregar o agregado Table pelo tableId através do port Table", "Validar que a mesa existe; se não existir, falhar a operação", "Aplicar os novos valores de number, name e status na entidade Table", "Definir updatedAt com ctx.clock.now() preservando createdAt original", "Persistir o agregado Table através do port Table na mesma transação", "Retornar tableId, number, name, status e updatedAt da mesa atualizada"];
            }];
            readonly mdmRefs: readonly ["Table"];
        };
    };
    export default updateTableUsecase;
    export const pipeline: readonly [{
        readonly id: "updateTable__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/updateTable.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_2_application/usecases/updateTable.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_3_domain/entities/order.defs" {
    export const orderDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly fields: readonly [{
                readonly fieldId: "id";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do pedido";
            }, {
                readonly fieldId: "orderType";
                readonly type: "string";
                readonly required: true;
                readonly description: "Modalidade do pedido: dine-in (mesa) ou takeout";
                readonly enum: readonly ["dineIn", "takeout"];
            }, {
                readonly fieldId: "tableId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência à mesa para pedidos dine-in; nulo para pedidos takeout";
            }, {
                readonly fieldId: "shiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Turno de operação ao qual o pedido está vinculado";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Status atual do pedido no fluxo de cozinha e entrega";
                readonly enum: readonly ["pending", "inKitchen", "preparing", "ready", "delivered", "cancelled"];
            }, {
                readonly fieldId: "total";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor total calculado do pedido";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do pedido";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do pedido";
            }];
            readonly statusEnum: readonly ["pending", "inKitchen", "preparing", "ready", "delivered", "cancelled"];
            readonly invariants: readonly ["If orderType is dineIn then tableId must be non-null", "If orderType is takeout then tableId must be null", "total must be greater than or equal to zero", "Status transitions must follow the valid flow: pending→inKitchen→preparing→ready→delivered; cancelled can occur from any non-delivered state", "shiftId must reference an open Shift at the time of order creation"];
            readonly valueObjects: readonly [];
        };
    };
    export default orderDomainEntity;
    export const pipeline: readonly [{
        readonly id: "order__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_3_domain/entities/order.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_3_domain/entities/order.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_3_domain/entities/orderItem.defs" {
    export const orderItemDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "OrderItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "OrderItem";
            readonly fields: readonly [{
                readonly fieldId: "orderItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do item do pedido";
            }, {
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao pedido ao qual este item pertence";
            }, {
                readonly fieldId: "menuItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao item do cardápio solicitado";
            }, {
                readonly fieldId: "quantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade solicitada do item";
            }, {
                readonly fieldId: "unitPrice";
                readonly type: "money";
                readonly required: true;
                readonly description: "Preço unitário do item no momento do pedido";
            }, {
                readonly fieldId: "itemTotal";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor total da linha do item (quantidade × preço unitário com ajustes de combo/substituição)";
            }, {
                readonly fieldId: "substitutionsApplied";
                readonly type: "text";
                readonly required: false;
                readonly description: "Descrição das substituições aplicadas ao item do cardápio";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Status atual do item na cozinha";
                readonly enum: readonly ["pending", "preparing", "ready", "delivered"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["pending", "preparing", "ready", "delivered"];
            readonly invariants: readonly ["quantity must be greater than zero", "unitPrice must be greater than or equal to zero", "itemTotal must be consistent with quantity multiplied by unitPrice accounting for substitutions", "Status transitions must follow: pending→preparing→ready→delivered"];
            readonly valueObjects: readonly [];
        };
    };
    export default orderItemDomainEntity;
    export const pipeline: readonly [{
        readonly id: "orderItem__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_3_domain/entities/orderItem.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_3_domain/entities/orderItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.defs" {
    export const orderStatusEventDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "OrderStatusEvent";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "OrderStatusEvent";
            readonly fields: readonly [{
                readonly fieldId: "orderStatusEventId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do evento de status do pedido.";
            }, {
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao pedido cujo status sofreu transição.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Novo status do pedido após a transição.";
                readonly enum: readonly ["criado", "em preparo", "pronto", "entregue", "cancelado"];
            }, {
                readonly fieldId: "previousStatus";
                readonly type: "string";
                readonly required: false;
                readonly description: "Status anterior do pedido antes da transição.";
                readonly enum: readonly ["criado", "em preparo", "pronto", "entregue", "cancelado"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro do evento.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro.";
            }];
            readonly invariants: readonly [];
            readonly valueObjects: readonly [];
        };
    };
    export default orderStatusEventDomainEntity;
    export const pipeline: readonly [{
        readonly id: "orderStatusEvent__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_3_domain/entities/orderStatusEvent.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_3_domain/entities/shift.defs" {
    export const shiftDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Shift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Shift";
            readonly fields: readonly [{
                readonly fieldId: "shiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do turno";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Status atual do turno: aberto ou fechado";
                readonly enum: readonly ["open", "closed"];
            }, {
                readonly fieldId: "openedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de abertura do turno";
            }, {
                readonly fieldId: "closedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora de fechamento do turno";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["open", "closed"];
            readonly invariants: readonly ["If status is closed then closedAt must be non-null", "If status is open then closedAt must be null", "closedAt must be after openedAt when present", "Only one Shift may be open at any given time"];
            readonly valueObjects: readonly [];
        };
    };
    export default shiftDomainEntity;
    export const pipeline: readonly [{
        readonly id: "shift__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_3_domain/entities/shift.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_3_domain/entities/shift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_3_domain/entities/shiftStatusEvent.defs" {
    export const shiftStatusEventDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "ShiftStatusEvent";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "ShiftStatusEvent";
            readonly fields: readonly [{
                readonly fieldId: "shiftStatusEventId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do evento de status do turno.";
            }, {
                readonly fieldId: "shiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao turno ao qual o evento pertence.";
            }, {
                readonly fieldId: "eventType";
                readonly type: "string";
                readonly required: true;
                readonly description: "Tipo do evento de status: abertura ou fechamento do turno.";
                readonly enum: readonly ["abertura", "fechamento"];
            }, {
                readonly fieldId: "consolidatedTotal";
                readonly type: "money";
                readonly required: true;
                readonly description: "Total consolidado (vendas/movimentações) registrado no momento do evento.";
            }, {
                readonly fieldId: "recordedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora em que o evento ocorreu.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro no sistema.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro no sistema.";
            }];
            readonly invariants: readonly [];
            readonly valueObjects: readonly [];
        };
    };
    export default shiftStatusEventDomainEntity;
    export const pipeline: readonly [{
        readonly id: "shiftStatusEvent__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_3_domain/entities/shiftStatusEvent.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_3_domain/entities/shiftStatusEvent.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_3_domain/entities/stockLevel.defs" {
    export const stockLevelDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "StockLevel";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockLevel";
            readonly fields: readonly [{
                readonly fieldId: "stockLevelId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do nível de estoque";
            }, {
                readonly fieldId: "stockItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao item de estoque cadastrado (MDM)";
            }, {
                readonly fieldId: "currentQuantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade atual do insumo em estoque";
            }, {
                readonly fieldId: "lastMovementAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Timestamp da última movimentação de estoque";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly invariants: readonly ["currentQuantity must be greater than or equal to zero", "lastMovementAt must be greater than or equal to createdAt"];
            readonly valueObjects: readonly [];
        };
    };
    export default stockLevelDomainEntity;
    export const pipeline: readonly [{
        readonly id: "stockLevel__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_3_domain/entities/stockLevel.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_3_domain/entities/stockLevel.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/cafeFlow/layer_3_domain/entities/stockMovementEvent.defs" {
    export const stockMovementEventDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "StockMovementEvent";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockMovementEvent";
            readonly fields: readonly [{
                readonly fieldId: "stockMovementEventId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do evento de movimentação de estoque";
            }, {
                readonly fieldId: "stockItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao item de estoque movimentado";
            }, {
                readonly fieldId: "movementType";
                readonly type: "string";
                readonly required: true;
                readonly description: "Tipo da movimentação: baixa ou reposição de estoque";
                readonly enum: readonly ["baixa", "reposicao"];
            }, {
                readonly fieldId: "quantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade movimentada";
            }, {
                readonly fieldId: "reason";
                readonly type: "text";
                readonly required: true;
                readonly description: "Motivo da movimentação de estoque";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly invariants: readonly [];
            readonly valueObjects: readonly [];
        };
    };
    export default stockMovementEventDomainEntity;
    export const pipeline: readonly [{
        readonly id: "stockMovementEvent__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/cafeFlow/layer_3_domain/entities/stockMovementEvent.ts";
        readonly defPath: "_102049_/l1/cafeFlow/layer_3_domain/entities/stockMovementEvent.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-attendant-pos.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "ws-attendant-pos__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/cafeFlow/web/contracts/ws-attendant-pos.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/contracts/ws-attendant-pos.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-attendant-pos" {
    export interface CafeFlowCreateOrderInput {
        orderType: "dineIn" | "takeout";
        status: "pending" | "inKitchen" | "preparing" | "ready" | "delivered" | "cancelled";
        total: number;
    }
    export interface CafeFlowCreateOrderOutput {
        id: string;
    }
    export interface CafeFlowSettleOrderInput {
        status: "pending" | "inKitchen" | "preparing" | "ready" | "delivered" | "cancelled";
    }
    export interface CafeFlowSettleOrderOutput {
        id: string;
    }
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-attendant-pos.test" {
    export {};
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-cook-kitchen.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        })[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "ws-cook-kitchen__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/cafeFlow/web/contracts/ws-cook-kitchen.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/contracts/ws-cook-kitchen.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-cook-kitchen" {
    export interface CafeFlowUpdateKitchenStatusInput {
        status: "criado" | "em preparo" | "pronto" | "entregue" | "cancelado";
        previousStatus?: "criado" | "em preparo" | "pronto" | "entregue" | "cancelado";
    }
    export interface CafeFlowUpdateKitchenStatusOutput {
        orderStatusEventId: string;
    }
    export interface CafeFlowCreateStockMovementInput {
        movementType: "baixa" | "reposicao";
        quantity: number;
        reason: string;
    }
    export interface CafeFlowCreateStockMovementOutput {
        stockMovementEventId: string;
    }
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-cook-kitchen.test" {
    export {};
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-manager-combo-rules.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "ws-manager-combo-rules__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/cafeFlow/web/contracts/ws-manager-combo-rules.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/contracts/ws-manager-combo-rules.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-manager-combo-rules" {
    export interface CafeFlowQueryComboRulesInput {
        comboRuleId?: string;
        menuItemId?: string;
        name?: string;
        status?: "active" | "inactive";
        createdAt?: string;
        updatedAt?: string;
    }
    export interface CafeFlowQueryComboRulesOutputItem {
        comboRuleId: string;
        menuItemId: string;
        name: string;
        description: string;
        priceDifference: number;
        status: "active" | "inactive";
        createdAt: string;
        updatedAt: string;
    }
    export type CafeFlowQueryComboRulesOutput = CafeFlowQueryComboRulesOutputItem[];
    export interface CafeFlowCreateComboRuleInput {
        name: string;
        description?: string;
        priceDifference: number;
        status: "active" | "inactive";
    }
    export interface CafeFlowCreateComboRuleOutput {
        comboRuleId: string;
    }
    export interface CafeFlowUpdateComboRuleInput {
        name: string;
        description?: string;
        priceDifference: number;
        status: "active" | "inactive";
    }
    export interface CafeFlowUpdateComboRuleOutput {
        comboRuleId: string;
    }
    export interface CafeFlowDeleteComboRuleInput {
        comboRuleId?: string;
        menuItemId?: string;
        name: string;
        description?: string;
        priceDifference: number;
        status: "active" | "inactive";
    }
    export interface CafeFlowDeleteComboRuleOutput {
        comboRuleId: string;
    }
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-manager-combo-rules.test" {
    export {};
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-manager-menu.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "ws-manager-menu__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/cafeFlow/web/contracts/ws-manager-menu.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/contracts/ws-manager-menu.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-manager-menu" {
    export interface CafeFlowQueryMenuItemsInput {
        menuItemId?: string;
        name?: string;
        category?: string;
        status?: "active" | "inactive";
        createdAt?: string;
        updatedAt?: string;
    }
    export interface CafeFlowQueryMenuItemsOutputItem {
        menuItemId: string;
        name: string;
        category: string;
        price: number;
        description: string;
        status: "active" | "inactive";
        createdAt: string;
        updatedAt: string;
    }
    export type CafeFlowQueryMenuItemsOutput = CafeFlowQueryMenuItemsOutputItem[];
    export interface CafeFlowCreateMenuItemInput {
        name: string;
        category: string;
        price: number;
        description?: string;
        status: "active" | "inactive";
    }
    export interface CafeFlowCreateMenuItemOutput {
        menuItemId: string;
    }
    export interface CafeFlowUpdateMenuItemInput {
        name: string;
        category: string;
        price: number;
        description?: string;
        status: "active" | "inactive";
    }
    export interface CafeFlowUpdateMenuItemOutput {
        menuItemId: string;
    }
    export interface CafeFlowDeleteMenuItemInput {
        menuItemId?: string;
        name: string;
        category: string;
        price: number;
        description?: string;
        status: "active" | "inactive";
    }
    export interface CafeFlowDeleteMenuItemOutput {
        menuItemId: string;
    }
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-manager-menu.test" {
    export {};
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-manager-shift.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "ws-manager-shift__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/cafeFlow/web/contracts/ws-manager-shift.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/contracts/ws-manager-shift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-manager-shift" {
    export interface CafeFlowOpenShiftInput {
        status: "open" | "closed";
        openedAt: string;
        closedAt?: string;
    }
    export interface CafeFlowOpenShiftOutput {
        shiftId: string;
    }
    export interface CafeFlowQueryDashboardInput {
        shiftId?: string;
        status?: "open" | "closed";
        openedAt?: string;
        closedAt?: string;
        createdAt?: string;
        updatedAt?: string;
    }
    export interface CafeFlowQueryDashboardOutputItem {
        shiftId: string;
        status: "open" | "closed";
        openedAt: string;
        closedAt: string;
        createdAt: string;
        updatedAt: string;
    }
    export type CafeFlowQueryDashboardOutput = CafeFlowQueryDashboardOutputItem[];
    export interface CafeFlowCloseShiftInput {
        status: "open" | "closed";
        closedAt?: string;
    }
    export interface CafeFlowCloseShiftOutput {
        shiftId: string;
    }
    export interface CafeFlowGenerateShiftClosingReportInput {
        shiftId?: string;
        status?: "open" | "closed";
        openedAt?: string;
        closedAt?: string;
        createdAt?: string;
        updatedAt?: string;
    }
    export interface CafeFlowGenerateShiftClosingReportOutputItem {
        shiftId: string;
        status: "open" | "closed";
        openedAt: string;
        closedAt: string;
        createdAt: string;
        updatedAt: string;
    }
    export type CafeFlowGenerateShiftClosingReportOutput = CafeFlowGenerateShiftClosingReportOutputItem[];
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-manager-shift.test" {
    export {};
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-adjustment.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
        }[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "ws-manager-stock-adjustment__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-adjustment.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-adjustment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-adjustment" {
    export interface CafeFlowQueryStockLevelsInput {
        stockItemId?: string;
        lastMovementAt?: string;
    }
    export interface CafeFlowQueryStockLevelsOutputItem {
        stockItemId: string;
        currentQuantity: number;
        lastMovementAt: string;
    }
    export type CafeFlowQueryStockLevelsOutput = CafeFlowQueryStockLevelsOutputItem[];
    export interface CafeFlowAdjustStockLevelInput {
        currentQuantity: number;
        lastMovementAt: string;
    }
    export interface CafeFlowAdjustStockLevelOutput {
        stockLevelId: string;
    }
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-adjustment.test" {
    export {};
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-items.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "ws-manager-stock-items__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-items.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-items.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-items" {
    export interface CafeFlowQueryStockItemsInput {
        stockItemId?: string;
        name?: string;
        status?: "active" | "inactive";
        createdAt?: string;
        updatedAt?: string;
    }
    export interface CafeFlowQueryStockItemsOutputItem {
        stockItemId: string;
        name: string;
        unitOfMeasure: string;
        minimumQuantity: number;
        status: "active" | "inactive";
        createdAt: string;
        updatedAt: string;
    }
    export type CafeFlowQueryStockItemsOutput = CafeFlowQueryStockItemsOutputItem[];
    export interface CafeFlowCreateStockItemInput {
        name: string;
        unitOfMeasure: string;
        minimumQuantity: number;
        status: "active" | "inactive";
    }
    export interface CafeFlowCreateStockItemOutput {
        stockItemId: string;
    }
    export interface CafeFlowUpdateStockItemInput {
        name: string;
        unitOfMeasure: string;
        minimumQuantity: number;
        status: "active" | "inactive";
    }
    export interface CafeFlowUpdateStockItemOutput {
        stockItemId: string;
    }
    export interface CafeFlowDeleteStockItemInput {
        stockItemId?: string;
        name: string;
        unitOfMeasure: string;
        minimumQuantity: number;
        status: "active" | "inactive";
    }
    export interface CafeFlowDeleteStockItemOutput {
        stockItemId: string;
    }
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-items.test" {
    export {};
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-manager-tables.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "ws-manager-tables__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/cafeFlow/web/contracts/ws-manager-tables.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/contracts/ws-manager-tables.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-manager-tables" {
    export interface CafeFlowQueryTablesInput {
        tableId?: string;
        name?: string;
        status?: "active" | "inactive";
        createdAt?: string;
        updatedAt?: string;
    }
    export interface CafeFlowQueryTablesOutputItem {
        tableId: string;
        number: string;
        name: string;
        status: "active" | "inactive";
        createdAt: string;
        updatedAt: string;
    }
    export type CafeFlowQueryTablesOutput = CafeFlowQueryTablesOutputItem[];
    export interface CafeFlowCreateTableInput {
        number: string;
        name?: string;
        status: "active" | "inactive";
    }
    export interface CafeFlowCreateTableOutput {
        tableId: string;
    }
    export interface CafeFlowUpdateTableInput {
        number: string;
        name?: string;
        status: "active" | "inactive";
    }
    export interface CafeFlowUpdateTableOutput {
        tableId: string;
    }
    export interface CafeFlowDeleteTableInput {
        tableId?: string;
        number: string;
        name?: string;
        status: "active" | "inactive";
    }
    export interface CafeFlowDeleteTableOutput {
        tableId: string;
    }
}
declare module "_102049_/l2/cafeFlow/web/contracts/ws-manager-tables.test" {
    export {};
}
declare module "_102049_/l2/cafeFlow/web/desktop/page11/ws-attendant-pos.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    order: number;
                    submitAction?: undefined;
                } | {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        submitAction?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    })[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        submitAction?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    })[];
                })[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "ws-attendant-pos__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/cafeFlow/web/desktop/page11/ws-attendant-pos.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/desktop/page11/ws-attendant-pos.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/cafeFlow/web/shared/ws-attendant-pos.defs.ts", "_102049_/l2/cafeFlow/web/shared/ws-attendant-pos.ts", "_102049_/l2/cafeFlow/web/contracts/ws-attendant-pos.defs.ts", "_102049_/l2/cafeFlow/web/contracts/ws-attendant-pos.ts"];
        readonly dependsOn: readonly ["ws-attendant-pos__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Clean, fast-touch POS interface with kitchen display board; dashboard with cards and charts for management.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-attendant-pos" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowCreateOrderInput, CafeFlowSettleOrderInput } from "_102049_/l2/cafeFlow/web/contracts/ws-attendant-pos";
    const message_pt: {
        "ws-attendant-pos.section.main.title": string;
        "ws-attendant-pos.organism.createOrder.title": string;
        "ws-attendant-pos.organism.settleOrder.title": string;
        "ws-attendant-pos.createOrder.step.selectTable.title": string;
        "ws-attendant-pos.createOrder.step.addItems.title": string;
        "ws-attendant-pos.createOrder.step.applyCombos.title": string;
        "ws-attendant-pos.createOrder.step.confirmSend.title": string;
        "ws-attendant-pos.settleOrder.step.verifyReady.title": string;
        "ws-attendant-pos.settleOrder.step.confirmDelivery.title": string;
        "ws-attendant-pos.settleOrder.step.finalize.title": string;
        "ws-attendant-pos.field.orderType.label": string;
        "ws-attendant-pos.field.status.label": string;
        "ws-attendant-pos.field.total.label": string;
        "ws-attendant-pos.action.createOrder.label": string;
        "ws-attendant-pos.action.settleOrder.label": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowWsAttendantPosBase extends CollabLitElement {
        status: string;
        createOrderState: 'idle' | 'loading' | 'success' | 'error';
        createOrderOrderType: CafeFlowCreateOrderInput['orderType'] | '';
        createOrderStatus: CafeFlowCreateOrderInput['status'] | '';
        createOrderTotal: number | '';
        settleOrderState: 'idle' | 'loading' | 'success' | 'error';
        settleOrderStatus: CafeFlowSettleOrderInput['status'] | '';
        protected get msg(): MessageType;
        private readonly stateKeys;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(stateKey: string, value: unknown): void;
        setCreateOrderOrderType(value: CafeFlowCreateOrderInput['orderType'] | ''): void;
        handleCreateOrderOrderTypeChange(event: Event): void;
        setCreateOrderStatus(value: CafeFlowCreateOrderInput['status'] | ''): void;
        handleCreateOrderStatusChange(event: Event): void;
        setCreateOrderTotal(value: number | ''): void;
        handleCreateOrderTotalChange(event: Event): void;
        setSettleOrderStatus(value: CafeFlowSettleOrderInput['status'] | ''): void;
        handleSettleOrderStatusChange(event: Event): void;
        createOrder(signal?: AbortSignal): Promise<void>;
        handleCreateOrderClick(): Promise<void>;
        settleOrder(signal?: AbortSignal): Promise<void>;
        handleSettleOrderClick(): Promise<void>;
    }
}
declare module "_102049_/l2/cafeFlow/web/desktop/page11/ws-attendant-pos" {
    import { CafeFlowWsAttendantPosBase } from "_102049_/l2/cafeFlow/web/shared/ws-attendant-pos";
    export class CafeFlowDesktopPage11WsAttendantPosPage extends CafeFlowWsAttendantPosBase {
        render(): any;
    }
}
declare module "_102049_/l2/cafeFlow/web/desktop/page11/ws-cook-kitchen.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: any[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    order: number;
                    submitAction?: undefined;
                } | {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                })[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: any[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        submitAction?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    })[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "ws-cook-kitchen__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/cafeFlow/web/desktop/page11/ws-cook-kitchen.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/desktop/page11/ws-cook-kitchen.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/cafeFlow/web/shared/ws-cook-kitchen.defs.ts", "_102049_/l2/cafeFlow/web/shared/ws-cook-kitchen.ts", "_102049_/l2/cafeFlow/web/contracts/ws-cook-kitchen.defs.ts", "_102049_/l2/cafeFlow/web/contracts/ws-cook-kitchen.ts"];
        readonly dependsOn: readonly ["ws-cook-kitchen__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Clean, fast-touch POS interface with kitchen display board; dashboard with cards and charts for management.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-cook-kitchen" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowUpdateKitchenStatusInput, CafeFlowCreateStockMovementInput } from "_102049_/l2/cafeFlow/web/contracts/ws-cook-kitchen";
    const message_pt: {
        "ws-cook-kitchen.section.kitchenQueue.title": string;
        "ws-cook-kitchen.organism.updateKitchenStatus.title": string;
        "ws-cook-kitchen.organism.createStockMovement.title": string;
        "ws-cook-kitchen.intent.ticketQueue.title": string;
        "ws-cook-kitchen.intent.startPreparation.title": string;
        "ws-cook-kitchen.intent.markReady.title": string;
        "ws-cook-kitchen.intent.stockMovement.title": string;
        "ws-cook-kitchen.field.orderId": string;
        "ws-cook-kitchen.field.orderType": string;
        "ws-cook-kitchen.field.tableId": string;
        "ws-cook-kitchen.field.orderStatus": string;
        "ws-cook-kitchen.field.total": string;
        "ws-cook-kitchen.field.createdAt": string;
        "ws-cook-kitchen.field.previousStatus": string;
        "ws-cook-kitchen.field.status": string;
        "ws-cook-kitchen.action.updateKitchenStatus": string;
        "ws-cook-kitchen.action.markReady": string;
        "ws-cook-kitchen.field.movementType": string;
        "ws-cook-kitchen.field.quantity": string;
        "ws-cook-kitchen.field.reason": string;
        "ws-cook-kitchen.action.createStockMovement": string;
    };
    type MessageType = typeof message_pt;
    type ActionStatus = 'idle' | 'loading' | 'success' | 'error';
    export class CafeFlowWsCookKitchenBase extends CollabLitElement {
        status: string;
        updateKitchenStatusState: ActionStatus;
        updateKitchenStatusStatus: CafeFlowUpdateKitchenStatusInput['status'] | '';
        updateKitchenStatusPreviousStatus: CafeFlowUpdateKitchenStatusInput['previousStatus'] | '';
        createStockMovementState: ActionStatus;
        createStockMovementMovementType: CafeFlowCreateStockMovementInput['movementType'] | '';
        createStockMovementQuantity: CafeFlowCreateStockMovementInput['quantity'] | '';
        createStockMovementReason: CafeFlowCreateStockMovementInput['reason'] | '';
        LayoutColOrderId: string;
        LayoutColOrderType: string;
        LayoutColTableId: string;
        LayoutColTotal: string;
        LayoutColCreatedAt: string;
        private readonly stateKeys;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private initializeState;
        handleIcaStateChange(key: string, value: unknown): void;
        setUpdateKitchenStatusStatus(value: CafeFlowUpdateKitchenStatusInput['status'] | ''): void;
        handleUpdateKitchenStatusStatusChange(event: Event): void;
        setUpdateKitchenStatusPreviousStatus(value: CafeFlowUpdateKitchenStatusInput['previousStatus'] | ''): void;
        handleUpdateKitchenStatusPreviousStatusChange(event: Event): void;
        setCreateStockMovementMovementType(value: CafeFlowCreateStockMovementInput['movementType'] | ''): void;
        handleCreateStockMovementMovementTypeChange(event: Event): void;
        setCreateStockMovementQuantity(value: CafeFlowCreateStockMovementInput['quantity'] | ''): void;
        handleCreateStockMovementQuantityChange(event: Event): void;
        setCreateStockMovementReason(value: CafeFlowCreateStockMovementInput['reason'] | ''): void;
        handleCreateStockMovementReasonChange(event: Event): void;
        updateKitchenStatus(options?: {
            signal?: AbortSignal;
        }): Promise<void>;
        handleUpdateKitchenStatusClick(): void;
        createStockMovement(options?: {
            signal?: AbortSignal;
        }): Promise<void>;
        handleCreateStockMovementClick(): void;
    }
}
declare module "_102049_/l2/cafeFlow/web/desktop/page11/ws-cook-kitchen" {
    import { CafeFlowWsCookKitchenBase } from "_102049_/l2/cafeFlow/web/shared/ws-cook-kitchen";
    export class CafeFlowDesktopPage11WsCookKitchenPage extends CafeFlowWsCookKitchenBase {
        render(): any;
    }
}
declare module "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-combo-rules.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            inputType?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        })[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            inputType?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            }[];
        };
        dataBindings: ({
            id: string;
            source: string;
            description: string;
            stateKey: string;
            command?: undefined;
            inputStateKeys?: undefined;
        } | {
            id: string;
            source: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "ws-manager-combo-rules__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-combo-rules.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-combo-rules.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/cafeFlow/web/shared/ws-manager-combo-rules.defs.ts", "_102049_/l2/cafeFlow/web/shared/ws-manager-combo-rules.ts", "_102049_/l2/cafeFlow/web/contracts/ws-manager-combo-rules.defs.ts", "_102049_/l2/cafeFlow/web/contracts/ws-manager-combo-rules.ts"];
        readonly dependsOn: readonly ["ws-manager-combo-rules__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Clean, fast-touch POS interface with kitchen display board; dashboard with cards and charts for management.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-manager-combo-rules" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowQueryComboRulesOutput, CafeFlowCreateComboRuleOutput, CafeFlowUpdateComboRuleOutput, CafeFlowDeleteComboRuleOutput } from "_102049_/l2/cafeFlow/web/contracts/ws-manager-combo-rules";
    const message_pt: {
        "page.title": string;
        "organism.queryComboRules.title": string;
        "organism.createComboRule.title": string;
        "organism.updateComboRule.title": string;
        "organism.deleteComboRule.title": string;
        "intention.queryList.title": string;
        "intention.createForm.title": string;
        "intention.updateForm.title": string;
        "intention.deleteForm.title": string;
        "action.queryComboRules.label": string;
        "action.createComboRule.label": string;
        "action.updateComboRule.label": string;
        "action.deleteComboRule.label": string;
        "field.comboRuleId.label": string;
        "field.menuItemId.label": string;
        "field.name.label": string;
        "field.description.label": string;
        "field.priceDifference.label": string;
        "field.status.label": string;
        "field.createdAt.label": string;
        "field.updatedAt.label": string;
        "empty.queryComboRules.label": string;
        "sec.main.title": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowWsManagerComboRulesBase extends CollabLitElement {
        status: string;
        queryComboRulesState: 'idle' | 'loading' | 'success' | 'error';
        queryComboRulesComboRuleId: string;
        queryComboRulesMenuItemId: string;
        queryComboRulesName: string;
        queryComboRulesStatus: string;
        queryComboRulesCreatedAt: string;
        queryComboRulesUpdatedAt: string;
        queryComboRulesData: CafeFlowQueryComboRulesOutput;
        createComboRuleState: 'idle' | 'loading' | 'success' | 'error';
        createComboRuleName: string;
        createComboRuleDescription: string;
        createComboRulePriceDifference: number | string;
        createComboRuleStatus: string;
        updateComboRuleState: 'idle' | 'loading' | 'success' | 'error';
        updateComboRuleName: string;
        updateComboRuleDescription: string;
        updateComboRulePriceDifference: number | string;
        updateComboRuleStatus: string;
        deleteComboRuleState: 'idle' | 'loading' | 'success' | 'error';
        deleteComboRuleComboRuleId: string;
        deleteComboRuleMenuItemId: string;
        deleteComboRuleName: string;
        deleteComboRuleDescription: string;
        deleteComboRulePriceDifference: number | string;
        deleteComboRuleStatus: string;
        OutputCreateComboRule: CafeFlowCreateComboRuleOutput | null;
        OutputUpdateComboRule: CafeFlowUpdateComboRuleOutput | null;
        OutputDeleteComboRule: CafeFlowDeleteComboRuleOutput | null;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        protected handleIcaStateChange(stateKey: string, value: unknown): void;
        private initializeState;
        private readState;
        private subscribeToState;
        private unsubscribeFromState;
        loadQueryComboRules(): Promise<void>;
        handleQueryComboRulesClick(_event: Event): void;
        createComboRule(signal?: AbortSignal): Promise<void>;
        handleCreateComboRuleClick(_event: Event): void;
        updateComboRule(signal?: AbortSignal): Promise<void>;
        handleUpdateComboRuleClick(_event: Event): void;
        deleteComboRule(signal?: AbortSignal): Promise<void>;
        handleDeleteComboRuleClick(_event: Event): void;
        setQueryComboRulesComboRuleId(value: string): void;
        handleQueryComboRulesComboRuleIdChange(event: Event): void;
        setQueryComboRulesMenuItemId(value: string): void;
        handleQueryComboRulesMenuItemIdChange(event: Event): void;
        setQueryComboRulesName(value: string): void;
        handleQueryComboRulesNameChange(event: Event): void;
        setQueryComboRulesStatus(value: string): void;
        handleQueryComboRulesStatusChange(event: Event): void;
        setQueryComboRulesCreatedAt(value: string): void;
        handleQueryComboRulesCreatedAtChange(event: Event): void;
        setQueryComboRulesUpdatedAt(value: string): void;
        handleQueryComboRulesUpdatedAtChange(event: Event): void;
        setCreateComboRuleName(value: string): void;
        handleCreateComboRuleNameChange(event: Event): void;
        setCreateComboRuleDescription(value: string): void;
        handleCreateComboRuleDescriptionChange(event: Event): void;
        setCreateComboRulePriceDifference(value: string): void;
        handleCreateComboRulePriceDifferenceChange(event: Event): void;
        setCreateComboRuleStatus(value: string): void;
        handleCreateComboRuleStatusChange(event: Event): void;
        setUpdateComboRuleName(value: string): void;
        handleUpdateComboRuleNameChange(event: Event): void;
        setUpdateComboRuleDescription(value: string): void;
        handleUpdateComboRuleDescriptionChange(event: Event): void;
        setUpdateComboRulePriceDifference(value: string): void;
        handleUpdateComboRulePriceDifferenceChange(event: Event): void;
        setUpdateComboRuleStatus(value: string): void;
        handleUpdateComboRuleStatusChange(event: Event): void;
        setDeleteComboRuleComboRuleId(value: string): void;
        handleDeleteComboRuleComboRuleIdChange(event: Event): void;
        setDeleteComboRuleMenuItemId(value: string): void;
        handleDeleteComboRuleMenuItemIdChange(event: Event): void;
        setDeleteComboRuleName(value: string): void;
        handleDeleteComboRuleNameChange(event: Event): void;
        setDeleteComboRuleDescription(value: string): void;
        handleDeleteComboRuleDescriptionChange(event: Event): void;
        setDeleteComboRulePriceDifference(value: string): void;
        handleDeleteComboRulePriceDifferenceChange(event: Event): void;
        setDeleteComboRuleStatus(value: string): void;
        handleDeleteComboRuleStatusChange(event: Event): void;
    }
}
declare module "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-combo-rules" {
    import { CafeFlowWsManagerComboRulesBase } from "_102049_/l2/cafeFlow/web/shared/ws-manager-combo-rules";
    export class CafeFlowDesktopPage11WsManagerComboRulesPage extends CafeFlowWsManagerComboRulesBase {
        render(): any;
    }
}
declare module "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-menu.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "ws-manager-menu__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-menu.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-menu.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/cafeFlow/web/shared/ws-manager-menu.defs.ts", "_102049_/l2/cafeFlow/web/shared/ws-manager-menu.ts", "_102049_/l2/cafeFlow/web/contracts/ws-manager-menu.defs.ts", "_102049_/l2/cafeFlow/web/contracts/ws-manager-menu.ts"];
        readonly dependsOn: readonly ["ws-manager-menu__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Clean, fast-touch POS interface with kitchen display board; dashboard with cards and charts for management.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-manager-menu" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import { type BffClientOptions } from '_102029_/l2/bffClient';
    import type { CafeFlowQueryMenuItemsOutput } from "_102049_/l2/cafeFlow/web/contracts/ws-manager-menu";
    const message_pt: {
        "wsManagerMenu.section.management.title": string;
        "wsManagerMenu.organism.queryMenuItems.title": string;
        "wsManagerMenu.organism.createMenuItem.title": string;
        "wsManagerMenu.organism.updateMenuItem.title": string;
        "wsManagerMenu.organism.deleteMenuItem.title": string;
        "wsManagerMenu.organism.summary.title": string;
        "wsManagerMenu.intent.queryMenuItems.title": string;
        "wsManagerMenu.intent.createMenuItem.title": string;
        "wsManagerMenu.intent.updateMenuItem.title": string;
        "wsManagerMenu.intent.deleteMenuItem.title": string;
        "wsManagerMenu.intent.summary.title": string;
        "wsManagerMenu.field.menuItemId": string;
        "wsManagerMenu.field.name": string;
        "wsManagerMenu.field.category": string;
        "wsManagerMenu.field.price": string;
        "wsManagerMenu.field.description": string;
        "wsManagerMenu.field.status": string;
        "wsManagerMenu.field.createdAt": string;
        "wsManagerMenu.field.updatedAt": string;
        "wsManagerMenu.action.query": string;
        "wsManagerMenu.action.saveItem": string;
        "wsManagerMenu.action.saveChanges": string;
        "wsManagerMenu.action.confirmDelete": string;
    };
    type MessageType = typeof message_pt;
    type ActionStatus = 'idle' | 'loading' | 'success' | 'error';
    type MenuItemStatus = 'active' | 'inactive' | '';
    export class CafeFlowWsManagerMenuBase extends CollabLitElement {
        status: string;
        queryMenuItemsState: ActionStatus;
        queryMenuItemsMenuItemId: string;
        queryMenuItemsName: string;
        queryMenuItemsCategory: string;
        queryMenuItemsStatus: MenuItemStatus;
        queryMenuItemsCreatedAt: string;
        queryMenuItemsUpdatedAt: string;
        queryMenuItemsData: CafeFlowQueryMenuItemsOutput;
        createMenuItemState: ActionStatus;
        createMenuItemName: string;
        createMenuItemCategory: string;
        createMenuItemPrice: number;
        createMenuItemDescription: string;
        createMenuItemStatus: MenuItemStatus;
        updateMenuItemState: ActionStatus;
        updateMenuItemName: string;
        updateMenuItemCategory: string;
        updateMenuItemPrice: number;
        updateMenuItemDescription: string;
        updateMenuItemStatus: MenuItemStatus;
        deleteMenuItemState: ActionStatus;
        deleteMenuItemMenuItemId: string;
        deleteMenuItemName: string;
        deleteMenuItemCategory: string;
        deleteMenuItemPrice: number;
        deleteMenuItemDescription: string;
        deleteMenuItemStatus: MenuItemStatus;
        private readonly stateKeys;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: unknown): void;
        private initStateValue;
        setQueryMenuItemsMenuItemId(value: string): void;
        handleQueryMenuItemsMenuItemIdChange(event: Event): void;
        setQueryMenuItemsName(value: string): void;
        handleQueryMenuItemsNameChange(event: Event): void;
        setQueryMenuItemsCategory(value: string): void;
        handleQueryMenuItemsCategoryChange(event: Event): void;
        setQueryMenuItemsStatus(value: MenuItemStatus): void;
        handleQueryMenuItemsStatusChange(event: Event): void;
        setQueryMenuItemsCreatedAt(value: string): void;
        handleQueryMenuItemsCreatedAtChange(event: Event): void;
        setQueryMenuItemsUpdatedAt(value: string): void;
        handleQueryMenuItemsUpdatedAtChange(event: Event): void;
        setCreateMenuItemName(value: string): void;
        handleCreateMenuItemNameChange(event: Event): void;
        setCreateMenuItemCategory(value: string): void;
        handleCreateMenuItemCategoryChange(event: Event): void;
        setCreateMenuItemPrice(value: number): void;
        handleCreateMenuItemPriceChange(event: Event): void;
        setCreateMenuItemDescription(value: string): void;
        handleCreateMenuItemDescriptionChange(event: Event): void;
        setCreateMenuItemStatus(value: MenuItemStatus): void;
        handleCreateMenuItemStatusChange(event: Event): void;
        setUpdateMenuItemName(value: string): void;
        handleUpdateMenuItemNameChange(event: Event): void;
        setUpdateMenuItemCategory(value: string): void;
        handleUpdateMenuItemCategoryChange(event: Event): void;
        setUpdateMenuItemPrice(value: number): void;
        handleUpdateMenuItemPriceChange(event: Event): void;
        setUpdateMenuItemDescription(value: string): void;
        handleUpdateMenuItemDescriptionChange(event: Event): void;
        setUpdateMenuItemStatus(value: MenuItemStatus): void;
        handleUpdateMenuItemStatusChange(event: Event): void;
        setDeleteMenuItemMenuItemId(value: string): void;
        handleDeleteMenuItemMenuItemIdChange(event: Event): void;
        setDeleteMenuItemName(value: string): void;
        handleDeleteMenuItemNameChange(event: Event): void;
        setDeleteMenuItemCategory(value: string): void;
        handleDeleteMenuItemCategoryChange(event: Event): void;
        setDeleteMenuItemPrice(value: number): void;
        handleDeleteMenuItemPriceChange(event: Event): void;
        setDeleteMenuItemDescription(value: string): void;
        handleDeleteMenuItemDescriptionChange(event: Event): void;
        setDeleteMenuItemStatus(value: MenuItemStatus): void;
        handleDeleteMenuItemStatusChange(event: Event): void;
        loadQueryMenuItems(options?: BffClientOptions): Promise<void>;
        handleQueryMenuItemsClick(event: Event): void;
        createMenuItem(options?: BffClientOptions): Promise<void>;
        handleCreateMenuItemClick(event: Event): void;
        updateMenuItem(options?: BffClientOptions): Promise<void>;
        handleUpdateMenuItemClick(event: Event): void;
        deleteMenuItem(options?: BffClientOptions): Promise<void>;
        handleDeleteMenuItemClick(event: Event): void;
    }
}
declare module "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-menu" {
    import { CafeFlowWsManagerMenuBase } from "_102049_/l2/cafeFlow/web/shared/ws-manager-menu";
    export class CafeFlowDesktopPage11WsManagerMenuPage extends CafeFlowWsManagerMenuBase {
        render(): any;
    }
}
declare module "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-shift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "ws-manager-shift__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-shift.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-shift.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/cafeFlow/web/shared/ws-manager-shift.defs.ts", "_102049_/l2/cafeFlow/web/shared/ws-manager-shift.ts", "_102049_/l2/cafeFlow/web/contracts/ws-manager-shift.defs.ts", "_102049_/l2/cafeFlow/web/contracts/ws-manager-shift.ts"];
        readonly dependsOn: readonly ["ws-manager-shift__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Clean, fast-touch POS interface with kitchen display board; dashboard with cards and charts for management.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-manager-shift" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import { type BffClientOptions } from '_102029_/l2/bffClient';
    import type { CafeFlowGenerateShiftClosingReportOutput, CafeFlowOpenShiftInput, CafeFlowQueryDashboardOutput } from "_102049_/l2/cafeFlow/web/contracts/ws-manager-shift";
    const message_pt: {
        "wsManagerShift.section.shiftLifecycle.title": string;
        "wsManagerShift.organism.openShift.title": string;
        "wsManagerShift.intention.openShift.form.title": string;
        "wsManagerShift.field.openShift.status": string;
        "wsManagerShift.field.openShift.openedAt": string;
        "wsManagerShift.field.openShift.closedAt": string;
        "wsManagerShift.action.openShift.submit": string;
        "wsManagerShift.organism.queryDashboard.title": string;
        "wsManagerShift.intention.queryDashboard.list.title": string;
        "wsManagerShift.col.queryDashboard.shiftId": string;
        "wsManagerShift.col.queryDashboard.status": string;
        "wsManagerShift.col.queryDashboard.openedAt": string;
        "wsManagerShift.col.queryDashboard.closedAt": string;
        "wsManagerShift.col.queryDashboard.createdAt": string;
        "wsManagerShift.col.queryDashboard.updatedAt": string;
        "wsManagerShift.filter.queryDashboard.shiftId": string;
        "wsManagerShift.filter.queryDashboard.status": string;
        "wsManagerShift.filter.queryDashboard.openedAt": string;
        "wsManagerShift.filter.queryDashboard.closedAt": string;
        "wsManagerShift.filter.queryDashboard.createdAt": string;
        "wsManagerShift.filter.queryDashboard.updatedAt": string;
        "wsManagerShift.action.queryDashboard.refresh": string;
        "wsManagerShift.organism.closeShift.title": string;
        "wsManagerShift.intention.closeShift.form.title": string;
        "wsManagerShift.field.closeShift.status": string;
        "wsManagerShift.field.closeShift.closedAt": string;
        "wsManagerShift.action.closeShift.submit": string;
        "wsManagerShift.organism.generateShiftClosingReport.title": string;
        "wsManagerShift.intention.generateShiftClosingReport.list.title": string;
        "wsManagerShift.col.generateShiftClosingReport.shiftId": string;
        "wsManagerShift.col.generateShiftClosingReport.status": string;
        "wsManagerShift.col.generateShiftClosingReport.openedAt": string;
        "wsManagerShift.col.generateShiftClosingReport.closedAt": string;
        "wsManagerShift.col.generateShiftClosingReport.createdAt": string;
        "wsManagerShift.col.generateShiftClosingReport.updatedAt": string;
        "wsManagerShift.filter.generateShiftClosingReport.shiftId": string;
        "wsManagerShift.filter.generateShiftClosingReport.status": string;
        "wsManagerShift.filter.generateShiftClosingReport.openedAt": string;
        "wsManagerShift.filter.generateShiftClosingReport.closedAt": string;
        "wsManagerShift.filter.generateShiftClosingReport.createdAt": string;
        "wsManagerShift.filter.generateShiftClosingReport.updatedAt": string;
        "wsManagerShift.action.generateShiftClosingReport.run": string;
    };
    type MessageType = typeof message_pt;
    type ActionStatus = 'idle' | 'loading' | 'success' | 'error';
    type ShiftStatusInput = CafeFlowOpenShiftInput['status'] | '';
    export class CafeFlowWsManagerShiftBase extends CollabLitElement {
        status: string;
        openShiftState: ActionStatus;
        openShiftStatus: ShiftStatusInput;
        openShiftOpenedAt: string;
        openShiftClosedAt: string;
        queryDashboardState: ActionStatus;
        queryDashboardShiftId: string;
        queryDashboardStatus: ShiftStatusInput;
        queryDashboardOpenedAt: string;
        queryDashboardClosedAt: string;
        queryDashboardCreatedAt: string;
        queryDashboardUpdatedAt: string;
        queryDashboardData: CafeFlowQueryDashboardOutput;
        closeShiftState: ActionStatus;
        closeShiftStatus: ShiftStatusInput;
        closeShiftClosedAt: string;
        generateShiftClosingReportState: ActionStatus;
        generateShiftClosingReportShiftId: string;
        generateShiftClosingReportStatus: ShiftStatusInput;
        generateShiftClosingReportOpenedAt: string;
        generateShiftClosingReportClosedAt: string;
        generateShiftClosingReportCreatedAt: string;
        generateShiftClosingReportUpdatedAt: string;
        generateShiftClosingReportData: CafeFlowGenerateShiftClosingReportOutput;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(stateKey: string, value: unknown): void;
        setOpenShiftStatus(value: ShiftStatusInput): void;
        handleOpenShiftStatusChange(event: Event): void;
        setOpenShiftOpenedAt(value: string): void;
        handleOpenShiftOpenedAtChange(event: Event): void;
        setOpenShiftClosedAt(value: string): void;
        handleOpenShiftClosedAtChange(event: Event): void;
        setQueryDashboardShiftId(value: string): void;
        handleQueryDashboardShiftIdChange(event: Event): void;
        setQueryDashboardStatus(value: ShiftStatusInput): void;
        handleQueryDashboardStatusChange(event: Event): void;
        setQueryDashboardOpenedAt(value: string): void;
        handleQueryDashboardOpenedAtChange(event: Event): void;
        setQueryDashboardClosedAt(value: string): void;
        handleQueryDashboardClosedAtChange(event: Event): void;
        setQueryDashboardCreatedAt(value: string): void;
        handleQueryDashboardCreatedAtChange(event: Event): void;
        setQueryDashboardUpdatedAt(value: string): void;
        handleQueryDashboardUpdatedAtChange(event: Event): void;
        setCloseShiftStatus(value: ShiftStatusInput): void;
        handleCloseShiftStatusChange(event: Event): void;
        setCloseShiftClosedAt(value: string): void;
        handleCloseShiftClosedAtChange(event: Event): void;
        setGenerateShiftClosingReportShiftId(value: string): void;
        handleGenerateShiftClosingReportShiftIdChange(event: Event): void;
        setGenerateShiftClosingReportStatus(value: ShiftStatusInput): void;
        handleGenerateShiftClosingReportStatusChange(event: Event): void;
        setGenerateShiftClosingReportOpenedAt(value: string): void;
        handleGenerateShiftClosingReportOpenedAtChange(event: Event): void;
        setGenerateShiftClosingReportClosedAt(value: string): void;
        handleGenerateShiftClosingReportClosedAtChange(event: Event): void;
        setGenerateShiftClosingReportCreatedAt(value: string): void;
        handleGenerateShiftClosingReportCreatedAtChange(event: Event): void;
        setGenerateShiftClosingReportUpdatedAt(value: string): void;
        handleGenerateShiftClosingReportUpdatedAtChange(event: Event): void;
        openShift(options?: BffClientOptions): Promise<void>;
        handleOpenShiftClick(_event: Event): Promise<void>;
        loadQueryDashboard(options?: BffClientOptions): Promise<void>;
        handleQueryDashboardClick(_event: Event): Promise<void>;
        closeShift(options?: BffClientOptions): Promise<void>;
        handleCloseShiftClick(_event: Event): Promise<void>;
        loadGenerateShiftClosingReport(options?: BffClientOptions): Promise<void>;
        handleGenerateShiftClosingReportClick(_event: Event): Promise<void>;
        private readStateValue;
        private asActionStatus;
        private updateActionStatus;
    }
}
declare module "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-shift" {
    import { CafeFlowWsManagerShiftBase } from "_102049_/l2/cafeFlow/web/shared/ws-manager-shift";
    export class CafeFlowDesktopPage11WsManagerShiftPage extends CafeFlowWsManagerShiftBase {
        render(): any;
    }
}
declare module "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-stock-adjustment.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                } | {
                    id: string;
                    intent: string;
                    order: number;
                    submitAction?: undefined;
                })[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        submitAction?: undefined;
                    })[];
                })[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "ws-manager-stock-adjustment__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-stock-adjustment.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-stock-adjustment.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/cafeFlow/web/shared/ws-manager-stock-adjustment.defs.ts", "_102049_/l2/cafeFlow/web/shared/ws-manager-stock-adjustment.ts", "_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-adjustment.defs.ts", "_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-adjustment.ts"];
        readonly dependsOn: readonly ["ws-manager-stock-adjustment__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Clean, fast-touch POS interface with kitchen display board; dashboard with cards and charts for management.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-manager-stock-adjustment" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowQueryStockLevelsOutput } from "_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-adjustment";
    const message_pt: {
        "ws-manager-stock-adjustment.section.stockAdjustment.title": string;
        "ws-manager-stock-adjustment.organism.queryStockLevels.title": string;
        "ws-manager-stock-adjustment.organism.adjustStockLevel.title": string;
        "ws-manager-stock-adjustment.intention.queryStockLevels.title": string;
        "ws-manager-stock-adjustment.intention.adjustStockLevel.title": string;
        "ws-manager-stock-adjustment.intention.review.title": string;
        "ws-manager-stock-adjustment.field.stockItemId.label": string;
        "ws-manager-stock-adjustment.field.stockItemId.filterLabel": string;
        "ws-manager-stock-adjustment.field.currentQuantity.label": string;
        "ws-manager-stock-adjustment.field.lastMovementAt.label": string;
        "ws-manager-stock-adjustment.field.lastMovementAt.filterLabel": string;
        "ws-manager-stock-adjustment.action.queryStockLevels.label": string;
        "ws-manager-stock-adjustment.action.adjustStockLevel.label": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowWsManagerStockAdjustmentBase extends CollabLitElement {
        status: string;
        queryStockLevelsState: 'idle' | 'loading' | 'success' | 'error';
        queryStockLevelsStockItemId: string;
        queryStockLevelsLastMovementAt: string;
        queryStockLevelsData: CafeFlowQueryStockLevelsOutput;
        adjustStockLevelState: 'idle' | 'loading' | 'success' | 'error';
        adjustStockLevelCurrentQuantity: number | string;
        adjustStockLevelLastMovementAt: string;
        private readonly _stateKeys;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(stateKey: string, value: unknown): void;
        private initializeStateFromStore;
        private initStateValue;
        setQueryStockLevelsStockItemId(value: string): void;
        handleQueryStockLevelsStockItemIdChange(event: Event): void;
        setQueryStockLevelsLastMovementAt(value: string): void;
        handleQueryStockLevelsLastMovementAtChange(event: Event): void;
        setAdjustStockLevelCurrentQuantity(value: number | string): void;
        handleAdjustStockLevelCurrentQuantityChange(event: Event): void;
        setAdjustStockLevelLastMovementAt(value: string): void;
        handleAdjustStockLevelLastMovementAtChange(event: Event): void;
        loadQueryStockLevels(signal?: AbortSignal): Promise<void>;
        handleQueryStockLevelsClick(event: Event): void;
        adjustStockLevel(signal?: AbortSignal): Promise<void>;
        handleAdjustStockLevelClick(event: Event): void;
    }
}
declare module "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-stock-adjustment" {
    import { CafeFlowWsManagerStockAdjustmentBase } from "_102049_/l2/cafeFlow/web/shared/ws-manager-stock-adjustment";
    export class CafeFlowDesktopPage11WsManagerStockAdjustmentPage extends CafeFlowWsManagerStockAdjustmentBase {
        render(): any;
    }
}
declare module "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-stock-items.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                } | {
                    id: string;
                    intent: string;
                    order: number;
                    action?: undefined;
                    submitAction?: undefined;
                })[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        action?: undefined;
                        submitAction?: undefined;
                    })[];
                })[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "ws-manager-stock-items__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-stock-items.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-stock-items.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/cafeFlow/web/shared/ws-manager-stock-items.defs.ts", "_102049_/l2/cafeFlow/web/shared/ws-manager-stock-items.ts", "_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-items.defs.ts", "_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-items.ts"];
        readonly dependsOn: readonly ["ws-manager-stock-items__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Clean, fast-touch POS interface with kitchen display board; dashboard with cards and charts for management.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-manager-stock-items" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import { type BffClientOptions } from '_102029_/l2/bffClient';
    import type { CafeFlowQueryStockItemsOutput } from "_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-items";
    const message_pt: {
        "wsManagerStockItems.section.main.title": string;
        "wsManagerStockItems.organism.query.title": string;
        "wsManagerStockItems.intent.queryList.title": string;
        "wsManagerStockItems.queryList.empty": string;
        "wsManagerStockItems.field.stockItemId": string;
        "wsManagerStockItems.field.name": string;
        "wsManagerStockItems.field.unitOfMeasure": string;
        "wsManagerStockItems.field.minimumQuantity": string;
        "wsManagerStockItems.field.status": string;
        "wsManagerStockItems.field.createdAt": string;
        "wsManagerStockItems.field.updatedAt": string;
        "wsManagerStockItems.action.query": string;
        "wsManagerStockItems.action.update": string;
        "wsManagerStockItems.action.delete": string;
        "wsManagerStockItems.organism.create.title": string;
        "wsManagerStockItems.intent.create.title": string;
        "wsManagerStockItems.action.saveCreate": string;
        "wsManagerStockItems.organism.update.title": string;
        "wsManagerStockItems.intent.update.title": string;
        "wsManagerStockItems.action.saveUpdate": string;
        "wsManagerStockItems.organism.delete.title": string;
        "wsManagerStockItems.intent.delete.title": string;
        "wsManagerStockItems.action.confirmDelete": string;
        "wsManagerStockItems.intent.summary.title": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowWsManagerStockItemsBase extends CollabLitElement {
        status: string;
        queryStockItemsState: 'idle' | 'loading' | 'success' | 'error';
        queryStockItemsStockItemId: string;
        queryStockItemsName: string;
        queryStockItemsStatus: 'active' | 'inactive' | '';
        queryStockItemsCreatedAt: string;
        queryStockItemsUpdatedAt: string;
        queryStockItemsData: CafeFlowQueryStockItemsOutput;
        createStockItemState: 'idle' | 'loading' | 'success' | 'error';
        createStockItemName: string;
        createStockItemUnitOfMeasure: string;
        createStockItemMinimumQuantity: number | '';
        createStockItemStatus: 'active' | 'inactive' | '';
        updateStockItemState: 'idle' | 'loading' | 'success' | 'error';
        updateStockItemName: string;
        updateStockItemUnitOfMeasure: string;
        updateStockItemMinimumQuantity: number | '';
        updateStockItemStatus: 'active' | 'inactive' | '';
        deleteStockItemState: 'idle' | 'loading' | 'success' | 'error';
        deleteStockItemStockItemId: string;
        deleteStockItemName: string;
        deleteStockItemUnitOfMeasure: string;
        deleteStockItemMinimumQuantity: number | '';
        deleteStockItemStatus: 'active' | 'inactive' | '';
        private readonly _stateKeys;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: unknown): void;
        private initializeStateFromStore;
        setQueryStockItemsStockItemId(value: string): void;
        handleQueryStockItemsStockItemIdChange(event: Event): void;
        setQueryStockItemsName(value: string): void;
        handleQueryStockItemsNameChange(event: Event): void;
        setQueryStockItemsStatus(value: 'active' | 'inactive' | ''): void;
        handleQueryStockItemsStatusChange(event: Event): void;
        setQueryStockItemsCreatedAt(value: string): void;
        handleQueryStockItemsCreatedAtChange(event: Event): void;
        setQueryStockItemsUpdatedAt(value: string): void;
        handleQueryStockItemsUpdatedAtChange(event: Event): void;
        setCreateStockItemName(value: string): void;
        handleCreateStockItemNameChange(event: Event): void;
        setCreateStockItemUnitOfMeasure(value: string): void;
        handleCreateStockItemUnitOfMeasureChange(event: Event): void;
        setCreateStockItemMinimumQuantity(value: number | ''): void;
        handleCreateStockItemMinimumQuantityChange(event: Event): void;
        setCreateStockItemStatus(value: 'active' | 'inactive' | ''): void;
        handleCreateStockItemStatusChange(event: Event): void;
        setUpdateStockItemName(value: string): void;
        handleUpdateStockItemNameChange(event: Event): void;
        setUpdateStockItemUnitOfMeasure(value: string): void;
        handleUpdateStockItemUnitOfMeasureChange(event: Event): void;
        setUpdateStockItemMinimumQuantity(value: number | ''): void;
        handleUpdateStockItemMinimumQuantityChange(event: Event): void;
        setUpdateStockItemStatus(value: 'active' | 'inactive' | ''): void;
        handleUpdateStockItemStatusChange(event: Event): void;
        setDeleteStockItemStockItemId(value: string): void;
        handleDeleteStockItemStockItemIdChange(event: Event): void;
        setDeleteStockItemName(value: string): void;
        handleDeleteStockItemNameChange(event: Event): void;
        setDeleteStockItemUnitOfMeasure(value: string): void;
        handleDeleteStockItemUnitOfMeasureChange(event: Event): void;
        setDeleteStockItemMinimumQuantity(value: number | ''): void;
        handleDeleteStockItemMinimumQuantityChange(event: Event): void;
        setDeleteStockItemStatus(value: 'active' | 'inactive' | ''): void;
        handleDeleteStockItemStatusChange(event: Event): void;
        loadQueryStockItems(options?: BffClientOptions): Promise<void>;
        handleQueryStockItemsClick(event: Event): void;
        createStockItem(options?: BffClientOptions): Promise<void>;
        handleCreateStockItemClick(event: Event): void;
        updateStockItem(options?: BffClientOptions): Promise<void>;
        handleUpdateStockItemClick(event: Event): void;
        deleteStockItem(options?: BffClientOptions): Promise<void>;
        handleDeleteStockItemClick(event: Event): void;
    }
}
declare module "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-stock-items" {
    import { CafeFlowWsManagerStockItemsBase } from "_102049_/l2/cafeFlow/web/shared/ws-manager-stock-items";
    export class CafeFlowDesktopPage11WsManagerStockItemsPage extends CafeFlowWsManagerStockItemsBase {
        render(): any;
    }
}
declare module "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-tables.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            inputType?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        })[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "ws-manager-tables__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-tables.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-tables.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/cafeFlow/web/shared/ws-manager-tables.defs.ts", "_102049_/l2/cafeFlow/web/shared/ws-manager-tables.ts", "_102049_/l2/cafeFlow/web/contracts/ws-manager-tables.defs.ts", "_102049_/l2/cafeFlow/web/contracts/ws-manager-tables.ts"];
        readonly dependsOn: readonly ["ws-manager-tables__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Clean, fast-touch POS interface with kitchen display board; dashboard with cards and charts for management.";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-manager-tables" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowQueryTablesInput, CafeFlowQueryTablesOutput, CafeFlowCreateTableInput, CafeFlowUpdateTableInput, CafeFlowDeleteTableInput } from "_102049_/l2/cafeFlow/web/contracts/ws-manager-tables";
    const message_pt: {
        "ws-manager-tables.section.gestaoMesas.title": string;
        "ws-manager-tables.organism.queryTables.title": string;
        "ws-manager-tables.intent.queryTables.title": string;
        "ws-manager-tables.table.tableId": string;
        "ws-manager-tables.table.number": string;
        "ws-manager-tables.table.name": string;
        "ws-manager-tables.table.status": string;
        "ws-manager-tables.table.createdAt": string;
        "ws-manager-tables.table.updatedAt": string;
        "ws-manager-tables.filter.tableId": string;
        "ws-manager-tables.filter.name": string;
        "ws-manager-tables.filter.status": string;
        "ws-manager-tables.filter.createdAt": string;
        "ws-manager-tables.filter.updatedAt": string;
        "ws-manager-tables.action.queryTables": string;
        "ws-manager-tables.organism.createTable.title": string;
        "ws-manager-tables.intent.createTable.title": string;
        "ws-manager-tables.field.number": string;
        "ws-manager-tables.field.name": string;
        "ws-manager-tables.field.status": string;
        "ws-manager-tables.action.createTable": string;
        "ws-manager-tables.organism.updateTable.title": string;
        "ws-manager-tables.intent.updateTable.title": string;
        "ws-manager-tables.action.updateTable": string;
        "ws-manager-tables.organism.deleteTable.title": string;
        "ws-manager-tables.intent.deleteTable.title": string;
        "ws-manager-tables.field.tableId": string;
        "ws-manager-tables.action.deleteTable": string;
        "ws-manager-tables.organism.summary.title": string;
        "ws-manager-tables.intent.summary.title": string;
    };
    type MessageType = typeof message_pt;
    type ActionStatus = 'idle' | 'loading' | 'success' | 'error';
    export class CafeFlowWsManagerTablesBase extends CollabLitElement {
        status: string;
        queryTablesState: ActionStatus;
        queryTablesTableId: string;
        queryTablesName: string;
        queryTablesStatus: CafeFlowQueryTablesInput['status'] | '';
        queryTablesCreatedAt: string;
        queryTablesUpdatedAt: string;
        queryTablesData: CafeFlowQueryTablesOutput;
        createTableState: ActionStatus;
        createTableNumber: string;
        createTableName: string;
        createTableStatus: CafeFlowCreateTableInput['status'] | '';
        updateTableState: ActionStatus;
        updateTableNumber: string;
        updateTableName: string;
        updateTableStatus: CafeFlowUpdateTableInput['status'] | '';
        deleteTableState: ActionStatus;
        deleteTableTableId: string;
        deleteTableNumber: string;
        deleteTableName: string;
        deleteTableStatus: CafeFlowDeleteTableInput['status'] | '';
        protected get msg(): MessageType;
        private readonly stateKeys;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(stateKey: string, value: unknown): void;
        private applyStateValue;
        private getInputValue;
        setQueryTablesTableId(value: string): void;
        handleQueryTablesTableIdChange(event: Event): void;
        setQueryTablesName(value: string): void;
        handleQueryTablesNameChange(event: Event): void;
        setQueryTablesStatus(value: string): void;
        handleQueryTablesStatusChange(event: Event): void;
        setQueryTablesCreatedAt(value: string): void;
        handleQueryTablesCreatedAtChange(event: Event): void;
        setQueryTablesUpdatedAt(value: string): void;
        handleQueryTablesUpdatedAtChange(event: Event): void;
        setCreateTableNumber(value: string): void;
        handleCreateTableNumberChange(event: Event): void;
        setCreateTableName(value: string): void;
        handleCreateTableNameChange(event: Event): void;
        setCreateTableStatus(value: string): void;
        handleCreateTableStatusChange(event: Event): void;
        setUpdateTableNumber(value: string): void;
        handleUpdateTableNumberChange(event: Event): void;
        setUpdateTableName(value: string): void;
        handleUpdateTableNameChange(event: Event): void;
        setUpdateTableStatus(value: string): void;
        handleUpdateTableStatusChange(event: Event): void;
        setDeleteTableTableId(value: string): void;
        handleDeleteTableTableIdChange(event: Event): void;
        setDeleteTableNumber(value: string): void;
        handleDeleteTableNumberChange(event: Event): void;
        setDeleteTableName(value: string): void;
        handleDeleteTableNameChange(event: Event): void;
        setDeleteTableStatus(value: string): void;
        handleDeleteTableStatusChange(event: Event): void;
        loadQueryTables(signal?: AbortSignal): Promise<void>;
        handleQueryTablesClick(event: Event): void;
        createTable(signal?: AbortSignal): Promise<void>;
        handleCreateTableClick(event: Event): void;
        updateTable(signal?: AbortSignal): Promise<void>;
        handleUpdateTableClick(event: Event): void;
        deleteTable(signal?: AbortSignal): Promise<void>;
        handleDeleteTableClick(event: Event): void;
    }
}
declare module "_102049_/l2/cafeFlow/web/desktop/page11/ws-manager-tables" {
    import { CafeFlowWsManagerTablesBase } from "_102049_/l2/cafeFlow/web/shared/ws-manager-tables";
    export class CafeFlowDesktopPage11WsManagerTablesPage extends CafeFlowWsManagerTablesBase {
        render(): any;
    }
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-attendant-pos.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "ws-attendant-pos.section.main.title": string;
            "ws-attendant-pos.organism.createOrder.title": string;
            "ws-attendant-pos.organism.settleOrder.title": string;
            "ws-attendant-pos.createOrder.step.selectTable.title": string;
            "ws-attendant-pos.createOrder.step.addItems.title": string;
            "ws-attendant-pos.createOrder.step.applyCombos.title": string;
            "ws-attendant-pos.createOrder.step.confirmSend.title": string;
            "ws-attendant-pos.settleOrder.step.verifyReady.title": string;
            "ws-attendant-pos.settleOrder.step.confirmDelivery.title": string;
            "ws-attendant-pos.settleOrder.step.finalize.title": string;
            "ws-attendant-pos.field.orderType.label": string;
            "ws-attendant-pos.field.status.label": string;
            "ws-attendant-pos.field.total.label": string;
            "ws-attendant-pos.action.createOrder.label": string;
            "ws-attendant-pos.action.settleOrder.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "ws-attendant-pos__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/cafeFlow/web/shared/ws-attendant-pos.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/shared/ws-attendant-pos.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/cafeFlow/web/contracts/ws-attendant-pos.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["ws-attendant-pos__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-attendant-pos.test" {
    export {};
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-cook-kitchen.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "ws-cook-kitchen.section.kitchenQueue.title": string;
            "ws-cook-kitchen.organism.updateKitchenStatus.title": string;
            "ws-cook-kitchen.organism.createStockMovement.title": string;
            "ws-cook-kitchen.intent.ticketQueue.title": string;
            "ws-cook-kitchen.intent.startPreparation.title": string;
            "ws-cook-kitchen.intent.markReady.title": string;
            "ws-cook-kitchen.intent.stockMovement.title": string;
            "ws-cook-kitchen.field.orderId": string;
            "ws-cook-kitchen.field.orderType": string;
            "ws-cook-kitchen.field.tableId": string;
            "ws-cook-kitchen.field.orderStatus": string;
            "ws-cook-kitchen.field.total": string;
            "ws-cook-kitchen.field.createdAt": string;
            "ws-cook-kitchen.field.previousStatus": string;
            "ws-cook-kitchen.field.status": string;
            "ws-cook-kitchen.action.updateKitchenStatus": string;
            "ws-cook-kitchen.action.markReady": string;
            "ws-cook-kitchen.field.movementType": string;
            "ws-cook-kitchen.field.quantity": string;
            "ws-cook-kitchen.field.reason": string;
            "ws-cook-kitchen.action.createStockMovement": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "ws-cook-kitchen__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/cafeFlow/web/shared/ws-cook-kitchen.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/shared/ws-cook-kitchen.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/cafeFlow/web/contracts/ws-cook-kitchen.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["ws-cook-kitchen__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-cook-kitchen.test" {
    export {};
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-manager-combo-rules.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.title": string;
            "organism.queryComboRules.title": string;
            "organism.createComboRule.title": string;
            "organism.updateComboRule.title": string;
            "organism.deleteComboRule.title": string;
            "intention.queryList.title": string;
            "intention.createForm.title": string;
            "intention.updateForm.title": string;
            "intention.deleteForm.title": string;
            "action.queryComboRules.label": string;
            "action.createComboRule.label": string;
            "action.updateComboRule.label": string;
            "action.deleteComboRule.label": string;
            "field.comboRuleId.label": string;
            "field.menuItemId.label": string;
            "field.name.label": string;
            "field.description.label": string;
            "field.priceDifference.label": string;
            "field.status.label": string;
            "field.createdAt.label": string;
            "field.updatedAt.label": string;
            "empty.queryComboRules.label": string;
            "sec.main.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "ws-manager-combo-rules__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/cafeFlow/web/shared/ws-manager-combo-rules.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/shared/ws-manager-combo-rules.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/cafeFlow/web/contracts/ws-manager-combo-rules.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["ws-manager-combo-rules__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-manager-combo-rules.test" {
    export {};
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-manager-menu.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "wsManagerMenu.section.management.title": string;
            "wsManagerMenu.organism.queryMenuItems.title": string;
            "wsManagerMenu.organism.createMenuItem.title": string;
            "wsManagerMenu.organism.updateMenuItem.title": string;
            "wsManagerMenu.organism.deleteMenuItem.title": string;
            "wsManagerMenu.organism.summary.title": string;
            "wsManagerMenu.intent.queryMenuItems.title": string;
            "wsManagerMenu.intent.createMenuItem.title": string;
            "wsManagerMenu.intent.updateMenuItem.title": string;
            "wsManagerMenu.intent.deleteMenuItem.title": string;
            "wsManagerMenu.intent.summary.title": string;
            "wsManagerMenu.field.menuItemId": string;
            "wsManagerMenu.field.name": string;
            "wsManagerMenu.field.category": string;
            "wsManagerMenu.field.price": string;
            "wsManagerMenu.field.description": string;
            "wsManagerMenu.field.status": string;
            "wsManagerMenu.field.createdAt": string;
            "wsManagerMenu.field.updatedAt": string;
            "wsManagerMenu.action.query": string;
            "wsManagerMenu.action.saveItem": string;
            "wsManagerMenu.action.saveChanges": string;
            "wsManagerMenu.action.confirmDelete": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "ws-manager-menu__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/cafeFlow/web/shared/ws-manager-menu.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/shared/ws-manager-menu.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/cafeFlow/web/contracts/ws-manager-menu.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["ws-manager-menu__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-manager-menu.test" {
    export {};
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-manager-shift.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "wsManagerShift.section.shiftLifecycle.title": string;
            "wsManagerShift.organism.openShift.title": string;
            "wsManagerShift.intention.openShift.form.title": string;
            "wsManagerShift.field.openShift.status": string;
            "wsManagerShift.field.openShift.openedAt": string;
            "wsManagerShift.field.openShift.closedAt": string;
            "wsManagerShift.action.openShift.submit": string;
            "wsManagerShift.organism.queryDashboard.title": string;
            "wsManagerShift.intention.queryDashboard.list.title": string;
            "wsManagerShift.col.queryDashboard.shiftId": string;
            "wsManagerShift.col.queryDashboard.status": string;
            "wsManagerShift.col.queryDashboard.openedAt": string;
            "wsManagerShift.col.queryDashboard.closedAt": string;
            "wsManagerShift.col.queryDashboard.createdAt": string;
            "wsManagerShift.col.queryDashboard.updatedAt": string;
            "wsManagerShift.filter.queryDashboard.shiftId": string;
            "wsManagerShift.filter.queryDashboard.status": string;
            "wsManagerShift.filter.queryDashboard.openedAt": string;
            "wsManagerShift.filter.queryDashboard.closedAt": string;
            "wsManagerShift.filter.queryDashboard.createdAt": string;
            "wsManagerShift.filter.queryDashboard.updatedAt": string;
            "wsManagerShift.action.queryDashboard.refresh": string;
            "wsManagerShift.organism.closeShift.title": string;
            "wsManagerShift.intention.closeShift.form.title": string;
            "wsManagerShift.field.closeShift.status": string;
            "wsManagerShift.field.closeShift.closedAt": string;
            "wsManagerShift.action.closeShift.submit": string;
            "wsManagerShift.organism.generateShiftClosingReport.title": string;
            "wsManagerShift.intention.generateShiftClosingReport.list.title": string;
            "wsManagerShift.col.generateShiftClosingReport.shiftId": string;
            "wsManagerShift.col.generateShiftClosingReport.status": string;
            "wsManagerShift.col.generateShiftClosingReport.openedAt": string;
            "wsManagerShift.col.generateShiftClosingReport.closedAt": string;
            "wsManagerShift.col.generateShiftClosingReport.createdAt": string;
            "wsManagerShift.col.generateShiftClosingReport.updatedAt": string;
            "wsManagerShift.filter.generateShiftClosingReport.shiftId": string;
            "wsManagerShift.filter.generateShiftClosingReport.status": string;
            "wsManagerShift.filter.generateShiftClosingReport.openedAt": string;
            "wsManagerShift.filter.generateShiftClosingReport.closedAt": string;
            "wsManagerShift.filter.generateShiftClosingReport.createdAt": string;
            "wsManagerShift.filter.generateShiftClosingReport.updatedAt": string;
            "wsManagerShift.action.generateShiftClosingReport.run": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "ws-manager-shift__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/cafeFlow/web/shared/ws-manager-shift.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/shared/ws-manager-shift.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/cafeFlow/web/contracts/ws-manager-shift.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["ws-manager-shift__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-manager-shift.test" {
    export {};
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-manager-stock-adjustment.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "ws-manager-stock-adjustment.section.stockAdjustment.title": string;
            "ws-manager-stock-adjustment.organism.queryStockLevels.title": string;
            "ws-manager-stock-adjustment.organism.adjustStockLevel.title": string;
            "ws-manager-stock-adjustment.intention.queryStockLevels.title": string;
            "ws-manager-stock-adjustment.intention.adjustStockLevel.title": string;
            "ws-manager-stock-adjustment.intention.review.title": string;
            "ws-manager-stock-adjustment.field.stockItemId.label": string;
            "ws-manager-stock-adjustment.field.stockItemId.filterLabel": string;
            "ws-manager-stock-adjustment.field.currentQuantity.label": string;
            "ws-manager-stock-adjustment.field.lastMovementAt.label": string;
            "ws-manager-stock-adjustment.field.lastMovementAt.filterLabel": string;
            "ws-manager-stock-adjustment.action.queryStockLevels.label": string;
            "ws-manager-stock-adjustment.action.adjustStockLevel.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "ws-manager-stock-adjustment__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/cafeFlow/web/shared/ws-manager-stock-adjustment.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/shared/ws-manager-stock-adjustment.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-adjustment.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["ws-manager-stock-adjustment__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-manager-stock-adjustment.test" {
    export {};
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-manager-stock-items.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "wsManagerStockItems.section.main.title": string;
            "wsManagerStockItems.organism.query.title": string;
            "wsManagerStockItems.intent.queryList.title": string;
            "wsManagerStockItems.queryList.empty": string;
            "wsManagerStockItems.field.stockItemId": string;
            "wsManagerStockItems.field.name": string;
            "wsManagerStockItems.field.unitOfMeasure": string;
            "wsManagerStockItems.field.minimumQuantity": string;
            "wsManagerStockItems.field.status": string;
            "wsManagerStockItems.field.createdAt": string;
            "wsManagerStockItems.field.updatedAt": string;
            "wsManagerStockItems.action.query": string;
            "wsManagerStockItems.action.update": string;
            "wsManagerStockItems.action.delete": string;
            "wsManagerStockItems.organism.create.title": string;
            "wsManagerStockItems.intent.create.title": string;
            "wsManagerStockItems.action.saveCreate": string;
            "wsManagerStockItems.organism.update.title": string;
            "wsManagerStockItems.intent.update.title": string;
            "wsManagerStockItems.action.saveUpdate": string;
            "wsManagerStockItems.organism.delete.title": string;
            "wsManagerStockItems.intent.delete.title": string;
            "wsManagerStockItems.action.confirmDelete": string;
            "wsManagerStockItems.intent.summary.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "ws-manager-stock-items__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/cafeFlow/web/shared/ws-manager-stock-items.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/shared/ws-manager-stock-items.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-items.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["ws-manager-stock-items__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-manager-stock-items.test" {
    export {};
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-manager-tables.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "ws-manager-tables.section.gestaoMesas.title": string;
            "ws-manager-tables.organism.queryTables.title": string;
            "ws-manager-tables.intent.queryTables.title": string;
            "ws-manager-tables.table.tableId": string;
            "ws-manager-tables.table.number": string;
            "ws-manager-tables.table.name": string;
            "ws-manager-tables.table.status": string;
            "ws-manager-tables.table.createdAt": string;
            "ws-manager-tables.table.updatedAt": string;
            "ws-manager-tables.filter.tableId": string;
            "ws-manager-tables.filter.name": string;
            "ws-manager-tables.filter.status": string;
            "ws-manager-tables.filter.createdAt": string;
            "ws-manager-tables.filter.updatedAt": string;
            "ws-manager-tables.action.queryTables": string;
            "ws-manager-tables.organism.createTable.title": string;
            "ws-manager-tables.intent.createTable.title": string;
            "ws-manager-tables.field.number": string;
            "ws-manager-tables.field.name": string;
            "ws-manager-tables.field.status": string;
            "ws-manager-tables.action.createTable": string;
            "ws-manager-tables.organism.updateTable.title": string;
            "ws-manager-tables.intent.updateTable.title": string;
            "ws-manager-tables.action.updateTable": string;
            "ws-manager-tables.organism.deleteTable.title": string;
            "ws-manager-tables.intent.deleteTable.title": string;
            "ws-manager-tables.field.tableId": string;
            "ws-manager-tables.action.deleteTable": string;
            "ws-manager-tables.organism.summary.title": string;
            "ws-manager-tables.intent.summary.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "ws-manager-tables__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/cafeFlow/web/shared/ws-manager-tables.ts";
        readonly defPath: "_102049_/l2/cafeFlow/web/shared/ws-manager-tables.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/cafeFlow/web/contracts/ws-manager-tables.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["ws-manager-tables__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/cafeFlow/web/shared/ws-manager-tables.test" {
    export {};
}

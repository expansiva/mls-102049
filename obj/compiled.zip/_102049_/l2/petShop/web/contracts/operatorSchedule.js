/// <mls fileReference="_102049_/l2/petShop/web/contracts/operatorSchedule.ts" enhancement="_blank"/>
export {};

/// <mls fileReference="_102049_/l2/petShop/web/contracts/reservationManagement.updateReservationStatusCommand.ts" enhancement="_blank"/>
export const updateReservationStatusCommandRoute = 'petShop.reservationManagement.updateReservationStatusCommand';

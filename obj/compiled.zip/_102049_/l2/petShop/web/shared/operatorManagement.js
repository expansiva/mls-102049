/// <mls fileReference="_102049_/l2/petShop/web/shared/operatorManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "operatorManagement.browse.title": "Operadores cadastrados",
    "operatorManagement.browse.empty": "Nenhum operador cadastrado ainda. Clique em \"Cadastrar operador\" para adicionar o primeiro.",
    "operatorManagement.create.title": "Cadastrar operador",
    "operatorManagement.create.empty": "Preencha os dados abaixo para cadastrar um novo operador.",
    "operatorManagement.update.title": "Editar operador",
    "operatorManagement.update.empty": "Selecione um operador na lista para editar seus dados.",
    "operatorManagement.field.name": "Nome",
    "operatorManagement.field.email": "E-mail",
    "operatorManagement.field.phone": "Telefone",
    "operatorManagement.field.active": "Ativo",
    "operatorManagement.field.updatedAt": "Atualizado em",
    "operatorManagement.field.operatorId": "Operador",
    "operatorManagement.filter.active": "Apenas ativos",
    "operatorManagement.action.create": "Cadastrar operador",
    "operatorManagement.action.create.submit": "Salvar operador",
    "operatorManagement.action.update": "Editar",
    "operatorManagement.action.update.submit": "Salvar alterações",
    "action.createOperator.success": "Operador cadastrado com sucesso. Ele já está disponível para alocação em turnos e agendamentos.",
    "action.createOperator.error": "Não foi possível cadastrar o operador. Verifique os dados informados e tente novamente.",
    "action.updateOperator.success": "Dados do operador atualizados com sucesso.",
    "action.updateOperator.error": "Não foi possível atualizar o operador. Verifique os dados informados e tente novamente.",
    "sec.operator.management.title": "Sec operator management",
    "org.browse.operators.title": "Listar operadores cadastrados com filtros e ações por linha",
    "org.create.operator.title": "Cadastrar novo operador com nome, e mail, telefone e status ativo",
    "org.update.operator.title": "Editar dados de um operador selecionado na lista"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class PetShopOperatorManagementBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.browseOperatorsState = 'idle';
        this.browseOperatorsActiveFilter = '';
        this.browseOperatorsData = { items: [], total: 0 };
        this.createOperatorState = 'idle';
        this.createOperatorName = '';
        this.createOperatorEmail = '';
        this.createOperatorPhone = '';
        this.createOperatorActive = '';
        this.createOperatorOutput = null;
        this.createOperatorError = '';
        this.updateOperatorState = 'idle';
        this.updateOperatorOperatorId = '';
        this.updateOperatorName = '';
        this.updateOperatorEmail = '';
        this.updateOperatorPhone = '';
        this.updateOperatorActive = '';
        this.updateOperatorOutput = null;
        this.updateOperatorError = '';
        this.subscribedKeys = [];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        const savedStatus = getState('ui.operatorManagement.status');
        if (savedStatus !== undefined)
            this.status = savedStatus;
        const savedBrowseState = getState('ui.operatorManagement.action.browseOperators.status');
        if (savedBrowseState !== undefined)
            this.browseOperatorsState = savedBrowseState;
        const savedBrowseData = getState('ui.operatorManagement.data.browseOperators');
        if (savedBrowseData !== undefined)
            this.browseOperatorsData = savedBrowseData;
        const savedActiveFilter = getState('ui.operatorManagement.input.browseOperators.activeFilter');
        if (savedActiveFilter !== undefined)
            this.browseOperatorsActiveFilter = savedActiveFilter;
        const savedCreateState = getState('ui.operatorManagement.action.createOperator.status');
        if (savedCreateState !== undefined)
            this.createOperatorState = savedCreateState;
        const savedCreateError = getState('ui.operatorManagement.action.createOperator.error');
        if (savedCreateError !== undefined)
            this.createOperatorError = savedCreateError;
        const savedUpdateState = getState('ui.operatorManagement.action.updateOperator.status');
        if (savedUpdateState !== undefined)
            this.updateOperatorState = savedUpdateState;
        const savedUpdateError = getState('ui.operatorManagement.action.updateOperator.error');
        if (savedUpdateError !== undefined)
            this.updateOperatorError = savedUpdateError;
        const sharedKeys = [
            'ui.operatorManagement.status',
            'ui.operatorManagement.data.browseOperators',
        ];
        subscribe(sharedKeys, this);
        this.subscribedKeys = sharedKeys;
        this.loadBrowseOperators();
    }
    disconnectedCallback() {
        if (this.subscribedKeys.length > 0) {
            unsubscribe(this.subscribedKeys, this);
        }
        super.disconnectedCallback();
    }
    // ---- Route param parsing ----
    parseRouteParams() {
        const pattern = '/petShop/operatorManagement/:operatorId?';
        const patternParts = pattern.split('/').filter((p) => p.length > 0);
        const pathParts = window.location.pathname.split('/').filter((p) => p.length > 0);
        const params = {};
        for (let i = 0; i < patternParts.length; i++) {
            const part = patternParts[i];
            if (part.startsWith(':')) {
                const isOptional = part.endsWith('?');
                const name = isOptional ? part.slice(1, -1) : part.slice(1);
                const value = pathParts[i] ? decodeURIComponent(pathParts[i]) : '';
                if (value) {
                    params[name] = value;
                }
            }
        }
        return params;
    }
    // ---- Query: browseOperators ----
    async loadBrowseOperators() {
        this.browseOperatorsState = 'loading';
        setState('ui.operatorManagement.action.browseOperators.status', 'loading');
        this.requestUpdate();
        const activeFilterBool = this.browseOperatorsActiveFilter === '' ? undefined : this.browseOperatorsActiveFilter === 'true';
        const params = {};
        if (activeFilterBool !== undefined) {
            params.activeFilter = activeFilterBool;
        }
        const options = { mode: 'silent' };
        const response = await execBff('petShop.browseOperators.browseOperators', params, options);
        if (response.ok) {
            const data = response.data ?? { items: [], total: 0 };
            this.browseOperatorsData = data;
            setState('ui.operatorManagement.data.browseOperators', data);
            this.browseOperatorsState = 'success';
            setState('ui.operatorManagement.action.browseOperators.status', 'success');
        }
        else {
            this.browseOperatorsData = { items: [], total: 0 };
            setState('ui.operatorManagement.data.browseOperators', { items: [], total: 0 });
            this.browseOperatorsState = 'error';
            setState('ui.operatorManagement.action.browseOperators.status', 'error');
            if (response.error) {
                console.error('[browseOperators]', response.error.message);
            }
        }
        this.requestUpdate();
    }
    handleBrowseOperatorsClick(_e) {
        this.loadBrowseOperators();
    }
    // ---- Command: createOperator ----
    async createOperator() {
        this.createOperatorState = 'loading';
        setState('ui.operatorManagement.action.createOperator.status', 'loading');
        this.createOperatorError = '';
        setState('ui.operatorManagement.action.createOperator.error', '');
        this.requestUpdate();
        const params = {
            name: this.createOperatorName,
            active: this.createOperatorActive === 'true',
        };
        if (this.createOperatorEmail) {
            params.email = this.createOperatorEmail;
        }
        if (this.createOperatorPhone) {
            params.phone = this.createOperatorPhone;
        }
        const options = { mode: 'blocking' };
        const response = await execBff('petShop.createOperator.createOperator', params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.createOperatorOutput = data;
            setState('ui.operatorManagement.output.createOperator', data);
            // Refresh browseOperators first
            await this.loadBrowseOperators();
            // Clear inputs
            this.createOperatorName = '';
            setState('ui.operatorManagement.input.createOperator.name', '');
            this.createOperatorEmail = '';
            setState('ui.operatorManagement.input.createOperator.email', '');
            this.createOperatorPhone = '';
            setState('ui.operatorManagement.input.createOperator.phone', '');
            this.createOperatorActive = '';
            setState('ui.operatorManagement.input.createOperator.active', '');
            this.createOperatorState = 'success';
            setState('ui.operatorManagement.action.createOperator.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? this.msg['action.createOperator.error'];
            this.createOperatorError = errorMsg;
            setState('ui.operatorManagement.action.createOperator.error', errorMsg);
            this.createOperatorState = 'error';
            setState('ui.operatorManagement.action.createOperator.status', 'error');
        }
        this.requestUpdate();
    }
    handleCreateOperatorClick(e) {
        e.preventDefault();
        runBlockingUiAction(async (_signal) => {
            await this.createOperator();
        }, { mode: 'blocking' });
    }
    // ---- Command: updateOperator ----
    async updateOperator() {
        // Parse route params
        const routeParams = this.parseRouteParams();
        const routeOperatorId = routeParams['operatorId'] ?? '';
        if (routeOperatorId && !this.updateOperatorOperatorId) {
            this.updateOperatorOperatorId = routeOperatorId;
            setState('ui.operatorManagement.input.updateOperator.operatorId', routeOperatorId);
        }
        if (!this.updateOperatorOperatorId) {
            this.updateOperatorState = 'idle';
            setState('ui.operatorManagement.action.updateOperator.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.updateOperatorState = 'loading';
        setState('ui.operatorManagement.action.updateOperator.status', 'loading');
        this.updateOperatorError = '';
        setState('ui.operatorManagement.action.updateOperator.error', '');
        this.requestUpdate();
        const params = {
            operatorId: this.updateOperatorOperatorId,
            name: this.updateOperatorName,
            active: this.updateOperatorActive === 'true',
        };
        if (this.updateOperatorEmail) {
            params.email = this.updateOperatorEmail;
        }
        if (this.updateOperatorPhone) {
            params.phone = this.updateOperatorPhone;
        }
        const options = { mode: 'blocking' };
        const response = await execBff('petShop.updateOperator.updateOperator', params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.updateOperatorOutput = data;
            setState('ui.operatorManagement.output.updateOperator', data);
            // Refresh browseOperators first
            await this.loadBrowseOperators();
            // Clear inputs
            this.updateOperatorName = '';
            setState('ui.operatorManagement.input.updateOperator.name', '');
            this.updateOperatorEmail = '';
            setState('ui.operatorManagement.input.updateOperator.email', '');
            this.updateOperatorPhone = '';
            setState('ui.operatorManagement.input.updateOperator.phone', '');
            this.updateOperatorActive = '';
            setState('ui.operatorManagement.input.updateOperator.active', '');
            this.updateOperatorState = 'success';
            setState('ui.operatorManagement.action.updateOperator.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? this.msg['action.updateOperator.error'];
            this.updateOperatorError = errorMsg;
            setState('ui.operatorManagement.action.updateOperator.error', errorMsg);
            this.updateOperatorState = 'error';
            setState('ui.operatorManagement.action.updateOperator.status', 'error');
        }
        this.requestUpdate();
    }
    handleUpdateOperatorClick(e) {
        e.preventDefault();
        runBlockingUiAction(async (_signal) => {
            await this.updateOperator();
        }, { mode: 'blocking' });
    }
    // ---- State setters ----
    setBrowseOperatorsActiveFilter(value) {
        this.browseOperatorsActiveFilter = value;
        setState('ui.operatorManagement.input.browseOperators.activeFilter', value);
        this.requestUpdate();
    }
    handleBrowseOperatorsActiveFilterChange(e) {
        const target = e.target;
        const value = target.type === 'checkbox' ? String(target.checked) : target.value;
        this.setBrowseOperatorsActiveFilter(value);
    }
    setCreateOperatorName(value) {
        this.createOperatorName = value;
        setState('ui.operatorManagement.input.createOperator.name', value);
        this.requestUpdate();
    }
    handleCreateOperatorNameChange(e) {
        const target = e.target;
        this.setCreateOperatorName(target.value);
    }
    setCreateOperatorEmail(value) {
        this.createOperatorEmail = value;
        setState('ui.operatorManagement.input.createOperator.email', value);
        this.requestUpdate();
    }
    handleCreateOperatorEmailChange(e) {
        const target = e.target;
        this.setCreateOperatorEmail(target.value);
    }
    setCreateOperatorPhone(value) {
        this.createOperatorPhone = value;
        setState('ui.operatorManagement.input.createOperator.phone', value);
        this.requestUpdate();
    }
    handleCreateOperatorPhoneChange(e) {
        const target = e.target;
        this.setCreateOperatorPhone(target.value);
    }
    setCreateOperatorActive(value) {
        this.createOperatorActive = value;
        setState('ui.operatorManagement.input.createOperator.active', value);
        this.requestUpdate();
    }
    handleCreateOperatorActiveChange(e) {
        const target = e.target;
        const value = target.type === 'checkbox' ? String(target.checked) : target.value;
        this.setCreateOperatorActive(value);
    }
    setUpdateOperatorOperatorId(value) {
        this.updateOperatorOperatorId = value;
        setState('ui.operatorManagement.input.updateOperator.operatorId', value);
        this.requestUpdate();
    }
    handleUpdateOperatorOperatorIdChange(e) {
        const target = e.target;
        this.setUpdateOperatorOperatorId(target.value);
    }
    setUpdateOperatorName(value) {
        this.updateOperatorName = value;
        setState('ui.operatorManagement.input.updateOperator.name', value);
        this.requestUpdate();
    }
    handleUpdateOperatorNameChange(e) {
        const target = e.target;
        this.setUpdateOperatorName(target.value);
    }
    setUpdateOperatorEmail(value) {
        this.updateOperatorEmail = value;
        setState('ui.operatorManagement.input.updateOperator.email', value);
        this.requestUpdate();
    }
    handleUpdateOperatorEmailChange(e) {
        const target = e.target;
        this.setUpdateOperatorEmail(target.value);
    }
    setUpdateOperatorPhone(value) {
        this.updateOperatorPhone = value;
        setState('ui.operatorManagement.input.updateOperator.phone', value);
        this.requestUpdate();
    }
    handleUpdateOperatorPhoneChange(e) {
        const target = e.target;
        this.setUpdateOperatorPhone(target.value);
    }
    setUpdateOperatorActive(value) {
        this.updateOperatorActive = value;
        setState('ui.operatorManagement.input.updateOperator.active', value);
        this.requestUpdate();
    }
    handleUpdateOperatorActiveChange(e) {
        const target = e.target;
        const value = target.type === 'checkbox' ? String(target.checked) : target.value;
        this.setUpdateOperatorActive(value);
    }
}
__decorate([
    property({ type: String })
], PetShopOperatorManagementBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], PetShopOperatorManagementBase.prototype, "browseOperatorsState", void 0);
__decorate([
    property({ type: String })
], PetShopOperatorManagementBase.prototype, "browseOperatorsActiveFilter", void 0);
__decorate([
    property({ type: Object })
], PetShopOperatorManagementBase.prototype, "browseOperatorsData", void 0);
__decorate([
    property({ type: String })
], PetShopOperatorManagementBase.prototype, "createOperatorState", void 0);
__decorate([
    property({ type: String })
], PetShopOperatorManagementBase.prototype, "createOperatorName", void 0);
__decorate([
    property({ type: String })
], PetShopOperatorManagementBase.prototype, "createOperatorEmail", void 0);
__decorate([
    property({ type: String })
], PetShopOperatorManagementBase.prototype, "createOperatorPhone", void 0);
__decorate([
    property({ type: String })
], PetShopOperatorManagementBase.prototype, "createOperatorActive", void 0);
__decorate([
    property({ type: Object })
], PetShopOperatorManagementBase.prototype, "createOperatorOutput", void 0);
__decorate([
    property({ type: String })
], PetShopOperatorManagementBase.prototype, "createOperatorError", void 0);
__decorate([
    property({ type: String })
], PetShopOperatorManagementBase.prototype, "updateOperatorState", void 0);
__decorate([
    property({ type: String })
], PetShopOperatorManagementBase.prototype, "updateOperatorOperatorId", void 0);
__decorate([
    property({ type: String })
], PetShopOperatorManagementBase.prototype, "updateOperatorName", void 0);
__decorate([
    property({ type: String })
], PetShopOperatorManagementBase.prototype, "updateOperatorEmail", void 0);
__decorate([
    property({ type: String })
], PetShopOperatorManagementBase.prototype, "updateOperatorPhone", void 0);
__decorate([
    property({ type: String })
], PetShopOperatorManagementBase.prototype, "updateOperatorActive", void 0);
__decorate([
    property({ type: Object })
], PetShopOperatorManagementBase.prototype, "updateOperatorOutput", void 0);
__decorate([
    property({ type: String })
], PetShopOperatorManagementBase.prototype, "updateOperatorError", void 0);

/// <mls fileReference="_102049_/l4/operations/browseCatalog.defs.ts" enhancement="_blank"/>

export const operationBrowseCatalog = {
  "operationId": "browseCatalog",
  "title": "Navegar pelo catálogo completo",
  "actor": "cliente",
  "entity": "Product",
  "kind": "query",
  "reads": [
    "Product",
    "PetType",
    "Category"
  ],
  "writes": [],
  "rulesApplied": [
    "onlyAvailableProductsVisibleAndReservable",
    "searchIsCaseInsensitiveAndPartial",
    "filtersCanBeCombined",
    "highlightRequiresAvailableProduct"
  ],
  "story": {
    "actor": "cliente",
    "goal": "Navegar pelo catálogo completo de produtos disponíveis na loja, aplicando busca por nome e filtros combinados",
    "steps": [
      "O cliente acessa a página do catálogo de produtos",
      "O sistema retorna a lista paginada de produtos com status available",
      "O cliente pode buscar por nome (insensível a caixa, correspondência parcial) e filtrar por tipo de pet, categoria e faixa de preço",
      "O sistema aplica todos os filtros simultaneamente e retorna os resultados correspondentes"
    ],
    "outcome": "O cliente visualiza a lista paginada de produtos disponíveis que correspondem aos critérios de busca e filtros aplicados, podendo prosseguir para reservar produtos"
  },
  "accessPattern": {
    "kind": "list",
    "entity": "Product",
    "keyField": "Product.productId",
    "filters": [
      "Product.status",
      "Product.name",
      "Product.petTypeId",
      "Product.categoryId",
      "Product.price",
      "Product.highlighted"
    ],
    "sort": [
      "Product.createdAt"
    ],
    "pagination": "required",
    "selection": "multiple",
    "output": [
      "Product.productId",
      "Product.name",
      "Product.description",
      "Product.price",
      "Product.petTypeId",
      "Product.categoryId",
      "Product.highlighted",
      "Product.status"
    ]
  },
  "outputShape": {
    "kind": "paginated",
    "fields": [
      {
        "name": "products",
        "type": "array",
        "required": true,
        "item": {
          "fields": [
            {
              "name": "productId",
              "type": "string",
              "required": true,
              "fieldRef": "Product.productId"
            },
            {
              "name": "name",
              "type": "string",
              "required": true,
              "fieldRef": "Product.name"
            },
            {
              "name": "description",
              "type": "string",
              "required": false,
              "fieldRef": "Product.description"
            },
            {
              "name": "price",
              "type": "number",
              "required": true,
              "fieldRef": "Product.price"
            },
            {
              "name": "petTypeId",
              "type": "string",
              "required": true,
              "fieldRef": "Product.petTypeId"
            },
            {
              "name": "petTypeName",
              "type": "string",
              "required": false
            },
            {
              "name": "categoryId",
              "type": "string",
              "required": true,
              "fieldRef": "Product.categoryId"
            },
            {
              "name": "categoryName",
              "type": "string",
              "required": false
            },
            {
              "name": "highlighted",
              "type": "boolean",
              "required": true,
              "fieldRef": "Product.highlighted"
            },
            {
              "name": "status",
              "type": "string",
              "required": true,
              "fieldRef": "Product.status"
            }
          ]
        }
      },
      {
        "name": "total",
        "type": "number",
        "required": true
      },
      {
        "name": "page",
        "type": "number",
        "required": true
      },
      {
        "name": "pageSize",
        "type": "number",
        "required": true
      }
    ]
  },
  "inputs": [
    {
      "inputId": "searchTerm",
      "fieldRef": "Product.name",
      "required": false,
      "source": "userInput",
      "description": "Termo de busca para filtrar produtos por nome, insensível a maiúsculas e minúsculas com correspondência parcial"
    },
    {
      "inputId": "petTypeId",
      "fieldRef": "Product.petTypeId",
      "required": false,
      "source": "userInput",
      "description": "Identificador do tipo de pet para filtrar produtos indicados para esse tipo"
    },
    {
      "inputId": "categoryId",
      "fieldRef": "Product.categoryId",
      "required": false,
      "source": "userInput",
      "description": "Identificador da categoria para filtrar produtos pertencentes a essa categoria"
    },
    {
      "inputId": "minPrice",
      "fieldRef": "Product.price",
      "required": false,
      "source": "userInput",
      "description": "Preço mínimo da faixa de valor para filtragem por faixa de preço"
    },
    {
      "inputId": "maxPrice",
      "fieldRef": "Product.price",
      "required": false,
      "source": "userInput",
      "description": "Preço máximo da faixa de valor para filtragem por faixa de preço"
    }
  ],
  "contextResolution": [],
  "acceptanceAssertions": [
    "A lista de produtos retornada contém apenas produtos com status 'available'; produtos indisponíveis nunca aparecem nos resultados",
    "A busca por nome é insensível a maiúsculas e minúsculas e considera correspondências parciais do termo informado",
    "Os filtros de tipo de pet, categoria e faixa de valor podem ser aplicados simultaneamente sem exclusão mútua entre eles",
    "Produtos marcados como destaque só aparecem como destaque quando estão disponíveis; produtos em destaque que ficam indisponíveis deixam de aparecer automaticamente",
    "O resultado é paginado e inclui o total de produtos que correspondem aos filtros aplicados, juntamente com a página atual e o tamanho da página",
    "Cada item do resultado inclui o nome do tipo de pet e o nome da categoria correspondentes para exibição na vitrine"
  ],
  "pageId": "browseCatalog",
  "commandName": "browseCatalog",
  "bffName": "petShop.browseCatalog.browseCatalog",
  "capability": {
    "capabilityId": "browseCatalog",
    "title": "Navegar pelo catálogo completo",
    "actor": "cliente",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationBrowseCatalog;

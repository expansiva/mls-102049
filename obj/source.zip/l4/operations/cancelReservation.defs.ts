/// <mls fileReference="_102049_/l4/operations/cancelReservation.defs.ts" enhancement="_blank"/>

export const operationCancelReservation = {
  "operationId": "cancelReservation",
  "title": "Cancelar reserva",
  "actor": "cliente",
  "entity": "Reservation",
  "kind": "update",
  "reads": [
    "Reservation",
    "ReservationItem",
    "Product"
  ],
  "writes": [
    "Reservation",
    "Product"
  ],
  "rulesApplied": [
    "reservationRequiresAuthentication",
    "onlyActiveReservationsCanBeCancelled",
    "cancellationRestoresAvailability",
    "reservationStatusReflectsStage"
  ],
  "story": {
    "actor": "cliente",
    "goal": "Cancelar uma reserva ativa que não deseja mais retirar, liberando os produtos de volta ao catálogo",
    "steps": [
      "O cliente seleciona uma reserva ativa na tela de detalhes",
      "O cliente aciona a opção de cancelar e opcionalmente informa um motivo",
      "O sistema valida que a reserva está em status 'active' ou 'ready' e pertence ao cliente autenticado",
      "O sistema atualiza o status da reserva para 'cancelled', registra cancelledAt e cancelReason",
      "O sistema restaura a disponibilidade de todos os produtos associados via ReservationItem"
    ],
    "outcome": "A reserva é cancelada, os produtos voltam ao catálogo imediatamente e o cliente recebe a confirmação com os dados atualizados"
  },
  "accessPattern": {
    "kind": "commandInput",
    "entity": "Reservation",
    "keyField": "Reservation.reservationId",
    "filters": [
      "Reservation.status"
    ],
    "pagination": "none",
    "selection": "single",
    "output": [
      "Reservation.reservationId",
      "Reservation.status",
      "Reservation.cancelledAt",
      "Reservation.cancelReason",
      "Reservation.updatedAt"
    ]
  },
  "outputShape": {
    "kind": "object",
    "fields": [
      {
        "name": "reservationId",
        "type": "string",
        "required": true,
        "fieldRef": "Reservation.reservationId"
      },
      {
        "name": "status",
        "type": "string",
        "required": true,
        "fieldRef": "Reservation.status"
      },
      {
        "name": "cancelledAt",
        "type": "string",
        "required": true,
        "fieldRef": "Reservation.cancelledAt"
      },
      {
        "name": "cancelReason",
        "type": "string",
        "required": false,
        "fieldRef": "Reservation.cancelReason"
      },
      {
        "name": "updatedAt",
        "type": "string",
        "required": true,
        "fieldRef": "Reservation.updatedAt"
      },
      {
        "name": "restoredProducts",
        "type": "array",
        "required": true,
        "item": {
          "fields": [
            {
              "name": "productId",
              "type": "string",
              "required": true,
              "fieldRef": "Product.productId"
            },
            {
              "name": "available",
              "type": "boolean",
              "required": true,
              "fieldRef": "Product.available"
            }
          ]
        }
      }
    ]
  },
  "inputs": [
    {
      "inputId": "reservationId",
      "fieldRef": "Reservation.reservationId",
      "required": true,
      "source": "selectedEntity",
      "description": "Identificador da reserva selecionada para cancelamento"
    },
    {
      "inputId": "cancelReason",
      "fieldRef": "Reservation.cancelReason",
      "required": false,
      "source": "userInput",
      "description": "Motivo opcional informado pelo cliente ao cancelar a reserva"
    }
  ],
  "contextResolution": [
    {
      "inputId": "reservationId",
      "targetRef": "Reservation.reservationId",
      "source": "selectedEntity",
      "originRef": "Reservation.reservationId",
      "description": "A reserva atualmente selecionada pelo cliente na tela de detalhes da reserva"
    },
    {
      "targetRef": "Reservation.customerId",
      "source": "actorSession",
      "originRef": "actorSession.actorId",
      "description": "O ID do cliente autenticado obtido da sessão, usado para verificar que o cliente é o dono da reserva"
    },
    {
      "targetRef": "Reservation.cancelledAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "O timestamp atual do sistema registrado como momento do cancelamento"
    },
    {
      "targetRef": "Reservation.status",
      "source": "workflowState",
      "originRef": "Reservation.status",
      "description": "O status atual da reserva é lido para validar que apenas reservas ativas ou prontas podem ser canceladas"
    }
  ],
  "acceptanceAssertions": [
    "Após o cancelamento, a reserva existe com status igual a 'cancelled'",
    "Após o cancelamento, o campo cancelledAt da reserva é preenchido com o timestamp atual",
    "Apenas reservas com status 'active' ou 'ready' podem ser canceladas; reservas com status 'expired', 'delivered' ou 'cancelled' são rejeitadas",
    "Após o cancelamento, os produtos associados à reserva voltam imediatamente a ficar disponíveis no catálogo",
    "O cliente deve ser o dono da reserva (customerId corresponde ao actorId da sessão) para cancelá-la",
    "O campo cancelReason é opcional e, quando informado, é persistido na reserva"
  ],
  "pageId": "reservationLifecycle",
  "commandName": "cancelReservation",
  "bffName": "petShop.reservationLifecycle.cancelReservation",
  "capability": {
    "capabilityId": "reservationLifecycle",
    "title": "Ciclo de vida da reserva",
    "actor": "cliente",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationCancelReservation;

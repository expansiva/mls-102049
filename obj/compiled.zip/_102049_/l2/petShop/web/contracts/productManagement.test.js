/// <mls fileReference="_102049_/l2/petShop/web/contracts/productManagement.test.ts" enhancement="_blank"/>
export {};

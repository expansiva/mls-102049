/// <mls fileReference="_102049_/l2/cafeFlow/web/shared/ws-manager-shift.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "wsManagerShift.section.shiftLifecycle.title": "Turno Diário – Abertura, Dashboard e Fechamento",
    "wsManagerShift.organism.openShift.title": "Abertura do Turno",
    "wsManagerShift.intention.openShift.form.title": "Abrir turno",
    "wsManagerShift.field.openShift.status": "Status do turno",
    "wsManagerShift.field.openShift.openedAt": "Abertura do turno",
    "wsManagerShift.field.openShift.closedAt": "Fechamento do turno (opcional)",
    "wsManagerShift.action.openShift.submit": "Abrir turno",
    "wsManagerShift.organism.queryDashboard.title": "Dashboard do Turno",
    "wsManagerShift.intention.queryDashboard.list.title": "Agregação do dashboard",
    "wsManagerShift.col.queryDashboard.shiftId": "ID do turno",
    "wsManagerShift.col.queryDashboard.status": "Status",
    "wsManagerShift.col.queryDashboard.openedAt": "Abertura",
    "wsManagerShift.col.queryDashboard.closedAt": "Fechamento",
    "wsManagerShift.col.queryDashboard.createdAt": "Criado em",
    "wsManagerShift.col.queryDashboard.updatedAt": "Atualizado em",
    "wsManagerShift.filter.queryDashboard.shiftId": "ID do turno",
    "wsManagerShift.filter.queryDashboard.status": "Status",
    "wsManagerShift.filter.queryDashboard.openedAt": "Abertura",
    "wsManagerShift.filter.queryDashboard.closedAt": "Fechamento",
    "wsManagerShift.filter.queryDashboard.createdAt": "Criado em",
    "wsManagerShift.filter.queryDashboard.updatedAt": "Atualizado em",
    "wsManagerShift.action.queryDashboard.refresh": "Atualizar dashboard",
    "wsManagerShift.organism.closeShift.title": "Fechamento do Turno",
    "wsManagerShift.intention.closeShift.form.title": "Fechar turno",
    "wsManagerShift.field.closeShift.status": "Status do turno",
    "wsManagerShift.field.closeShift.closedAt": "Fechamento do turno",
    "wsManagerShift.action.closeShift.submit": "Fechar turno",
    "wsManagerShift.organism.generateShiftClosingReport.title": "Relatório de Fechamento",
    "wsManagerShift.intention.generateShiftClosingReport.list.title": "Relatório de fechamento do turno",
    "wsManagerShift.col.generateShiftClosingReport.shiftId": "ID do turno",
    "wsManagerShift.col.generateShiftClosingReport.status": "Status",
    "wsManagerShift.col.generateShiftClosingReport.openedAt": "Abertura",
    "wsManagerShift.col.generateShiftClosingReport.closedAt": "Fechamento",
    "wsManagerShift.col.generateShiftClosingReport.createdAt": "Criado em",
    "wsManagerShift.col.generateShiftClosingReport.updatedAt": "Atualizado em",
    "wsManagerShift.filter.generateShiftClosingReport.shiftId": "ID do turno",
    "wsManagerShift.filter.generateShiftClosingReport.status": "Status",
    "wsManagerShift.filter.generateShiftClosingReport.openedAt": "Abertura",
    "wsManagerShift.filter.generateShiftClosingReport.closedAt": "Fechamento",
    "wsManagerShift.filter.generateShiftClosingReport.createdAt": "Criado em",
    "wsManagerShift.filter.generateShiftClosingReport.updatedAt": "Atualizado em",
    "wsManagerShift.action.generateShiftClosingReport.run": "Gerar relatório"
};
const messages = { pt: message_pt };
export class CafeFlowWsManagerShiftBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.openShiftState = 'idle';
        this.openShiftStatus = '';
        this.openShiftOpenedAt = '';
        this.openShiftClosedAt = '';
        this.queryDashboardState = 'idle';
        this.queryDashboardShiftId = '';
        this.queryDashboardStatus = '';
        this.queryDashboardOpenedAt = '';
        this.queryDashboardClosedAt = '';
        this.queryDashboardCreatedAt = '';
        this.queryDashboardUpdatedAt = '';
        this.queryDashboardData = [];
        this.closeShiftState = 'idle';
        this.closeShiftStatus = '';
        this.closeShiftClosedAt = '';
        this.generateShiftClosingReportState = 'idle';
        this.generateShiftClosingReportShiftId = '';
        this.generateShiftClosingReportStatus = '';
        this.generateShiftClosingReportOpenedAt = '';
        this.generateShiftClosingReportClosedAt = '';
        this.generateShiftClosingReportCreatedAt = '';
        this.generateShiftClosingReportUpdatedAt = '';
        this.generateShiftClosingReportData = [];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = this.readStateValue('ui.ws-manager-shift.status', this.status);
        this.openShiftState = this.readStateValue('ui.ws-manager-shift.action.openShift.status', this.openShiftState);
        this.openShiftStatus = this.readStateValue('ui.ws-manager-shift.input.openShift.status', this.openShiftStatus);
        this.openShiftOpenedAt = this.readStateValue('ui.ws-manager-shift.input.openShift.openedAt', this.openShiftOpenedAt);
        this.openShiftClosedAt = this.readStateValue('ui.ws-manager-shift.input.openShift.closedAt', this.openShiftClosedAt);
        this.queryDashboardState = this.readStateValue('ui.ws-manager-shift.action.queryDashboard.status', this.queryDashboardState);
        this.queryDashboardShiftId = this.readStateValue('ui.ws-manager-shift.input.queryDashboard.shiftId', this.queryDashboardShiftId);
        this.queryDashboardStatus = this.readStateValue('ui.ws-manager-shift.input.queryDashboard.status', this.queryDashboardStatus);
        this.queryDashboardOpenedAt = this.readStateValue('ui.ws-manager-shift.input.queryDashboard.openedAt', this.queryDashboardOpenedAt);
        this.queryDashboardClosedAt = this.readStateValue('ui.ws-manager-shift.input.queryDashboard.closedAt', this.queryDashboardClosedAt);
        this.queryDashboardCreatedAt = this.readStateValue('ui.ws-manager-shift.input.queryDashboard.createdAt', this.queryDashboardCreatedAt);
        this.queryDashboardUpdatedAt = this.readStateValue('ui.ws-manager-shift.input.queryDashboard.updatedAt', this.queryDashboardUpdatedAt);
        this.queryDashboardData = this.readStateValue('ui.ws-manager-shift.data.queryDashboard', this.queryDashboardData);
        this.closeShiftState = this.readStateValue('ui.ws-manager-shift.action.closeShift.status', this.closeShiftState);
        this.closeShiftStatus = this.readStateValue('ui.ws-manager-shift.input.closeShift.status', this.closeShiftStatus);
        this.closeShiftClosedAt = this.readStateValue('ui.ws-manager-shift.input.closeShift.closedAt', this.closeShiftClosedAt);
        this.generateShiftClosingReportState = this.readStateValue('ui.ws-manager-shift.action.generateShiftClosingReport.status', this.generateShiftClosingReportState);
        this.generateShiftClosingReportShiftId = this.readStateValue('ui.ws-manager-shift.input.generateShiftClosingReport.shiftId', this.generateShiftClosingReportShiftId);
        this.generateShiftClosingReportStatus = this.readStateValue('ui.ws-manager-shift.input.generateShiftClosingReport.status', this.generateShiftClosingReportStatus);
        this.generateShiftClosingReportOpenedAt = this.readStateValue('ui.ws-manager-shift.input.generateShiftClosingReport.openedAt', this.generateShiftClosingReportOpenedAt);
        this.generateShiftClosingReportClosedAt = this.readStateValue('ui.ws-manager-shift.input.generateShiftClosingReport.closedAt', this.generateShiftClosingReportClosedAt);
        this.generateShiftClosingReportCreatedAt = this.readStateValue('ui.ws-manager-shift.input.generateShiftClosingReport.createdAt', this.generateShiftClosingReportCreatedAt);
        this.generateShiftClosingReportUpdatedAt = this.readStateValue('ui.ws-manager-shift.input.generateShiftClosingReport.updatedAt', this.generateShiftClosingReportUpdatedAt);
        this.generateShiftClosingReportData = this.readStateValue('ui.ws-manager-shift.data.generateShiftClosingReport', this.generateShiftClosingReportData);
        subscribe([
            'ui.ws-manager-shift.status',
            'ui.ws-manager-shift.action.openShift.status',
            'ui.ws-manager-shift.input.openShift.status',
            'ui.ws-manager-shift.input.openShift.openedAt',
            'ui.ws-manager-shift.input.openShift.closedAt',
            'ui.ws-manager-shift.action.queryDashboard.status',
            'ui.ws-manager-shift.input.queryDashboard.shiftId',
            'ui.ws-manager-shift.input.queryDashboard.status',
            'ui.ws-manager-shift.input.queryDashboard.openedAt',
            'ui.ws-manager-shift.input.queryDashboard.closedAt',
            'ui.ws-manager-shift.input.queryDashboard.createdAt',
            'ui.ws-manager-shift.input.queryDashboard.updatedAt',
            'ui.ws-manager-shift.data.queryDashboard',
            'ui.ws-manager-shift.action.closeShift.status',
            'ui.ws-manager-shift.input.closeShift.status',
            'ui.ws-manager-shift.input.closeShift.closedAt',
            'ui.ws-manager-shift.action.generateShiftClosingReport.status',
            'ui.ws-manager-shift.input.generateShiftClosingReport.shiftId',
            'ui.ws-manager-shift.input.generateShiftClosingReport.status',
            'ui.ws-manager-shift.input.generateShiftClosingReport.openedAt',
            'ui.ws-manager-shift.input.generateShiftClosingReport.closedAt',
            'ui.ws-manager-shift.input.generateShiftClosingReport.createdAt',
            'ui.ws-manager-shift.input.generateShiftClosingReport.updatedAt',
            'ui.ws-manager-shift.data.generateShiftClosingReport',
        ], this);
        void this.loadQueryDashboard();
        void this.loadGenerateShiftClosingReport();
    }
    disconnectedCallback() {
        unsubscribe([
            'ui.ws-manager-shift.status',
            'ui.ws-manager-shift.action.openShift.status',
            'ui.ws-manager-shift.input.openShift.status',
            'ui.ws-manager-shift.input.openShift.openedAt',
            'ui.ws-manager-shift.input.openShift.closedAt',
            'ui.ws-manager-shift.action.queryDashboard.status',
            'ui.ws-manager-shift.input.queryDashboard.shiftId',
            'ui.ws-manager-shift.input.queryDashboard.status',
            'ui.ws-manager-shift.input.queryDashboard.openedAt',
            'ui.ws-manager-shift.input.queryDashboard.closedAt',
            'ui.ws-manager-shift.input.queryDashboard.createdAt',
            'ui.ws-manager-shift.input.queryDashboard.updatedAt',
            'ui.ws-manager-shift.data.queryDashboard',
            'ui.ws-manager-shift.action.closeShift.status',
            'ui.ws-manager-shift.input.closeShift.status',
            'ui.ws-manager-shift.input.closeShift.closedAt',
            'ui.ws-manager-shift.action.generateShiftClosingReport.status',
            'ui.ws-manager-shift.input.generateShiftClosingReport.shiftId',
            'ui.ws-manager-shift.input.generateShiftClosingReport.status',
            'ui.ws-manager-shift.input.generateShiftClosingReport.openedAt',
            'ui.ws-manager-shift.input.generateShiftClosingReport.closedAt',
            'ui.ws-manager-shift.input.generateShiftClosingReport.createdAt',
            'ui.ws-manager-shift.input.generateShiftClosingReport.updatedAt',
            'ui.ws-manager-shift.data.generateShiftClosingReport',
        ], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(stateKey, value) {
        switch (stateKey) {
            case 'ui.ws-manager-shift.status':
                if (typeof value === 'string')
                    this.status = value;
                break;
            case 'ui.ws-manager-shift.action.openShift.status':
                this.openShiftState = this.asActionStatus(value, this.openShiftState);
                break;
            case 'ui.ws-manager-shift.input.openShift.status':
                if (typeof value === 'string')
                    this.openShiftStatus = value;
                break;
            case 'ui.ws-manager-shift.input.openShift.openedAt':
                if (typeof value === 'string')
                    this.openShiftOpenedAt = value;
                break;
            case 'ui.ws-manager-shift.input.openShift.closedAt':
                if (typeof value === 'string')
                    this.openShiftClosedAt = value;
                break;
            case 'ui.ws-manager-shift.action.queryDashboard.status':
                this.queryDashboardState = this.asActionStatus(value, this.queryDashboardState);
                break;
            case 'ui.ws-manager-shift.input.queryDashboard.shiftId':
                if (typeof value === 'string')
                    this.queryDashboardShiftId = value;
                break;
            case 'ui.ws-manager-shift.input.queryDashboard.status':
                if (typeof value === 'string')
                    this.queryDashboardStatus = value;
                break;
            case 'ui.ws-manager-shift.input.queryDashboard.openedAt':
                if (typeof value === 'string')
                    this.queryDashboardOpenedAt = value;
                break;
            case 'ui.ws-manager-shift.input.queryDashboard.closedAt':
                if (typeof value === 'string')
                    this.queryDashboardClosedAt = value;
                break;
            case 'ui.ws-manager-shift.input.queryDashboard.createdAt':
                if (typeof value === 'string')
                    this.queryDashboardCreatedAt = value;
                break;
            case 'ui.ws-manager-shift.input.queryDashboard.updatedAt':
                if (typeof value === 'string')
                    this.queryDashboardUpdatedAt = value;
                break;
            case 'ui.ws-manager-shift.data.queryDashboard':
                if (Array.isArray(value))
                    this.queryDashboardData = value;
                break;
            case 'ui.ws-manager-shift.action.closeShift.status':
                this.closeShiftState = this.asActionStatus(value, this.closeShiftState);
                break;
            case 'ui.ws-manager-shift.input.closeShift.status':
                if (typeof value === 'string')
                    this.closeShiftStatus = value;
                break;
            case 'ui.ws-manager-shift.input.closeShift.closedAt':
                if (typeof value === 'string')
                    this.closeShiftClosedAt = value;
                break;
            case 'ui.ws-manager-shift.action.generateShiftClosingReport.status':
                this.generateShiftClosingReportState = this.asActionStatus(value, this.generateShiftClosingReportState);
                break;
            case 'ui.ws-manager-shift.input.generateShiftClosingReport.shiftId':
                if (typeof value === 'string')
                    this.generateShiftClosingReportShiftId = value;
                break;
            case 'ui.ws-manager-shift.input.generateShiftClosingReport.status':
                if (typeof value === 'string')
                    this.generateShiftClosingReportStatus = value;
                break;
            case 'ui.ws-manager-shift.input.generateShiftClosingReport.openedAt':
                if (typeof value === 'string')
                    this.generateShiftClosingReportOpenedAt = value;
                break;
            case 'ui.ws-manager-shift.input.generateShiftClosingReport.closedAt':
                if (typeof value === 'string')
                    this.generateShiftClosingReportClosedAt = value;
                break;
            case 'ui.ws-manager-shift.input.generateShiftClosingReport.createdAt':
                if (typeof value === 'string')
                    this.generateShiftClosingReportCreatedAt = value;
                break;
            case 'ui.ws-manager-shift.input.generateShiftClosingReport.updatedAt':
                if (typeof value === 'string')
                    this.generateShiftClosingReportUpdatedAt = value;
                break;
            case 'ui.ws-manager-shift.data.generateShiftClosingReport':
                if (Array.isArray(value))
                    this.generateShiftClosingReportData = value;
                break;
            default:
                break;
        }
    }
    setOpenShiftStatus(value) {
        this.openShiftStatus = value;
        setState('ui.ws-manager-shift.input.openShift.status', value);
        this.requestUpdate();
    }
    handleOpenShiftStatusChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setOpenShiftStatus(value);
    }
    setOpenShiftOpenedAt(value) {
        this.openShiftOpenedAt = value;
        setState('ui.ws-manager-shift.input.openShift.openedAt', value);
        this.requestUpdate();
    }
    handleOpenShiftOpenedAtChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setOpenShiftOpenedAt(value);
    }
    setOpenShiftClosedAt(value) {
        this.openShiftClosedAt = value;
        setState('ui.ws-manager-shift.input.openShift.closedAt', value);
        this.requestUpdate();
    }
    handleOpenShiftClosedAtChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setOpenShiftClosedAt(value);
    }
    setQueryDashboardShiftId(value) {
        this.queryDashboardShiftId = value;
        setState('ui.ws-manager-shift.input.queryDashboard.shiftId', value);
        this.requestUpdate();
    }
    handleQueryDashboardShiftIdChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setQueryDashboardShiftId(value);
    }
    setQueryDashboardStatus(value) {
        this.queryDashboardStatus = value;
        setState('ui.ws-manager-shift.input.queryDashboard.status', value);
        this.requestUpdate();
    }
    handleQueryDashboardStatusChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setQueryDashboardStatus(value);
    }
    setQueryDashboardOpenedAt(value) {
        this.queryDashboardOpenedAt = value;
        setState('ui.ws-manager-shift.input.queryDashboard.openedAt', value);
        this.requestUpdate();
    }
    handleQueryDashboardOpenedAtChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setQueryDashboardOpenedAt(value);
    }
    setQueryDashboardClosedAt(value) {
        this.queryDashboardClosedAt = value;
        setState('ui.ws-manager-shift.input.queryDashboard.closedAt', value);
        this.requestUpdate();
    }
    handleQueryDashboardClosedAtChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setQueryDashboardClosedAt(value);
    }
    setQueryDashboardCreatedAt(value) {
        this.queryDashboardCreatedAt = value;
        setState('ui.ws-manager-shift.input.queryDashboard.createdAt', value);
        this.requestUpdate();
    }
    handleQueryDashboardCreatedAtChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setQueryDashboardCreatedAt(value);
    }
    setQueryDashboardUpdatedAt(value) {
        this.queryDashboardUpdatedAt = value;
        setState('ui.ws-manager-shift.input.queryDashboard.updatedAt', value);
        this.requestUpdate();
    }
    handleQueryDashboardUpdatedAtChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setQueryDashboardUpdatedAt(value);
    }
    setCloseShiftStatus(value) {
        this.closeShiftStatus = value;
        setState('ui.ws-manager-shift.input.closeShift.status', value);
        this.requestUpdate();
    }
    handleCloseShiftStatusChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setCloseShiftStatus(value);
    }
    setCloseShiftClosedAt(value) {
        this.closeShiftClosedAt = value;
        setState('ui.ws-manager-shift.input.closeShift.closedAt', value);
        this.requestUpdate();
    }
    handleCloseShiftClosedAtChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setCloseShiftClosedAt(value);
    }
    setGenerateShiftClosingReportShiftId(value) {
        this.generateShiftClosingReportShiftId = value;
        setState('ui.ws-manager-shift.input.generateShiftClosingReport.shiftId', value);
        this.requestUpdate();
    }
    handleGenerateShiftClosingReportShiftIdChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setGenerateShiftClosingReportShiftId(value);
    }
    setGenerateShiftClosingReportStatus(value) {
        this.generateShiftClosingReportStatus = value;
        setState('ui.ws-manager-shift.input.generateShiftClosingReport.status', value);
        this.requestUpdate();
    }
    handleGenerateShiftClosingReportStatusChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setGenerateShiftClosingReportStatus(value);
    }
    setGenerateShiftClosingReportOpenedAt(value) {
        this.generateShiftClosingReportOpenedAt = value;
        setState('ui.ws-manager-shift.input.generateShiftClosingReport.openedAt', value);
        this.requestUpdate();
    }
    handleGenerateShiftClosingReportOpenedAtChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setGenerateShiftClosingReportOpenedAt(value);
    }
    setGenerateShiftClosingReportClosedAt(value) {
        this.generateShiftClosingReportClosedAt = value;
        setState('ui.ws-manager-shift.input.generateShiftClosingReport.closedAt', value);
        this.requestUpdate();
    }
    handleGenerateShiftClosingReportClosedAtChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setGenerateShiftClosingReportClosedAt(value);
    }
    setGenerateShiftClosingReportCreatedAt(value) {
        this.generateShiftClosingReportCreatedAt = value;
        setState('ui.ws-manager-shift.input.generateShiftClosingReport.createdAt', value);
        this.requestUpdate();
    }
    handleGenerateShiftClosingReportCreatedAtChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setGenerateShiftClosingReportCreatedAt(value);
    }
    setGenerateShiftClosingReportUpdatedAt(value) {
        this.generateShiftClosingReportUpdatedAt = value;
        setState('ui.ws-manager-shift.input.generateShiftClosingReport.updatedAt', value);
        this.requestUpdate();
    }
    handleGenerateShiftClosingReportUpdatedAtChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setGenerateShiftClosingReportUpdatedAt(value);
    }
    async openShift(options = {}) {
        this.updateActionStatus('ui.ws-manager-shift.action.openShift.status', 'openShiftState', 'loading');
        const params = {
            status: this.openShiftStatus,
            openedAt: this.openShiftOpenedAt,
        };
        if (this.openShiftClosedAt) {
            params.closedAt = this.openShiftClosedAt;
        }
        const response = await execBff('cafeFlow.dailyShiftLifecycle.openShift', params, { ...options, mode: 'blocking' });
        if (response.ok) {
            this.updateActionStatus('ui.ws-manager-shift.action.openShift.status', 'openShiftState', 'success');
            return;
        }
        this.updateActionStatus('ui.ws-manager-shift.action.openShift.status', 'openShiftState', 'error');
        throw new Error(response.error?.message ?? 'Erro ao abrir turno');
    }
    async handleOpenShiftClick(_event) {
        await runBlockingUiAction((signal) => this.openShift({ signal }));
    }
    async loadQueryDashboard(options = {}) {
        this.updateActionStatus('ui.ws-manager-shift.action.queryDashboard.status', 'queryDashboardState', 'loading');
        const params = {};
        if (this.queryDashboardShiftId)
            params.shiftId = this.queryDashboardShiftId;
        if (this.queryDashboardStatus)
            params.status = this.queryDashboardStatus;
        if (this.queryDashboardOpenedAt)
            params.openedAt = this.queryDashboardOpenedAt;
        if (this.queryDashboardClosedAt)
            params.closedAt = this.queryDashboardClosedAt;
        if (this.queryDashboardCreatedAt)
            params.createdAt = this.queryDashboardCreatedAt;
        if (this.queryDashboardUpdatedAt)
            params.updatedAt = this.queryDashboardUpdatedAt;
        const response = await execBff('cafeFlow.dailyShiftLifecycle.queryDashboard', params, { ...options, mode: 'silent' });
        if (response.ok) {
            const data = response.data ?? [];
            this.queryDashboardData = data;
            setState('ui.ws-manager-shift.data.queryDashboard', data);
            this.updateActionStatus('ui.ws-manager-shift.action.queryDashboard.status', 'queryDashboardState', 'success');
            return;
        }
        this.queryDashboardData = [];
        setState('ui.ws-manager-shift.data.queryDashboard', []);
        this.updateActionStatus('ui.ws-manager-shift.action.queryDashboard.status', 'queryDashboardState', 'error');
    }
    async handleQueryDashboardClick(_event) {
        await this.loadQueryDashboard();
    }
    async closeShift(options = {}) {
        this.updateActionStatus('ui.ws-manager-shift.action.closeShift.status', 'closeShiftState', 'loading');
        const params = {
            status: this.closeShiftStatus,
        };
        if (this.closeShiftClosedAt) {
            params.closedAt = this.closeShiftClosedAt;
        }
        const response = await execBff('cafeFlow.dailyShiftLifecycle.closeShift', params, { ...options, mode: 'blocking' });
        if (response.ok) {
            this.updateActionStatus('ui.ws-manager-shift.action.closeShift.status', 'closeShiftState', 'success');
            return;
        }
        this.updateActionStatus('ui.ws-manager-shift.action.closeShift.status', 'closeShiftState', 'error');
        throw new Error(response.error?.message ?? 'Erro ao fechar turno');
    }
    async handleCloseShiftClick(_event) {
        await runBlockingUiAction((signal) => this.closeShift({ signal }));
    }
    async loadGenerateShiftClosingReport(options = {}) {
        this.updateActionStatus('ui.ws-manager-shift.action.generateShiftClosingReport.status', 'generateShiftClosingReportState', 'loading');
        const params = {};
        if (this.generateShiftClosingReportShiftId)
            params.shiftId = this.generateShiftClosingReportShiftId;
        if (this.generateShiftClosingReportStatus) {
            params.status = this.generateShiftClosingReportStatus;
        }
        if (this.generateShiftClosingReportOpenedAt)
            params.openedAt = this.generateShiftClosingReportOpenedAt;
        if (this.generateShiftClosingReportClosedAt)
            params.closedAt = this.generateShiftClosingReportClosedAt;
        if (this.generateShiftClosingReportCreatedAt)
            params.createdAt = this.generateShiftClosingReportCreatedAt;
        if (this.generateShiftClosingReportUpdatedAt)
            params.updatedAt = this.generateShiftClosingReportUpdatedAt;
        const response = await execBff('cafeFlow.dailyShiftLifecycle.generateShiftClosingReport', params, { ...options, mode: 'silent' });
        if (response.ok) {
            const data = response.data ?? [];
            this.generateShiftClosingReportData = data;
            setState('ui.ws-manager-shift.data.generateShiftClosingReport', data);
            this.updateActionStatus('ui.ws-manager-shift.action.generateShiftClosingReport.status', 'generateShiftClosingReportState', 'success');
            return;
        }
        this.generateShiftClosingReportData = [];
        setState('ui.ws-manager-shift.data.generateShiftClosingReport', []);
        this.updateActionStatus('ui.ws-manager-shift.action.generateShiftClosingReport.status', 'generateShiftClosingReportState', 'error');
    }
    async handleGenerateShiftClosingReportClick(_event) {
        await this.loadGenerateShiftClosingReport();
    }
    readStateValue(stateKey, fallback) {
        const stored = getState(stateKey);
        if (stored === undefined) {
            setState(stateKey, fallback);
            return fallback;
        }
        return stored;
    }
    asActionStatus(value, fallback) {
        if (value === 'idle' || value === 'loading' || value === 'success' || value === 'error') {
            return value;
        }
        return fallback;
    }
    updateActionStatus(stateKey, prop, status) {
        this[prop] = status;
        setState(stateKey, status);
    }
}
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "openShiftState", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "openShiftStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "openShiftOpenedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "openShiftClosedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "queryDashboardState", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "queryDashboardShiftId", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "queryDashboardStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "queryDashboardOpenedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "queryDashboardClosedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "queryDashboardCreatedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "queryDashboardUpdatedAt", void 0);
__decorate([
    property({ type: Array })
], CafeFlowWsManagerShiftBase.prototype, "queryDashboardData", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "closeShiftState", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "closeShiftStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "closeShiftClosedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "generateShiftClosingReportState", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "generateShiftClosingReportShiftId", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "generateShiftClosingReportStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "generateShiftClosingReportOpenedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "generateShiftClosingReportClosedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "generateShiftClosingReportCreatedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerShiftBase.prototype, "generateShiftClosingReportUpdatedAt", void 0);
__decorate([
    property({ type: Array })
], CafeFlowWsManagerShiftBase.prototype, "generateShiftClosingReportData", void 0);

/// <mls fileReference="_102049_/l4/workflows/kitchenPreparation.defs.ts" enhancement="_blank"/>

export const kitchenPreparationDef = {
  "schemaVersion": "2026-06-06",
  "artifactType": "workflow",
  "artifactId": "kitchenPreparation",
  "moduleName": "cafeFlow",
  "status": "draft",
  "source": {
    "agentName": "agentPlanWorkflowDefinition",
    "stepId": 29,
    "planId": "plan-validate-solution-coverage"
  },
  "data": {
    "workflowDefinition": {
      "workflowId": "kitchenPreparation",
      "title": "Fluxo de preparo na cozinha",
      "purpose": "Coordenar a fila de preparo dos pedidos na cozinha, controlando as transições de status de recebido, preparando, pronto e entregue.",
      "executionMode": "taskWorkflow",
      "createsTask": true,
      "taskConfig": {
        "taskTitleTemplate": "Preparar pedido {{orderId}}",
        "assigneeRules": [
          "actor:kitchen"
        ],
        "slaRules": [
          "due:30m",
          "priority:normal"
        ],
        "taskRoomRequired": true
      },
      "actors": [
        "kitchen"
      ],
      "states": [
        {
          "stateId": "recebido",
          "description": "Pedido recebido e aguardando início do preparo."
        },
        {
          "stateId": "preparando",
          "description": "Pedido em preparo na cozinha."
        },
        {
          "stateId": "pronto",
          "description": "Pedido pronto para entrega/retirada."
        },
        {
          "stateId": "entregue",
          "description": "Pedido entregue ao cliente."
        },
        {
          "stateId": "cancelado",
          "description": "Pedido cancelado; fluxo encerrado."
        }
      ],
      "transitions": [
        {
          "from": "recebido",
          "to": "preparando",
          "trigger": "startPreparation",
          "actor": "kitchen",
          "conditions": [
            "orderStatusLifecycle"
          ],
          "actions": [
            "Order.orderStatusId=preparando",
            "Order.updatedAt=now"
          ],
          "rulesApplied": [
            "orderStatusLifecycle"
          ]
        },
        {
          "from": "preparando",
          "to": "pronto",
          "trigger": "markReady",
          "actor": "kitchen",
          "conditions": [
            "orderStatusLifecycle"
          ],
          "actions": [
            "Order.orderStatusId=pronto",
            "Order.updatedAt=now"
          ],
          "rulesApplied": [
            "orderStatusLifecycle"
          ]
        },
        {
          "from": "pronto",
          "to": "entregue",
          "trigger": "markDelivered",
          "actor": "kitchen",
          "conditions": [
            "orderStatusLifecycle"
          ],
          "actions": [
            "Order.orderStatusId=entregue",
            "Order.updatedAt=now"
          ],
          "rulesApplied": [
            "orderStatusLifecycle"
          ]
        },
        {
          "from": "recebido",
          "to": "cancelado",
          "trigger": "cancelOrder",
          "actor": "kitchen",
          "conditions": [
            "orderStatusLifecycle"
          ],
          "actions": [
            "Order.orderStatusId=cancelado",
            "Order.updatedAt=now"
          ],
          "rulesApplied": [
            "orderStatusLifecycle"
          ]
        },
        {
          "from": "preparando",
          "to": "cancelado",
          "trigger": "cancelOrder",
          "actor": "kitchen",
          "conditions": [
            "orderStatusLifecycle"
          ],
          "actions": [
            "Order.orderStatusId=cancelado",
            "Order.updatedAt=now"
          ],
          "rulesApplied": [
            "orderStatusLifecycle"
          ]
        }
      ],
      "requiredEntities": [
        "Order"
      ],
      "persistenceRefs": [
        "order",
        "operationalMetrics"
      ],
      "usecaseRefs": [
        "atualizarStatusPedido"
      ],
      "metricRefs": [
        "operationalMetrics"
      ],
      "userActions": [
        "iniciarPreparo",
        "marcarPronto",
        "marcarEntregue",
        "cancelarPedido"
      ],
      "relatedPages": [
        "painelCozinha"
      ],
      "relatedAgents": [],
      "relatedPlugins": [],
      "rulesApplied": [
        "orderStatusLifecycle"
      ],
      "implementationSuggestions": [
        {
          "suggestionId": "kitchenRealtimeQueue",
          "title": "Exibir fila de preparo em tempo real",
          "priority": "now",
          "description": "O painel da cozinha deve refletir o estado atual da fila sem necessidade de refresh manual.",
          "tradeoff": "Requer atualização em tempo real e pode aumentar o custo de infraestrutura."
        },
        {
          "suggestionId": "prepTimeEstimate",
          "title": "Calcular tempo estimado de preparo por pedido",
          "priority": "soon",
          "description": "Auxiliar a cozinha a priorizar pedidos e informar o atendente sobre atrasos.",
          "tradeoff": "Depende de histórico de métricas e pode exigir ajuste fino dos modelos."
        }
      ],
      "workflowScope": "singleModule",
      "moduleRefs": [
        "cafeFlow"
      ],
      "pageRefsByModule": [],
      "entityRefsByModule": [
        {
          "moduleId": "cafeFlow",
          "entity": "Order"
        }
      ],
      "writesArtifacts": [
        {
          "moduleId": "cafeFlow",
          "artifactType": "workflow",
          "artifactId": "kitchenPreparation"
        }
      ]
    },
    "defsPlan": {
      "fileName": "workflows/kitchenPreparation.defs.ts",
      "exportName": "kitchenPreparationDef",
      "saveAsDefs": true
    }
  }
} as const;

export default kitchenPreparationDef;

/// <mls fileReference="_102049_/l2/cafeFlow/web/contracts/ws-manager-menu.ts" enhancement="_blank"/>
export {};

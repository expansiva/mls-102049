declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/assignOperatorToShift.defs" {
    export const assignOperatorToShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "assignOperatorToShift";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "assignOperatorToShift";
            readonly controllerName: "AssignOperatorToShiftController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopAssignOperatorToShiftHandler";
                readonly command: "assignOperatorToShift";
                readonly usecaseRef: "assignOperatorToShift";
                readonly inputTypeName: "AssignOperatorToShiftInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "operatorId";
                    readonly fieldRef: "ShiftAssignment.operatorId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Operador selecionado pelo administrador para ser alocado no turno.";
                }, {
                    readonly inputId: "shiftId";
                    readonly fieldRef: "ShiftAssignment.shiftId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Turno de trabalho selecionado pelo administrador para receber a alocação do operador.";
                }, {
                    readonly inputId: "shiftAssignmentId";
                    readonly fieldRef: "ShiftAssignment.shiftAssignmentId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Identificador único gerado automaticamente para a nova alocação.";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "ShiftAssignment.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora automáticas de criação da alocação.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "ShiftAssignment.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora automáticas da última atualização da alocação.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "ShiftAssignment.shiftAssignmentId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "O backend gera um UUID para o identificador da nova alocação no momento da criação.";
                }, {
                    readonly targetRef: "ShiftAssignment.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra o timestamp atual do sistema como data de criação da alocação.";
                }, {
                    readonly targetRef: "ShiftAssignment.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra o timestamp atual do sistema como data de atualização inicial da alocação.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "ShiftAssignment";
                    readonly keyField: "ShiftAssignment.shiftAssignmentId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["ShiftAssignment.shiftAssignmentId", "ShiftAssignment.operatorId", "ShiftAssignment.shiftId", "ShiftAssignment.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.assignOperatorToShift.assignOperatorToShift";
                readonly handlerName: "petShopAssignOperatorToShiftHandler";
            }];
        };
    };
    export default assignOperatorToShiftController;
    export const pipeline: readonly [{
        readonly id: "assignOperatorToShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/assignOperatorToShift.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/assignOperatorToShift.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/assignOperatorToShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/shiftAssignment" {
    export interface ShiftAssignment {
        shiftAssignmentId: string;
        operatorId: string;
        shiftId: string;
        createdAt: string;
        updatedAt: string;
    }
    /**
     * Invariant: updatedAt must be greater than or equal to createdAt.
     */
    export function shiftAssignmentUpdatedAtIsValid(assignment: Pick<ShiftAssignment, 'createdAt' | 'updatedAt'>): boolean;
    /**
     * Invariant: an operator cannot be assigned to the same shift more than once.
     * Checks a collection of assignments for duplicate (operatorId, shiftId) pairs.
     */
    export function hasDuplicateOperatorShift(assignments: Array<Pick<ShiftAssignment, 'operatorId' | 'shiftId'>>, operatorId: string, shiftId: string): boolean;
    /**
     * Invariant: operatorId must reference an active operator.
     * This is a pure domain helper — the actual "active" check is performed by the
     * application layer which has access to the operator repository. This function
     * is provided so the domain can express the rule signature and be used in tests
     * with a pre-resolved active-operator set.
     */
    export function operatorIsActive(operatorId: string, activeOperatorIds: ReadonlySet<string>): boolean;
}
declare module "_102049_/l1/petShop/layer_2_application/ports/shiftAssignmentRepository" {
    import type { ShiftAssignment } from "_102049_/l1/petShop/layer_3_domain/entities/shiftAssignment";
    export type ShiftAssignmentId = string;
    export type OperatorId = string;
    export type LocalDate = string;
    export interface ShiftAssignmentFilter {
        operatorId?: OperatorId;
        shiftId?: string;
        date?: LocalDate;
    }
    export interface IShiftAssignmentRepository {
        getById(id: ShiftAssignmentId): Promise<ShiftAssignment | null>;
        list(filter: ShiftAssignmentFilter): Promise<ShiftAssignment[]>;
        save(assignment: ShiftAssignment): Promise<void>;
        findByOperatorId(operatorId: OperatorId): Promise<ShiftAssignment[]>;
        findByDate(date: LocalDate): Promise<ShiftAssignment[]>;
    }
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/operator" {
    export interface Operator {
        operatorId: string;
        name: string;
        email: string | null;
        phone: string | null;
        active: boolean;
        createdAt: string;
        updatedAt: string;
    }
    export function operatorCanBeAllocated(operator: Pick<Operator, 'active'>): boolean;
    export function operatorUpdatedAtIsValid(operator: Pick<Operator, 'createdAt' | 'updatedAt'>): boolean;
}
declare module "_102049_/l1/petShop/layer_2_application/ports/operatorRepository" {
    import type { Operator } from "_102049_/l1/petShop/layer_3_domain/entities/operator";
    export type OperatorId = string;
    export type Email = string;
    export interface OperatorFilter {
        active?: boolean;
        name?: string;
    }
    export interface IOperatorRepository {
        getById(id: OperatorId): Promise<Operator | null>;
        list(filter?: OperatorFilter): Promise<Operator[]>;
        save(operator: Operator): Promise<void>;
        findByEmail(email: Email): Promise<Operator | null>;
        findActive(): Promise<Operator[]>;
    }
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/assignOperatorToShift" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface AssignOperatorToShiftInput {
        operatorId: string;
        shiftId: string;
    }
    export interface AssignOperatorToShiftOutput {
        shiftAssignmentId: string;
        operatorId: string;
        shiftId: string;
        createdAt: string;
    }
    export function assignOperatorToShift(ctx: RequestContext, input: AssignOperatorToShiftInput): Promise<AssignOperatorToShiftOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/assignOperatorToShift" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopAssignOperatorToShiftHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseAdoptablePets.defs" {
    export const browseAdoptablePetsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseAdoptablePets";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseAdoptablePets";
            readonly controllerName: "BrowseAdoptablePetsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopBrowseAdoptablePetsHandler";
                readonly command: "browseAdoptablePets";
                readonly usecaseRef: "browseAdoptablePets";
                readonly kind: "query";
                readonly inputContract: readonly [];
                readonly contextResolution: readonly [{
                    readonly targetRef: "AdoptablePet.status";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend aplica automaticamente o filtro status='available' a todas as consultas da galeria, garantindo que apenas pets disponíveis sejam retornados conforme a regra de domínio.";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "AdoptablePet";
                    readonly keyField: "AdoptablePet.adoptablePetId";
                    readonly pagination: "required";
                    readonly selection: "none";
                    readonly output: readonly ["AdoptablePet.adoptablePetId", "AdoptablePet.name", "AdoptablePet.age", "AdoptablePet.description", "AdoptablePet.photoUrl"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.browseAdoptablePets.browseAdoptablePets";
                readonly handlerName: "petShopBrowseAdoptablePetsHandler";
            }];
        };
    };
    export default browseAdoptablePetsController;
    export const pipeline: readonly [{
        readonly id: "browseAdoptablePets__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseAdoptablePets.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseAdoptablePets.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/browseAdoptablePets.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseAdoptablePets" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopBrowseAdoptablePetsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseAdoptablePetsAdmin.defs" {
    export const browseAdoptablePetsAdminController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseAdoptablePetsAdmin";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseAdoptablePetsAdmin";
            readonly controllerName: "BrowseAdoptablePetsAdminController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopBrowseAdoptablePetsAdminHandler";
                readonly command: "browseAdoptablePetsAdmin";
                readonly usecaseRef: "browseAdoptablePetsAdmin";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "statusFilter";
                    readonly fieldRef: "AdoptablePet.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional de status (available ou unavailable) para restringir a lista de pets exibida.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "AdoptablePet.adoptablePetId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend identifica o administrador autenticado via sessão para autorizar o acesso à lista de pets cadastrados.";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "AdoptablePet";
                    readonly keyField: "AdoptablePet.adoptablePetId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["AdoptablePet.adoptablePetId", "AdoptablePet.name", "AdoptablePet.age", "AdoptablePet.description", "AdoptablePet.photoUrl", "AdoptablePet.status", "AdoptablePet.createdAt", "AdoptablePet.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.browseAdoptablePetsAdmin.browseAdoptablePetsAdmin";
                readonly handlerName: "petShopBrowseAdoptablePetsAdminHandler";
            }];
        };
    };
    export default browseAdoptablePetsAdminController;
    export const pipeline: readonly [{
        readonly id: "browseAdoptablePetsAdmin__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseAdoptablePetsAdmin.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseAdoptablePetsAdmin.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/browseAdoptablePetsAdmin.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseAdoptablePetsAdmin" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopBrowseAdoptablePetsAdminHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseHomePage.defs" {
    export const browseHomePageController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseHomePage";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseHomePage";
            readonly controllerName: "BrowseHomePageController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopBrowseHomePageHandler";
                readonly command: "browseHomePage";
                readonly usecaseRef: "browseHomePage";
                readonly kind: "view";
                readonly inputContract: readonly [];
                readonly contextResolution: readonly [];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Product";
                    readonly keyField: "Product.productId";
                    readonly filters: readonly ["Product.featured", "Product.status"];
                    readonly sort: readonly ["Product.createdAt"];
                    readonly pagination: "optional";
                    readonly selection: "multiple";
                    readonly output: readonly ["Product.productId", "Product.name", "Product.description", "Product.price", "Product.imageUrl", "Product.productCategoryId", "Product.featured", "Product.status"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.browseHomePage.browseHomePage";
                readonly handlerName: "petShopBrowseHomePageHandler";
            }];
        };
    };
    export default browseHomePageController;
    export const pipeline: readonly [{
        readonly id: "browseHomePage__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseHomePage.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseHomePage.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/browseHomePage.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseHomePage" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopBrowseHomePageHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseOperators.defs" {
    export const browseOperatorsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseOperators";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseOperators";
            readonly controllerName: "BrowseOperatorsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopBrowseOperatorsHandler";
                readonly command: "browseOperators";
                readonly usecaseRef: "browseOperators";
                readonly inputTypeName: "BrowseOperatorsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "activeFilter";
                    readonly fieldRef: "Operator.active";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional para listar apenas operadores ativos ou inativos.";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "Operator.operatorId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do administrador autenticado que solicita a lista de operadores.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Operator.operatorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend resolve o identificador do administrador a partir da sessão autenticada para autorizar o acesso à lista de operadores.";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Operator";
                    readonly keyField: "Operator.operatorId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["Operator.operatorId", "Operator.name", "Operator.email", "Operator.phone", "Operator.active", "Operator.createdAt", "Operator.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.browseOperators.browseOperators";
                readonly handlerName: "petShopBrowseOperatorsHandler";
            }];
        };
    };
    export default browseOperatorsController;
    export const pipeline: readonly [{
        readonly id: "browseOperators__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseOperators.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseOperators.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/browseOperators.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseOperators" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseOperatorsInput {
        activeFilter?: boolean;
    }
    export interface BrowseOperatorsOutputItem {
        operatorId: string;
        name: string;
        email: string | null;
        phone: string | null;
        active: boolean;
        createdAt: string;
        updatedAt: string;
    }
    export interface BrowseOperatorsOutput {
        operators: BrowseOperatorsOutputItem[];
    }
    export function browseOperators(ctx: RequestContext, input: BrowseOperatorsInput): Promise<BrowseOperatorsOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseOperators" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopBrowseOperatorsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseProductCatalog.defs" {
    export const browseProductCatalogController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseProductCatalog";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseProductCatalog";
            readonly controllerName: "BrowseProductCatalogController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopBrowseProductCatalogHandler";
                readonly command: "browseProductCatalog";
                readonly usecaseRef: "browseProductCatalog";
                readonly inputTypeName: "BrowseProductCatalogInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "searchName";
                    readonly fieldRef: "Product.name";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Texto de busca para filtrar produtos pelo nome";
                }, {
                    readonly inputId: "productCategoryId";
                    readonly fieldRef: "Product.productCategoryId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Identificador da categoria para filtrar os produtos do catálogo";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Product.status";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.locale";
                    readonly description: "O backend aplica automaticamente o filtro status=active para que o cliente veja apenas produtos ativos no catálogo, sem exigir esse campo na requisição";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Product";
                    readonly keyField: "Product.productId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["Product.productId", "Product.name", "Product.description", "Product.price", "Product.imageUrl", "Product.productCategoryId", "Product.featured"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.browseProductCatalog.browseProductCatalog";
                readonly handlerName: "petShopBrowseProductCatalogHandler";
            }];
        };
    };
    export default browseProductCatalogController;
    export const pipeline: readonly [{
        readonly id: "browseProductCatalog__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseProductCatalog.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseProductCatalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/browseProductCatalog.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/product" {
    export type ProductStatus = 'active' | 'inactive';
    export interface Product {
        productId: string;
        name: string;
        description: string | null;
        price: number;
        imageUrl: string | null;
        productCategoryId: string;
        featured: boolean;
        status: ProductStatus;
        createdAt: string;
        updatedAt: string;
    }
    export const PRODUCT_STATUS_TRANSITIONS: Record<ProductStatus, ProductStatus[]>;
    export function canTransitionProduct(from: ProductStatus, to: ProductStatus): boolean;
    export function productPriceIsValid(price: number): boolean;
    export function productIsVisibleInCatalog(product: Pick<Product, 'status'>): boolean;
    export function productCanBeFeatured(product: Pick<Product, 'status' | 'featured'>): boolean;
    export function productUpdatedAtIsValid(product: Pick<Product, 'createdAt' | 'updatedAt'>): boolean;
    export function validateProductInvariants(product: Product): string[];
}
declare module "_102049_/l1/petShop/layer_2_application/ports/productRepository" {
    import type { Product, ProductStatus } from "_102049_/l1/petShop/layer_3_domain/entities/product";
    export type ProductId = string;
    export type Sku = string;
    export type Category = string;
    export interface ProductFilter {
        status?: ProductStatus;
        productCategoryId?: string;
        featured?: boolean;
        name?: string;
    }
    export interface IProductRepository {
        getById(id: ProductId): Promise<Product | null>;
        list(filter: ProductFilter): Promise<Product[]>;
        save(product: Product): Promise<void>;
        findBySku(sku: Sku): Promise<Product | null>;
        findByCategory(category: Category): Promise<Product[]>;
    }
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseProductCatalog" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseProductCatalogInput {
        searchName?: string;
        productCategoryId?: string;
        page?: number;
        pageSize?: number;
    }
    export interface BrowseProductCatalogItem {
        productId: string;
        name: string;
        description: string | null;
        price: number;
        imageUrl: string | null;
        productCategoryId: string;
        featured: boolean;
    }
    export interface BrowseProductCatalogOutput {
        products: BrowseProductCatalogItem[];
        totalCount: number;
    }
    export function browseProductCatalog(ctx: RequestContext, input: BrowseProductCatalogInput): Promise<BrowseProductCatalogOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseProductCatalog" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopBrowseProductCatalogHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseProducts.defs" {
    export const browseProductsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseProducts";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseProducts";
            readonly controllerName: "BrowseProductsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopBrowseProductsHandler";
                readonly command: "browseProducts";
                readonly usecaseRef: "browseProducts";
                readonly inputTypeName: "BrowseProductsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "searchName";
                    readonly fieldRef: "Product.name";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Texto de busca para filtrar produtos pelo nome.";
                }, {
                    readonly inputId: "filterStatus";
                    readonly fieldRef: "Product.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro de situação do produto: ativo ou inativo.";
                }, {
                    readonly inputId: "filterProductCategoryId";
                    readonly fieldRef: "Product.productCategoryId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro por categoria de produto.";
                }, {
                    readonly inputId: "filterFeatured";
                    readonly fieldRef: "Product.featured";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro para exibir apenas produtos marcados como destaque.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "actorSession.actorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend resolve o identificador do administrador a partir da sessão ativa para autorizar o acesso à lista de produtos.";
                }, {
                    readonly targetRef: "actorSession.scope";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.scope";
                    readonly description: "O backend resolve o escopo da sessão do administrador para garantir que apenas usuários com perfil admin possam consultar o catálogo.";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Product";
                    readonly keyField: "Product.productId";
                    readonly pagination: "optional";
                    readonly selection: "multiple";
                    readonly output: readonly ["Product.productId", "Product.name", "Product.price", "Product.imageUrl", "Product.productCategoryId", "Product.featured", "Product.status", "Product.createdAt", "Product.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.browseProducts.browseProducts";
                readonly handlerName: "petShopBrowseProductsHandler";
            }];
        };
    };
    export default browseProductsController;
    export const pipeline: readonly [{
        readonly id: "browseProducts__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseProducts.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseProducts.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/browseProducts.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseProducts" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseProductsInput {
        searchName?: string;
        filterStatus?: string;
        filterProductCategoryId?: string;
        filterFeatured?: boolean;
    }
    export interface BrowseProductsOutputItem {
        productId: string;
        name: string;
        price: number;
        imageUrl: string | null;
        productCategoryId: string;
        featured: boolean;
        status: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface BrowseProductsOutput {
        products: BrowseProductsOutputItem[];
    }
    export function browseProducts(ctx: RequestContext, input: BrowseProductsInput): Promise<BrowseProductsOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseProducts" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopBrowseProductsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseServiceCatalog.defs" {
    export const browseServiceCatalogController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseServiceCatalog";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseServiceCatalog";
            readonly controllerName: "BrowseServiceCatalogController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopBrowseServiceCatalogHandler";
                readonly command: "browseServiceCatalog";
                readonly usecaseRef: "browseServiceCatalog";
                readonly inputTypeName: "BrowseServiceCatalogInput";
                readonly kind: "query";
                readonly inputContract: readonly [];
                readonly contextResolution: readonly [];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Service";
                    readonly keyField: "Service.serviceId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["Service.serviceId", "Service.name", "Service.description", "Service.estimatedDurationMinutes", "Service.price"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.browseServiceCatalog.browseServiceCatalog";
                readonly handlerName: "petShopBrowseServiceCatalogHandler";
            }];
        };
    };
    export default browseServiceCatalogController;
    export const pipeline: readonly [{
        readonly id: "browseServiceCatalog__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseServiceCatalog.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseServiceCatalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/browseServiceCatalog.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/service" {
    export type ServiceStatus = 'active' | 'inactive';
    export interface Service {
        serviceId: string;
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
        status: ServiceStatus;
        deactivatedAt: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export const SERVICE_STATUS_VALUES: ServiceStatus[];
    export function isValidServiceStatus(value: string): value is ServiceStatus;
    export function serviceHasPositiveDuration(service: Pick<Service, 'estimatedDurationMinutes'>): boolean;
    export function serviceHasNonNegativePrice(service: Pick<Service, 'price'>): boolean;
    export function isServiceActive(service: Pick<Service, 'status'>): boolean;
    export function isServiceInactive(service: Pick<Service, 'status'>): boolean;
    export function serviceStatusInvariantConsistent(service: Pick<Service, 'status' | 'deactivatedAt'>): boolean;
    export function serviceUpdatedAtIsValid(service: Pick<Service, 'createdAt' | 'updatedAt'>): boolean;
    export function validateServiceInvariants(service: Service): string[];
}
declare module "_102049_/l1/petShop/layer_2_application/ports/serviceRepository" {
    import type { Service, ServiceStatus } from "_102049_/l1/petShop/layer_3_domain/entities/service";
    export type ServiceId = string;
    export type ServiceType = string;
    export interface ServiceFilter {
        serviceId?: ServiceId;
        status?: ServiceStatus;
        name?: string;
    }
    export interface IServiceRepository {
        getById(id: ServiceId): Promise<Service | null>;
        list(filter?: ServiceFilter): Promise<Service[]>;
        save(service: Service): Promise<void>;
        findByType(type: ServiceType): Promise<Service[]>;
        findActive(): Promise<Service[]>;
    }
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseServiceCatalog" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseServiceCatalogInput {
        page?: number;
        pageSize?: number;
    }
    export interface BrowseServiceCatalogItem {
        serviceId: string;
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
    }
    export interface BrowseServiceCatalogOutput {
        items: BrowseServiceCatalogItem[];
        page: number;
        pageSize: number;
        total: number;
    }
    export function browseServiceCatalog(ctx: RequestContext, input: BrowseServiceCatalogInput): Promise<BrowseServiceCatalogOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseServiceCatalog" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopBrowseServiceCatalogHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseServices.defs" {
    export const browseServicesController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseServices";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseServices";
            readonly controllerName: "BrowseServicesController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopBrowseServicesHandler";
                readonly command: "browseServices";
                readonly usecaseRef: "browseServices";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "statusFilter";
                    readonly fieldRef: "Service.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional por status de ativação (active ou inactive) para restringir a listagem.";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "Operator.operatorId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do administrador autenticado que solicita a listagem.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Operator.operatorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend resolve o identificador do administrador a partir da sessão ativa do ator autenticado.";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Service";
                    readonly keyField: "Service.serviceId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["Service.serviceId", "Service.name", "Service.description", "Service.estimatedDurationMinutes", "Service.price", "Service.status", "Service.deactivatedAt", "Service.createdAt", "Service.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.browseServices.browseServices";
                readonly handlerName: "petShopBrowseServicesHandler";
            }];
        };
    };
    export default browseServicesController;
    export const pipeline: readonly [{
        readonly id: "browseServices__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseServices.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseServices.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/browseServices.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseServices" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopBrowseServicesHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseShifts.defs" {
    export const browseShiftsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseShifts";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseShifts";
            readonly controllerName: "BrowseShiftsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopBrowseShiftsHandler";
                readonly command: "browseShifts";
                readonly usecaseRef: "browseShifts";
                readonly inputTypeName: "BrowseShiftsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "activeFilter";
                    readonly fieldRef: "Shift.active";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional para exibir apenas turnos ativos ou inativos.";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "Shift.shiftId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do administrador autenticado que solicita a lista de turnos.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "actorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend resolve o identificador do administrador a partir da sessão ativa do ator autenticado.";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Shift";
                    readonly keyField: "Shift.shiftId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["Shift.shiftId", "Shift.name", "Shift.startTime", "Shift.endTime", "Shift.monday", "Shift.tuesday", "Shift.wednesday", "Shift.thursday", "Shift.friday", "Shift.saturday", "Shift.sunday", "Shift.active", "Shift.createdAt", "Shift.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.browseShifts.browseShifts";
                readonly handlerName: "petShopBrowseShiftsHandler";
            }];
        };
    };
    export default browseShiftsController;
    export const pipeline: readonly [{
        readonly id: "browseShifts__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseShifts.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseShifts.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/browseShifts.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseShifts" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseShiftsInput {
        activeFilter?: boolean;
    }
    export interface BrowseShiftsItem {
        shiftId: string;
        name: string;
        startTime: string;
        endTime: string;
        monday: boolean;
        tuesday: boolean;
        wednesday: boolean;
        thursday: boolean;
        friday: boolean;
        saturday: boolean;
        sunday: boolean;
        active: boolean;
        createdAt: string;
        updatedAt: string;
    }
    export interface BrowseShiftsOutput {
        shifts: BrowseShiftsItem[];
    }
    export function browseShifts(ctx: RequestContext, input: BrowseShiftsInput): Promise<BrowseShiftsOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseShifts" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopBrowseShiftsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/completeServiceExecution.defs" {
    export const completeServiceExecutionController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "completeServiceExecution";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "serviceBookingLifecycle";
            readonly controllerName: "CompleteServiceExecutionController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopCompleteServiceExecutionHandler";
                readonly command: "completeServiceExecution";
                readonly usecaseRef: "completeServiceExecution";
                readonly inputTypeName: "CompleteServiceExecutionInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "serviceBookingId";
                    readonly fieldRef: "ServiceBooking.serviceBookingId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador do agendamento de serviço a ser concluído, selecionado pelo operador na agenda.";
                }, {
                    readonly inputId: "operatorId";
                    readonly fieldRef: "ServiceBooking.operatorId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do operador autenticado que está concluindo o serviço, usado para validar que ele é o operador atribuído.";
                }, {
                    readonly inputId: "completedAt";
                    readonly fieldRef: "ServiceBooking.completedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora em que o serviço foi marcado como concluído, gerada automaticamente pelo sistema.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "ServiceBooking.serviceBookingId";
                    readonly source: "selectedEntity";
                    readonly originRef: "ServiceBooking.serviceBookingId";
                    readonly description: "O agendamento atualmente selecionado pelo operador na tela de agenda, identificado pelo seu serviceBookingId.";
                }, {
                    readonly targetRef: "ServiceBooking.operatorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O identificador do operador autenticado obtido da sessão ativa, usado para verificar se ele é o operador atribuído ao agendamento.";
                }, {
                    readonly targetRef: "ServiceBooking.completedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "A data e hora atual do sistema no momento da conclusão, registrada automaticamente como completedAt.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "ServiceBooking";
                    readonly keyField: "ServiceBooking.serviceBookingId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["ServiceBooking.serviceBookingId", "ServiceBooking.status", "ServiceBooking.completedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.serviceBookingLifecycle.completeServiceExecution";
                readonly handlerName: "petShopCompleteServiceExecutionHandler";
            }];
        };
    };
    export default completeServiceExecutionController;
    export const pipeline: readonly [{
        readonly id: "completeServiceExecution__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/completeServiceExecution.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/completeServiceExecution.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/completeServiceExecution.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/serviceBooking" {
    export type ServiceBookingStatus = 'confirmed' | 'inProgress' | 'completed' | 'cancelled';
    export interface ServiceBooking {
        serviceBookingId: string;
        serviceId: string;
        operatorId: string;
        shiftId: string;
        customerName: string;
        customerPhone: string;
        bookingDate: string;
        bookingTime: string;
        status: ServiceBookingStatus;
        notes: string | null;
        completedAt: string | null;
        cancelledAt: string | null;
        cancelReason: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export const SERVICE_BOOKING_STATUS_TRANSITIONS: Record<ServiceBookingStatus, ServiceBookingStatus[]>;
    export function canTransitionServiceBooking(from: ServiceBookingStatus, to: ServiceBookingStatus): boolean;
    export function isValidServiceBookingStatus(status: string): status is ServiceBookingStatus;
    /**
     * bookingDate must be between Monday and Saturday (inclusive).
     * Expects an ISO date string (YYYY-MM-DD).
     */
    export function isBookingDateWithinOperatingDays(bookingDate: string): boolean;
    /**
     * bookingTime must be within store operating hours (09:00 to 18:00).
     * Expects a time string in HH:mm format.
     */
    export function isBookingTimeWithinOperatingHours(bookingTime: string): boolean;
    /**
     * When status is 'completed', completedAt must be set.
     */
    export function serviceBookingCompletedRequiresCompletedAt(booking: Pick<ServiceBooking, 'status' | 'completedAt'>): boolean;
    /**
     * When status is 'cancelled', cancelledAt and cancelReason must be set.
     */
    export function serviceBookingCancelledRequiresCancellationFields(booking: Pick<ServiceBooking, 'status' | 'cancelledAt' | 'cancelReason'>): boolean;
    /**
     * completedAt and cancelledAt are mutually exclusive.
     */
    export function serviceBookingCompletionAndCancellationAreMutuallyExclusive(booking: Pick<ServiceBooking, 'completedAt' | 'cancelledAt'>): boolean;
    /**
     * updatedAt must be greater than or equal to createdAt.
     */
    export function serviceBookingUpdatedAtIsValid(booking: Pick<ServiceBooking, 'createdAt' | 'updatedAt'>): boolean;
    /**
     * Validates all invariants for a ServiceBooking entity.
     * Returns an array of error messages (empty if valid).
     */
    export function validateServiceBookingInvariants(booking: ServiceBooking): string[];
}
declare module "_102049_/l1/petShop/layer_2_application/ports/serviceBookingRepository" {
    import type { ServiceBooking, ServiceBookingStatus } from "_102049_/l1/petShop/layer_3_domain/entities/serviceBooking";
    export type ServiceBookingId = string;
    export type CustomerId = string;
    export interface DateRange {
        from: string;
        to: string;
    }
    export interface ServiceBookingFilter {
        serviceBookingId?: ServiceBookingId;
        serviceId?: string;
        operatorId?: string;
        shiftId?: string;
        status?: ServiceBookingStatus;
        bookingDate?: string;
    }
    export interface IServiceBookingRepository {
        getById(id: ServiceBookingId): Promise<ServiceBooking | null>;
        list(filter: ServiceBookingFilter): Promise<ServiceBooking[]>;
        save(booking: ServiceBooking): Promise<void>;
        findByCustomerId(customerId: CustomerId): Promise<ServiceBooking[]>;
        findByPeriod(period: DateRange): Promise<ServiceBooking[]>;
    }
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/completeServiceExecution" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CompleteServiceExecutionInput {
        serviceBookingId: string;
    }
    export interface CompleteServiceExecutionOutput {
        serviceBookingId: string;
        status: string;
        completedAt: string;
    }
    export function completeServiceExecution(ctx: RequestContext, input: CompleteServiceExecutionInput): Promise<CompleteServiceExecutionOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/completeServiceExecution" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopCompleteServiceExecutionHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createAdoptablePet.defs" {
    export const createAdoptablePetController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createAdoptablePet";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createAdoptablePet";
            readonly controllerName: "CreateAdoptablePetController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopCreateAdoptablePetHandler";
                readonly command: "createAdoptablePet";
                readonly usecaseRef: "createAdoptablePet";
                readonly inputTypeName: "CreateAdoptablePetInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "name";
                    readonly fieldRef: "AdoptablePet.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do pet informado pelo administrador";
                }, {
                    readonly inputId: "age";
                    readonly fieldRef: "AdoptablePet.age";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Idade do pet em anos informada pelo administrador";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "AdoptablePet.description";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Descrição do pet exibida na galeria pública";
                }, {
                    readonly inputId: "photoUrl";
                    readonly fieldRef: "AdoptablePet.photoUrl";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "URL da foto do pet no armazenamento de mídia da plataforma";
                }, {
                    readonly inputId: "adoptablePetId";
                    readonly fieldRef: "AdoptablePet.adoptablePetId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Identificador único gerado automaticamente pelo sistema";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "AdoptablePet.status";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Status de disponibilidade definido como disponível no cadastro";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "AdoptablePet.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora de cadastro gerada automaticamente";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "AdoptablePet.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização gerada automaticamente";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "AdoptablePet.adoptablePetId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "O backend gera um UUID v4 automaticamente ao persistir o novo pet";
                }, {
                    readonly targetRef: "AdoptablePet.status";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define o status inicial como 'available' para que o pet apareça na galeria pública conforme a regra de domínio";
                }, {
                    readonly targetRef: "AdoptablePet.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra a data e hora atual do servidor no momento da criação";
                }, {
                    readonly targetRef: "AdoptablePet.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra a data e hora atual do servidor no momento da criação, igual a createdAt";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "AdoptablePet";
                    readonly keyField: "AdoptablePet.adoptablePetId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["AdoptablePet.adoptablePetId", "AdoptablePet.name", "AdoptablePet.age", "AdoptablePet.description", "AdoptablePet.photoUrl", "AdoptablePet.status", "AdoptablePet.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.createAdoptablePet.createAdoptablePet";
                readonly handlerName: "petShopCreateAdoptablePetHandler";
            }];
        };
    };
    export default createAdoptablePetController;
    export const pipeline: readonly [{
        readonly id: "createAdoptablePet__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createAdoptablePet.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createAdoptablePet.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/createAdoptablePet.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/adoptablePet" {
    export type AdoptablePetStatus = 'available' | 'unavailable';
    export interface AdoptablePet {
        adoptablePetId: string;
        name: string;
        age: number;
        description: string;
        photoUrl: string;
        status: AdoptablePetStatus;
        createdAt: string;
        updatedAt: string;
    }
    export const ADOPTABLE_PET_STATUS_TRANSITIONS: Record<AdoptablePetStatus, AdoptablePetStatus[]>;
    export function canTransitionAdoptablePetStatus(from: AdoptablePetStatus, to: AdoptablePetStatus): boolean;
    export function adoptablePetAgeIsValid(age: number): boolean;
    export function adoptablePetStatusIsValid(status: string): status is AdoptablePetStatus;
    export function adoptablePetIsVisibleInGallery(pet: Pick<AdoptablePet, 'status'>): boolean;
    export function adoptablePetTimestampsAreValid(pet: Pick<AdoptablePet, 'createdAt' | 'updatedAt'>): boolean;
    export function validateAdoptablePetInvariants(pet: AdoptablePet): string[];
}
declare module "_102049_/l1/petShop/layer_2_application/ports/adoptablePetRepository" {
    import type { AdoptablePet, AdoptablePetStatus } from "_102049_/l1/petShop/layer_3_domain/entities/adoptablePet";
    export type AdoptablePetId = string;
    export type Species = string;
    export interface AdoptablePetFilter {
        status?: AdoptablePetStatus;
        species?: Species;
    }
    export interface IAdoptablePetRepository {
        getById(id: AdoptablePetId): Promise<AdoptablePet | null>;
        list(filter?: AdoptablePetFilter): Promise<AdoptablePet[]>;
        save(pet: AdoptablePet): Promise<void>;
        findAvailable(): Promise<AdoptablePet[]>;
        findBySpecies(species: Species): Promise<AdoptablePet[]>;
    }
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/createAdoptablePet" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateAdoptablePetInput {
        name: string;
        age: number;
        description: string;
        photoUrl: string;
    }
    export interface CreateAdoptablePetOutput {
        adoptablePetId: string;
        name: string;
        age: number;
        description: string;
        photoUrl: string;
        status: string;
        createdAt: string;
    }
    export function createAdoptablePet(ctx: RequestContext, input: CreateAdoptablePetInput): Promise<CreateAdoptablePetOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createAdoptablePet" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopCreateAdoptablePetHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createOperator.defs" {
    export const createOperatorController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createOperator";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createOperator";
            readonly controllerName: "CreateOperatorController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopCreateOperatorHandler";
                readonly command: "createOperator";
                readonly usecaseRef: "createOperator";
                readonly inputTypeName: "CreateOperatorInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "name";
                    readonly fieldRef: "Operator.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome completo do operador exibido na agenda e nos agendamentos atribuídos.";
                }, {
                    readonly inputId: "email";
                    readonly fieldRef: "Operator.email";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "E-mail de contato do operador para notificações de agenda.";
                }, {
                    readonly inputId: "phone";
                    readonly fieldRef: "Operator.phone";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Telefone de contato do operador.";
                }, {
                    readonly inputId: "active";
                    readonly fieldRef: "Operator.active";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o operador inicia ativo e pode ser alocado em turnos; o formulário apresenta a opção marcada por padrão.";
                }, {
                    readonly inputId: "operatorId";
                    readonly fieldRef: "Operator.operatorId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Identificador único do operador gerado automaticamente pelo sistema.";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "Operator.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora de cadastro do operador, definida automaticamente no momento da criação.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Operator.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização, inicialmente igual à data de criação.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Operator.operatorId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "O backend gera um UUID v4 automaticamente ao persistir o novo operador.";
                }, {
                    readonly targetRef: "Operator.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra o timestamp atual no momento da criação do operador.";
                }, {
                    readonly targetRef: "Operator.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define o timestamp atual igual ao de criação na primeira persistência.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Operator";
                    readonly keyField: "Operator.operatorId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["Operator.operatorId", "Operator.name", "Operator.email", "Operator.phone", "Operator.active", "Operator.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.createOperator.createOperator";
                readonly handlerName: "petShopCreateOperatorHandler";
            }];
        };
    };
    export default createOperatorController;
    export const pipeline: readonly [{
        readonly id: "createOperator__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createOperator.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createOperator.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/createOperator.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/createOperator" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateOperatorInput {
        name: string;
        email?: string;
        phone?: string;
        active: boolean;
    }
    export interface CreateOperatorOutput {
        operatorId: string;
        name: string;
        email: string | null;
        phone: string | null;
        active: boolean;
        createdAt: string;
    }
    export function createOperator(ctx: RequestContext, input: CreateOperatorInput): Promise<CreateOperatorOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createOperator" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopCreateOperatorHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createProduct.defs" {
    export const createProductController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createProduct";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createProduct";
            readonly controllerName: "CreateProductController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopCreateProductHandler";
                readonly command: "createProduct";
                readonly usecaseRef: "createProduct";
                readonly inputTypeName: "CreateProductInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "name";
                    readonly fieldRef: "Product.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do produto exibido no catálogo e na página inicial.";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "Product.description";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Descrição detalhada do produto para o cliente.";
                }, {
                    readonly inputId: "price";
                    readonly fieldRef: "Product.price";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Preço do produto cobrado na retirada presencial na loja.";
                }, {
                    readonly inputId: "imageUrl";
                    readonly fieldRef: "Product.imageUrl";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "URL da imagem do produto no armazenamento de mídia da plataforma.";
                }, {
                    readonly inputId: "productCategoryId";
                    readonly fieldRef: "Product.productCategoryId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Categoria do produto selecionada pelo administrador.";
                }, {
                    readonly inputId: "featured";
                    readonly fieldRef: "Product.featured";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o produto deve ser exibido em destaque na página inicial.";
                }, {
                    readonly inputId: "productId";
                    readonly fieldRef: "Product.productId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Identificador único do produto gerado automaticamente.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Product.status";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Status inicial do produto, definido como ativo no cadastro.";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "Product.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora de cadastro do produto.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Product.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização do produto.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Product.productId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "O backend gera um UUID para o novo produto antes da persistência.";
                }, {
                    readonly targetRef: "Product.status";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define o status inicial do produto como 'active' no momento do cadastro.";
                }, {
                    readonly targetRef: "Product.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra a data e hora atuais no campo createdAt ao criar o produto.";
                }, {
                    readonly targetRef: "Product.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra a data e hora atuais no campo updatedAt ao criar o produto.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Product";
                    readonly keyField: "Product.productId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Product.productId", "Product.name", "Product.price", "Product.productCategoryId", "Product.featured", "Product.status", "Product.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.createProduct.createProduct";
                readonly handlerName: "petShopCreateProductHandler";
            }];
        };
    };
    export default createProductController;
    export const pipeline: readonly [{
        readonly id: "createProduct__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createProduct.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createProduct.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/createProduct.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/createProduct" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateProductInput {
        name: string;
        description?: string;
        price: number;
        imageUrl?: string;
        productCategoryId: string;
        featured: boolean;
    }
    export interface CreateProductOutput {
        productId: string;
        name: string;
        price: number;
        productCategoryId: string;
        featured: boolean;
        status: string;
        createdAt: string;
    }
    export function createProduct(ctx: RequestContext, input: CreateProductInput): Promise<CreateProductOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createProduct" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopCreateProductHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createService.defs" {
    export const createServiceController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createService";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createService";
            readonly controllerName: "CreateServiceController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopCreateServiceHandler";
                readonly command: "createService";
                readonly usecaseRef: "createService";
                readonly inputTypeName: "CreateServiceInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "name";
                    readonly fieldRef: "Service.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do serviço oferecido, como banho e tosa.";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "Service.description";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Descrição detalhada do serviço oferecido ao cliente.";
                }, {
                    readonly inputId: "estimatedDurationMinutes";
                    readonly fieldRef: "Service.estimatedDurationMinutes";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Duração estimada do serviço em minutos, usada para cálculo de horários disponíveis.";
                }, {
                    readonly inputId: "price";
                    readonly fieldRef: "Service.price";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Preço do serviço, cobrado presencialmente na loja após a execução.";
                }, {
                    readonly inputId: "serviceId";
                    readonly fieldRef: "Service.serviceId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Identificador único do serviço, gerado automaticamente pelo sistema.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Service.status";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Estado de ativação do serviço; ao cadastrar, o sistema define automaticamente como ativo.";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "Service.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora de criação do registro, definida automaticamente pelo sistema.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Service.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização do registro, definida automaticamente pelo sistema.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Service.serviceId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "O backend gera um UUID para o novo serviço no momento da persistência.";
                }, {
                    readonly targetRef: "Service.status";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define o status inicial como 'active' para que o serviço recém-criado apareça na listagem para clientes.";
                }, {
                    readonly targetRef: "Service.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra a data e hora atuais no momento da criação do registro.";
                }, {
                    readonly targetRef: "Service.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra a data e hora atuais no momento da criação do registro, coincidindo com createdAt.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Service";
                    readonly keyField: "Service.serviceId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["Service.serviceId", "Service.name", "Service.description", "Service.estimatedDurationMinutes", "Service.price", "Service.status", "Service.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.createService.createService";
                readonly handlerName: "petShopCreateServiceHandler";
            }];
        };
    };
    export default createServiceController;
    export const pipeline: readonly [{
        readonly id: "createService__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createService.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createService.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/createService.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/createService" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateServiceInput {
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
    }
    export interface CreateServiceOutput {
        serviceId: string;
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
        status: string;
        createdAt: string;
    }
    export function createService(ctx: RequestContext, input: CreateServiceInput): Promise<CreateServiceOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createService" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopCreateServiceHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createServiceBooking.defs" {
    export const createServiceBookingController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createServiceBooking";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "serviceBookingLifecycle";
            readonly controllerName: "CreateServiceBookingController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopCreateServiceBookingHandler";
                readonly command: "createServiceBooking";
                readonly usecaseRef: "createServiceBooking";
                readonly inputTypeName: "CreateServiceBookingInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "serviceId";
                    readonly fieldRef: "Service.serviceId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Serviço selecionado pelo cliente para agendamento.";
                }, {
                    readonly inputId: "customerName";
                    readonly fieldRef: "ServiceBooking.customerName";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do cliente que realiza o agendamento.";
                }, {
                    readonly inputId: "customerPhone";
                    readonly fieldRef: "ServiceBooking.customerPhone";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Telefone de contato do cliente.";
                }, {
                    readonly inputId: "bookingDate";
                    readonly fieldRef: "ServiceBooking.bookingDate";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Data do agendamento escolhida pelo cliente, dentro do horário de funcionamento.";
                }, {
                    readonly inputId: "bookingTime";
                    readonly fieldRef: "ServiceBooking.bookingTime";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Horário do agendamento escolhido pelo cliente, dentro do intervalo de funcionamento.";
                }, {
                    readonly inputId: "notes";
                    readonly fieldRef: "ServiceBooking.notes";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Observações adicionais opcionais informadas pelo cliente.";
                }, {
                    readonly inputId: "serviceBookingId";
                    readonly fieldRef: "ServiceBooking.serviceBookingId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Identificador único gerado pelo sistema para o novo agendamento.";
                }, {
                    readonly inputId: "shiftId";
                    readonly fieldRef: "ServiceBooking.shiftId";
                    readonly required: true;
                    readonly source: "previousStepOutput";
                    readonly description: "Turno correspondente à data e horário escolhidos, determinado pela disponibilidade de operadores.";
                }, {
                    readonly inputId: "operatorId";
                    readonly fieldRef: "ServiceBooking.operatorId";
                    readonly required: true;
                    readonly source: "previousStepOutput";
                    readonly description: "Operador disponível selecionado pelo sistema entre os alocados no turno correspondente.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "ServiceBooking.status";
                    readonly required: true;
                    readonly source: "workflowState";
                    readonly description: "Status inicial do agendamento definido pelo ciclo de vida como confirmed.";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "ServiceBooking.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora de criação do agendamento gerada pelo sistema.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "ServiceBooking.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização do agendamento gerada pelo sistema.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "ServiceBooking.serviceBookingId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "O backend gera um novo UUID para o identificador do agendamento no momento da criação.";
                }, {
                    readonly targetRef: "ServiceBooking.shiftId";
                    readonly source: "previousStepOutput";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "O backend consulta as entidades Shift que cobrem a bookingDate e bookingTime informadas pelo cliente e seleciona o turno correspondente.";
                }, {
                    readonly targetRef: "ServiceBooking.operatorId";
                    readonly source: "previousStepOutput";
                    readonly originRef: "Operator.operatorId";
                    readonly description: "O backend consulta ShiftAssignment para o turno resolvido, verifica operadores com capacidade disponível (número de agendamentos existentes menor que o número de operadores alocados) e seleciona um operador disponível.";
                }, {
                    readonly targetRef: "ServiceBooking.status";
                    readonly source: "workflowState";
                    readonly originRef: "ServiceBooking.status";
                    readonly description: "O workflow serviceBookingLifecycle define o estado inicial do agendamento como confirmed ao criar a instância.";
                }, {
                    readonly targetRef: "ServiceBooking.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra o timestamp atual do sistema no momento da criação do agendamento.";
                }, {
                    readonly targetRef: "ServiceBooking.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra o timestamp atual do sistema como data da última atualização ao criar o agendamento.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "ServiceBooking";
                    readonly keyField: "ServiceBooking.serviceBookingId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["ServiceBooking.serviceBookingId", "ServiceBooking.serviceId", "ServiceBooking.operatorId", "ServiceBooking.shiftId", "ServiceBooking.bookingDate", "ServiceBooking.bookingTime", "ServiceBooking.status", "ServiceBooking.customerName"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.serviceBookingLifecycle.createServiceBooking";
                readonly handlerName: "petShopCreateServiceBookingHandler";
            }];
        };
    };
    export default createServiceBookingController;
    export const pipeline: readonly [{
        readonly id: "createServiceBooking__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createServiceBooking.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createServiceBooking.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/createServiceBooking.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/createServiceBooking" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateServiceBookingInput {
        serviceId: string;
        customerName: string;
        customerPhone: string;
        bookingDate: string;
        bookingTime: string;
        notes?: string;
    }
    export interface CreateServiceBookingOutput {
        serviceBookingId: string;
        serviceId: string;
        operatorId: string;
        shiftId: string;
        bookingDate: string;
        bookingTime: string;
        status: string;
        customerName: string;
    }
    export function createServiceBooking(ctx: RequestContext, input: CreateServiceBookingInput): Promise<CreateServiceBookingOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createServiceBooking" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopCreateServiceBookingHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createShift.defs" {
    export const createShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createShift";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createShift";
            readonly controllerName: "CreateShiftController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopCreateShiftHandler";
                readonly command: "createShift";
                readonly usecaseRef: "createShift";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "name";
                    readonly fieldRef: "Shift.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do turno para identificação (ex.: Manhã, Tarde, Dia Inteiro).";
                }, {
                    readonly inputId: "startTime";
                    readonly fieldRef: "Shift.startTime";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Horário de início do turno no formato HH:mm (ex.: 09:00).";
                }, {
                    readonly inputId: "endTime";
                    readonly fieldRef: "Shift.endTime";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Horário de fim do turno no formato HH:mm (ex.: 18:00).";
                }, {
                    readonly inputId: "monday";
                    readonly fieldRef: "Shift.monday";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o turno ocorre às segundas-feiras.";
                }, {
                    readonly inputId: "tuesday";
                    readonly fieldRef: "Shift.tuesday";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o turno ocorre às terças-feiras.";
                }, {
                    readonly inputId: "wednesday";
                    readonly fieldRef: "Shift.wednesday";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o turno ocorre às quartas-feiras.";
                }, {
                    readonly inputId: "thursday";
                    readonly fieldRef: "Shift.thursday";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o turno ocorre às quintas-feiras.";
                }, {
                    readonly inputId: "friday";
                    readonly fieldRef: "Shift.friday";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o turno ocorre às sextas-feiras.";
                }, {
                    readonly inputId: "saturday";
                    readonly fieldRef: "Shift.saturday";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o turno ocorre aos sábados.";
                }, {
                    readonly inputId: "sunday";
                    readonly fieldRef: "Shift.sunday";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o turno ocorre aos domingos.";
                }, {
                    readonly inputId: "active";
                    readonly fieldRef: "Shift.active";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o turno está ativo e disponível para alocação de operadores e agendamentos.";
                }, {
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Shift.shiftId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Identificador único do turno gerado automaticamente pelo sistema.";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "Shift.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora de criação do turno, definida automaticamente pelo sistema.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Shift.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização do turno, definida automaticamente como a data de criação.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Shift.shiftId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "O backend gera um UUID v4 para o identificador único do turno no momento da criação.";
                }, {
                    readonly targetRef: "Shift.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra o timestamp atual do servidor como data de criação do turno.";
                }, {
                    readonly targetRef: "Shift.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra o timestamp atual do servidor como data de atualização do turno, igual à data de criação na criação.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Shift";
                    readonly keyField: "Shift.shiftId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Shift.shiftId", "Shift.name", "Shift.startTime", "Shift.endTime", "Shift.monday", "Shift.tuesday", "Shift.wednesday", "Shift.thursday", "Shift.friday", "Shift.saturday", "Shift.sunday", "Shift.active", "Shift.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.createShift.createShift";
                readonly handlerName: "petShopCreateShiftHandler";
            }];
        };
    };
    export default createShiftController;
    export const pipeline: readonly [{
        readonly id: "createShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createShift.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createShift.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/createShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createShift" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopCreateShiftHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/expressAdoptionInterest.defs" {
    export const expressAdoptionInterestController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "expressAdoptionInterest";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "expressAdoptionInterest";
            readonly controllerName: "ExpressAdoptionInterestController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopExpressAdoptionInterestHandler";
                readonly command: "expressAdoptionInterest";
                readonly usecaseRef: "expressAdoptionInterest";
                readonly inputTypeName: "ExpressAdoptionInterestInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "adoptablePetId";
                    readonly fieldRef: "AdoptionInterest.adoptablePetId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Pet disponível para adoção selecionado pelo cliente no site.";
                }, {
                    readonly inputId: "customerName";
                    readonly fieldRef: "AdoptionInterest.customerName";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome completo do cliente que manifesta interesse em adotar.";
                }, {
                    readonly inputId: "customerEmail";
                    readonly fieldRef: "AdoptionInterest.customerEmail";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "E-mail de contato do cliente para comunicação sobre a adoção.";
                }, {
                    readonly inputId: "customerPhone";
                    readonly fieldRef: "AdoptionInterest.customerPhone";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Telefone de contato do cliente para agendamento da visita presencial.";
                }, {
                    readonly inputId: "adoptionInterestId";
                    readonly fieldRef: "AdoptionInterest.adoptionInterestId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Identificador único gerado automaticamente para o registro de interesse.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "AdoptionInterest.status";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Status inicial do registro, definido como 'registered'.";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "AdoptionInterest.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora do registro do interesse, gerada automaticamente.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "AdoptionInterest.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização, definida igual ao createdAt na criação.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "AdoptionInterest.adoptablePetId";
                    readonly source: "selectedEntity";
                    readonly originRef: "AdoptablePet.adoptablePetId";
                    readonly description: "O backend obtém o ID do pet atualmente selecionado pelo cliente na tela de visualização de pets disponíveis para adoção.";
                }, {
                    readonly targetRef: "AdoptionInterest.adoptionInterestId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "O backend gera um UUID automaticamente para o novo registro de interesse.";
                }, {
                    readonly targetRef: "AdoptionInterest.status";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define o status inicial como 'registered', pois a adoção é apenas iniciada online conforme regra de negócio.";
                }, {
                    readonly targetRef: "AdoptionInterest.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra a data e hora atuais no momento da criação do interesse.";
                }, {
                    readonly targetRef: "AdoptionInterest.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define a data e hora da última atualização igual ao momento da criação.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "AdoptionInterest";
                    readonly keyField: "AdoptionInterest.adoptionInterestId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["AdoptionInterest.adoptionInterestId", "AdoptionInterest.status", "AdoptionInterest.adoptablePetId", "AdoptionInterest.customerName", "AdoptionInterest.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.expressAdoptionInterest.expressAdoptionInterest";
                readonly handlerName: "petShopExpressAdoptionInterestHandler";
            }];
        };
    };
    export default expressAdoptionInterestController;
    export const pipeline: readonly [{
        readonly id: "expressAdoptionInterest__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/expressAdoptionInterest.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/expressAdoptionInterest.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/expressAdoptionInterest.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/adoptionInterest" {
    export type AdoptionInterestStatus = 'registered' | 'completed' | 'cancelled';
    export interface AdoptionInterest {
        adoptionInterestId: string;
        adoptablePetId: string;
        customerName: string;
        customerEmail: string;
        customerPhone: string | null;
        status: AdoptionInterestStatus;
        operatorId: string | null;
        verificationNotes: string | null;
        completedAt: string | null;
        cancelledAt: string | null;
        cancellationReason: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export const ADOPTION_INTEREST_STATUS_TRANSITIONS: Record<AdoptionInterestStatus, AdoptionInterestStatus[]>;
    export function canTransitionAdoptionInterest(from: AdoptionInterestStatus, to: AdoptionInterestStatus): boolean;
    export function validateAdoptionInterest(interest: AdoptionInterest): string[];
}
declare module "_102049_/l1/petShop/layer_2_application/ports/adoptionInterestRepository" {
    import type { AdoptionInterest, AdoptionInterestStatus } from "_102049_/l1/petShop/layer_3_domain/entities/adoptionInterest";
    export type AdoptionInterestId = string;
    export type AdopterId = string;
    export type AdoptablePetId = string;
    export interface AdoptionInterestFilter {
        status?: AdoptionInterestStatus;
        adoptablePetId?: AdoptablePetId;
        customerEmail?: string;
    }
    export interface IAdoptionInterestRepository {
        getById(id: AdoptionInterestId): Promise<AdoptionInterest | null>;
        list(filter?: AdoptionInterestFilter): Promise<AdoptionInterest[]>;
        save(interest: AdoptionInterest): Promise<void>;
        findByAdopterId(adopterId: AdopterId): Promise<AdoptionInterest[]>;
        findByPetId(petId: AdoptablePetId): Promise<AdoptionInterest[]>;
    }
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/expressAdoptionInterest" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ExpressAdoptionInterestInput {
        adoptablePetId: string;
        customerName: string;
        customerEmail: string;
        customerPhone?: string;
    }
    export interface ExpressAdoptionInterestOutput {
        adoptionInterestId: string;
        status: string;
        adoptablePetId: string;
        customerName: string;
        createdAt: string;
    }
    export function expressAdoptionInterest(ctx: RequestContext, input: ExpressAdoptionInterestInput): Promise<ExpressAdoptionInterestOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/expressAdoptionInterest" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopExpressAdoptionInterestHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/placeStorePickupOrder.defs" {
    export const placeStorePickupOrderController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "placeStorePickupOrder";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "placeStorePickupOrder";
            readonly controllerName: "PlaceStorePickupOrderController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopPlaceStorePickupOrderHandler";
                readonly command: "placeStorePickupOrder";
                readonly usecaseRef: "placeStorePickupOrder";
                readonly inputTypeName: "PlaceStorePickupOrderInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "customerName";
                    readonly fieldRef: "Order.customerName";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do cliente que está finalizando o pedido de retirada";
                }, {
                    readonly inputId: "customerPhone";
                    readonly fieldRef: "Order.customerPhone";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Telefone de contato opcional do cliente para confirmação da retirada";
                }, {
                    readonly inputId: "orderId";
                    readonly fieldRef: "Order.orderId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Identificador único gerado pelo sistema para o novo pedido";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "Order.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora de registro do pedido no momento da criação";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Order.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização do pedido no momento da criação";
                }, {
                    readonly inputId: "cartItems";
                    readonly fieldRef: "OrderItem.productId";
                    readonly required: true;
                    readonly source: "workflowState";
                    readonly description: "Itens do carrinho de compras construídos nas etapas anteriores do fluxo de navegação e revisão";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.orderId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "O sistema gera um novo UUID para identificar o pedido no momento da criação";
                }, {
                    readonly targetRef: "Order.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O sistema registra a data e hora atual no momento da criação do pedido";
                }, {
                    readonly targetRef: "Order.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O sistema registra a data e hora atual como última atualização no momento da criação do pedido";
                }, {
                    readonly targetRef: "OrderItem.productId";
                    readonly source: "workflowState";
                    readonly originRef: "OrderItem.productId";
                    readonly description: "O estado do fluxo mantém os itens do carrinho adicionados pelo cliente nas etapas anteriores de navegação e revisão, que são associados ao novo pedido como OrderItems";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Order.orderId", "Order.status", "Order.customerName", "Order.customerPhone", "Order.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.placeStorePickupOrder.placeStorePickupOrder";
                readonly handlerName: "petShopPlaceStorePickupOrderHandler";
            }];
        };
    };
    export default placeStorePickupOrderController;
    export const pipeline: readonly [{
        readonly id: "placeStorePickupOrder__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/placeStorePickupOrder.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/placeStorePickupOrder.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/placeStorePickupOrder.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/order" {
    export type OrderStatus = 'registered' | 'completed' | 'cancelled';
    export interface OrderItem {
        orderItemId: string;
        orderId: string;
        productId: string;
        quantity: number;
        unitPrice: number;
        createdAt: string;
        updatedAt: string;
    }
    export interface Order {
        orderId: string;
        status: OrderStatus;
        customerName: string;
        customerPhone: string | null;
        createdAt: string;
        updatedAt: string;
        completedAt: string | null;
        cancelledAt: string | null;
        cancellationReason: string | null;
        items: OrderItem[];
    }
    export const ORDER_STATUS_TRANSITIONS: Record<OrderStatus, OrderStatus[]>;
    export function canTransitionOrder(from: OrderStatus, to: OrderStatus): boolean;
    export function orderRequiresItem(order: Pick<Order, 'items'>): boolean;
    export function recomputeOrderTotal(items: OrderItem[]): number;
    export function orderHasItems(order: Pick<Order, 'items'>): boolean;
    export function isCompletedInvariantValid(order: Pick<Order, 'status' | 'completedAt'>): boolean;
    export function isCancelledInvariantValid(order: Pick<Order, 'status' | 'cancelledAt' | 'cancellationReason'>): boolean;
    export function areCompletionAndCancellationMutuallyExclusive(order: Pick<Order, 'completedAt' | 'cancelledAt'>): boolean;
    export function canCompleteOrCancel(order: Pick<Order, 'items'>): boolean;
    export function isUpdatedAtValid(order: Pick<Order, 'createdAt' | 'updatedAt'>): boolean;
    export function validateOrderInvariants(order: Order): string[];
}
declare module "_102049_/l1/petShop/layer_2_application/ports/orderRepository" {
    import type { Order, OrderStatus } from "_102049_/l1/petShop/layer_3_domain/entities/order";
    export type OrderId = string;
    export type CustomerId = string;
    export interface OrderFilter {
        status?: OrderStatus;
        customerId?: CustomerId;
    }
    export interface IOrderRepository {
        getById(id: OrderId): Promise<Order | null>;
        list(filter?: OrderFilter): Promise<Order[]>;
        save(order: Order): Promise<void>;
        findByCustomerId(customerId: CustomerId): Promise<Order[]>;
        findByStatus(status: OrderStatus): Promise<Order[]>;
    }
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/placeStorePickupOrder" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CartItemInput {
        productId: string;
        quantity: number;
    }
    export interface PlaceStorePickupOrderInput {
        customerName: string;
        customerPhone?: string;
        cartItems: CartItemInput[];
    }
    export interface PlaceStorePickupOrderOutput {
        orderId: string;
        status: string;
        customerName: string;
        customerPhone?: string;
        createdAt: string;
    }
    export function placeStorePickupOrder(ctx: RequestContext, input: PlaceStorePickupOrderInput): Promise<PlaceStorePickupOrderOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/placeStorePickupOrder" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopPlaceStorePickupOrderHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/reviewSchedulingCapacity.defs" {
    export const reviewSchedulingCapacityController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "reviewSchedulingCapacity";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "reviewSchedulingCapacity";
            readonly controllerName: "ReviewSchedulingCapacityController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopReviewSchedulingCapacityHandler";
                readonly command: "reviewSchedulingCapacity";
                readonly usecaseRef: "reviewSchedulingCapacity";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "ShiftAssignment.shiftId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional para revisar a capacidade de um turno específico";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "Operator.operatorId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identidade do administrador autenticado que solicita a revisão";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "actorSession.actorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend extrai o ID do administrador a partir da sessão autenticada para autorizar o acesso à revisão de capacidade";
                }, {
                    readonly targetRef: "businessContext.activeCompanyId";
                    readonly source: "businessContext";
                    readonly originRef: "businessContext.activeCompanyId";
                    readonly description: "O backend resolve a empresa ativa a partir do contexto de negócio para escopar as alocações consultadas à empresa correta";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "ShiftAssignment";
                    readonly keyField: "ShiftAssignment.shiftAssignmentId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["ShiftAssignment.shiftAssignmentId", "ShiftAssignment.operatorId", "ShiftAssignment.shiftId", "ShiftAssignment.createdAt", "Shift.shiftId", "Shift.startTime", "Shift.endTime", "Operator.operatorId", "Operator.name"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.reviewSchedulingCapacity.reviewSchedulingCapacity";
                readonly handlerName: "petShopReviewSchedulingCapacityHandler";
            }];
        };
    };
    export default reviewSchedulingCapacityController;
    export const pipeline: readonly [{
        readonly id: "reviewSchedulingCapacity__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/reviewSchedulingCapacity.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/reviewSchedulingCapacity.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/reviewSchedulingCapacity.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/reviewSchedulingCapacity" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopReviewSchedulingCapacityHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/startServiceExecution.defs" {
    export const startServiceExecutionController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "startServiceExecution";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "serviceBookingLifecycle";
            readonly controllerName: "StartServiceExecutionController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopStartServiceExecutionHandler";
                readonly command: "startServiceExecution";
                readonly usecaseRef: "startServiceExecution";
                readonly inputTypeName: "StartServiceExecutionInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "serviceBookingId";
                    readonly fieldRef: "ServiceBooking.serviceBookingId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador do agendamento de serviço selecionado pelo operador para iniciar o atendimento.";
                }, {
                    readonly inputId: "operatorId";
                    readonly fieldRef: "ServiceBooking.operatorId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do operador autenticado que está iniciando o atendimento, usado para validar que ele é o operador atribuído ao agendamento.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "ServiceBooking.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da atualização do agendamento, registrada automaticamente pelo sistema no momento da transição de status.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "ServiceBooking.serviceBookingId";
                    readonly source: "selectedEntity";
                    readonly originRef: "ServiceBooking.serviceBookingId";
                    readonly description: "O agendamento atualmente selecionado pelo operador na tela de agenda, identificado pelo seu serviceBookingId.";
                }, {
                    readonly targetRef: "ServiceBooking.operatorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O identificador do operador autenticado na sessão atual, usado para verificar se ele é o operador atribuído ao agendamento antes de permitir a transição.";
                }, {
                    readonly targetRef: "ServiceBooking.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O timestamp atual do sistema, gravado automaticamente como updatedAt no momento em que o status é alterado para inProgress.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "ServiceBooking";
                    readonly keyField: "ServiceBooking.serviceBookingId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["ServiceBooking.serviceBookingId", "ServiceBooking.status", "ServiceBooking.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.serviceBookingLifecycle.startServiceExecution";
                readonly handlerName: "petShopStartServiceExecutionHandler";
            }];
        };
    };
    export default startServiceExecutionController;
    export const pipeline: readonly [{
        readonly id: "startServiceExecution__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/startServiceExecution.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/startServiceExecution.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/startServiceExecution.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/startServiceExecution" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface StartServiceExecutionInput {
        serviceBookingId: string;
    }
    export interface StartServiceExecutionOutput {
        serviceBookingId: string;
        status: string;
        updatedAt: string;
    }
    export function startServiceExecution(ctx: RequestContext, input: StartServiceExecutionInput): Promise<StartServiceExecutionOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/startServiceExecution" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopStartServiceExecutionHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateAdoptablePet.defs" {
    export const updateAdoptablePetController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateAdoptablePet";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateAdoptablePet";
            readonly controllerName: "UpdateAdoptablePetController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopUpdateAdoptablePetHandler";
                readonly command: "updateAdoptablePet";
                readonly usecaseRef: "updateAdoptablePet";
                readonly inputTypeName: "UpdateAdoptablePetInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "adoptablePetId";
                    readonly fieldRef: "AdoptablePet.adoptablePetId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador do pet selecionado para edição na lista de gestão";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "AdoptablePet.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do pet editado pelo administrador";
                }, {
                    readonly inputId: "age";
                    readonly fieldRef: "AdoptablePet.age";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Idade do pet em anos editada pelo administrador";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "AdoptablePet.description";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Descrição do pet editada pelo administrador";
                }, {
                    readonly inputId: "photoUrl";
                    readonly fieldRef: "AdoptablePet.photoUrl";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "URL da foto do pet no armazenamento de mídia da plataforma";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "AdoptablePet.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Disponibilidade do pet: available ou unavailable";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "AdoptablePet.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da atualização, gerada automaticamente pelo sistema";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "AdoptablePet.adoptablePetId";
                    readonly source: "selectedEntity";
                    readonly originRef: "AdoptablePet.adoptablePetId";
                    readonly description: "O backend resolve o identificador do pet a partir da entidade selecionada pelo administrador na lista de gestão de pets";
                }, {
                    readonly targetRef: "AdoptablePet.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define updatedAt com o timestamp atual no momento da persistência da atualização";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "AdoptablePet";
                    readonly keyField: "AdoptablePet.adoptablePetId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["AdoptablePet.adoptablePetId", "AdoptablePet.name", "AdoptablePet.age", "AdoptablePet.description", "AdoptablePet.photoUrl", "AdoptablePet.status", "AdoptablePet.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.updateAdoptablePet.updateAdoptablePet";
                readonly handlerName: "petShopUpdateAdoptablePetHandler";
            }];
        };
    };
    export default updateAdoptablePetController;
    export const pipeline: readonly [{
        readonly id: "updateAdoptablePet__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateAdoptablePet.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateAdoptablePet.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/updateAdoptablePet.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/updateAdoptablePet" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateAdoptablePetInput {
        adoptablePetId: string;
        name: string;
        age: number;
        description: string;
        photoUrl: string;
        status: string;
    }
    export interface UpdateAdoptablePetOutput {
        adoptablePetId: string;
        name: string;
        age: number;
        description: string;
        photoUrl: string;
        status: string;
        updatedAt: string;
    }
    export function updateAdoptablePet(ctx: RequestContext, input: UpdateAdoptablePetInput): Promise<UpdateAdoptablePetOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateAdoptablePet" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopUpdateAdoptablePetHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateOperator.defs" {
    export const updateOperatorController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateOperator";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateOperator";
            readonly controllerName: "UpdateOperatorController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopUpdateOperatorHandler";
                readonly command: "updateOperator";
                readonly usecaseRef: "updateOperator";
                readonly inputTypeName: "UpdateOperatorInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "operatorId";
                    readonly fieldRef: "Operator.operatorId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identificador do operador a ser editado, obtido da rota de edição.";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "Operator.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome completo do operador editado pelo administrador.";
                }, {
                    readonly inputId: "email";
                    readonly fieldRef: "Operator.email";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "E-mail de contato do operador, opcional.";
                }, {
                    readonly inputId: "phone";
                    readonly fieldRef: "Operator.phone";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Telefone de contato do operador, opcional.";
                }, {
                    readonly inputId: "active";
                    readonly fieldRef: "Operator.active";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o operador está ativo e pode ser alocado em turnos.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Operator.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da atualização, definida automaticamente pelo servidor.";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "Operator.operatorId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do administrador autenticado que realiza a edição, para auditoria.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Operator.operatorId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.operatorId";
                    readonly description: "O backend extrai o operatorId do parâmetro de rota para localizar o operador a ser editado.";
                }, {
                    readonly targetRef: "Operator.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define updatedAt com o timestamp atual no momento da persistência da alteração.";
                }, {
                    readonly targetRef: "Operator.operatorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend obtém o identificador do administrador autenticado a partir da sessão para auditoria da alteração.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Operator";
                    readonly keyField: "Operator.operatorId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Operator.operatorId", "Operator.name", "Operator.email", "Operator.phone", "Operator.active", "Operator.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.updateOperator.updateOperator";
                readonly handlerName: "petShopUpdateOperatorHandler";
            }];
        };
    };
    export default updateOperatorController;
    export const pipeline: readonly [{
        readonly id: "updateOperator__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateOperator.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateOperator.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/updateOperator.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/updateOperator" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateOperatorInput {
        operatorId: string;
        name: string;
        email?: string;
        phone?: string;
        active: boolean;
    }
    export interface UpdateOperatorOutput {
        operatorId: string;
        name: string;
        email: string | null;
        phone: string | null;
        active: boolean;
        updatedAt: string;
    }
    export function updateOperator(ctx: RequestContext, input: UpdateOperatorInput): Promise<UpdateOperatorOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateOperator" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopUpdateOperatorHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateProduct.defs" {
    export const updateProductController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateProduct";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateProduct";
            readonly controllerName: "UpdateProductController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopUpdateProductHandler";
                readonly command: "updateProduct";
                readonly usecaseRef: "updateProduct";
                readonly inputTypeName: "UpdateProductInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "productId";
                    readonly fieldRef: "Product.productId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador do produto selecionado para edição.";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "Product.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome atualizado do produto exibido no catálogo.";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "Product.description";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Descrição detalhada atualizada do produto.";
                }, {
                    readonly inputId: "price";
                    readonly fieldRef: "Product.price";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Preço atualizado do produto cobrado na retirada presencial.";
                }, {
                    readonly inputId: "imageUrl";
                    readonly fieldRef: "Product.imageUrl";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "URL da imagem do produto no armazenamento de mídia da plataforma.";
                }, {
                    readonly inputId: "productCategoryId";
                    readonly fieldRef: "Product.productCategoryId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Categoria do produto selecionada na lista de categorias cadastradas.";
                }, {
                    readonly inputId: "featured";
                    readonly fieldRef: "Product.featured";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o produto deve ser exibido em destaque na página inicial.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Product.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Situação do produto: ativo ou inativo.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Product.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp da última atualização, gerado automaticamente pelo sistema.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Product.productId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Product.productId";
                    readonly description: "O backend resolve o productId a partir do produto atualmente selecionado na tela de gestão de produtos.";
                }, {
                    readonly targetRef: "Product.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define updatedAt com o timestamp atual no momento da persistência da atualização.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Product";
                    readonly keyField: "Product.productId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Product.productId", "Product.name", "Product.description", "Product.price", "Product.imageUrl", "Product.productCategoryId", "Product.featured", "Product.status", "Product.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.updateProduct.updateProduct";
                readonly handlerName: "petShopUpdateProductHandler";
            }];
        };
    };
    export default updateProductController;
    export const pipeline: readonly [{
        readonly id: "updateProduct__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateProduct.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateProduct.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/updateProduct.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/updateProduct" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateProductInput {
        productId: string;
        name: string;
        description?: string;
        price: number;
        imageUrl?: string;
        productCategoryId: string;
        featured: boolean;
        status: string;
    }
    export interface UpdateProductOutput {
        productId: string;
        name: string;
        description: string | null;
        price: number;
        imageUrl: string | null;
        productCategoryId: string;
        featured: boolean;
        status: string;
        updatedAt: string;
    }
    export function updateProduct(ctx: RequestContext, input: UpdateProductInput): Promise<UpdateProductOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateProduct" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopUpdateProductHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateService.defs" {
    export const updateServiceController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateService";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateService";
            readonly controllerName: "UpdateServiceController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopUpdateServiceHandler";
                readonly command: "updateService";
                readonly usecaseRef: "updateService";
                readonly inputTypeName: "UpdateServiceInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "serviceId";
                    readonly fieldRef: "Service.serviceId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador do serviço selecionado para edição.";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "Service.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome atualizado do serviço, como banho e tosa.";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "Service.description";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Descrição detalhada atualizada do serviço oferecido.";
                }, {
                    readonly inputId: "estimatedDurationMinutes";
                    readonly fieldRef: "Service.estimatedDurationMinutes";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Duração estimada atualizada do serviço em minutos.";
                }, {
                    readonly inputId: "price";
                    readonly fieldRef: "Service.price";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Preço atualizado do serviço cobrado na loja.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Service.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Novo estado de ativação do serviço: active ou inactive.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Service.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização, definida automaticamente pelo sistema.";
                }, {
                    readonly inputId: "deactivatedAt";
                    readonly fieldRef: "Service.deactivatedAt";
                    readonly required: false;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora de desativação, definida automaticamente quando o status passa a inactive.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Service.serviceId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Service.serviceId";
                    readonly description: "O backend resolve o serviceId a partir do serviço atualmente selecionado pelo administrador na lista de serviços.";
                }, {
                    readonly targetRef: "Service.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define updatedAt com o timestamp atual no momento da persistência da atualização.";
                }, {
                    readonly targetRef: "Service.deactivatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define deactivatedAt com o timestamp atual quando o status do serviço passa a inactive; permanece nulo quando o status é active.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Service";
                    readonly keyField: "Service.serviceId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Service.serviceId", "Service.name", "Service.description", "Service.estimatedDurationMinutes", "Service.price", "Service.status", "Service.deactivatedAt", "Service.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.updateService.updateService";
                readonly handlerName: "petShopUpdateServiceHandler";
            }];
        };
    };
    export default updateServiceController;
    export const pipeline: readonly [{
        readonly id: "updateService__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateService.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateService.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/updateService.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/updateService" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateServiceInput {
        serviceId: string;
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
        status: string;
    }
    export interface UpdateServiceOutput {
        serviceId: string;
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
        status: string;
        deactivatedAt: string | null;
        updatedAt: string;
    }
    export function updateService(ctx: RequestContext, input: UpdateServiceInput): Promise<UpdateServiceOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateService" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopUpdateServiceHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateShift.defs" {
    export const updateShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateShift";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateShift";
            readonly controllerName: "UpdateShiftController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopUpdateShiftHandler";
                readonly command: "updateShift";
                readonly usecaseRef: "updateShift";
                readonly inputTypeName: "UpdateShiftInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Shift.shiftId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador do turno selecionado para edição.";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "Shift.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do turno informado pelo administrador (ex.: Manhã, Tarde, Dia Inteiro).";
                }, {
                    readonly inputId: "startTime";
                    readonly fieldRef: "Shift.startTime";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Horário de início do turno no formato HH:mm.";
                }, {
                    readonly inputId: "endTime";
                    readonly fieldRef: "Shift.endTime";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Horário de fim do turno no formato HH:mm.";
                }, {
                    readonly inputId: "monday";
                    readonly fieldRef: "Shift.monday";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o turno ocorre às segundas-feiras.";
                }, {
                    readonly inputId: "tuesday";
                    readonly fieldRef: "Shift.tuesday";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o turno ocorre às terças-feiras.";
                }, {
                    readonly inputId: "wednesday";
                    readonly fieldRef: "Shift.wednesday";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o turno ocorre às quartas-feiras.";
                }, {
                    readonly inputId: "thursday";
                    readonly fieldRef: "Shift.thursday";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o turno ocorre às quintas-feiras.";
                }, {
                    readonly inputId: "friday";
                    readonly fieldRef: "Shift.friday";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o turno ocorre às sextas-feiras.";
                }, {
                    readonly inputId: "saturday";
                    readonly fieldRef: "Shift.saturday";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o turno ocorre aos sábados.";
                }, {
                    readonly inputId: "sunday";
                    readonly fieldRef: "Shift.sunday";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o turno ocorre aos domingos.";
                }, {
                    readonly inputId: "active";
                    readonly fieldRef: "Shift.active";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o turno está ativo e disponível para alocação.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Shift.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização, gerada automaticamente pelo sistema.";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "Shift.shiftId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do administrador autenticado que realiza a edição, para auditoria.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Shift.shiftId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "O backend obtém o shiftId a partir do turno atualmente selecionado na tela de listagem de turnos.";
                }, {
                    readonly targetRef: "Shift.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define updatedAt com o timestamp atual no momento da execução da atualização.";
                }, {
                    readonly targetRef: "actorSession.actorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend extrai o actorId da sessão autenticada do administrador para registro de auditoria.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Shift";
                    readonly keyField: "Shift.shiftId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Shift.shiftId", "Shift.name", "Shift.startTime", "Shift.endTime", "Shift.monday", "Shift.tuesday", "Shift.wednesday", "Shift.thursday", "Shift.friday", "Shift.saturday", "Shift.sunday", "Shift.active"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.updateShift.updateShift";
                readonly handlerName: "petShopUpdateShiftHandler";
            }];
        };
    };
    export default updateShiftController;
    export const pipeline: readonly [{
        readonly id: "updateShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateShift.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateShift.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/updateShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/updateShift" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateShiftInput {
        shiftId: string;
        name: string;
        startTime: string;
        endTime: string;
        monday: boolean;
        tuesday: boolean;
        wednesday: boolean;
        thursday: boolean;
        friday: boolean;
        saturday: boolean;
        sunday: boolean;
        active: boolean;
    }
    export interface UpdateShiftOutput {
        shiftId: string;
        name: string;
        startTime: string;
        endTime: string;
        monday: boolean;
        tuesday: boolean;
        wednesday: boolean;
        thursday: boolean;
        friday: boolean;
        saturday: boolean;
        sunday: boolean;
        active: boolean;
    }
    export function updateShift(ctx: RequestContext, input: UpdateShiftInput): Promise<UpdateShiftOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateShift" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopUpdateShiftHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewAdoptablePetDetails.defs" {
    export const viewAdoptablePetDetailsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewAdoptablePetDetails";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewAdoptablePetDetails";
            readonly controllerName: "ViewAdoptablePetDetailsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopViewAdoptablePetDetailsHandler";
                readonly command: "viewAdoptablePetDetails";
                readonly usecaseRef: "viewAdoptablePetDetails";
                readonly inputTypeName: "ViewAdoptablePetDetailsInput";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "adoptablePetId";
                    readonly fieldRef: "AdoptablePet.adoptablePetId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identificador do pet selecionado na galeria, passado como parâmetro de rota";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "AdoptablePet.adoptablePetId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.adoptablePetId";
                    readonly description: "O backend extrai o identificador do pet do parâmetro de rota da URL para buscar o registro correspondente";
                }];
                readonly accessPattern: {
                    readonly kind: "getById";
                    readonly description: "";
                    readonly entity: "AdoptablePet";
                    readonly keyField: "AdoptablePet.adoptablePetId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["AdoptablePet.name", "AdoptablePet.age", "AdoptablePet.description", "AdoptablePet.photoUrl", "AdoptablePet.status"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.viewAdoptablePetDetails.viewAdoptablePetDetails";
                readonly handlerName: "petShopViewAdoptablePetDetailsHandler";
            }];
        };
    };
    export default viewAdoptablePetDetailsController;
    export const pipeline: readonly [{
        readonly id: "viewAdoptablePetDetails__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewAdoptablePetDetails.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewAdoptablePetDetails.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/viewAdoptablePetDetails.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/viewAdoptablePetDetails" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewAdoptablePetDetailsInput {
        adoptablePetId: string;
    }
    export interface ViewAdoptablePetDetailsOutput {
        adoptablePetId: string;
        name: string;
        age: number;
        description: string;
        photoUrl: string;
        status: string;
    }
    export function viewAdoptablePetDetails(ctx: RequestContext, input: ViewAdoptablePetDetailsInput): Promise<ViewAdoptablePetDetailsOutput | null>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewAdoptablePetDetails" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopViewAdoptablePetDetailsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewOperatorSchedule.defs" {
    export const viewOperatorScheduleController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewOperatorSchedule";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewOperatorSchedule";
            readonly controllerName: "ViewOperatorScheduleController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopViewOperatorScheduleHandler";
                readonly command: "viewOperatorSchedule";
                readonly usecaseRef: "viewOperatorSchedule";
                readonly inputTypeName: "ViewOperatorScheduleInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "operatorId";
                    readonly fieldRef: "ServiceBooking.operatorId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do operador autenticado, usado para filtrar apenas os agendamentos a ele atribuídos.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "ServiceBooking.operatorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "Resolvido a partir da sessão autenticada do operador, identificando o operador que está consultando sua agenda.";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "ServiceBooking";
                    readonly keyField: "ServiceBooking.serviceBookingId";
                    readonly pagination: "optional";
                    readonly selection: "single";
                    readonly output: readonly ["ServiceBooking.serviceBookingId", "ServiceBooking.serviceId", "ServiceBooking.customerName", "ServiceBooking.customerPhone", "ServiceBooking.bookingDate", "ServiceBooking.bookingTime", "ServiceBooking.status", "ServiceBooking.notes"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.viewOperatorSchedule.viewOperatorSchedule";
                readonly handlerName: "petShopViewOperatorScheduleHandler";
            }];
        };
    };
    export default viewOperatorScheduleController;
    export const pipeline: readonly [{
        readonly id: "viewOperatorSchedule__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewOperatorSchedule.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewOperatorSchedule.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/viewOperatorSchedule.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/viewOperatorSchedule" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewOperatorScheduleInput {
    }
    export interface ViewOperatorScheduleItem {
        serviceBookingId: string;
        serviceId: string;
        customerName: string;
        customerPhone: string;
        bookingDate: string;
        bookingTime: string;
        status: string;
        notes?: string | null;
    }
    export interface ViewOperatorScheduleOutput {
        bookings: ViewOperatorScheduleItem[];
    }
    export function viewOperatorSchedule(ctx: RequestContext, _input: ViewOperatorScheduleInput): Promise<ViewOperatorScheduleOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewOperatorSchedule" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopViewOperatorScheduleHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewProductDetails.defs" {
    export const viewProductDetailsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewProductDetails";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewProductDetails";
            readonly controllerName: "ViewProductDetailsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopViewProductDetailsHandler";
                readonly command: "viewProductDetails";
                readonly usecaseRef: "viewProductDetails";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "productId";
                    readonly fieldRef: "Product.productId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identificador do produto selecionado pelo cliente para visualização dos detalhes.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Product.productId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.productId";
                    readonly description: "O backend extrai o productId do parâmetro de rota da URL para buscar o produto correspondente no catálogo.";
                }, {
                    readonly targetRef: "ProductCategory.productCategoryId";
                    readonly source: "previousStepOutput";
                    readonly originRef: "Product.productCategoryId";
                    readonly description: "O backend resolve a categoria do produto a partir do campo productCategoryId retornado na consulta do produto, buscando o registro correspondente em ProductCategory para exibir o nome da categoria.";
                }];
                readonly accessPattern: {
                    readonly kind: "getById";
                    readonly description: "";
                    readonly entity: "Product";
                    readonly keyField: "Product.productId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Product.productId", "Product.name", "Product.description", "Product.price", "Product.imageUrl", "Product.productCategoryId", "Product.featured", "Product.status"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.viewProductDetails.viewProductDetails";
                readonly handlerName: "petShopViewProductDetailsHandler";
            }];
        };
    };
    export default viewProductDetailsController;
    export const pipeline: readonly [{
        readonly id: "viewProductDetails__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewProductDetails.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewProductDetails.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/viewProductDetails.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewProductDetails" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopViewProductDetailsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewServiceBookingDetails.defs" {
    export const viewServiceBookingDetailsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewServiceBookingDetails";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewServiceBookingDetails";
            readonly controllerName: "ViewServiceBookingDetailsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "petShopViewServiceBookingDetailsHandler";
                readonly command: "viewServiceBookingDetails";
                readonly usecaseRef: "viewServiceBookingDetails";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "serviceBookingId";
                    readonly fieldRef: "ServiceBooking.serviceBookingId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identificador do agendamento selecionado pelo operador na agenda de turno.";
                }, {
                    readonly inputId: "operatorId";
                    readonly fieldRef: "ServiceBooking.operatorId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do operador autenticado, usado para verificar que o agendamento pertence ao seu turno.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "ServiceBooking.serviceBookingId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.serviceBookingId";
                    readonly description: "O ID do agendamento é extraído do parâmetro de rota da tela de detalhes selecionada pelo operador.";
                }, {
                    readonly targetRef: "ServiceBooking.operatorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O ID do operador autenticado é obtido da sessão ativa para restringir a visualização apenas a agendamentos do seu turno.";
                }];
                readonly accessPattern: {
                    readonly kind: "getById";
                    readonly description: "";
                    readonly entity: "ServiceBooking";
                    readonly keyField: "ServiceBooking.serviceBookingId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["ServiceBooking.serviceBookingId", "ServiceBooking.serviceId", "ServiceBooking.operatorId", "ServiceBooking.shiftId", "ServiceBooking.customerName", "ServiceBooking.customerPhone", "ServiceBooking.bookingDate", "ServiceBooking.bookingTime", "ServiceBooking.status", "ServiceBooking.notes", "ServiceBooking.completedAt", "ServiceBooking.cancelledAt", "ServiceBooking.cancelReason", "ServiceBooking.createdAt", "ServiceBooking.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.viewServiceBookingDetails.viewServiceBookingDetails";
                readonly handlerName: "petShopViewServiceBookingDetailsHandler";
            }];
        };
    };
    export default viewServiceBookingDetailsController;
    export const pipeline: readonly [{
        readonly id: "viewServiceBookingDetails__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewServiceBookingDetails.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewServiceBookingDetails.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/viewServiceBookingDetails.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewServiceBookingDetails" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopViewServiceBookingDetailsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/adoptablePet.defs" {
    export const adoptablePetTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "AdoptablePet";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "AdoptablePet";
            readonly tableName: "adoptable_pet";
            readonly columns: readonly [{
                readonly name: "adoptable_pet_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Pet status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "name, age, description, photo_url, updated_at";
            }];
            readonly primaryKey: readonly ["adoptable_pet_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_adoptable_pet_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_adoptable_pet_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default adoptablePetTableDefinition;
    export const pipeline: readonly [{
        readonly id: "adoptablePet__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/adoptablePet.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/adoptablePet.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/adoptablePet.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/adoptablePet" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const adoptablePetTableDef: TableDefinition;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/adoptablePetRepositoryAdapter.defs" {
    export const adoptablePetRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "AdoptablePetRepositoryAdapter";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "AdoptablePetRepositoryAdapter";
            readonly entityId: "AdoptablePet";
            readonly portRef: "IAdoptablePetRepository";
            readonly tableRef: "adoptable_pets";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns: adoptable_pet_id, status, created_at.", "Details JSONB holds: name, age, description, photo_url, updated_at.", "Uses ctx.data.moduleData for local persistence."];
        };
    };
    export default adoptablePetRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "adoptablePetRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/adoptablePetRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/adoptablePetRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/adoptablePetRepository.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/persistence/adoptablePet.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/adoptablePet.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/adoptablePetRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IAdoptablePetRepository } from "_102049_/l1/petShop/layer_2_application/ports/adoptablePetRepository";
    export function createAdoptablePetRepositoryAdapter(ctx: RequestContext): IAdoptablePetRepository;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/adoptionInterest.defs" {
    export const adoptionInterestTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "AdoptionInterest";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "AdoptionInterest";
            readonly tableName: "adoption_interest";
            readonly columns: readonly [{
                readonly name: "adoption_interest_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK";
            }, {
                readonly name: "adoptable_pet_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to adoptable_pet";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Interest status";
            }, {
                readonly name: "operator_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to operator";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "customer_name, customer_email, customer_phone, verification_notes, completed_at, cancelled_at, cancellation_reason, updated_at";
            }];
            readonly primaryKey: readonly ["adoption_interest_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_adoption_interest_adoptable_pet_id";
                readonly columns: readonly ["adoptable_pet_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_adoption_interest_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_adoption_interest_operator_id";
                readonly columns: readonly ["operator_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_adoption_interest_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default adoptionInterestTableDefinition;
    export const pipeline: readonly [{
        readonly id: "adoptionInterest__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/adoptionInterest.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/adoptionInterest.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/adoptionInterest.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/adoptionInterest" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const adoptionInterestTableDef: TableDefinition;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/adoptionInterestRepositoryAdapter.defs" {
    export const adoptionInterestRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "AdoptionInterestRepositoryAdapter";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "AdoptionInterestRepositoryAdapter";
            readonly entityId: "AdoptionInterest";
            readonly portRef: "IAdoptionInterestRepository";
            readonly tableRef: "adoption_interests";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns: adoption_interest_id, adoptable_pet_id, status, operator_id, created_at.", "Details JSONB holds: customer_name, customer_email, customer_phone, verification_notes, completed_at, cancelled_at, cancellation_reason, updated_at.", "Uses ctx.data.moduleData for local persistence."];
        };
    };
    export default adoptionInterestRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "adoptionInterestRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/adoptionInterestRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/adoptionInterestRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/adoptionInterestRepository.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/persistence/adoptionInterest.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/adoptionInterest.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/adoptionInterestRepositoryAdapter" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IAdoptionInterestRepository } from "_102049_/l1/petShop/layer_2_application/ports/adoptionInterestRepository";
    export function createAdoptionInterestRepositoryAdapter(ctx: RequestContext): IAdoptionInterestRepository;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/operator.defs" {
    export const operatorTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Operator";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Operator";
            readonly tableName: "operator";
            readonly columns: readonly [{
                readonly name: "operator_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "name, email, phone, active, updated_at";
            }];
            readonly primaryKey: readonly ["operator_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_operator_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default operatorTableDefinition;
    export const pipeline: readonly [{
        readonly id: "operator__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/operator.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/operator.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/operator.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/operator" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const operatorTableDef: TableDefinition;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/operatorRepositoryAdapter.defs" {
    export const operatorRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "OperatorRepositoryAdapter";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "OperatorRepositoryAdapter";
            readonly entityId: "Operator";
            readonly portRef: "IOperatorRepository";
            readonly tableRef: "operators";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns: operator_id, created_at.", "Details JSONB holds: name, email, phone, active, updated_at.", "Uses ctx.data.moduleData for local persistence."];
        };
    };
    export default operatorRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "operatorRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/operatorRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/operatorRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/operatorRepository.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/persistence/operator.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/operator.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/operatorRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IOperatorRepository } from "_102049_/l1/petShop/layer_2_application/ports/operatorRepository";
    export function createOperatorRepositoryAdapter(ctx: RequestContext): IOperatorRepository;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Order";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Order";
            readonly tableName: "order";
            readonly columns: readonly [{
                readonly name: "order_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Order status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "customer_name, customer_phone, updated_at, completed_at, cancelled_at, cancellation_reason, order_items";
            }];
            readonly primaryKey: readonly ["order_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_order_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["OrderItem"];
            };
        };
    };
    export default orderTableDefinition;
    export const pipeline: readonly [{
        readonly id: "order__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/order.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/order.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/order" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const orderTableDef: TableDefinition;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs" {
    export const orderRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "OrderRepositoryAdapter";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "OrderRepositoryAdapter";
            readonly entityId: "Order";
            readonly portRef: "IOrderRepository";
            readonly tableRef: "orders";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns: order_id, status, created_at.", "Details JSONB holds: customer_name, customer_phone, updated_at, completed_at, cancelled_at, cancellation_reason and embedded OrderItem collection.", "Uses ctx.data.moduleData for local persistence."];
        };
    };
    export default orderRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "orderRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/orderRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/orderRepository.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/persistence/order.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/orderRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IOrderRepository } from "_102049_/l1/petShop/layer_2_application/ports/orderRepository";
    export function createOrderRepositoryAdapter(ctx: RequestContext): IOrderRepository;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/product.defs" {
    export const productTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Product";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Product";
            readonly tableName: "product";
            readonly columns: readonly [{
                readonly name: "product_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK";
            }, {
                readonly name: "product_category_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to product_category";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Product status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "name, description, price, image_url, featured, updated_at";
            }];
            readonly primaryKey: readonly ["product_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_product_product_category_id";
                readonly columns: readonly ["product_category_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_product_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_product_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default productTableDefinition;
    export const pipeline: readonly [{
        readonly id: "product__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/product.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/product.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/product" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const productTableDef: TableDefinition;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/productRepositoryAdapter.defs" {
    export const productRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ProductRepositoryAdapter";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ProductRepositoryAdapter";
            readonly entityId: "Product";
            readonly portRef: "IProductRepository";
            readonly tableRef: "products";
            readonly mdmReads: readonly ["ProductCategory"];
            readonly notes: readonly ["Real columns: product_id, product_category_id, status, created_at.", "Details JSONB holds: name, description, price, image_url, featured, updated_at.", "Resolves ProductCategory MDM ref via ctx.mdm.collection.getMany/hydrateMany (bulk load, no loop).", "Uses ctx.data.moduleData for local persistence."];
        };
    };
    export default productRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "productRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/productRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/productRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/persistence/product.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/productRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IProductRepository } from "_102049_/l1/petShop/layer_2_application/ports/productRepository";
    export function createProductRepositoryAdapter(ctx: RequestContext): IProductRepository;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/seeds" {
    import type { TableSeedRows } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const adoptablePetSeeds: TableSeedRows;
    export const adoptionInterestSeeds: TableSeedRows;
    export const operatorSeeds: TableSeedRows;
    export const orderSeeds: TableSeedRows;
    export const productSeeds: TableSeedRows;
    export const serviceSeeds: TableSeedRows;
    export const serviceBookingSeeds: TableSeedRows;
    export const shiftAssignmentSeeds: TableSeedRows;
    export const mdmEntityIndexSeeds: TableSeedRows;
    export const mdmDocumentSeeds: TableSeedRows;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/service.defs" {
    export const serviceTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Service";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Service";
            readonly tableName: "service";
            readonly columns: readonly [{
                readonly name: "service_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Service status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "name, description, estimated_duration_minutes, price, deactivated_at, updated_at";
            }];
            readonly primaryKey: readonly ["service_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_service_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_service_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default serviceTableDefinition;
    export const pipeline: readonly [{
        readonly id: "service__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/service.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/service.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/service.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/service" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const serviceTableDef: TableDefinition;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/serviceBooking.defs" {
    export const serviceBookingTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "ServiceBooking";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "ServiceBooking";
            readonly tableName: "service_booking";
            readonly columns: readonly [{
                readonly name: "service_booking_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK";
            }, {
                readonly name: "service_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to service";
            }, {
                readonly name: "operator_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to operator";
            }, {
                readonly name: "shift_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to shift";
            }, {
                readonly name: "status";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "Booking status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "customer_name, customer_phone, booking_date, booking_time, notes, completed_at, cancelled_at, cancel_reason, updated_at";
            }];
            readonly primaryKey: readonly ["service_booking_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_service_booking_service_id";
                readonly columns: readonly ["service_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_service_booking_operator_id";
                readonly columns: readonly ["operator_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_service_booking_shift_id";
                readonly columns: readonly ["shift_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_service_booking_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_service_booking_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default serviceBookingTableDefinition;
    export const pipeline: readonly [{
        readonly id: "serviceBooking__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/serviceBooking.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/serviceBooking.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/serviceBooking.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/serviceBooking" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const serviceBookingTableDef: TableDefinition;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/serviceBookingRepositoryAdapter.defs" {
    export const serviceBookingRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ServiceBookingRepositoryAdapter";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ServiceBookingRepositoryAdapter";
            readonly entityId: "ServiceBooking";
            readonly portRef: "IServiceBookingRepository";
            readonly tableRef: "service_bookings";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns: service_booking_id, service_id, operator_id, shift_id, status, created_at.", "Details JSONB holds: customer_name, customer_phone, booking_date, booking_time, notes, completed_at, cancelled_at, cancel_reason, updated_at.", "Uses ctx.data.moduleData for local persistence."];
        };
    };
    export default serviceBookingRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "serviceBookingRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/serviceBookingRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/serviceBookingRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/serviceBookingRepository.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/persistence/serviceBooking.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/serviceBooking.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/serviceBookingRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IServiceBookingRepository } from "_102049_/l1/petShop/layer_2_application/ports/serviceBookingRepository";
    export function createServiceBookingRepositoryAdapter(ctx: RequestContext): IServiceBookingRepository;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/serviceRepositoryAdapter.defs" {
    export const serviceRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ServiceRepositoryAdapter";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ServiceRepositoryAdapter";
            readonly entityId: "Service";
            readonly portRef: "IServiceRepository";
            readonly tableRef: "services";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns: service_id, status, created_at.", "Details JSONB holds: name, description, estimated_duration_minutes, price, deactivated_at, updated_at.", "Uses ctx.data.moduleData for local persistence."];
        };
    };
    export default serviceRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "serviceRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/serviceRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/serviceRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/serviceRepository.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/persistence/service.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/service.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/serviceRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IServiceRepository } from "_102049_/l1/petShop/layer_2_application/ports/serviceRepository";
    export function createServiceRepositoryAdapter(ctx: RequestContext): IServiceRepository;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/shiftAssignment.defs" {
    export const shiftAssignmentTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "ShiftAssignment";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "ShiftAssignment";
            readonly tableName: "shift_assignment";
            readonly columns: readonly [{
                readonly name: "shift_assignment_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK";
            }, {
                readonly name: "operator_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to operator";
            }, {
                readonly name: "shift_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "FK to shift";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "Ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "updated_at";
            }];
            readonly primaryKey: readonly ["shift_assignment_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_shift_assignment_operator_id";
                readonly columns: readonly ["operator_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_shift_assignment_shift_id";
                readonly columns: readonly ["shift_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_shift_assignment_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default shiftAssignmentTableDefinition;
    export const pipeline: readonly [{
        readonly id: "shiftAssignment__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/shiftAssignment.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/shiftAssignment.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/shiftAssignment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/shiftAssignment" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const shiftAssignmentTableDef: TableDefinition;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/shiftAssignmentRepositoryAdapter.defs" {
    export const shiftAssignmentRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ShiftAssignmentRepositoryAdapter";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ShiftAssignmentRepositoryAdapter";
            readonly entityId: "ShiftAssignment";
            readonly portRef: "IShiftAssignmentRepository";
            readonly tableRef: "shift_assignments";
            readonly mdmReads: readonly ["Shift"];
            readonly notes: readonly ["Real columns: shift_assignment_id, operator_id, shift_id, created_at.", "Details JSONB holds: updated_at.", "Resolves Shift MDM ref via ctx.mdm.collection.getMany/hydrateMany (bulk load, no loop).", "Uses ctx.data.moduleData for local persistence."];
        };
    };
    export default shiftAssignmentRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "shiftAssignmentRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/shiftAssignmentRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/shiftAssignmentRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/shiftAssignmentRepository.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/persistence/shiftAssignment.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/shiftAssignment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/shiftAssignmentRepositoryAdapter" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IShiftAssignmentRepository } from "_102049_/l1/petShop/layer_2_application/ports/shiftAssignmentRepository";
    export function createShiftAssignmentRepositoryAdapter(ctx: RequestContext): IShiftAssignmentRepository;
}
declare module "_102049_/l1/petShop/layer_2_application/ports/adoptablePetRepository.defs" {
    export const adoptablePetRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "AdoptablePetRepository";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "AdoptablePet";
            readonly interfaceName: "IAdoptablePetRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: AdoptablePetId"];
                readonly returns: "AdoptablePet | null";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: AdoptablePetFilter"];
                readonly returns: "AdoptablePet[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["pet: AdoptablePet"];
                readonly returns: "void";
            }, {
                readonly name: "findAvailable";
                readonly params: readonly [];
                readonly returns: "AdoptablePet[]";
            }, {
                readonly name: "findBySpecies";
                readonly params: readonly ["species: Species"];
                readonly returns: "AdoptablePet[]";
            }];
        };
    };
    export default adoptablePetRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "adoptablePetRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/ports/adoptablePetRepository.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/ports/adoptablePetRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/adoptablePet.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/ports/adoptionInterestRepository.defs" {
    export const adoptionInterestRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "AdoptionInterestRepository";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "AdoptionInterest";
            readonly interfaceName: "IAdoptionInterestRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: AdoptionInterestId"];
                readonly returns: "AdoptionInterest | null";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: AdoptionInterestFilter"];
                readonly returns: "AdoptionInterest[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["interest: AdoptionInterest"];
                readonly returns: "void";
            }, {
                readonly name: "findByAdopterId";
                readonly params: readonly ["adopterId: AdopterId"];
                readonly returns: "AdoptionInterest[]";
            }, {
                readonly name: "findByPetId";
                readonly params: readonly ["petId: AdoptablePetId"];
                readonly returns: "AdoptionInterest[]";
            }];
        };
    };
    export default adoptionInterestRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "adoptionInterestRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/ports/adoptionInterestRepository.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/ports/adoptionInterestRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/adoptionInterest.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/ports/operatorRepository.defs" {
    export const operatorRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "OperatorRepository";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Operator";
            readonly interfaceName: "IOperatorRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: OperatorId"];
                readonly returns: "Operator | null";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: OperatorFilter"];
                readonly returns: "Operator[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["operator: Operator"];
                readonly returns: "void";
            }, {
                readonly name: "findByEmail";
                readonly params: readonly ["email: Email"];
                readonly returns: "Operator | null";
            }, {
                readonly name: "findActive";
                readonly params: readonly [];
                readonly returns: "Operator[]";
            }];
        };
    };
    export default operatorRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "operatorRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/ports/operatorRepository.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/ports/operatorRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/operator.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/ports/orderRepository.defs" {
    export const orderRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "OrderRepository";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly interfaceName: "IOrderRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: OrderId"];
                readonly returns: "Order | null";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: OrderFilter"];
                readonly returns: "Order[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["order: Order"];
                readonly returns: "void";
            }, {
                readonly name: "findByCustomerId";
                readonly params: readonly ["customerId: CustomerId"];
                readonly returns: "Order[]";
            }, {
                readonly name: "findByStatus";
                readonly params: readonly ["status: OrderStatus"];
                readonly returns: "Order[]";
            }];
        };
    };
    export default orderRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "orderRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/ports/orderRepository.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/ports/orderRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/ports/productRepository.defs" {
    export const productRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ProductRepository";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Product";
            readonly interfaceName: "IProductRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: ProductId"];
                readonly returns: "Product | null";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: ProductFilter"];
                readonly returns: "Product[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["product: Product"];
                readonly returns: "void";
            }, {
                readonly name: "findBySku";
                readonly params: readonly ["sku: Sku"];
                readonly returns: "Product | null";
            }, {
                readonly name: "findByCategory";
                readonly params: readonly ["category: Category"];
                readonly returns: "Product[]";
            }];
        };
    };
    export default productRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "productRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/ports/productRepository.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/ports/productRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/ports/serviceBookingRepository.defs" {
    export const serviceBookingRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ServiceBookingRepository";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "ServiceBooking";
            readonly interfaceName: "IServiceBookingRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: ServiceBookingId"];
                readonly returns: "ServiceBooking | null";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: ServiceBookingFilter"];
                readonly returns: "ServiceBooking[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["booking: ServiceBooking"];
                readonly returns: "void";
            }, {
                readonly name: "findByCustomerId";
                readonly params: readonly ["customerId: CustomerId"];
                readonly returns: "ServiceBooking[]";
            }, {
                readonly name: "findByPeriod";
                readonly params: readonly ["period: DateRange"];
                readonly returns: "ServiceBooking[]";
            }];
        };
    };
    export default serviceBookingRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "serviceBookingRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/ports/serviceBookingRepository.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/ports/serviceBookingRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/serviceBooking.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/ports/serviceRepository.defs" {
    export const serviceRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ServiceRepository";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Service";
            readonly interfaceName: "IServiceRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: ServiceId"];
                readonly returns: "Service | null";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: ServiceFilter"];
                readonly returns: "Service[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["service: Service"];
                readonly returns: "void";
            }, {
                readonly name: "findByType";
                readonly params: readonly ["type: ServiceType"];
                readonly returns: "Service[]";
            }, {
                readonly name: "findActive";
                readonly params: readonly [];
                readonly returns: "Service[]";
            }];
        };
    };
    export default serviceRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "serviceRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/ports/serviceRepository.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/ports/serviceRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/service.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/ports/shiftAssignmentRepository.defs" {
    export const shiftAssignmentRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ShiftAssignmentRepository";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "ShiftAssignment";
            readonly interfaceName: "IShiftAssignmentRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: ShiftAssignmentId"];
                readonly returns: "ShiftAssignment | null";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: ShiftAssignmentFilter"];
                readonly returns: "ShiftAssignment[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["assignment: ShiftAssignment"];
                readonly returns: "void";
            }, {
                readonly name: "findByOperatorId";
                readonly params: readonly ["operatorId: OperatorId"];
                readonly returns: "ShiftAssignment[]";
            }, {
                readonly name: "findByDate";
                readonly params: readonly ["date: LocalDate"];
                readonly returns: "ShiftAssignment[]";
            }];
        };
    };
    export default shiftAssignmentRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "shiftAssignmentRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/ports/shiftAssignmentRepository.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/ports/shiftAssignmentRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/shiftAssignment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/assignOperatorToShift.defs" {
    export const assignOperatorToShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "assignOperatorToShift";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "assignOperatorToShift";
            readonly ports: readonly ["ShiftAssignment", "Operator"];
            readonly functions: readonly [{
                readonly functionName: "assignOperatorToShift";
                readonly inputTypeName: "AssignOperatorToShiftInput";
                readonly outputTypeName: "AssignOperatorToShiftOutput";
                readonly input: readonly [{
                    readonly name: "operatorId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftAssignment";
                    readonly description: "Operador selecionado pelo administrador para ser alocado no turno.";
                }, {
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftAssignment";
                    readonly description: "Turno de trabalho selecionado pelo administrador para receber a alocação do operador.";
                }];
                readonly output: readonly [{
                    readonly name: "shiftAssignmentId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftAssignment";
                    readonly description: "Identificador único da nova alocação criada.";
                }, {
                    readonly name: "operatorId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftAssignment";
                    readonly description: "Operador alocado.";
                }, {
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftAssignment";
                    readonly description: "Turno que recebeu a alocação.";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftAssignment";
                    readonly description: "Timestamp de criação da alocação.";
                }];
                readonly ports: readonly ["ShiftAssignment", "Operator"];
                readonly rulesApplied: readonly ["schedulingCapacityByOperators", "operatorMultipleShiftsAllowed"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load Operator by operatorId via Operator port (resolveRepository + getById); validate it exists and active === true, else throw validation error referencing the operator.", "2. Load Shift by shiftId via ctx.mdm.entity.get({ mdmId: shiftId }); validate it exists and active === true, else throw validation error referencing the shift.", "3. Apply rule operatorMultipleShiftsAllowed: query existing ShiftAssignment records for the given operatorId via ShiftAssignment port (list by operatorId filter). The rule explicitly ALLOWS the operator to be assigned to multiple shifts including overlapping ones — do NOT block the creation regardless of existing assignments.", "4. Apply rule schedulingCapacityByOperators: the scheduling capacity of a shift is determined by the number of operators assigned to it. Adding this operator increases the shift's capacity by one. There is no upper cap that blocks this assignment — the rule is descriptive and does not reject the operation.", "5. Generate shiftAssignmentId via ctx.idGenerator, and set createdAt and updatedAt to ctx.clock.now() (ISO string).", "6. Create the ShiftAssignment record via the ShiftAssignment port (create) inside a single transaction (ctx.data transaction wrapper).", "7. Return { shiftAssignmentId, operatorId, shiftId, createdAt }."];
            }];
            readonly mdmRefs: readonly ["Shift"];
        };
    };
    export default assignOperatorToShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "assignOperatorToShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/assignOperatorToShift.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/assignOperatorToShift.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/shiftAssignmentRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/operatorRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/shiftAssignment.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/operator.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseOperators.defs" {
    export const browseOperatorsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseOperators";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseOperators";
            readonly ports: readonly ["Operator"];
            readonly functions: readonly [{
                readonly functionName: "browseOperators";
                readonly inputTypeName: "BrowseOperatorsInput";
                readonly outputTypeName: "BrowseOperatorsOutput";
                readonly input: readonly [{
                    readonly name: "activeFilter";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly description: "Filtro opcional para listar apenas operadores ativos ou inativos.";
                }];
                readonly output: readonly [{
                    readonly name: "operatorId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Operator";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Operator";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Operator";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Operator";
                }, {
                    readonly name: "active";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Operator";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Operator";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Operator";
                }];
                readonly ports: readonly ["Operator"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Resolve actorId from ctx.sessionContext (actorSession) to authorize the request — reject if no authenticated actor is present.", "Load the Operator port (resolveRepository) and call list with an optional filter on the 'active' field when activeFilter is provided.", "Project each Operator to the output fields: operatorId, name, email, phone, active, createdAt, updatedAt.", "Return the collection of projected operators."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default browseOperatorsUsecase;
    export const pipeline: readonly [{
        readonly id: "browseOperators__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/browseOperators.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/browseOperators.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/operatorRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/operator.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseProductCatalog.defs" {
    export const browseProductCatalogUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseProductCatalog";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseProductCatalog";
            readonly ports: readonly ["Product"];
            readonly functions: readonly [{
                readonly functionName: "browseProductCatalog";
                readonly inputTypeName: "BrowseProductCatalogInput";
                readonly outputTypeName: "BrowseProductCatalogOutput";
                readonly input: readonly [{
                    readonly name: "searchName";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Texto de busca para filtrar produtos pelo nome";
                }, {
                    readonly name: "productCategoryId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Identificador da categoria para filtrar os produtos do catálogo";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Número da página para paginação opcional";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Quantidade de itens por página para paginação opcional";
                }];
                readonly output: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Identificador do produto";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Nome do produto";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Descrição do produto";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Preço do produto";
                }, {
                    readonly name: "imageUrl";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "URL da imagem do produto";
                }, {
                    readonly name: "productCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Identificador da categoria do produto";
                }, {
                    readonly name: "featured";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Indica se o produto está em destaque";
                }, {
                    readonly name: "totalCount";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Total de produtos encontrados para suporte à paginação";
                }];
                readonly ports: readonly ["Product"];
                readonly rulesApplied: readonly ["featuredProductRequiresActive", "productImageUsesPlatformStorage"];
                readonly transactional: false;
                readonly steps: readonly ["1. Build a list query on the Product port with an automatic filter status=active (systemDefault from contextResolution) so only active products appear in the catalog", "2. If searchName is provided, add a case-insensitive contains filter on Product.name", "3. If productCategoryId is provided, add an equality filter on Product.productCategoryId", "4. If page and pageSize are provided, apply pagination (offset = (page-1)*pageSize, limit = pageSize); otherwise return all matching products", "5. Execute the list query through the Product port and collect matching Product records", "6. Apply rule featuredProductRequiresActive: any product with featured=true must have status=active; since the query already filters status=active this invariant is satisfied — if a featured product is found with status!=active, exclude it from results", "7. Apply rule productImageUsesPlatformStorage: for each returned product, ensure imageUrl (when present) references the platform storage URL pattern; if it does not, set imageUrl to null to avoid exposing non-platform URLs", "8. Hydrate ProductCategory names via ctx.mdm.collection.getMany using the distinct productCategoryId values from the results (plural-first, no loop-per-item calls)", "9. Project each product to the output fields: productId, name, description, price, imageUrl, productCategoryId, featured", "10. Return the projected collection along with totalCount for pagination support"];
            }];
            readonly mdmRefs: readonly ["ProductCategory"];
        };
    };
    export default browseProductCatalogUsecase;
    export const pipeline: readonly [{
        readonly id: "browseProductCatalog__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/browseProductCatalog.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/browseProductCatalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseProducts.defs" {
    export const browseProductsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseProducts";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseProducts";
            readonly ports: readonly ["Product"];
            readonly functions: readonly [{
                readonly functionName: "browseProducts";
                readonly inputTypeName: "BrowseProductsInput";
                readonly outputTypeName: "BrowseProductsOutput";
                readonly input: readonly [{
                    readonly name: "searchName";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Texto de busca para filtrar produtos pelo nome.";
                }, {
                    readonly name: "filterStatus";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Filtro de situação do produto: active ou inactive.";
                }, {
                    readonly name: "filterProductCategoryId";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Filtro por categoria de produto (MDM id).";
                }, {
                    readonly name: "filterFeatured";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly description: "Filtro para exibir apenas produtos marcados como destaque.";
                }];
                readonly output: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "imageUrl";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "productCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "featured";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }];
                readonly ports: readonly ["Product"];
                readonly rulesApplied: readonly ["featuredProductRequiresActive"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolve actorSession from ctx.sessionContext to verify the caller has admin scope; reject with 403 if not admin.", "2. Build a list query on the Product port using optional filters: searchName (LIKE on Product.name), filterStatus (exact match on Product.status), filterProductCategoryId (exact match on Product.productCategoryId), filterFeatured (exact match on Product.featured).", "3. Apply rule featuredProductRequiresActive: when filterFeatured is true, force an additional filter Product.status = 'active' so only active featured products are returned; also exclude any product where featured=true but status != 'active' from the result set.", "4. Order results by Product.createdAt descending.", "5. Collect all productCategoryId values from the result set and bulk-read ProductCategory MDM records via ctx.mdm.collection.getMany for hydration if needed.", "6. Return the projected list of products with fields productId, name, price, imageUrl, productCategoryId, featured, status, createdAt, updatedAt."];
            }];
            readonly mdmRefs: readonly ["ProductCategory"];
        };
    };
    export default browseProductsUsecase;
    export const pipeline: readonly [{
        readonly id: "browseProducts__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/browseProducts.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/browseProducts.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseServiceCatalog.defs" {
    export const browseServiceCatalogUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseServiceCatalog";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseServiceCatalog";
            readonly ports: readonly ["Service"];
            readonly functions: readonly [{
                readonly functionName: "browseServiceCatalog";
                readonly inputTypeName: "BrowseServiceCatalogInput";
                readonly outputTypeName: "BrowseServiceCatalogOutput";
                readonly input: readonly [{
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Page number for pagination (1-based)";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Number of items per page";
                }];
                readonly output: readonly [{
                    readonly name: "serviceId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Service";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Service";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Service";
                }, {
                    readonly name: "estimatedDurationMinutes";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Service";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Service";
                }];
                readonly ports: readonly ["Service"];
                readonly rulesApplied: readonly ["activeServicesOnlyListed"];
                readonly transactional: false;
                readonly steps: readonly ["Load all Service entities from the Service port applying a filter where status equals 'active' (rule activeServicesOnlyListed)", "If page and pageSize are provided, apply pagination: skip (page-1)*pageSize and take pageSize items", "Project each Service to { serviceId, name, description, estimatedDurationMinutes, price }", "Return the projected list of active services"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default browseServiceCatalogUsecase;
    export const pipeline: readonly [{
        readonly id: "browseServiceCatalog__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/browseServiceCatalog.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/browseServiceCatalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/serviceRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/service.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseServices" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseServicesInput {
        status?: string;
    }
    export interface BrowseServicesItem {
        serviceId: string;
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
        status: string;
        deactivatedAt: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export interface BrowseServicesOutput {
        services: BrowseServicesItem[];
    }
    export function browseServices(ctx: RequestContext, input: BrowseServicesInput): Promise<BrowseServicesOutput>;
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseShifts.defs" {
    export const browseShiftsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseShifts";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseShifts";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "browseShifts";
                readonly inputTypeName: "BrowseShiftsInput";
                readonly outputTypeName: "BrowseShiftsOutput";
                readonly input: readonly [{
                    readonly name: "activeFilter";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly description: "Filtro opcional para exibir apenas turnos ativos (true) ou inativos (false).";
                }];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Identificador único do turno.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Nome do turno.";
                }, {
                    readonly name: "startTime";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Horário de início do turno.";
                }, {
                    readonly name: "endTime";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Horário de fim do turno.";
                }, {
                    readonly name: "monday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre na segunda-feira.";
                }, {
                    readonly name: "tuesday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre na terça-feira.";
                }, {
                    readonly name: "wednesday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre na quarta-feira.";
                }, {
                    readonly name: "thursday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre na quinta-feira.";
                }, {
                    readonly name: "friday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre na sexta-feira.";
                }, {
                    readonly name: "saturday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre no sábado.";
                }, {
                    readonly name: "sunday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre no domingo.";
                }, {
                    readonly name: "active";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Status ativo do turno.";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Data de criação do turno.";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Data de atualização do turno.";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["businessHoursForScheduling", "operatorMultipleShiftsAllowed"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolve actorId from ctx.sessionContext (actorSession) — not a public input.", "2. Query MDM for all Shift records via ctx.mdm.collection.listByType({ type: 'Shift' }).", "3. If activeFilter is provided, filter results to only those where active === activeFilter.", "4. Apply businessHoursForScheduling rule inline: validate that each returned shift's startTime/endTime fall within 09:00–18:00 and operating days are Monday–Saturday; flag any shift that violates this as a configuration warning in the result set (does not exclude, but annotates).", "5. Apply operatorMultipleShiftsAllowed rule inline: no filtering needed — multiple shifts are allowed per operator; the rule is satisfied by returning the full list without deduplication.", "6. Project each Shift to the declared output fields (shiftId, name, startTime, endTime, monday–sunday, active, createdAt, updatedAt) and return the collection."];
            }];
            readonly mdmRefs: readonly ["Shift"];
        };
    };
    export default browseShiftsUsecase;
    export const pipeline: readonly [{
        readonly id: "browseShifts__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/browseShifts.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/browseShifts.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/completeServiceExecution.defs" {
    export const completeServiceExecutionUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "completeServiceExecution";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "completeServiceExecution";
            readonly ports: readonly ["ServiceBooking"];
            readonly functions: readonly [{
                readonly functionName: "completeServiceExecution";
                readonly inputTypeName: "CompleteServiceExecutionInput";
                readonly outputTypeName: "CompleteServiceExecutionOutput";
                readonly input: readonly [{
                    readonly name: "serviceBookingId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Identificador do agendamento de serviço a ser concluído, selecionado pelo operador na agenda.";
                }];
                readonly output: readonly [{
                    readonly name: "serviceBookingId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                }, {
                    readonly name: "completedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                }];
                readonly ports: readonly ["ServiceBooking"];
                readonly rulesApplied: readonly ["onlyAssignedOperatorCanComplete", "paymentInStoreOnly"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolve operatorId from ctx.sessionContext.actorId and completedAt from ctx.clock.now().", "2. Load ServiceBooking by serviceBookingId via ServiceBooking port (getById).", "3. Validate the booking exists; if not found throw a not-found error.", "4. Apply rule 'onlyAssignedOperatorCanComplete': compare booking.operatorId with the resolved operatorId from session. If they differ, throw a validation error with rule id 'onlyAssignedOperatorCanComplete'.", "5. Validate booking.status === 'inProgress'; if not, throw a validation error indicating the booking is not in a completable state.", "6. Apply rule 'paymentInStoreOnly': assert that no online payment/charge is triggered. This is an inline guard — the usecase must NOT call any payment or billing port. Record the rule id 'paymentInStoreOnly' in the execution trace.", "7. Mutate the booking: set status to 'completed' and completedAt to the resolved system datetime; set updatedAt to ctx.clock.now().", "8. Save the updated ServiceBooking through the ServiceBooking port inside the same transaction.", "9. Return { serviceBookingId, status: 'completed', completedAt }."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default completeServiceExecutionUsecase;
    export const pipeline: readonly [{
        readonly id: "completeServiceExecution__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/completeServiceExecution.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/completeServiceExecution.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/serviceBookingRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/serviceBooking.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/createAdoptablePet.defs" {
    export const createAdoptablePetUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createAdoptablePet";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createAdoptablePet";
            readonly ports: readonly ["AdoptablePet"];
            readonly functions: readonly [{
                readonly functionName: "createAdoptablePet";
                readonly inputTypeName: "CreateAdoptablePetInput";
                readonly outputTypeName: "CreateAdoptablePetOutput";
                readonly input: readonly [{
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Nome do pet informado pelo administrador";
                    readonly ofEntity: "AdoptablePet";
                }, {
                    readonly name: "age";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Idade do pet em anos informada pelo administrador";
                    readonly ofEntity: "AdoptablePet";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Descrição do pet exibida na galeria pública";
                    readonly ofEntity: "AdoptablePet";
                }, {
                    readonly name: "photoUrl";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "URL da foto do pet no armazenamento de mídia da plataforma";
                    readonly ofEntity: "AdoptablePet";
                }];
                readonly output: readonly [{
                    readonly name: "adoptablePetId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador único gerado automaticamente";
                    readonly ofEntity: "AdoptablePet";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                }, {
                    readonly name: "age";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                }, {
                    readonly name: "photoUrl";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status de disponibilidade definido como 'available'";
                    readonly ofEntity: "AdoptablePet";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Data e hora de cadastro gerada automaticamente";
                    readonly ofEntity: "AdoptablePet";
                }];
                readonly ports: readonly ["AdoptablePet"];
                readonly rulesApplied: readonly ["onlyAvailablePetsShownInGallery", "petImageUsesPlatformStorage"];
                readonly transactional: true;
                readonly steps: readonly ["1. Validate required user inputs: name (non-empty string), age (positive number), description (non-empty text), photoUrl (non-empty string).", "2. Apply rule petImageUsesPlatformStorage: validate that photoUrl starts with the platform media storage base URL (e.g. https://media.<platform-domain>/). If it does not, reject with validation error including rule id 'petImageUsesPlatformStorage'.", "3. Resolve system defaults: generate adoptablePetId via ctx.idGenerator.uuid(), set status to 'available' (so the pet appears in the public gallery per rule onlyAvailablePetsShownInGallery), set createdAt and updatedAt to ctx.clock.now().", "4. Build the AdoptablePet aggregate with all fields: adoptablePetId, name, age, description, photoUrl, status='available', createdAt, updatedAt.", "5. Persist the new AdoptablePet through its port (AdoptablePet.save) inside a single transaction via ctx.data transaction wrapper.", "6. Return the projected output fields: adoptablePetId, name, age, description, photoUrl, status, createdAt."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default createAdoptablePetUsecase;
    export const pipeline: readonly [{
        readonly id: "createAdoptablePet__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/createAdoptablePet.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/createAdoptablePet.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/adoptablePetRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/adoptablePet.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/createOperator.defs" {
    export const createOperatorUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createOperator";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createOperator";
            readonly ports: readonly ["Operator"];
            readonly functions: readonly [{
                readonly functionName: "createOperator";
                readonly inputTypeName: "CreateOperatorInput";
                readonly outputTypeName: "CreateOperatorOutput";
                readonly input: readonly [{
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Operator";
                    readonly description: "Nome completo do operador exibido na agenda e nos agendamentos atribuídos.";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Operator";
                    readonly description: "E-mail de contato do operador para notificações de agenda.";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Operator";
                    readonly description: "Telefone de contato do operador.";
                }, {
                    readonly name: "active";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Operator";
                    readonly description: "Indica se o operador inicia ativo e pode ser alocado em turnos.";
                }];
                readonly output: readonly [{
                    readonly name: "operatorId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Operator";
                    readonly description: "Identificador único do operador gerado automaticamente.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Operator";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Operator";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Operator";
                }, {
                    readonly name: "active";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Operator";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Operator";
                }];
                readonly ports: readonly ["Operator"];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["1. Validate that name is non-empty (required field).", "2. Generate operatorId via ctx.idGenerator (UUID v4).", "3. Set createdAt and updatedAt to ctx.clock.now().", "4. Build the Operator aggregate with the provided name, email, phone, active and the generated id/timestamps.", "5. Persist the Operator through its port inside a single transaction (ctx.data transaction wrapper).", "6. Return the created operator projection: operatorId, name, email, phone, active, createdAt."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default createOperatorUsecase;
    export const pipeline: readonly [{
        readonly id: "createOperator__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/createOperator.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/createOperator.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/operatorRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/operator.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/createProduct.defs" {
    export const createProductUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createProduct";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createProduct";
            readonly ports: readonly ["Product"];
            readonly functions: readonly [{
                readonly functionName: "createProduct";
                readonly inputTypeName: "CreateProductInput";
                readonly outputTypeName: "CreateProductOutput";
                readonly input: readonly [{
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Nome do produto exibido no catálogo e na página inicial.";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Descrição detalhada do produto para o cliente.";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Preço do produto cobrado na retirada presencial na loja.";
                }, {
                    readonly name: "imageUrl";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "URL da imagem do produto no armazenamento de mídia da plataforma.";
                }, {
                    readonly name: "productCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Categoria do produto selecionada pelo administrador.";
                }, {
                    readonly name: "featured";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Indica se o produto deve ser exibido em destaque na página inicial.";
                }];
                readonly output: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Identificador único do produto gerado automaticamente.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "productCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "featured";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }];
                readonly ports: readonly ["Product"];
                readonly rulesApplied: readonly ["featuredProductRequiresActive", "productImageUsesPlatformStorage"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolve system defaults: productId = ctx.idGenerator.uuid(), status = 'active', createdAt = updatedAt = ctx.clock.now().", "2. Validate that productCategoryId refers to an existing ProductCategory in MDM via ctx.mdm.entity.get({ mdmId: productCategoryId }). If not found, throw validation error 'productCategoryId does not correspond to an existing ProductCategory'.", "3. Apply rule featuredProductRequiresActive: if featured === true and status !== 'active', throw validation error 'featuredProductRequiresActive: a featured product must have status active'. Since status is always 'active' on create, this passes; the guard still runs to enforce the invariant.", "4. Apply rule productImageUsesPlatformStorage: if imageUrl is provided, validate that it points to the platform media storage domain (e.g. starts with the configured platform media base URL or matches the platform storage URL pattern). If it does not, throw validation error 'productImageUsesPlatformStorage: imageUrl must point to platform media storage, not module-local storage'.", "5. Build the Product aggregate with all fields (userInput + system defaults) and persist via ProductPort.save inside a single transaction (ctx.data transaction wrapper).", "6. Return the created product projection: productId, name, price, productCategoryId, featured, status, createdAt."];
            }];
            readonly mdmRefs: readonly ["ProductCategory"];
        };
    };
    export default createProductUsecase;
    export const pipeline: readonly [{
        readonly id: "createProduct__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/createProduct.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/createProduct.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/createService.defs" {
    export const createServiceUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createService";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createService";
            readonly ports: readonly ["Service"];
            readonly functions: readonly [{
                readonly functionName: "createService";
                readonly inputTypeName: "CreateServiceInput";
                readonly outputTypeName: "CreateServiceOutput";
                readonly input: readonly [{
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Service";
                    readonly description: "Nome do serviço oferecido, como banho e tosa.";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Service";
                    readonly description: "Descrição detalhada do serviço oferecido ao cliente.";
                }, {
                    readonly name: "estimatedDurationMinutes";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Service";
                    readonly description: "Duração estimada do serviço em minutos, usada para cálculo de horários disponíveis.";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Service";
                    readonly description: "Preço do serviço, cobrado presencialmente na loja após a execução.";
                }];
                readonly output: readonly [{
                    readonly name: "serviceId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Service";
                    readonly description: "Identificador único do serviço gerado automaticamente.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Service";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Service";
                }, {
                    readonly name: "estimatedDurationMinutes";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Service";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Service";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Service";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Service";
                }];
                readonly ports: readonly ["Service"];
                readonly rulesApplied: readonly ["activeServicesOnlyListed"];
                readonly transactional: true;
                readonly steps: readonly ["1. Validate that name is a non-empty string, description is a non-empty string, estimatedDurationMinutes is a positive integer, and price is a non-negative number.", "2. Generate serviceId via ctx.idGenerator.uuid().", "3. Set status to 'active' (systemDefault) so the new service is immediately visible in client listings per rule activeServicesOnlyListed.", "4. Set createdAt and updatedAt to ctx.clock.now() (systemDefault).", "5. Leave deactivatedAt as null (not set on creation).", "6. Persist the Service aggregate through the Service port inside a single transaction (ctx.data transaction wrapper).", "7. Return the created service projection: serviceId, name, description, estimatedDurationMinutes, price, status, createdAt."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default createServiceUsecase;
    export const pipeline: readonly [{
        readonly id: "createService__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/createService.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/createService.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/serviceRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/service.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/createServiceBooking.defs" {
    export const createServiceBookingUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createServiceBooking";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createServiceBooking";
            readonly ports: readonly ["ServiceBooking", "Service", "ShiftAssignment", "Operator"];
            readonly functions: readonly [{
                readonly functionName: "createServiceBooking";
                readonly inputTypeName: "CreateServiceBookingInput";
                readonly outputTypeName: "CreateServiceBookingOutput";
                readonly input: readonly [{
                    readonly name: "serviceId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Service";
                    readonly description: "Serviço selecionado pelo cliente para agendamento.";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Nome do cliente que realiza o agendamento.";
                }, {
                    readonly name: "customerPhone";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Telefone de contato do cliente.";
                }, {
                    readonly name: "bookingDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Data do agendamento escolhida pelo cliente, dentro do horário de funcionamento.";
                }, {
                    readonly name: "bookingTime";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Horário do agendamento escolhido pelo cliente, dentro do intervalo de funcionamento.";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Observações adicionais opcionais informadas pelo cliente.";
                }];
                readonly output: readonly [{
                    readonly name: "serviceBookingId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Identificador único do agendamento criado.";
                }, {
                    readonly name: "serviceId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Serviço agendado.";
                }, {
                    readonly name: "operatorId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Operador alocado ao agendamento.";
                }, {
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Turno correspondente à data e horário escolhidos.";
                }, {
                    readonly name: "bookingDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Data do agendamento.";
                }, {
                    readonly name: "bookingTime";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Horário do agendamento.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Status inicial do agendamento (confirmed).";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Nome do cliente.";
                }];
                readonly ports: readonly ["ServiceBooking", "Service", "ShiftAssignment", "Operator"];
                readonly rulesApplied: readonly ["paymentInStoreOnly", "schedulingCapacityByOperators", "noBookingWithoutAvailableOperator", "businessHoursForScheduling"];
                readonly transactional: true;
                readonly steps: readonly ["1. RULE businessHoursForScheduling: Parse bookingDate to determine day-of-week (Mon=1..Sat=6, Sun=0). Reject if Sunday. Parse bookingTime as HH:mm; reject if before 09:00 or after 18:00. Throw validation error with rule id if violated.", "2. Load Service by serviceId via Service port (getById). If not found or status != 'active', throw validation error.", "3. List active Shifts from MDM via ctx.mdm.collection.listByType({ type: 'Shift' }). Filter in memory for shifts where active=true AND the day-of-week flag matches bookingDate (e.g. monday=true for Monday) AND bookingTime >= startTime AND bookingTime <= endTime. Select the first matching shift; if none, throw validation error with rule businessHoursForScheduling.", "4. Load ShiftAssignments for the resolved shiftId via ShiftAssignment port (list filtered by shiftId). Collect operatorIds from the assignments.", "5. Load Operators by the collected operatorIds via Operator port (getMany). Filter to active=true operators. If no active operators, throw validation error with rule noBookingWithoutAvailableOperator.", "6. Count existing ServiceBookings with shiftId = resolved shiftId AND status = 'confirmed' via ServiceBooking port (list filtered by shiftId and status).", "7. RULE schedulingCapacityByOperators: If confirmedBookingsCount >= activeOperatorsCount, throw validation error with rule id — no capacity available.", "8. RULE noBookingWithoutAvailableOperator: Select the first active operator from the assignments as the assigned operatorId. If none available, throw validation error.", "9. RULE paymentInStoreOnly: Do NOT create any payment or transaction record. The booking is registered without charge — payment is in-store only.", "10. Generate serviceBookingId via ctx.idGenerator (UUID). Set status='confirmed' (workflowState initial). Set createdAt and updatedAt to ctx.clock.now().", "11. Save the new ServiceBooking aggregate via ServiceBooking port (create) inside the transaction wrapper (ctx.data transaction).", "12. Return the created ServiceBooking projection: serviceBookingId, serviceId, operatorId, shiftId, bookingDate, bookingTime, status, customerName."];
            }];
            readonly mdmRefs: readonly ["Shift"];
        };
    };
    export default createServiceBookingUsecase;
    export const pipeline: readonly [{
        readonly id: "createServiceBooking__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/createServiceBooking.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/createServiceBooking.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/serviceBookingRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/serviceRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/shiftAssignmentRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/operatorRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/serviceBooking.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/service.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/shiftAssignment.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/operator.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/expressAdoptionInterest.defs" {
    export const expressAdoptionInterestUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "expressAdoptionInterest";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "expressAdoptionInterest";
            readonly ports: readonly ["AdoptionInterest", "AdoptablePet"];
            readonly functions: readonly [{
                readonly functionName: "expressAdoptionInterest";
                readonly inputTypeName: "ExpressAdoptionInterestInput";
                readonly outputTypeName: "ExpressAdoptionInterestOutput";
                readonly input: readonly [{
                    readonly name: "adoptablePetId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                    readonly description: "Pet disponível para adoção selecionado pelo cliente no site.";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptionInterest";
                    readonly description: "Nome completo do cliente que manifesta interesse em adotar.";
                }, {
                    readonly name: "customerEmail";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptionInterest";
                    readonly description: "E-mail de contato do cliente para comunicação sobre a adoção.";
                }, {
                    readonly name: "customerPhone";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "AdoptionInterest";
                    readonly description: "Telefone de contato do cliente para agendamento da visita presencial.";
                }];
                readonly output: readonly [{
                    readonly name: "adoptionInterestId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "AdoptionInterest";
                    readonly description: "Identificador único do registro de interesse criado.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptionInterest";
                    readonly description: "Status inicial do registro, sempre 'registered'.";
                }, {
                    readonly name: "adoptablePetId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                    readonly description: "ID do pet adotável referenciado pelo interesse.";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptionInterest";
                    readonly description: "Nome do cliente informado.";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly ofEntity: "AdoptionInterest";
                    readonly description: "Data e hora da criação do registro.";
                }];
                readonly ports: readonly ["AdoptionInterest", "AdoptablePet"];
                readonly rulesApplied: readonly ["adoptionStartedOnlineFinishedInStore"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the selected AdoptablePet by adoptablePetId through the AdoptablePet port (getById).", "2. Validate the AdoptablePet exists and its status is 'available'; if not, reject with a validation error referencing rule adoptionStartedOnlineFinishedInStore.", "3. Validate customerName is non-empty and customerEmail is a non-empty string.", "4. Generate adoptionInterestId via ctx.idGenerator.", "5. Set status to 'registered' (rule adoptionStartedOnlineFinishedInStore: adoption starts online, finishes in store).", "6. Set createdAt and updatedAt to ctx.clock.now().", "7. Set operatorId, verificationNotes, completedAt, cancelledAt, cancellationReason to null (in-store finalization fields are not populated at online registration).", "8. Save the AdoptionInterest aggregate through the AdoptionInterest port inside a single transaction (ctx.data transaction wrapper).", "9. Return adoptionInterestId, status, adoptablePetId, customerName, createdAt."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default expressAdoptionInterestUsecase;
    export const pipeline: readonly [{
        readonly id: "expressAdoptionInterest__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/expressAdoptionInterest.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/expressAdoptionInterest.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/adoptionInterestRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/adoptablePetRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/adoptionInterest.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/adoptablePet.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/placeStorePickupOrder.defs" {
    export const placeStorePickupOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "placeStorePickupOrder";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "placeStorePickupOrder";
            readonly ports: readonly ["Order", "Product"];
            readonly functions: readonly [{
                readonly functionName: "placeStorePickupOrder";
                readonly inputTypeName: "PlaceStorePickupOrderInput";
                readonly outputTypeName: "PlaceStorePickupOrderOutput";
                readonly input: readonly [{
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Nome do cliente que está finalizando o pedido de retirada";
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "customerPhone";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Telefone de contato opcional do cliente para confirmação da retirada";
                    readonly ofEntity: "Order";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador único do pedido criado";
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Status do pedido após criação (registered)";
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Nome do cliente confirmado no pedido";
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "customerPhone";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Telefone de contato do cliente, se informado";
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Data e hora de registro do pedido";
                    readonly ofEntity: "Order";
                }];
                readonly ports: readonly ["Order", "Product"];
                readonly rulesApplied: readonly ["paymentInStoreOnly", "pickupInStoreOnly", "orderRequiresAtLeastOneItem"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolve cartItems from workflow state context (previous navigation/review steps) — these are NOT client inputs but server-side resolved state containing { productId, quantity } pairs.", "2. Apply rule 'orderRequiresAtLeastOneItem': validate that cartItems is not empty and contains at least one item; if empty, throw validation error with ruleId 'orderRequiresAtLeastOneItem'.", "3. Generate orderId via ctx.idGenerator (systemDefault UUID).", "4. Resolve current timestamp via ctx.clock for createdAt and updatedAt (systemDefault).", "5. Collect all productIds from cartItems and batch-read them through the Product port (plural-first) to validate existence and retrieve current price for each product.", "6. Validate every productId in cartItems corresponds to an active Product; if any product is missing or inactive, throw validation error listing the invalid productIds.", "7. Apply rule 'pickupInStoreOnly': the order is created with no delivery option — pickup is exclusively in the physical store; this is enforced by the order creation flow having no delivery/shipping fields.", "8. Apply rule 'paymentInStoreOnly': no online payment is processed — the order is created with status 'registered' and payment is expected to be completed in person at the store during pickup; no payment processing step is invoked.", "9. Build OrderItem collection from cartItems: for each item, generate orderItemId via ctx.idGenerator, set orderId to the new order's id, copy productId and quantity from cart item, set unitPrice from the Product's current price, and set createdAt/updatedAt to the current timestamp.", "10. Create the Order aggregate through the Order port with: orderId, status='registered', customerName, customerPhone (if provided), createdAt, updatedAt, and the embedded OrderItem collection.", "11. Save the Order (with embedded OrderItems) through the Order port inside a single transaction (ctx.data transaction wrapper).", "12. Return { orderId, status, customerName, customerPhone, createdAt }."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default placeStorePickupOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "placeStorePickupOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/placeStorePickupOrder.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/placeStorePickupOrder.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/orderRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/order.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/startServiceExecution.defs" {
    export const startServiceExecutionUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "startServiceExecution";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "startServiceExecution";
            readonly ports: readonly ["ServiceBooking", "Operator"];
            readonly functions: readonly [{
                readonly functionName: "startServiceExecution";
                readonly inputTypeName: "StartServiceExecutionInput";
                readonly outputTypeName: "StartServiceExecutionOutput";
                readonly input: readonly [{
                    readonly name: "serviceBookingId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Identificador do agendamento de serviço selecionado pelo operador para iniciar o atendimento.";
                }];
                readonly output: readonly [{
                    readonly name: "serviceBookingId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                }];
                readonly ports: readonly ["ServiceBooking", "Operator"];
                readonly rulesApplied: readonly ["operatorSeesOnlyAssignedShiftBookings", "onlyAssignedOperatorCanComplete"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolve operatorId from ctx.sessionContext.actorId (actorSession context — not a public input).", "2. Resolve updatedAt from ctx.clock.now() (systemDefault — not a public input).", "3. Load ServiceBooking by serviceBookingId via ServiceBooking port (getById).", "4. Validate booking exists; if not found, throw validation error 'ServiceBooking not found'.", "5. Validate booking.status === 'confirmed'; if not, throw validation error with rule detail: 'ServiceBooking must be in confirmed status to start execution; current status: {status}'.", "6. Apply rule onlyAssignedOperatorCanComplete: compare booking.operatorId with resolved operatorId (ctx.sessionContext.actorId). If they differ, throw authorization error 'Only the assigned operator can start this service booking'.", "7. Apply rule operatorSeesOnlyAssignedShiftBookings: load Operator by operatorId via Operator port (getById). Validate the operator is active. Then verify the operator is allocated to the same shift as the booking (booking.shiftId). If the operator's shift does not match booking.shiftId, throw authorization error 'Operator cannot access bookings from a different shift'.", "8. Transition booking.status to 'inProgress'.", "9. Set booking.updatedAt to the resolved system timestamp (ctx.clock.now()).", "10. Save the updated ServiceBooking via ServiceBooking port inside the same transaction.", "11. Return { serviceBookingId, status: 'inProgress', updatedAt }."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default startServiceExecutionUsecase;
    export const pipeline: readonly [{
        readonly id: "startServiceExecution__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/startServiceExecution.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/startServiceExecution.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/serviceBookingRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/operatorRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/serviceBooking.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/operator.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/updateAdoptablePet.defs" {
    export const updateAdoptablePetUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateAdoptablePet";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateAdoptablePet";
            readonly ports: readonly ["AdoptablePet"];
            readonly functions: readonly [{
                readonly functionName: "updateAdoptablePet";
                readonly inputTypeName: "UpdateAdoptablePetInput";
                readonly outputTypeName: "UpdateAdoptablePetOutput";
                readonly input: readonly [{
                    readonly name: "adoptablePetId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                    readonly description: "Identificador do pet selecionado para edição na lista de gestão";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                    readonly description: "Nome do pet editado pelo administrador";
                }, {
                    readonly name: "age";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                    readonly description: "Idade do pet em anos";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                    readonly description: "Descrição do pet";
                }, {
                    readonly name: "photoUrl";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                    readonly description: "URL da foto do pet no armazenamento de mídia da plataforma";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                    readonly description: "Disponibilidade do pet: available ou unavailable";
                }];
                readonly output: readonly [{
                    readonly name: "adoptablePetId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                }, {
                    readonly name: "age";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                }, {
                    readonly name: "photoUrl";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                }];
                readonly ports: readonly ["AdoptablePet"];
                readonly rulesApplied: readonly ["onlyAvailablePetsShownInGallery", "petImageUsesPlatformStorage"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the AdoptablePet aggregate by adoptablePetId via the AdoptablePet port (getById). If not found, return a validation error.", "2. Validate status is one of 'available' or 'unavailable' (rule onlyAvailablePetsShownInGallery — only pets with status 'available' are shown in the public gallery; setting 'unavailable' removes the pet from the gallery).", "3. Validate photoUrl is a platform storage URL (rule petImageUsesPlatformStorage — the photo must reference the platform media storage, not an arbitrary external URL or embedded file). Reject if the URL does not match the platform storage domain pattern.", "4. Validate required fields: name (non-empty), age (>= 0), description (non-empty).", "5. Set updatedAt to ctx.clock.now() (systemDefault — resolved server-side, never from client input).", "6. Apply the updated fields (name, age, description, photoUrl, status, updatedAt) to the loaded AdoptablePet aggregate.", "7. Save the AdoptablePet aggregate through the AdoptablePet port inside a single transaction (ctx.data transaction wrapper).", "8. Return the updated aggregate fields: adoptablePetId, name, age, description, photoUrl, status, updatedAt."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateAdoptablePetUsecase;
    export const pipeline: readonly [{
        readonly id: "updateAdoptablePet__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/updateAdoptablePet.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/updateAdoptablePet.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/adoptablePetRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/adoptablePet.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/updateOperator.defs" {
    export const updateOperatorUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateOperator";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateOperator";
            readonly ports: readonly ["Operator"];
            readonly functions: readonly [{
                readonly functionName: "updateOperator";
                readonly inputTypeName: "UpdateOperatorInput";
                readonly outputTypeName: "UpdateOperatorOutput";
                readonly input: readonly [{
                    readonly name: "operatorId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Operator";
                    readonly description: "Identificador do operador a ser editado, obtido do parâmetro de rota.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Operator";
                    readonly description: "Nome completo do operador editado pelo administrador.";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Operator";
                    readonly description: "E-mail de contato do operador, opcional.";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Operator";
                    readonly description: "Telefone de contato do operador, opcional.";
                }, {
                    readonly name: "active";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Operator";
                    readonly description: "Indica se o operador está ativo e pode ser alocado em turnos.";
                }];
                readonly output: readonly [{
                    readonly name: "operatorId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Operator";
                    readonly description: "Identificador do operador atualizado.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Operator";
                    readonly description: "Nome do operador após a atualização.";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Operator";
                    readonly description: "E-mail do operador após a atualização.";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Operator";
                    readonly description: "Telefone do operador após a atualização.";
                }, {
                    readonly name: "active";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Operator";
                    readonly description: "Status ativo do operador após a atualização.";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Operator";
                    readonly description: "Data e hora da última modificação.";
                }];
                readonly ports: readonly ["Operator"];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["1. Extrair operatorId do parâmetro de rota e validar que não é vazio.", "2. Resolver updatedAt a partir de ctx.clock.now() e actorId a partir de ctx.sessionContext.actorId (contexto de sessão, não input público).", "3. Carregar o operador existente através do port Operator.getById({ operatorId }).", "4. Se o operador não for encontrado, retornar erro de validação: 'Operador não encontrado para o operatorId informado.'", "5. Aplicar as alterações no agregado: atualizar name, active (sempre), e email/phone apenas quando fornecidos (preservar valores anteriores quando ausentes).", "6. Definir updatedAt no agregado com o timestamp resolvido do servidor.", "7. Persistir o agregado através do port Operator.save(operator) dentro da mesma transação.", "8. Retornar a projeção { operatorId, name, email, phone, active, updatedAt } do operador atualizado."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateOperatorUsecase;
    export const pipeline: readonly [{
        readonly id: "updateOperator__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/updateOperator.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/updateOperator.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/operatorRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/operator.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/updateProduct.defs" {
    export const updateProductUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateProduct";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateProduct";
            readonly ports: readonly ["Product"];
            readonly functions: readonly [{
                readonly functionName: "updateProduct";
                readonly inputTypeName: "UpdateProductInput";
                readonly outputTypeName: "UpdateProductOutput";
                readonly input: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Identificador do produto selecionado para edição.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Nome atualizado do produto exibido no catálogo.";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Descrição detalhada atualizada do produto.";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Preço atualizado do produto cobrado na retirada presencial.";
                }, {
                    readonly name: "imageUrl";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "URL da imagem do produto no armazenamento de mídia da plataforma.";
                }, {
                    readonly name: "productCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Categoria do produto selecionada na lista de categorias cadastradas.";
                }, {
                    readonly name: "featured";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Indica se o produto deve ser exibido em destaque na página inicial.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Situação do produto: ativo ou inativo.";
                }];
                readonly output: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Identificador do produto atualizado.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Nome atualizado do produto.";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Descrição atualizada do produto.";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Preço atualizado do produto.";
                }, {
                    readonly name: "imageUrl";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "URL da imagem do produto.";
                }, {
                    readonly name: "productCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Categoria do produto atualizada.";
                }, {
                    readonly name: "featured";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Indicador de destaque do produto.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Situação do produto após atualização.";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Timestamp da última atualização.";
                }];
                readonly ports: readonly ["Product"];
                readonly rulesApplied: readonly ["featuredProductRequiresActive", "productImageUsesPlatformStorage"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the existing Product aggregate from the Product port by productId; reject if not found.", "2. Validate productCategoryId against MDM: call ctx.mdm.entity.get({ mdmId: productCategoryId }) to confirm the ProductCategory exists; reject if not found.", "3. Apply rule featuredProductRequiresActive: if featured === true and status !== 'active', reject with validation error. If status === 'inactive', force featured = false.", "4. Apply rule productImageUsesPlatformStorage: if imageUrl is provided, validate that it starts with the platform media storage base URL pattern; reject otherwise.", "5. Set updatedAt = ctx.clock.now() (systemDefault, not user input).", "6. Mutate the Product aggregate with the validated fields (name, description, price, imageUrl, productCategoryId, featured, status, updatedAt).", "7. Save the Product aggregate through the Product port inside a single transaction (ctx.data transaction wrapper).", "8. Return the updated product fields: productId, name, description, price, imageUrl, productCategoryId, featured, status, updatedAt."];
            }];
            readonly mdmRefs: readonly ["ProductCategory"];
        };
    };
    export default updateProductUsecase;
    export const pipeline: readonly [{
        readonly id: "updateProduct__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/updateProduct.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/updateProduct.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/updateService.defs" {
    export const updateServiceUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateService";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateService";
            readonly ports: readonly ["Service", "ServiceBooking"];
            readonly functions: readonly [{
                readonly functionName: "updateService";
                readonly inputTypeName: "UpdateServiceInput";
                readonly outputTypeName: "UpdateServiceOutput";
                readonly input: readonly [{
                    readonly name: "serviceId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Service";
                    readonly description: "Identificador do serviço selecionado para edição.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Service";
                    readonly description: "Nome atualizado do serviço.";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Service";
                    readonly description: "Descrição detalhada atualizada do serviço oferecido.";
                }, {
                    readonly name: "estimatedDurationMinutes";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Service";
                    readonly description: "Duração estimada atualizada do serviço em minutos.";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Service";
                    readonly description: "Preço atualizado do serviço.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Service";
                    readonly description: "Novo estado de ativação do serviço: active ou inactive.";
                }];
                readonly output: readonly [{
                    readonly name: "serviceId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Service";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Service";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Service";
                }, {
                    readonly name: "estimatedDurationMinutes";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Service";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Service";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Service";
                }, {
                    readonly name: "deactivatedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Service";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Service";
                }];
                readonly ports: readonly ["Service", "ServiceBooking"];
                readonly rulesApplied: readonly ["activeServicesOnlyListed", "deactivatingServiceDoesNotCancelBookings"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the Service aggregate by serviceId via the Service port (getById). If not found, return a validation error.", "2. Validate that status is one of 'active' or 'inactive' (enum constraint on Service.status).", "3. Apply field updates to the loaded Service: name, description, estimatedDurationMinutes, price, and status from the public input.", "4. Set updatedAt to ctx.clock.now() (systemDefault resolution — never accepted from the client).", "5. If the new status is 'inactive' AND the previous status was 'active' (or deactivatedAt is null), set deactivatedAt to ctx.clock.now(). If the new status is 'active', set deactivatedAt to null. This implements the deactivatedAt systemDefault resolution.", "6. Rule deactivatingServiceDoesNotCancelBookings: when status transitions to 'inactive', do NOT query, modify, or cancel any ServiceBooking records. The ServiceBooking port is available for read-only verification if needed, but no booking mutations occur. Bookings with status 'confirmed' remain untouched.", "7. Rule activeServicesOnlyListed: this rule is enforced on the listing/read path, not on update. However, as a guard, if the service is being reactivated (status 'active'), ensure it will appear in client listings. No additional mutation needed — the status field itself drives the listing filter.", "8. Save the updated Service aggregate through the Service port inside the transaction.", "9. Return the projected output fields: serviceId, name, description, estimatedDurationMinutes, price, status, deactivatedAt, updatedAt."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateServiceUsecase;
    export const pipeline: readonly [{
        readonly id: "updateService__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/updateService.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/updateService.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/serviceRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/serviceBookingRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/service.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/serviceBooking.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/updateShift.defs" {
    export const updateShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateShift";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateShift";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateShift";
                readonly inputTypeName: "UpdateShiftInput";
                readonly outputTypeName: "UpdateShiftOutput";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Identificador do turno selecionado para edição.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Nome do turno informado pelo administrador (ex.: Manhã, Tarde, Dia Inteiro).";
                }, {
                    readonly name: "startTime";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Horário de início do turno no formato HH:mm.";
                }, {
                    readonly name: "endTime";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Horário de fim do turno no formato HH:mm.";
                }, {
                    readonly name: "monday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre às segundas-feiras.";
                }, {
                    readonly name: "tuesday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre às terças-feiras.";
                }, {
                    readonly name: "wednesday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre às quartas-feiras.";
                }, {
                    readonly name: "thursday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre às quintas-feiras.";
                }, {
                    readonly name: "friday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre às sextas-feiras.";
                }, {
                    readonly name: "saturday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre aos sábados.";
                }, {
                    readonly name: "sunday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre aos domingos.";
                }, {
                    readonly name: "active";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno está ativo e disponível para alocação.";
                }];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Identificador do turno atualizado.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Nome do turno atualizado.";
                }, {
                    readonly name: "startTime";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Horário de início do turno atualizado.";
                }, {
                    readonly name: "endTime";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Horário de fim do turno atualizado.";
                }, {
                    readonly name: "monday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre às segundas-feiras.";
                }, {
                    readonly name: "tuesday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre às terças-feiras.";
                }, {
                    readonly name: "wednesday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre às quartas-feiras.";
                }, {
                    readonly name: "thursday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre às quintas-feiras.";
                }, {
                    readonly name: "friday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre às sextas-feiras.";
                }, {
                    readonly name: "saturday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre aos sábados.";
                }, {
                    readonly name: "sunday";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno ocorre aos domingos.";
                }, {
                    readonly name: "active";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Indica se o turno está ativo e disponível para alocação.";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["businessHoursForScheduling", "operatorMultipleShiftsAllowed"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolve shiftId from the public input (selectedEntity).", "2. Resolve actorId from ctx.sessionContext (actorSession) and updatedAt from ctx.clock.now() (systemDefault) — neither is a public input.", "3. Validate required fields: name is non-empty, startTime and endTime are in HH:mm format, and at least one weekday flag (monday–sunday) is true.", "4. Apply businessHoursForScheduling: parse startTime and endTime; if they fall outside the standard 09:00–18:00 window, the update is still accepted as an explicit administrator override (the rule is permissive, not blocking) — no error is raised.", "5. Apply operatorMultipleShiftsAllowed: overlapping shifts on the same day are permitted; no conflict check is performed and no error is raised.", "6. Load the existing Shift MDM record via ctx.mdm.entity.get({ mdmId: shiftId }) to confirm it exists; throw a not-found validation error if absent.", "7. Update the Shift MDM record via ctx.mdm.entity.update({ mdmId: shiftId, details: { name, startTime, endTime, monday, tuesday, wednesday, thursday, friday, saturday, sunday, active, updatedAt } }) inside a single transaction (ctx.data transaction wrapper).", "8. Return the updated shift fields: shiftId, name, startTime, endTime, monday–sunday, active."];
            }];
            readonly mdmRefs: readonly ["Shift"];
        };
    };
    export default updateShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "updateShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/updateShift.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/updateShift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/viewAdoptablePetDetails.defs" {
    export const viewAdoptablePetDetailsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewAdoptablePetDetails";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewAdoptablePetDetails";
            readonly ports: readonly ["AdoptablePet"];
            readonly functions: readonly [{
                readonly functionName: "viewAdoptablePetDetails";
                readonly inputTypeName: "ViewAdoptablePetDetailsInput";
                readonly outputTypeName: "ViewAdoptablePetDetailsOutput";
                readonly input: readonly [{
                    readonly name: "adoptablePetId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                    readonly description: "Identificador do pet selecionado na galeria, passado como parâmetro de rota";
                }];
                readonly output: readonly [{
                    readonly name: "adoptablePetId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                    readonly description: "Identificador do pet retornado";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                    readonly description: "Nome do pet";
                }, {
                    readonly name: "age";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                    readonly description: "Idade do pet";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                    readonly description: "Descrição do pet";
                }, {
                    readonly name: "photoUrl";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                    readonly description: "URL da foto do pet no armazenamento de mídia";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "AdoptablePet";
                    readonly description: "Status de disponibilidade do pet (available | unavailable)";
                }];
                readonly ports: readonly ["AdoptablePet"];
                readonly rulesApplied: readonly ["onlyAvailablePetsShownInGallery"];
                readonly transactional: false;
                readonly steps: readonly ["1. Load the AdoptablePet aggregate by adoptablePetId via the AdoptablePet port (getById).", "2. If no aggregate is found for the given id, return an empty result (not-found).", "3. Apply rule 'onlyAvailablePetsShownInGallery': if the loaded pet has status 'unavailable', return an empty result — details of unavailable pets are never exposed.", "4. If status is 'available', project the fields name, age, description, photoUrl, status and adoptablePetId into the output.", "5. Return the projected viewAdoptablePetDetails output."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewAdoptablePetDetailsUsecase;
    export const pipeline: readonly [{
        readonly id: "viewAdoptablePetDetails__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/viewAdoptablePetDetails.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/viewAdoptablePetDetails.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/adoptablePetRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/adoptablePet.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/viewOperatorSchedule.defs" {
    export const viewOperatorScheduleUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewOperatorSchedule";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewOperatorSchedule";
            readonly ports: readonly ["ServiceBooking", "Service"];
            readonly functions: readonly [{
                readonly functionName: "viewOperatorSchedule";
                readonly inputTypeName: "ViewOperatorScheduleInput";
                readonly outputTypeName: "ViewOperatorScheduleOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "serviceBookingId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Identificador único do agendamento";
                }, {
                    readonly name: "serviceId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Identificador do serviço agendado";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Nome do cliente";
                }, {
                    readonly name: "customerPhone";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Telefone do cliente";
                }, {
                    readonly name: "bookingDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Data do agendamento";
                }, {
                    readonly name: "bookingTime";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Horário do agendamento";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Status do agendamento";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "ServiceBooking";
                    readonly description: "Observações do agendamento";
                }];
                readonly ports: readonly ["ServiceBooking", "Service"];
                readonly rulesApplied: readonly ["operatorSeesOnlyAssignedShiftBookings", "operatorScheduleShowsConfirmedOnly"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolver operatorId a partir de ctx.sessionContext.actorId (actorSession) — não é input público", "2. Carregar todos os ServiceBooking via ServiceBooking port filtrando por operatorId = operatorId resolvido da sessão (regra operatorSeesOnlyAssignedShiftBookings)", "3. Filtrar apenas agendamentos com status === 'confirmed' (regra operatorScheduleShowsConfirmedOnly)", "4. Ordenar resultado por bookingDate asc e bookingTime asc", "5. Projetar campos: serviceBookingId, serviceId, customerName, customerPhone, bookingDate, bookingTime, status, notes", "6. Retornar a lista projetada"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewOperatorScheduleUsecase;
    export const pipeline: readonly [{
        readonly id: "viewOperatorSchedule__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/viewOperatorSchedule.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/viewOperatorSchedule.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/serviceBookingRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/serviceRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/serviceBooking.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/service.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/adoptablePet.defs" {
    export const adoptablePetDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "AdoptablePet";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "AdoptablePet";
            readonly fields: readonly [{
                readonly fieldId: "adoptablePetId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do pet para adoção";
            }, {
                readonly fieldId: "name";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do pet";
            }, {
                readonly fieldId: "age";
                readonly type: "number";
                readonly required: true;
                readonly description: "Idade do pet em anos";
            }, {
                readonly fieldId: "description";
                readonly type: "text";
                readonly required: true;
                readonly description: "Descrição do pet exibida na galeria pública";
            }, {
                readonly fieldId: "photoUrl";
                readonly type: "string";
                readonly required: true;
                readonly description: "URL da foto do pet no armazenamento de mídia da plataforma";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Disponibilidade do pet para adoção, controla exibição na galeria";
                readonly enum: readonly ["available", "unavailable"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de cadastro do pet";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do pet";
            }];
            readonly statusEnum: readonly ["available", "unavailable"];
            readonly invariants: readonly ["age must be a non-negative number", "status must be 'available' or 'unavailable'", "only pets with status 'available' are shown in the public gallery", "updatedAt must be greater than or equal to createdAt"];
            readonly valueObjects: readonly [];
        };
    };
    export default adoptablePetDomainEntity;
    export const pipeline: readonly [{
        readonly id: "adoptablePet__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/petShop/layer_3_domain/entities/adoptablePet.ts";
        readonly defPath: "_102049_/l1/petShop/layer_3_domain/entities/adoptablePet.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/adoptionInterest.defs" {
    export const adoptionInterestDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "AdoptionInterest";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "AdoptionInterest";
            readonly fields: readonly [{
                readonly fieldId: "adoptionInterestId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único da manifestação de interesse em adoção.";
            }, {
                readonly fieldId: "adoptablePetId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao pet disponível para adoção que é objeto do interesse.";
            }, {
                readonly fieldId: "customerName";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome completo do cliente que manifesta interesse em adotar.";
            }, {
                readonly fieldId: "customerEmail";
                readonly type: "string";
                readonly required: true;
                readonly description: "E-mail de contato do cliente para comunicação sobre a adoção.";
            }, {
                readonly fieldId: "customerPhone";
                readonly type: "string";
                readonly required: false;
                readonly description: "Telefone de contato do cliente para agendamento da visita presencial.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação atual da manifestação de interesse: registrada, concluída ou cancelada.";
                readonly enum: readonly ["registered", "completed", "cancelled"];
            }, {
                readonly fieldId: "operatorId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Identificador do operador que realizou a verificação e finalização presencial na loja.";
            }, {
                readonly fieldId: "verificationNotes";
                readonly type: "text";
                readonly required: false;
                readonly description: "Anotações da verificação presencial e documentação apresentada pelo cliente na loja.";
            }, {
                readonly fieldId: "completedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que a adoção foi finalizada presencialmente na loja.";
            }, {
                readonly fieldId: "cancelledAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que a manifestação de interesse foi cancelada.";
            }, {
                readonly fieldId: "cancellationReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo do cancelamento da manifestação de interesse.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora em que o interesse foi registrado pelo cliente no site.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro de interesse.";
            }];
            readonly statusEnum: readonly ["registered", "completed", "cancelled"];
            readonly invariants: readonly ["status must be 'registered', 'completed', or 'cancelled'", "when status is 'completed', operatorId and completedAt must be set", "when status is 'cancelled', cancelledAt and cancellationReason must be set", "completedAt and cancelledAt are mutually exclusive — an interest cannot be both completed and cancelled", "operatorId is only set when the interest is being verified or completed by an operator", "updatedAt must be greater than or equal to createdAt"];
            readonly valueObjects: readonly [];
        };
    };
    export default adoptionInterestDomainEntity;
    export const pipeline: readonly [{
        readonly id: "adoptionInterest__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/petShop/layer_3_domain/entities/adoptionInterest.ts";
        readonly defPath: "_102049_/l1/petShop/layer_3_domain/entities/adoptionInterest.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/operator.defs" {
    export const operatorDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Operator";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Operator";
            readonly fields: readonly [{
                readonly fieldId: "operatorId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do operador.";
            }, {
                readonly fieldId: "name";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome completo do operador exibido na agenda e nos agendamentos atribuídos.";
            }, {
                readonly fieldId: "email";
                readonly type: "string";
                readonly required: false;
                readonly description: "E-mail de contato do operador para notificações de agenda.";
            }, {
                readonly fieldId: "phone";
                readonly type: "string";
                readonly required: false;
                readonly description: "Telefone de contato do operador.";
            }, {
                readonly fieldId: "active";
                readonly type: "boolean";
                readonly required: true;
                readonly description: "Indica se o operador está ativo e pode ser alocado em turnos e receber agendamentos.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de cadastro do operador pelo administrador.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização dos dados do operador.";
            }];
            readonly statusEnum: readonly [];
            readonly invariants: readonly ["only active operators can be allocated to shifts and receive service bookings", "updatedAt must be greater than or equal to createdAt"];
            readonly valueObjects: readonly [];
        };
    };
    export default operatorDomainEntity;
    export const pipeline: readonly [{
        readonly id: "operator__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/petShop/layer_3_domain/entities/operator.ts";
        readonly defPath: "_102049_/l1/petShop/layer_3_domain/entities/operator.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/order.defs" {
    export const orderDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Order";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly fields: readonly [{
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do pedido de retirada.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação atual do pedido: registrado, concluído ou cancelado.";
                readonly enum: readonly ["registered", "completed", "cancelled"];
            }, {
                readonly fieldId: "customerName";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do cliente que realizou o pedido de retirada.";
            }, {
                readonly fieldId: "customerPhone";
                readonly type: "string";
                readonly required: false;
                readonly description: "Telefone de contato do cliente para confirmação da retirada.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora em que o pedido foi registrado.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do pedido.";
            }, {
                readonly fieldId: "completedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que o pedido foi concluído na loja (retirada e pagamento realizados).";
            }, {
                readonly fieldId: "cancelledAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que o pedido foi cancelado.";
            }, {
                readonly fieldId: "cancellationReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo informado no cancelamento do pedido.";
            }];
            readonly statusEnum: readonly ["registered", "completed", "cancelled"];
            readonly invariants: readonly ["status must be 'registered', 'completed', or 'cancelled'", "an order must have at least one OrderItem", "when status is 'completed', completedAt must be set", "when status is 'cancelled', cancelledAt and cancellationReason must be set", "completedAt and cancelledAt are mutually exclusive", "order cannot be completed or cancelled if it has no items", "updatedAt must be greater than or equal to createdAt"];
            readonly valueObjects: readonly [{
                readonly name: "OrderItem";
                readonly fields: readonly [{
                    readonly fieldId: "orderItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do item do pedido";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao pedido de retirada ao qual este item pertence";
                }, {
                    readonly fieldId: "productId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao produto do catálogo solicitado pelo cliente";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade do produto solicitada pelo cliente";
                }, {
                    readonly fieldId: "unitPrice";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço unitário do produto registrado no momento do pedido para cálculo do total a pagar presencialmente";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do item do pedido";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do item do pedido";
                }];
                readonly collection: true;
            }];
        };
    };
    export default orderDomainEntity;
    export const pipeline: readonly [{
        readonly id: "order__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/petShop/layer_3_domain/entities/order.ts";
        readonly defPath: "_102049_/l1/petShop/layer_3_domain/entities/order.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/product.defs" {
    export const productDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Product";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Product";
            readonly fields: readonly [{
                readonly fieldId: "productId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do produto no catálogo.";
            }, {
                readonly fieldId: "name";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do produto exibido no catálogo e na página inicial.";
            }, {
                readonly fieldId: "description";
                readonly type: "text";
                readonly required: false;
                readonly description: "Descrição detalhada do produto para o cliente.";
            }, {
                readonly fieldId: "price";
                readonly type: "money";
                readonly required: true;
                readonly description: "Preço do produto cobrado na retirada presencial na loja.";
            }, {
                readonly fieldId: "imageUrl";
                readonly type: "string";
                readonly required: false;
                readonly description: "URL da imagem do produto armazenada no armazenamento de mídia da plataforma.";
            }, {
                readonly fieldId: "productCategoryId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência à categoria de produto à qual o produto pertence.";
            }, {
                readonly fieldId: "featured";
                readonly type: "boolean";
                readonly required: true;
                readonly description: "Indica se o produto deve ser exibido em destaque na página inicial.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação do produto no catálogo: ativo ou inativo.";
                readonly enum: readonly ["active", "inactive"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de cadastro do produto.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do produto.";
            }];
            readonly statusEnum: readonly ["active", "inactive"];
            readonly invariants: readonly ["status must be 'active' or 'inactive'", "price must be a non-negative monetary value", "only products with status 'active' are visible in the catalog", "only active products can be featured on the home page", "updatedAt must be greater than or equal to createdAt"];
            readonly valueObjects: readonly [];
        };
    };
    export default productDomainEntity;
    export const pipeline: readonly [{
        readonly id: "product__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/petShop/layer_3_domain/entities/product.ts";
        readonly defPath: "_102049_/l1/petShop/layer_3_domain/entities/product.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/service.defs" {
    export const serviceDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Service";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Service";
            readonly fields: readonly [{
                readonly fieldId: "serviceId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do serviço oferecido.";
            }, {
                readonly fieldId: "name";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do serviço oferecido, como banho e tosa.";
            }, {
                readonly fieldId: "description";
                readonly type: "text";
                readonly required: true;
                readonly description: "Descrição detalhada do serviço oferecido ao cliente.";
            }, {
                readonly fieldId: "estimatedDurationMinutes";
                readonly type: "number";
                readonly required: true;
                readonly description: "Duração estimada do serviço em minutos, usada para cálculo de horários disponíveis.";
            }, {
                readonly fieldId: "price";
                readonly type: "money";
                readonly required: true;
                readonly description: "Preço do serviço, cobrado presencialmente na loja após a execução.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estado de ativação do serviço; apenas serviços ativos aparecem na listagem para clientes.";
                readonly enum: readonly ["active", "inactive"];
            }, {
                readonly fieldId: "deactivatedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que o serviço foi desativado; desativar não cancela agendamentos já confirmados.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro do serviço.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro do serviço.";
            }];
            readonly statusEnum: readonly ["active", "inactive"];
            readonly invariants: readonly ["status must be 'active' or 'inactive'", "estimatedDurationMinutes must be a positive number", "price must be a non-negative monetary value", "only services with status 'active' are listed for customers", "deactivating a service does not cancel already confirmed bookings", "when status is 'inactive', deactivatedAt must be set", "when status is 'active', deactivatedAt must be null", "updatedAt must be greater than or equal to createdAt"];
            readonly valueObjects: readonly [];
        };
    };
    export default serviceDomainEntity;
    export const pipeline: readonly [{
        readonly id: "service__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/petShop/layer_3_domain/entities/service.ts";
        readonly defPath: "_102049_/l1/petShop/layer_3_domain/entities/service.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/serviceBooking.defs" {
    export const serviceBookingDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "ServiceBooking";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "ServiceBooking";
            readonly fields: readonly [{
                readonly fieldId: "serviceBookingId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do agendamento de serviço.";
            }, {
                readonly fieldId: "serviceId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao serviço agendado pelo cliente.";
            }, {
                readonly fieldId: "operatorId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao operador atribuído ao agendamento, disponível no turno correspondente.";
            }, {
                readonly fieldId: "shiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao turno em que o agendamento foi alocado, determinado pela disponibilidade de operadores.";
            }, {
                readonly fieldId: "customerName";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do cliente que realizou o agendamento.";
            }, {
                readonly fieldId: "customerPhone";
                readonly type: "string";
                readonly required: true;
                readonly description: "Telefone de contato do cliente para o agendamento.";
            }, {
                readonly fieldId: "bookingDate";
                readonly type: "date";
                readonly required: true;
                readonly description: "Data do agendamento do serviço, dentro do horário de funcionamento (segunda a sábado, 09:00 às 18:00).";
            }, {
                readonly fieldId: "bookingTime";
                readonly type: "string";
                readonly required: true;
                readonly description: "Horário do agendamento, dentro do intervalo de funcionamento da loja.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação atual do agendamento no ciclo de execução.";
                readonly enum: readonly ["confirmed", "inProgress", "completed", "cancelled"];
            }, {
                readonly fieldId: "notes";
                readonly type: "text";
                readonly required: false;
                readonly description: "Observações adicionais sobre o agendamento informadas pelo cliente ou operador.";
            }, {
                readonly fieldId: "completedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que o operador atribuído marcou o serviço como concluído.";
            }, {
                readonly fieldId: "cancelledAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que o agendamento foi cancelado.";
            }, {
                readonly fieldId: "cancelReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo do cancelamento do agendamento.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do agendamento.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do agendamento.";
            }];
            readonly statusEnum: readonly ["confirmed", "inProgress", "completed", "cancelled"];
            readonly invariants: readonly ["status must be 'confirmed', 'inProgress', 'completed', or 'cancelled'", "bookingDate must be between Monday and Saturday", "bookingTime must be within store operating hours (09:00 to 18:00)", "operatorId must reference an operator allocated to the shift identified by shiftId", "when status is 'completed', completedAt must be set", "when status is 'cancelled', cancelledAt and cancelReason must be set", "completedAt and cancelledAt are mutually exclusive", "status transitions must follow: confirmed -> inProgress -> completed, or confirmed/inProgress -> cancelled", "updatedAt must be greater than or equal to createdAt"];
            readonly valueObjects: readonly [];
        };
    };
    export default serviceBookingDomainEntity;
    export const pipeline: readonly [{
        readonly id: "serviceBooking__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/petShop/layer_3_domain/entities/serviceBooking.ts";
        readonly defPath: "_102049_/l1/petShop/layer_3_domain/entities/serviceBooking.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/shiftAssignment.defs" {
    export const shiftAssignmentDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "ShiftAssignment";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "ShiftAssignment";
            readonly fields: readonly [{
                readonly fieldId: "shiftAssignmentId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único da alocação de operador em turno.";
            }, {
                readonly fieldId: "operatorId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao operador alocado neste turno.";
            }, {
                readonly fieldId: "shiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao turno de trabalho ao qual o operador está alocado.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora em que a alocação foi criada.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização da alocação.";
            }];
            readonly statusEnum: readonly [];
            readonly invariants: readonly ["operatorId must reference an active operator", "an operator cannot be assigned to the same shift more than once", "updatedAt must be greater than or equal to createdAt"];
            readonly valueObjects: readonly [];
        };
    };
    export default shiftAssignmentDomainEntity;
    export const pipeline: readonly [{
        readonly id: "shiftAssignment__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/petShop/layer_3_domain/entities/shiftAssignment.ts";
        readonly defPath: "_102049_/l1/petShop/layer_3_domain/entities/shiftAssignment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l2/designSystem" {
    import { IDesignSystemTokens } from '_102029_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102049_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102049_/l2/petShop/web/contracts/adoptionGallery.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "adoptionGallery__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/adoptionGallery.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/adoptionGallery.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/adoptionGallery" {
    export interface PetShopBrowseAdoptablePetsInput {
    }
    export interface PetShopBrowseAdoptablePetsOutputItem {
        adoptablePetId: string;
        name: string;
        age: number;
        description: string;
        photoUrl: string;
    }
    export interface PetShopBrowseAdoptablePetsOutput {
        items: PetShopBrowseAdoptablePetsOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopViewAdoptablePetDetailsInput {
        adoptablePetId: string;
    }
    export interface PetShopViewAdoptablePetDetailsOutputItem {
        name: string;
        age: number;
        description: string;
        photoUrl: string;
        status: "available" | "unavailable";
    }
    export type PetShopViewAdoptablePetDetailsOutput = PetShopViewAdoptablePetDetailsOutputItem;
    export interface PetShopExpressAdoptionInterestInput {
        adoptablePetId: string;
        customerName: string;
        customerEmail: string;
        customerPhone?: string;
    }
    export interface PetShopExpressAdoptionInterestOutput {
        adoptionInterestId: string;
        status: "registered" | "completed" | "cancelled";
        adoptablePetId: string;
        customerName: string;
        createdAt: string;
    }
}
declare module "_102049_/l2/petShop/web/contracts/adoptionGallery.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/homePage.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: any[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "homePage__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/homePage.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/homePage.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/homePage" {
    export interface PetShopBrowseHomePageInput {
    }
    export interface PetShopBrowseHomePageOutputItem {
        productId: string;
        name: string;
        description: string;
        price: number;
        imageUrl: string;
        productCategoryId: string;
        featured: boolean;
        status: "active" | "inactive";
    }
    export interface PetShopBrowseHomePageOutput {
        items: PetShopBrowseHomePageOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
}
declare module "_102049_/l2/petShop/web/contracts/homePage.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/operatorManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "operatorManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/operatorManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/operatorManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/operatorManagement" {
    export interface PetShopBrowseOperatorsInput {
        activeFilter?: boolean;
    }
    export interface PetShopBrowseOperatorsOutputItem {
        operatorId: string;
        name: string;
        email: string;
        phone: string;
        active: boolean;
        createdAt: string;
        updatedAt: string;
    }
    export interface PetShopBrowseOperatorsOutput {
        items: PetShopBrowseOperatorsOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopCreateOperatorInput {
        name: string;
        email?: string;
        phone?: string;
        active: boolean;
    }
    export interface PetShopCreateOperatorOutput {
        operatorId: string;
        name: string;
        email: string;
        phone: string;
        active: boolean;
        createdAt: string;
    }
    export interface PetShopUpdateOperatorInput {
        operatorId: string;
        name: string;
        email?: string;
        phone?: string;
        active: boolean;
    }
    export interface PetShopUpdateOperatorOutput {
        operatorId: string;
        name: string;
        email: string;
        phone: string;
        active: boolean;
        updatedAt: string;
    }
}
declare module "_102049_/l2/petShop/web/contracts/operatorManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/operatorSchedule.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "operatorSchedule__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/operatorSchedule.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/operatorSchedule.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/operatorSchedule" {
    export interface PetShopViewOperatorScheduleInput {
    }
    export interface PetShopViewOperatorScheduleOutputItem {
        serviceBookingId: string;
        serviceId: string;
        customerName: string;
        customerPhone: string;
        bookingDate: string;
        bookingTime: string;
        status: "confirmed" | "inProgress" | "completed" | "cancelled";
        notes: string;
    }
    export interface PetShopViewOperatorScheduleOutput {
        items: PetShopViewOperatorScheduleOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopViewServiceBookingDetailsInput {
        serviceBookingId: string;
    }
    export interface PetShopViewServiceBookingDetailsOutputItem {
        serviceBookingId: string;
        serviceId: string;
        operatorId: string;
        shiftId: string;
        customerName: string;
        customerPhone: string;
        bookingDate: string;
        bookingTime: string;
        status: "confirmed" | "inProgress" | "completed" | "cancelled";
        notes: string;
        completedAt: string;
        cancelledAt: string;
        cancelReason: string;
        createdAt: string;
        updatedAt: string;
    }
    export type PetShopViewServiceBookingDetailsOutput = PetShopViewServiceBookingDetailsOutputItem;
}
declare module "_102049_/l2/petShop/web/contracts/operatorSchedule.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/petManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
            source: string;
            presentation: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "petManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/petManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/petManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/petManagement" {
    export interface PetShopBrowseAdoptablePetsAdminInput {
        statusFilter?: "available" | "unavailable";
    }
    export interface PetShopBrowseAdoptablePetsAdminOutputItem {
        adoptablePetId: string;
        name: string;
        age: number;
        description: string;
        photoUrl: string;
        status: "available" | "unavailable";
        createdAt: string;
        updatedAt: string;
    }
    export interface PetShopBrowseAdoptablePetsAdminOutput {
        items: PetShopBrowseAdoptablePetsAdminOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopCreateAdoptablePetInput {
        name: string;
        age: number;
        description: string;
        photoUrl: string;
    }
    export interface PetShopCreateAdoptablePetOutput {
        adoptablePetId: string;
        name: string;
        age: number;
        description: string;
        photoUrl: string;
        status: "available" | "unavailable";
        createdAt: string;
    }
    export interface PetShopUpdateAdoptablePetInput {
        adoptablePetId: string;
        name: string;
        age: number;
        description: string;
        photoUrl: string;
        status: "available" | "unavailable";
    }
    export interface PetShopUpdateAdoptablePetOutput {
        adoptablePetId: string;
        name: string;
        age: number;
        description: string;
        photoUrl: string;
        status: "available" | "unavailable";
        updatedAt: string;
    }
}
declare module "_102049_/l2/petShop/web/contracts/petManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/productCatalog.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "productCatalog__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/productCatalog.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/productCatalog.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/productCatalog" {
    export interface PetShopBrowseProductCatalogInput {
        searchName?: string;
        productCategoryId?: string;
    }
    export interface PetShopBrowseProductCatalogOutputItem {
        productId: string;
        name: string;
        description: string;
        price: number;
        imageUrl: string;
        productCategoryId: string;
        featured: boolean;
    }
    export interface PetShopBrowseProductCatalogOutput {
        items: PetShopBrowseProductCatalogOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopViewProductDetailsInput {
        productId: string;
    }
    export interface PetShopViewProductDetailsOutputItem {
        productId: string;
        name: string;
        description: string;
        price: number;
        imageUrl: string;
        productCategoryId: string;
        featured: boolean;
        status: "active" | "inactive";
    }
    export type PetShopViewProductDetailsOutput = PetShopViewProductDetailsOutputItem;
    export interface PetShopPlaceStorePickupOrderInput {
        customerName: string;
        customerPhone?: string;
    }
    export interface PetShopPlaceStorePickupOrderOutput {
        orderId: string;
        status: "registered" | "completed" | "cancelled";
        customerName: string;
        customerPhone: string;
        createdAt: string;
    }
}
declare module "_102049_/l2/petShop/web/contracts/productCatalog.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/productManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
            source: string;
            presentation: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "productManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/productManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/productManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/productManagement" {
    export interface PetShopBrowseProductsInput {
        searchName?: string;
        filterStatus?: "active" | "inactive";
        filterProductCategoryId?: string;
        filterFeatured?: boolean;
    }
    export interface PetShopBrowseProductsOutputItem {
        productId: string;
        name: string;
        price: number;
        imageUrl: string;
        productCategoryId: string;
        featured: boolean;
        status: "active" | "inactive";
        createdAt: string;
        updatedAt: string;
    }
    export interface PetShopBrowseProductsOutput {
        items: PetShopBrowseProductsOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopCreateProductInput {
        name: string;
        description?: string;
        price: number;
        imageUrl?: string;
        productCategoryId: string;
        featured: boolean;
    }
    export interface PetShopCreateProductOutput {
        productId: string;
        name: string;
        price: number;
        productCategoryId: string;
        featured: boolean;
        status: "active" | "inactive";
        createdAt: string;
    }
    export interface PetShopUpdateProductInput {
        productId: string;
        name: string;
        description?: string;
        price: number;
        imageUrl?: string;
        productCategoryId: string;
        featured: boolean;
        status: "active" | "inactive";
    }
    export interface PetShopUpdateProductOutput {
        productId: string;
        name: string;
        description: string;
        price: number;
        imageUrl: string;
        productCategoryId: string;
        featured: boolean;
        status: "active" | "inactive";
        updatedAt: string;
    }
}
declare module "_102049_/l2/petShop/web/contracts/productManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/schedulingCapacity.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "schedulingCapacity__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/schedulingCapacity.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/schedulingCapacity.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/schedulingCapacity" {
    export interface PetShopAssignOperatorToShiftInput {
        operatorId: string;
        shiftId: string;
    }
    export interface PetShopAssignOperatorToShiftOutput {
        shiftAssignmentId: string;
        operatorId: string;
        shiftId: string;
        createdAt: string;
    }
    export interface PetShopReviewSchedulingCapacityInput {
        shiftId?: string;
    }
    export interface PetShopReviewSchedulingCapacityOutputItem {
        shiftAssignmentId: string;
        operatorId: string;
        shiftId: string;
        createdAt: string;
        startTime: string;
        endTime: string;
        name: string;
    }
    export interface PetShopReviewSchedulingCapacityOutput {
        items: PetShopReviewSchedulingCapacityOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
}
declare module "_102049_/l2/petShop/web/contracts/schedulingCapacity.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/serviceBooking.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "serviceBooking__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/serviceBooking.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/serviceBooking.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/serviceBooking" {
    export interface PetShopBrowseServiceCatalogInput {
    }
    export interface PetShopBrowseServiceCatalogOutputItem {
        serviceId: string;
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
    }
    export interface PetShopBrowseServiceCatalogOutput {
        items: PetShopBrowseServiceCatalogOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopCreateServiceBookingInput {
        serviceId: string;
        customerName: string;
        customerPhone: string;
        bookingDate: string;
        bookingTime: string;
        notes?: string;
    }
    export interface PetShopCreateServiceBookingOutput {
        serviceBookingId: string;
        serviceId: string;
        operatorId: string;
        shiftId: string;
        bookingDate: string;
        bookingTime: string;
        status: "confirmed" | "inProgress" | "completed" | "cancelled";
        customerName: string;
    }
}
declare module "_102049_/l2/petShop/web/contracts/serviceBooking.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/serviceExecution.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "serviceExecution__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/serviceExecution.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/serviceExecution.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/serviceExecution" {
    export interface PetShopStartServiceExecutionInput {
        serviceBookingId: string;
    }
    export interface PetShopStartServiceExecutionOutput {
        serviceBookingId: string;
        status: "confirmed" | "inProgress" | "completed" | "cancelled";
        updatedAt: string;
    }
    export interface PetShopCompleteServiceExecutionInput {
        serviceBookingId: string;
    }
    export interface PetShopCompleteServiceExecutionOutput {
        serviceBookingId: string;
        status: "confirmed" | "inProgress" | "completed" | "cancelled";
        completedAt: string;
    }
}
declare module "_102049_/l2/petShop/web/contracts/serviceExecution.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/serviceManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
            source: string;
            presentation: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "serviceManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/serviceManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/serviceManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/serviceManagement" {
    export interface PetShopBrowseServicesInput {
        statusFilter?: "active" | "inactive";
    }
    export interface PetShopBrowseServicesOutputItem {
        serviceId: string;
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
        status: "active" | "inactive";
        deactivatedAt: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface PetShopBrowseServicesOutput {
        items: PetShopBrowseServicesOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopCreateServiceInput {
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
    }
    export interface PetShopCreateServiceOutput {
        serviceId: string;
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
        status: "active" | "inactive";
        createdAt: string;
    }
    export interface PetShopUpdateServiceInput {
        serviceId: string;
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
        status: "active" | "inactive";
    }
    export interface PetShopUpdateServiceOutput {
        serviceId: string;
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
        status: "active" | "inactive";
        deactivatedAt: string;
        updatedAt: string;
    }
}
declare module "_102049_/l2/petShop/web/contracts/serviceManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/shiftManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "shiftManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/shiftManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/shiftManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/shiftManagement" {
    export interface PetShopBrowseShiftsInput {
        activeFilter?: boolean;
    }
    export interface PetShopBrowseShiftsOutputItem {
        shiftId: string;
        name: string;
        startTime: string;
        endTime: string;
        monday: boolean;
        tuesday: boolean;
        wednesday: boolean;
        thursday: boolean;
        friday: boolean;
        saturday: boolean;
        sunday: boolean;
        active: boolean;
        createdAt: string;
        updatedAt: string;
    }
    export interface PetShopBrowseShiftsOutput {
        items: PetShopBrowseShiftsOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopCreateShiftInput {
        name: string;
        startTime: string;
        endTime: string;
        monday: boolean;
        tuesday: boolean;
        wednesday: boolean;
        thursday: boolean;
        friday: boolean;
        saturday: boolean;
        sunday: boolean;
        active: boolean;
    }
    export interface PetShopCreateShiftOutput {
        shiftId: string;
        name: string;
        startTime: string;
        endTime: string;
        monday: boolean;
        tuesday: boolean;
        wednesday: boolean;
        thursday: boolean;
        friday: boolean;
        saturday: boolean;
        sunday: boolean;
        active: boolean;
        createdAt: string;
    }
    export interface PetShopUpdateShiftInput {
        shiftId: string;
        name: string;
        startTime: string;
        endTime: string;
        monday: boolean;
        tuesday: boolean;
        wednesday: boolean;
        thursday: boolean;
        friday: boolean;
        saturday: boolean;
        sunday: boolean;
        active: boolean;
    }
    export interface PetShopUpdateShiftOutput {
        shiftId: string;
        name: string;
        startTime: string;
        endTime: string;
        monday: boolean;
        tuesday: boolean;
        wednesday: boolean;
        thursday: boolean;
        friday: boolean;
        saturday: boolean;
        sunday: boolean;
        active: boolean;
    }
}
declare module "_102049_/l2/petShop/web/contracts/shiftManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/desktop/page11/adoptionGallery.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "adoptionGallery__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/adoptionGallery.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/adoptionGallery.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/adoptionGallery.defs.ts", "_102049_/l2/petShop/web/shared/adoptionGallery.ts", "_102049_/l2/petShop/web/contracts/adoptionGallery.defs.ts", "_102049_/l2/petShop/web/contracts/adoptionGallery.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["adoptionGallery__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/adoptionGallery" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseAdoptablePetsOutput, PetShopViewAdoptablePetDetailsOutput, PetShopExpressAdoptionInterestOutput } from "_102049_/l2/petShop/web/contracts/adoptionGallery";
    const message_pt: {
        "adoptionGallery.section.title": string;
        "adoptionGallery.browse.title": string;
        "adoptionGallery.browse.empty": string;
        "adoptionGallery.details.title": string;
        "adoptionGallery.details.empty": string;
        "adoptionGallery.interestForm.title": string;
        "adoptionGallery.interestForm.empty": string;
        "adoptionGallery.summary.title": string;
        "adoptionGallery.summary.empty": string;
        "adoptionGallery.field.photoUrl": string;
        "adoptionGallery.field.name": string;
        "adoptionGallery.field.age": string;
        "adoptionGallery.field.description": string;
        "adoptionGallery.field.status": string;
        "adoptionGallery.field.adoptablePetId": string;
        "adoptionGallery.field.customerName": string;
        "adoptionGallery.field.customerEmail": string;
        "adoptionGallery.field.customerPhone": string;
        "adoptionGallery.field.adoptionInterestId": string;
        "adoptionGallery.field.interestStatus": string;
        "adoptionGallery.field.createdAt": string;
        "adoptionGallery.action.viewDetails": string;
        "adoptionGallery.action.expressInterest": string;
        "adoptionGallery.action.submitInterest": string;
        "action.expressAdoptionInterest.success": string;
        "action.expressAdoptionInterest.error": string;
        "org.browse.adoptable.pets.title": string;
        "org.view.pet.details.title": string;
        "org.express.interest.title": string;
        "org.adoption.summary.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopAdoptionGalleryBase extends CollabLitElement {
        status: string;
        browseAdoptablePetsState: "idle" | "loading" | "success" | "error";
        browseAdoptablePetsData: PetShopBrowseAdoptablePetsOutput;
        viewAdoptablePetDetailsState: "idle" | "loading" | "success" | "error";
        viewAdoptablePetDetailsAdoptablePetId: string;
        viewAdoptablePetDetailsData: PetShopViewAdoptablePetDetailsOutput | null;
        expressAdoptionInterestState: "idle" | "loading" | "success" | "error";
        expressAdoptionInterestAdoptablePetId: string;
        expressAdoptionInterestCustomerName: string;
        expressAdoptionInterestCustomerEmail: string;
        expressAdoptionInterestCustomerPhone: string;
        expressAdoptionInterestOutput: PetShopExpressAdoptionInterestOutput | null;
        expressAdoptionInterestError: string;
        protected get msg(): MessageType;
        private parseRouteParam;
        loadBrowseAdoptablePets(): Promise<void>;
        handleBrowseAdoptablePetsClick(_e: Event): void;
        loadViewAdoptablePetDetails(): Promise<void>;
        handleViewAdoptablePetDetailsClick(_e: Event): void;
        expressAdoptionInterest(): Promise<void>;
        handleExpressAdoptionInterestClick(e: Event): void;
        setViewAdoptablePetDetailsAdoptablePetId(value: string): void;
        handleViewAdoptablePetDetailsAdoptablePetIdChange(e: Event): void;
        setExpressAdoptionInterestAdoptablePetId(value: string): void;
        handleExpressAdoptionInterestAdoptablePetIdChange(e: Event): void;
        setExpressAdoptionInterestCustomerName(value: string): void;
        handleExpressAdoptionInterestCustomerNameChange(e: Event): void;
        setExpressAdoptionInterestCustomerEmail(value: string): void;
        handleExpressAdoptionInterestCustomerEmailChange(e: Event): void;
        setExpressAdoptionInterestCustomerPhone(value: string): void;
        handleExpressAdoptionInterestCustomerPhoneChange(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/adoptionGallery" {
    import { PetShopAdoptionGalleryBase } from "_102049_/l2/petShop/web/shared/adoptionGallery";
    export class PetShopDesktopPage11AdoptionGalleryPage extends PetShopAdoptionGalleryBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/homePage.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            inputType?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                            inputType?: undefined;
                        })[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            source: string;
                            stateKey: string;
                            inputType?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            source: string;
                            stateKey: string;
                            inputType?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    })[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            inputType?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            inputType?: undefined;
                            stateKey?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                            inputType?: undefined;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: any[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "homePage__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/homePage.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/homePage.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/homePage.defs.ts", "_102049_/l2/petShop/web/shared/homePage.ts", "_102049_/l2/petShop/web/contracts/homePage.defs.ts", "_102049_/l2/petShop/web/contracts/homePage.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["homePage__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/homePage" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseHomePageOutput } from "_102049_/l2/petShop/web/contracts/homePage";
    const message_pt: {
        "homePage.title": string;
        "homePage.section.featuredProducts": string;
        "homePage.section.services": string;
        "homePage.section.adoptablePets": string;
        "homePage.productList.title": string;
        "homePage.productList.empty": string;
        "homePage.productDetail.title": string;
        "homePage.productDetail.empty": string;
        "homePage.productDetail.imageUrl": string;
        "homePage.productDetail.name": string;
        "homePage.productDetail.description": string;
        "homePage.productDetail.price": string;
        "homePage.product.productId": string;
        "homePage.product.name": string;
        "homePage.product.description": string;
        "homePage.product.price": string;
        "homePage.product.imageUrl": string;
        "homePage.product.featured": string;
        "homePage.product.status": string;
        "homePage.servicesList.title": string;
        "homePage.servicesList.empty": string;
        "homePage.service.serviceId": string;
        "homePage.service.name": string;
        "homePage.service.description": string;
        "homePage.service.estimatedDurationMinutes": string;
        "homePage.service.price": string;
        "homePage.service.status": string;
        "homePage.petsGallery.title": string;
        "homePage.petsGallery.empty": string;
        "homePage.pet.adoptablePetId": string;
        "homePage.pet.name": string;
        "homePage.pet.age": string;
        "homePage.pet.description": string;
        "homePage.pet.photoUrl": string;
        "homePage.pet.status": string;
        "homePage.action.browseHomePage": string;
        "homePage.action.browseHomePage.success": string;
        "homePage.action.browseHomePage.error": string;
        "org.featured.products.title": string;
        "org.services.title": string;
        "org.adoptable.pets.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopHomePageBase extends CollabLitElement {
        status: string;
        browseHomePageState: "idle" | "loading" | "success" | "error";
        browseHomePageData: PetShopBrowseHomePageOutput;
        protected get msg(): MessageType;
        loadBrowseHomePage(): Promise<void>;
        handleBrowseHomePageClick(_event: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/homePage" {
    import { PetShopHomePageBase } from "_102049_/l2/petShop/web/shared/homePage";
    export class PetShopDesktopPage11HomePagePage extends PetShopHomePageBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/operatorManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "operatorManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/operatorManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/operatorManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/operatorManagement.defs.ts", "_102049_/l2/petShop/web/shared/operatorManagement.ts", "_102049_/l2/petShop/web/contracts/operatorManagement.defs.ts", "_102049_/l2/petShop/web/contracts/operatorManagement.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["operatorManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/operatorManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseOperatorsOutput, PetShopCreateOperatorOutput, PetShopUpdateOperatorOutput } from "_102049_/l2/petShop/web/contracts/operatorManagement";
    const message_pt: {
        "operatorManagement.browse.title": string;
        "operatorManagement.browse.empty": string;
        "operatorManagement.create.title": string;
        "operatorManagement.create.empty": string;
        "operatorManagement.update.title": string;
        "operatorManagement.update.empty": string;
        "operatorManagement.field.name": string;
        "operatorManagement.field.email": string;
        "operatorManagement.field.phone": string;
        "operatorManagement.field.active": string;
        "operatorManagement.field.updatedAt": string;
        "operatorManagement.field.operatorId": string;
        "operatorManagement.filter.active": string;
        "operatorManagement.action.create": string;
        "operatorManagement.action.create.submit": string;
        "operatorManagement.action.update": string;
        "operatorManagement.action.update.submit": string;
        "action.createOperator.success": string;
        "action.createOperator.error": string;
        "action.updateOperator.success": string;
        "action.updateOperator.error": string;
        "sec.operator.management.title": string;
        "org.browse.operators.title": string;
        "org.create.operator.title": string;
        "org.update.operator.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopOperatorManagementBase extends CollabLitElement {
        status: string;
        browseOperatorsState: 'idle' | 'loading' | 'success' | 'error';
        browseOperatorsActiveFilter: string;
        browseOperatorsData: PetShopBrowseOperatorsOutput;
        createOperatorState: 'idle' | 'loading' | 'success' | 'error';
        createOperatorName: string;
        createOperatorEmail: string;
        createOperatorPhone: string;
        createOperatorActive: string;
        createOperatorOutput: PetShopCreateOperatorOutput | null;
        createOperatorError: string;
        updateOperatorState: 'idle' | 'loading' | 'success' | 'error';
        updateOperatorOperatorId: string;
        updateOperatorName: string;
        updateOperatorEmail: string;
        updateOperatorPhone: string;
        updateOperatorActive: string;
        updateOperatorOutput: PetShopUpdateOperatorOutput | null;
        updateOperatorError: string;
        protected get msg(): MessageType;
        private subscribedKeys;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private parseRouteParams;
        loadBrowseOperators(): Promise<void>;
        handleBrowseOperatorsClick(_e: Event): void;
        createOperator(): Promise<void>;
        handleCreateOperatorClick(e: Event): void;
        updateOperator(): Promise<void>;
        handleUpdateOperatorClick(e: Event): void;
        setBrowseOperatorsActiveFilter(value: string): void;
        handleBrowseOperatorsActiveFilterChange(e: Event): void;
        setCreateOperatorName(value: string): void;
        handleCreateOperatorNameChange(e: Event): void;
        setCreateOperatorEmail(value: string): void;
        handleCreateOperatorEmailChange(e: Event): void;
        setCreateOperatorPhone(value: string): void;
        handleCreateOperatorPhoneChange(e: Event): void;
        setCreateOperatorActive(value: string): void;
        handleCreateOperatorActiveChange(e: Event): void;
        setUpdateOperatorOperatorId(value: string): void;
        handleUpdateOperatorOperatorIdChange(e: Event): void;
        setUpdateOperatorName(value: string): void;
        handleUpdateOperatorNameChange(e: Event): void;
        setUpdateOperatorEmail(value: string): void;
        handleUpdateOperatorEmailChange(e: Event): void;
        setUpdateOperatorPhone(value: string): void;
        handleUpdateOperatorPhoneChange(e: Event): void;
        setUpdateOperatorActive(value: string): void;
        handleUpdateOperatorActiveChange(e: Event): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/operatorManagement" {
    import { PetShopOperatorManagementBase } from "_102049_/l2/petShop/web/shared/operatorManagement";
    export class PetShopDesktopPage11OperatorManagementPage extends PetShopOperatorManagementBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/operatorSchedule.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "operatorSchedule__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/operatorSchedule.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/operatorSchedule.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/operatorSchedule.defs.ts", "_102049_/l2/petShop/web/shared/operatorSchedule.ts", "_102049_/l2/petShop/web/contracts/operatorSchedule.defs.ts", "_102049_/l2/petShop/web/contracts/operatorSchedule.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["operatorSchedule__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/operatorSchedule" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopViewOperatorScheduleOutput, PetShopViewServiceBookingDetailsOutput } from "_102049_/l2/petShop/web/contracts/operatorSchedule";
    const message_pt: {
        "page.title": string;
        "section.schedule.title": string;
        "section.payment.title": string;
        "organism.metrics.title": string;
        "organism.metrics.empty": string;
        "metric.confirmed": string;
        "metric.inProgress": string;
        "metric.completed": string;
        "metric.total": string;
        "organism.list.title": string;
        "organism.list.empty": string;
        "organism.details.title": string;
        "organism.details.empty": string;
        "organism.payment.title": string;
        "organism.payment.empty": string;
        "column.customerName": string;
        "column.customerPhone": string;
        "column.bookingDate": string;
        "column.bookingTime": string;
        "column.status": string;
        "column.notes": string;
        "filter.status": string;
        "filter.bookingDate": string;
        "field.serviceBookingId": string;
        "field.serviceId": string;
        "field.customerName": string;
        "field.customerPhone": string;
        "field.bookingDate": string;
        "field.bookingTime": string;
        "field.status": string;
        "field.notes": string;
        "field.completedAt": string;
        "field.cancelledAt": string;
        "field.cancelReason": string;
        "field.createdAt": string;
        "field.updatedAt": string;
        "field.paymentInfo": string;
        "field.paymentMethod": string;
        "action.viewDetails": string;
        "action.viewOperatorSchedule.success": string;
        "action.viewOperatorSchedule.error": string;
        "action.viewServiceBookingDetails.success": string;
        "action.viewServiceBookingDetails.error": string;
        "scheduleMetrics.title": string;
        "scheduleList.title": string;
        "bookingDetails.title": string;
        "paymentContext.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopOperatorScheduleBase extends CollabLitElement {
        status: string;
        viewOperatorScheduleState: "idle" | "loading" | "success" | "error";
        viewOperatorScheduleData: PetShopViewOperatorScheduleOutput;
        viewServiceBookingDetailsState: "idle" | "loading" | "success" | "error";
        viewServiceBookingDetailsServiceBookingId: string;
        viewServiceBookingDetailsData: PetShopViewServiceBookingDetailsOutput | null;
        protected get msg(): MessageType;
        private parseRouteParams;
        loadViewOperatorSchedule(): Promise<void>;
        handleViewOperatorScheduleClick(): void;
        loadViewServiceBookingDetails(): Promise<void>;
        handleViewServiceBookingDetailsClick(): void;
        setViewServiceBookingDetailsServiceBookingId(value: string): void;
        handleViewServiceBookingDetailsServiceBookingIdChange(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/operatorSchedule" {
    import { type TemplateResult } from 'lit';
    import { PetShopOperatorScheduleBase } from "_102049_/l2/petShop/web/shared/operatorSchedule";
    export class PetShopDesktopPage11OperatorSchedulePage extends PetShopOperatorScheduleBase {
        render(): TemplateResult;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/petManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "petManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/petManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/petManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/petManagement.defs.ts", "_102049_/l2/petShop/web/shared/petManagement.ts", "_102049_/l2/petShop/web/contracts/petManagement.defs.ts", "_102049_/l2/petShop/web/contracts/petManagement.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["petManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/petManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseAdoptablePetsAdminOutput, PetShopCreateAdoptablePetOutput, PetShopUpdateAdoptablePetOutput } from "_102049_/l2/petShop/web/contracts/petManagement";
    const message_pt: {
        "petManagement.section.title": string;
        "petManagement.list.title": string;
        "petManagement.list.empty": string;
        "petManagement.create.title": string;
        "petManagement.create.empty": string;
        "petManagement.update.title": string;
        "petManagement.update.empty": string;
        "petManagement.summary.title": string;
        "petManagement.summary.sectionTitle": string;
        "petManagement.summary.empty": string;
        "petManagement.field.name": string;
        "petManagement.field.age": string;
        "petManagement.field.description": string;
        "petManagement.field.photoUrl": string;
        "petManagement.field.status": string;
        "petManagement.field.adoptablePetId": string;
        "petManagement.field.createdAt": string;
        "petManagement.field.updatedAt": string;
        "petManagement.filter.statusFilter": string;
        "petManagement.action.create": string;
        "petManagement.action.create.submit": string;
        "petManagement.action.update": string;
        "petManagement.action.update.submit": string;
        "action.createAdoptablePet.success": string;
        "action.createAdoptablePet.error": string;
        "action.updateAdoptablePet.success": string;
        "action.updateAdoptablePet.error": string;
        "org.browse.pets.title": string;
        "org.create.pet.title": string;
        "org.update.pet.title": string;
        "org.pet.summary.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopPetManagementBase extends CollabLitElement {
        status: string;
        browseAdoptablePetsAdminState: 'idle' | 'loading' | 'success' | 'error';
        browseAdoptablePetsAdminStatusFilter: "available" | "unavailable" | '';
        browseAdoptablePetsAdminData: PetShopBrowseAdoptablePetsAdminOutput;
        createAdoptablePetState: 'idle' | 'loading' | 'success' | 'error';
        createAdoptablePetName: string;
        createAdoptablePetAge: number | '';
        createAdoptablePetDescription: string;
        createAdoptablePetPhotoUrl: string;
        createAdoptablePetOutput: PetShopCreateAdoptablePetOutput | null;
        createAdoptablePetError: string;
        updateAdoptablePetState: 'idle' | 'loading' | 'success' | 'error';
        updateAdoptablePetAdoptablePetId: string;
        updateAdoptablePetName: string;
        updateAdoptablePetAge: number | '';
        updateAdoptablePetDescription: string;
        updateAdoptablePetPhotoUrl: string;
        updateAdoptablePetStatus: "available" | "unavailable" | '';
        updateAdoptablePetOutput: PetShopUpdateAdoptablePetOutput | null;
        updateAdoptablePetError: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(stateKey: string, value: unknown): void;
        setBrowseAdoptablePetsAdminStatusFilter(value: "available" | "unavailable" | ''): void;
        handleBrowseAdoptablePetsAdminStatusFilterChange(event: Event): void;
        setCreateAdoptablePetName(value: string): void;
        handleCreateAdoptablePetNameChange(event: Event): void;
        setCreateAdoptablePetAge(value: number | ''): void;
        handleCreateAdoptablePetAgeChange(event: Event): void;
        setCreateAdoptablePetDescription(value: string): void;
        handleCreateAdoptablePetDescriptionChange(event: Event): void;
        setCreateAdoptablePetPhotoUrl(value: string): void;
        handleCreateAdoptablePetPhotoUrlChange(event: Event): void;
        setUpdateAdoptablePetAdoptablePetId(value: string): void;
        handleUpdateAdoptablePetAdoptablePetIdChange(event: Event): void;
        setUpdateAdoptablePetName(value: string): void;
        handleUpdateAdoptablePetNameChange(event: Event): void;
        setUpdateAdoptablePetAge(value: number | ''): void;
        handleUpdateAdoptablePetAgeChange(event: Event): void;
        setUpdateAdoptablePetDescription(value: string): void;
        handleUpdateAdoptablePetDescriptionChange(event: Event): void;
        setUpdateAdoptablePetPhotoUrl(value: string): void;
        handleUpdateAdoptablePetPhotoUrlChange(event: Event): void;
        setUpdateAdoptablePetStatus(value: "available" | "unavailable" | ''): void;
        handleUpdateAdoptablePetStatusChange(event: Event): void;
        loadBrowseAdoptablePetsAdmin(signal?: AbortSignal): Promise<boolean>;
        handleBrowseAdoptablePetsAdminClick(): void;
        createAdoptablePet(signal?: AbortSignal): Promise<boolean>;
        handleCreateAdoptablePetClick(): void;
        updateAdoptablePet(signal?: AbortSignal): Promise<boolean>;
        handleUpdateAdoptablePetClick(): void;
        private readTextValue;
        private readNumberValue;
        private createBrowseAdoptablePetsAdminDefault;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/petManagement" {
    import { PetShopPetManagementBase } from "_102049_/l2/petShop/web/shared/petManagement";
    export class PetShopDesktopPage11PetManagementPage extends PetShopPetManagementBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/productCatalog.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    order: number;
                    stateKey?: undefined;
                    action?: undefined;
                    submitAction?: undefined;
                } | {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                })[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            })[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        source?: undefined;
                        binding?: undefined;
                        action?: undefined;
                        submitAction?: undefined;
                        stateKey?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    })[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "productCatalog__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/productCatalog.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/productCatalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/productCatalog.defs.ts", "_102049_/l2/petShop/web/shared/productCatalog.ts", "_102049_/l2/petShop/web/contracts/productCatalog.defs.ts", "_102049_/l2/petShop/web/contracts/productCatalog.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["productCatalog__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/productCatalog" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseProductCatalogOutput, PetShopViewProductDetailsOutput, PetShopPlaceStorePickupOrderOutput } from "_102049_/l2/petShop/web/contracts/productCatalog";
    const message_pt: {
        "page.title": string;
        "section.catalog.title": string;
        "section.checkout.title": string;
        "organism.browse.title": string;
        "organism.details.title": string;
        "organism.cart.title": string;
        "organism.checkout.title": string;
        "organism.summary.title": string;
        "field.searchName": string;
        "field.productCategoryId": string;
        "field.productId": string;
        "field.name": string;
        "field.description": string;
        "field.price": string;
        "field.imageUrl": string;
        "field.featured": string;
        "field.status": string;
        "field.quantity": string;
        "field.unitPrice": string;
        "field.customerName": string;
        "field.customerPhone": string;
        "field.orderId": string;
        "field.createdAt": string;
        "column.imageUrl": string;
        "column.name": string;
        "column.price": string;
        "column.productCategoryId": string;
        "column.featured": string;
        "column.productId": string;
        "column.quantity": string;
        "column.unitPrice": string;
        "action.viewProductDetails": string;
        "action.placeStorePickupOrder": string;
        "empty.browse": string;
        "empty.details": string;
        "empty.cart": string;
        "empty.summary": string;
        "action.placeStorePickupOrder.success": string;
        "action.placeStorePickupOrder.error": string;
        "sec.catalog.title": string;
        "org.browse.catalog.title": string;
        "org.product.details.title": string;
        "org.cart.and.checkout.title": string;
        "org.order.result.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopProductCatalogBase extends CollabLitElement {
        status: string;
        browseProductCatalogState: "idle" | "loading" | "success" | "error";
        browseProductCatalogSearchName: string;
        browseProductCatalogProductCategoryId: string;
        browseProductCatalogData: PetShopBrowseProductCatalogOutput;
        viewProductDetailsState: "idle" | "loading" | "success" | "error";
        viewProductDetailsProductId: string;
        viewProductDetailsData: PetShopViewProductDetailsOutput | null;
        placeStorePickupOrderState: "idle" | "loading" | "success" | "error";
        placeStorePickupOrderCustomerName: string;
        placeStorePickupOrderCustomerPhone: string;
        placeStorePickupOrderOutput: PetShopPlaceStorePickupOrderOutput | null;
        placeStorePickupOrderError: string;
        private subscribedKeys;
        protected get msg(): MessageType;
        private parseRouteParams;
        setBrowseProductCatalogSearchName(value: string): void;
        handleBrowseProductCatalogSearchNameChange(e: Event): void;
        setBrowseProductCatalogProductCategoryId(value: string): void;
        handleBrowseProductCatalogProductCategoryIdChange(e: Event): void;
        setViewProductDetailsProductId(value: string): void;
        handleViewProductDetailsProductIdChange(e: Event): void;
        setPlaceStorePickupOrderCustomerName(value: string): void;
        handlePlaceStorePickupOrderCustomerNameChange(e: Event): void;
        setPlaceStorePickupOrderCustomerPhone(value: string): void;
        handlePlaceStorePickupOrderCustomerPhoneChange(e: Event): void;
        loadBrowseProductCatalog(): Promise<void>;
        handleBrowseProductCatalogClick(): void;
        loadViewProductDetails(): Promise<void>;
        handleViewProductDetailsClick(): void;
        placeStorePickupOrder(): Promise<void>;
        handlePlaceStorePickupOrderClick(): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/productCatalog" {
    import { PetShopProductCatalogBase } from "_102049_/l2/petShop/web/shared/productCatalog";
    export class PetShopDesktopPage11ProductCatalogPage extends PetShopProductCatalogBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/productManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                            source?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "productManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/productManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/productManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/productManagement.defs.ts", "_102049_/l2/petShop/web/shared/productManagement.ts", "_102049_/l2/petShop/web/contracts/productManagement.defs.ts", "_102049_/l2/petShop/web/contracts/productManagement.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["productManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/productManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseProductsOutput, PetShopCreateProductOutput, PetShopUpdateProductOutput } from "_102049_/l2/petShop/web/contracts/productManagement";
    const message_pt: {
        "page.title": string;
        "section.productManagement": string;
        "section.review": string;
        "organism.browseProducts.title": string;
        "organism.createProduct.title": string;
        "organism.updateProduct.title": string;
        "organism.review.title": string;
        "empty.browseProducts": string;
        "empty.createProduct": string;
        "empty.updateProduct": string;
        "empty.review": string;
        "column.name": string;
        "column.price": string;
        "column.productCategoryId": string;
        "column.featured": string;
        "column.status": string;
        "filter.searchName": string;
        "filter.filterStatus": string;
        "filter.filterProductCategoryId": string;
        "filter.filterFeatured": string;
        "field.name": string;
        "field.description": string;
        "field.price": string;
        "field.imageUrl": string;
        "field.productCategoryId": string;
        "field.featured": string;
        "field.status": string;
        "field.productId": string;
        "action.createProduct": string;
        "action.createProduct.submit": string;
        "action.updateProduct": string;
        "action.updateProduct.submit": string;
        "action.createProduct.success": string;
        "action.createProduct.error": string;
        "action.updateProduct.success": string;
        "action.updateProduct.error": string;
        "org.browseProducts.title": string;
        "org.createProduct.title": string;
        "org.updateProduct.title": string;
        "org.review.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopProductManagementBase extends CollabLitElement {
        status: string;
        browseProductsState: "idle" | "loading" | "success" | "error";
        browseProductsSearchName: string;
        browseProductsFilterStatus: string;
        browseProductsFilterProductCategoryId: string;
        browseProductsFilterFeatured: string;
        browseProductsData: PetShopBrowseProductsOutput;
        createProductState: "idle" | "loading" | "success" | "error";
        createProductName: string;
        createProductDescription: string;
        createProductPrice: string;
        createProductImageUrl: string;
        createProductProductCategoryId: string;
        createProductFeatured: string;
        createProductOutput: PetShopCreateProductOutput | null;
        createProductError: string;
        updateProductState: "idle" | "loading" | "success" | "error";
        updateProductProductId: string;
        updateProductName: string;
        updateProductDescription: string;
        updateProductPrice: string;
        updateProductImageUrl: string;
        updateProductProductCategoryId: string;
        updateProductFeatured: string;
        updateProductStatus: string;
        updateProductOutput: PetShopUpdateProductOutput | null;
        updateProductError: string;
        protected get msg(): MessageType;
        setBrowseProductsSearchName(value: string): void;
        handleBrowseProductsSearchNameChange(e: Event): void;
        setBrowseProductsFilterStatus(value: string): void;
        handleBrowseProductsFilterStatusChange(e: Event): void;
        setBrowseProductsFilterProductCategoryId(value: string): void;
        handleBrowseProductsFilterProductCategoryIdChange(e: Event): void;
        setBrowseProductsFilterFeatured(value: string): void;
        handleBrowseProductsFilterFeaturedChange(e: Event): void;
        setCreateProductName(value: string): void;
        handleCreateProductNameChange(e: Event): void;
        setCreateProductDescription(value: string): void;
        handleCreateProductDescriptionChange(e: Event): void;
        setCreateProductPrice(value: string): void;
        handleCreateProductPriceChange(e: Event): void;
        setCreateProductImageUrl(value: string): void;
        handleCreateProductImageUrlChange(e: Event): void;
        setCreateProductProductCategoryId(value: string): void;
        handleCreateProductProductCategoryIdChange(e: Event): void;
        setCreateProductFeatured(value: string): void;
        handleCreateProductFeaturedChange(e: Event): void;
        setUpdateProductProductId(value: string): void;
        handleUpdateProductProductIdChange(e: Event): void;
        setUpdateProductName(value: string): void;
        handleUpdateProductNameChange(e: Event): void;
        setUpdateProductDescription(value: string): void;
        handleUpdateProductDescriptionChange(e: Event): void;
        setUpdateProductPrice(value: string): void;
        handleUpdateProductPriceChange(e: Event): void;
        setUpdateProductImageUrl(value: string): void;
        handleUpdateProductImageUrlChange(e: Event): void;
        setUpdateProductProductCategoryId(value: string): void;
        handleUpdateProductProductCategoryIdChange(e: Event): void;
        setUpdateProductFeatured(value: string): void;
        handleUpdateProductFeaturedChange(e: Event): void;
        setUpdateProductStatus(value: string): void;
        handleUpdateProductStatusChange(e: Event): void;
        loadBrowseProducts(): Promise<void>;
        handleBrowseProductsClick(e: Event): void;
        createProduct(): Promise<void>;
        handleCreateProductClick(e: Event): void;
        updateProduct(): Promise<void>;
        handleUpdateProductClick(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/productManagement" {
    import { PetShopProductManagementBase } from "_102049_/l2/petShop/web/shared/productManagement";
    export class PetShopDesktopPage11ProductManagementPage extends PetShopProductManagementBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/schedulingCapacity.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: {
            operationId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "schedulingCapacity__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/schedulingCapacity.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/schedulingCapacity.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/schedulingCapacity.defs.ts", "_102049_/l2/petShop/web/shared/schedulingCapacity.ts", "_102049_/l2/petShop/web/contracts/schedulingCapacity.defs.ts", "_102049_/l2/petShop/web/contracts/schedulingCapacity.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["schedulingCapacity__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/schedulingCapacity" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopAssignOperatorToShiftOutput, PetShopReviewSchedulingCapacityOutput } from "_102049_/l2/petShop/web/contracts/schedulingCapacity";
    const message_pt: {
        "section.schedulingCapacity.title": string;
        "intention.queryList.title": string;
        "intention.queryList.empty": string;
        "intention.commandForm.title": string;
        "intention.commandForm.empty": string;
        "intention.summary.title": string;
        "intention.summary.empty": string;
        "field.operatorId.label": string;
        "field.shiftId.label": string;
        "column.shiftAssignmentId.label": string;
        "column.name.label": string;
        "column.shiftId.label": string;
        "column.startTime.label": string;
        "column.endTime.label": string;
        "column.createdAt.label": string;
        "filter.shiftId.label": string;
        "action.assignOperatorToShift.label": string;
        "action.reviewSchedulingCapacity.label": string;
        "action.assignOperatorToShift.success": string;
        "action.assignOperatorToShift.error": string;
        "action.reviewSchedulingCapacity.success": string;
        "action.reviewSchedulingCapacity.error": string;
        "org.review.scheduling.capacity.title": string;
        "org.assign.operator.to.shift.title": string;
        "org.capacity.summary.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopSchedulingCapacityBase extends CollabLitElement {
        status: string;
        assignOperatorToShiftState: "idle" | "loading" | "success" | "error";
        assignOperatorToShiftOperatorId: string;
        assignOperatorToShiftShiftId: string;
        assignOperatorToShiftOutput: PetShopAssignOperatorToShiftOutput | null;
        assignOperatorToShiftError: string;
        reviewSchedulingCapacityState: "idle" | "loading" | "success" | "error";
        reviewSchedulingCapacityShiftId: string;
        reviewSchedulingCapacityData: PetShopReviewSchedulingCapacityOutput;
        activeCompanyId: string;
        protected get msg(): MessageType;
        setAssignOperatorToShiftOperatorId(value: string): void;
        handleAssignOperatorToShiftOperatorIdChange(e: Event): void;
        setAssignOperatorToShiftShiftId(value: string): void;
        handleAssignOperatorToShiftShiftIdChange(e: Event): void;
        setReviewSchedulingCapacityShiftId(value: string): void;
        handleReviewSchedulingCapacityShiftIdChange(e: Event): void;
        loadReviewSchedulingCapacity(): Promise<void>;
        handleReviewSchedulingCapacityClick(e: Event): void;
        assignOperatorToShift(): Promise<void>;
        handleAssignOperatorToShiftClick(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: unknown): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/schedulingCapacity" {
    import { PetShopSchedulingCapacityBase } from "_102049_/l2/petShop/web/shared/schedulingCapacity";
    export class PetShopDesktopPage11SchedulingCapacityPage extends PetShopSchedulingCapacityBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/serviceBooking.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                            source?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "serviceBooking__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/serviceBooking.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/serviceBooking.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/serviceBooking.defs.ts", "_102049_/l2/petShop/web/shared/serviceBooking.ts", "_102049_/l2/petShop/web/contracts/serviceBooking.defs.ts", "_102049_/l2/petShop/web/contracts/serviceBooking.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["serviceBooking__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/serviceBooking" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseServiceCatalogOutput, PetShopCreateServiceBookingOutput } from "_102049_/l2/petShop/web/contracts/serviceBooking";
    const message_pt: {
        "page.title": string;
        "section.catalog.title": string;
        "section.catalog.empty": string;
        "section.booking.title": string;
        "section.booking.empty": string;
        "section.confirmation.title": string;
        "section.confirmation.empty": string;
        "field.serviceId.label": string;
        "field.customerName.label": string;
        "field.customerPhone.label": string;
        "field.bookingDate.label": string;
        "field.bookingTime.label": string;
        "field.notes.label": string;
        "field.serviceBookingId.label": string;
        "field.status.label": string;
        "column.serviceId.label": string;
        "column.name.label": string;
        "column.description.label": string;
        "column.estimatedDurationMinutes.label": string;
        "column.price.label": string;
        "filter.name.label": string;
        "action.browseServiceCatalog.label": string;
        "action.createServiceBooking.label": string;
        "action.createServiceBooking.success": string;
        "action.createServiceBooking.error": string;
        "summary.paymentNotice": string;
        "sec.catalog.title": string;
        "org.browseCatalog.title": string;
        "sec.booking.title": string;
        "org.createBooking.title": string;
        "sec.confirmation.title": string;
        "org.bookingSummary.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopServiceBookingBase extends CollabLitElement {
        status: string;
        browseServiceCatalogState: "idle" | "loading" | "success" | "error";
        browseServiceCatalogData: PetShopBrowseServiceCatalogOutput;
        createServiceBookingState: "idle" | "loading" | "success" | "error";
        createServiceBookingServiceId: string;
        createServiceBookingCustomerName: string;
        createServiceBookingCustomerPhone: string;
        createServiceBookingBookingDate: string;
        createServiceBookingBookingTime: string;
        createServiceBookingNotes: string;
        createServiceBookingOutput: PetShopCreateServiceBookingOutput | null;
        createServiceBookingError: string;
        protected get msg(): MessageType;
        private readonly stateKeyMap;
        private subscribedKeys;
        loadBrowseServiceCatalog(): Promise<void>;
        handleBrowseServiceCatalogClick(_e: Event): void;
        createServiceBooking(): Promise<void>;
        handleCreateServiceBookingClick(_e: Event): void;
        setCreateServiceBookingServiceId(value: string): void;
        handleCreateServiceBookingServiceIdChange(e: Event): void;
        setCreateServiceBookingCustomerName(value: string): void;
        handleCreateServiceBookingCustomerNameChange(e: Event): void;
        setCreateServiceBookingCustomerPhone(value: string): void;
        handleCreateServiceBookingCustomerPhoneChange(e: Event): void;
        setCreateServiceBookingBookingDate(value: string): void;
        handleCreateServiceBookingBookingDateChange(e: Event): void;
        setCreateServiceBookingBookingTime(value: string): void;
        handleCreateServiceBookingBookingTimeChange(e: Event): void;
        setCreateServiceBookingNotes(value: string): void;
        handleCreateServiceBookingNotesChange(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/serviceBooking" {
    import { PetShopServiceBookingBase } from "_102049_/l2/petShop/web/shared/serviceBooking";
    export class PetShopDesktopPage11ServiceBookingPage extends PetShopServiceBookingBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/serviceExecution.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                        }[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        source?: undefined;
                    })[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: ({
            id: string;
            source: string;
            entity: string;
            description: string;
            command?: undefined;
            stateKey?: undefined;
            inputStateKeys?: undefined;
        } | {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "serviceExecution__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/serviceExecution.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/serviceExecution.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/serviceExecution.defs.ts", "_102049_/l2/petShop/web/shared/serviceExecution.ts", "_102049_/l2/petShop/web/contracts/serviceExecution.defs.ts", "_102049_/l2/petShop/web/contracts/serviceExecution.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["serviceExecution__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/serviceExecution" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopStartServiceExecutionOutput, PetShopCompleteServiceExecutionOutput } from "_102049_/l2/petShop/web/contracts/serviceExecution";
    const message_pt: {
        "page.title": string;
        "section.bookings.title": string;
        "section.bookings.empty": string;
        "section.start.title": string;
        "section.start.empty": string;
        "section.complete.title": string;
        "section.complete.empty": string;
        "section.review.title": string;
        "section.review.empty": string;
        "column.customerName": string;
        "column.bookingDate": string;
        "column.bookingTime": string;
        "column.status": string;
        "column.notes": string;
        "column.updatedAt": string;
        "column.completedAt": string;
        "filter.status": string;
        "field.serviceBookingId": string;
        "action.startServiceExecution": string;
        "action.completeServiceExecution": string;
        "action.startServiceExecution.success": string;
        "action.startServiceExecution.error": string;
        "action.completeServiceExecution.success": string;
        "action.completeServiceExecution.error": string;
        "intention.bookingQuery.title": string;
        "intention.workflowStatus.title": string;
        "intention.startForm.title": string;
        "intention.completeForm.title": string;
        "intention.review.title": string;
        "sec.bookings.title": string;
        "org.booking.list.title": string;
        "sec.start.service.title": string;
        "org.start.service.title": string;
        "sec.complete.service.title": string;
        "org.complete.service.title": string;
        "sec.review.title": string;
        "org.review.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopServiceExecutionBase extends CollabLitElement {
        status: string;
        startServiceExecutionState: "idle" | "loading" | "success" | "error";
        startServiceExecutionServiceBookingId: string;
        startServiceExecutionOutput: PetShopStartServiceExecutionOutput | null;
        startServiceExecutionError: string;
        completeServiceExecutionState: "idle" | "loading" | "success" | "error";
        completeServiceExecutionServiceBookingId: string;
        completeServiceExecutionOutput: PetShopCompleteServiceExecutionOutput | null;
        completeServiceExecutionError: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setStartServiceExecutionServiceBookingId(value: string): void;
        handleStartServiceExecutionServiceBookingIdChange(e: Event): void;
        setCompleteServiceExecutionServiceBookingId(value: string): void;
        handleCompleteServiceExecutionServiceBookingIdChange(e: Event): void;
        startServiceExecution(): Promise<void>;
        handleStartServiceExecutionClick(): void;
        completeServiceExecution(): Promise<void>;
        handleCompleteServiceExecutionClick(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/serviceExecution" {
    import { PetShopServiceExecutionBase } from "_102049_/l2/petShop/web/shared/serviceExecution";
    export class PetShopDesktopPage11ServiceExecutionPage extends PetShopServiceExecutionBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/serviceManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "serviceManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/serviceManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/serviceManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/serviceManagement.defs.ts", "_102049_/l2/petShop/web/shared/serviceManagement.ts", "_102049_/l2/petShop/web/contracts/serviceManagement.defs.ts", "_102049_/l2/petShop/web/contracts/serviceManagement.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["serviceManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/serviceManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseServicesOutput, PetShopCreateServiceOutput, PetShopUpdateServiceOutput } from "_102049_/l2/petShop/web/contracts/serviceManagement";
    const message_pt: {
        "section.serviceManagement.title": string;
        "browseServices.title": string;
        "browseServices.empty": string;
        "createService.title": string;
        "createService.empty": string;
        "updateService.title": string;
        "updateService.empty": string;
        "field.name": string;
        "field.description": string;
        "field.estimatedDurationMinutes": string;
        "field.price": string;
        "field.status": string;
        "field.serviceId": string;
        "filter.statusFilter": string;
        "toolbar.createService": string;
        "rowAction.updateService": string;
        "action.createService.submit": string;
        "action.updateService.submit": string;
        "status.active": string;
        "status.inactive": string;
        "action.createService.success": string;
        "action.createService.error": string;
        "action.updateService.success": string;
        "action.updateService.error": string;
        "org.browse.services.title": string;
        "org.create.service.title": string;
        "org.update.service.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopServiceManagementBase extends CollabLitElement {
        status: string;
        browseServicesState: "idle" | "loading" | "success" | "error";
        browseServicesStatusFilter: string;
        browseServicesData: PetShopBrowseServicesOutput;
        createServiceState: "idle" | "loading" | "success" | "error";
        createServiceName: string;
        createServiceDescription: string;
        createServiceEstimatedDurationMinutes: string;
        createServicePrice: string;
        createServiceOutput: PetShopCreateServiceOutput | null;
        createServiceError: string;
        updateServiceState: "idle" | "loading" | "success" | "error";
        updateServiceServiceId: string;
        updateServiceName: string;
        updateServiceDescription: string;
        updateServiceEstimatedDurationMinutes: string;
        updateServicePrice: string;
        updateServiceStatus: string;
        updateServiceOutput: PetShopUpdateServiceOutput | null;
        updateServiceError: string;
        protected get msg(): MessageType;
        setBrowseServicesStatusFilter(value: string): void;
        handleBrowseServicesStatusFilterChange(e: Event): void;
        setCreateServiceName(value: string): void;
        handleCreateServiceNameChange(e: Event): void;
        setCreateServiceDescription(value: string): void;
        handleCreateServiceDescriptionChange(e: Event): void;
        setCreateServiceEstimatedDurationMinutes(value: string): void;
        handleCreateServiceEstimatedDurationMinutesChange(e: Event): void;
        setCreateServicePrice(value: string): void;
        handleCreateServicePriceChange(e: Event): void;
        setUpdateServiceServiceId(value: string): void;
        handleUpdateServiceServiceIdChange(e: Event): void;
        setUpdateServiceName(value: string): void;
        handleUpdateServiceNameChange(e: Event): void;
        setUpdateServiceDescription(value: string): void;
        handleUpdateServiceDescriptionChange(e: Event): void;
        setUpdateServiceEstimatedDurationMinutes(value: string): void;
        handleUpdateServiceEstimatedDurationMinutesChange(e: Event): void;
        setUpdateServicePrice(value: string): void;
        handleUpdateServicePriceChange(e: Event): void;
        setUpdateServiceStatus(value: string): void;
        handleUpdateServiceStatusChange(e: Event): void;
        loadBrowseServices(): Promise<void>;
        handleBrowseServicesClick(): void;
        createService(): Promise<void>;
        handleCreateServiceClick(): void;
        updateService(): Promise<void>;
        handleUpdateServiceClick(): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/serviceManagement" {
    import { PetShopServiceManagementBase } from "_102049_/l2/petShop/web/shared/serviceManagement";
    export class PetShopDesktopPage11ServiceManagementPage extends PetShopServiceManagementBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/shiftManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            })[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "shiftManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/shiftManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/shiftManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/shiftManagement.defs.ts", "_102049_/l2/petShop/web/shared/shiftManagement.ts", "_102049_/l2/petShop/web/contracts/shiftManagement.defs.ts", "_102049_/l2/petShop/web/contracts/shiftManagement.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["shiftManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/shiftManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseShiftsOutput, PetShopCreateShiftOutput, PetShopUpdateShiftOutput } from "_102049_/l2/petShop/web/contracts/shiftManagement";
    const message_pt: {
        "shiftManagement.section.gestaoTurnos.title": string;
        "shiftManagement.organism.browseShifts.title": string;
        "shiftManagement.organism.createShift.title": string;
        "shiftManagement.organism.updateShift.title": string;
        "shiftManagement.intent.browseList.title": string;
        "shiftManagement.intent.browseList.empty": string;
        "shiftManagement.intent.createForm.title": string;
        "shiftManagement.intent.updateForm.title": string;
        "shiftManagement.field.name.label": string;
        "shiftManagement.field.startTime.label": string;
        "shiftManagement.field.endTime.label": string;
        "shiftManagement.field.monday.label": string;
        "shiftManagement.field.tuesday.label": string;
        "shiftManagement.field.wednesday.label": string;
        "shiftManagement.field.thursday.label": string;
        "shiftManagement.field.friday.label": string;
        "shiftManagement.field.saturday.label": string;
        "shiftManagement.field.sunday.label": string;
        "shiftManagement.field.active.label": string;
        "shiftManagement.filter.activeFilter.label": string;
        "shiftManagement.action.createShift.label": string;
        "shiftManagement.action.updateShift.label": string;
        "shiftManagement.action.createShift.submit": string;
        "shiftManagement.action.updateShift.submit": string;
        "action.createShift.success": string;
        "action.createShift.error": string;
        "action.updateShift.success": string;
        "action.updateShift.error": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopShiftManagementBase extends CollabLitElement {
        status: string;
        browseShiftsState: 'idle' | 'loading' | 'success' | 'error';
        browseShiftsActiveFilter: string;
        browseShiftsData: PetShopBrowseShiftsOutput;
        createShiftState: 'idle' | 'loading' | 'success' | 'error';
        createShiftName: string;
        createShiftStartTime: string;
        createShiftEndTime: string;
        createShiftMonday: string;
        createShiftTuesday: string;
        createShiftWednesday: string;
        createShiftThursday: string;
        createShiftFriday: string;
        createShiftSaturday: string;
        createShiftSunday: string;
        createShiftActive: string;
        createShiftOutput: PetShopCreateShiftOutput | null;
        createShiftError: string;
        updateShiftState: 'idle' | 'loading' | 'success' | 'error';
        updateShiftShiftId: string;
        updateShiftName: string;
        updateShiftStartTime: string;
        updateShiftEndTime: string;
        updateShiftMonday: string;
        updateShiftTuesday: string;
        updateShiftWednesday: string;
        updateShiftThursday: string;
        updateShiftFriday: string;
        updateShiftSaturday: string;
        updateShiftSunday: string;
        updateShiftActive: string;
        updateShiftOutput: PetShopUpdateShiftOutput | null;
        updateShiftError: string;
        private readonly subscribedKeys;
        protected get msg(): MessageType;
        private toBool;
        private readInputValue;
        loadBrowseShifts(): Promise<boolean>;
        handleBrowseShiftsClick(): void;
        createShift(signal?: AbortSignal): Promise<void>;
        handleCreateShiftClick(): void;
        updateShift(signal?: AbortSignal): Promise<void>;
        handleUpdateShiftClick(): void;
        setBrowseShiftsActiveFilter(value: string): void;
        handleBrowseShiftsActiveFilterChange(e: Event): void;
        setCreateShiftName(value: string): void;
        handleCreateShiftNameChange(e: Event): void;
        setCreateShiftStartTime(value: string): void;
        handleCreateShiftStartTimeChange(e: Event): void;
        setCreateShiftEndTime(value: string): void;
        handleCreateShiftEndTimeChange(e: Event): void;
        setCreateShiftMonday(value: string): void;
        handleCreateShiftMondayChange(e: Event): void;
        setCreateShiftTuesday(value: string): void;
        handleCreateShiftTuesdayChange(e: Event): void;
        setCreateShiftWednesday(value: string): void;
        handleCreateShiftWednesdayChange(e: Event): void;
        setCreateShiftThursday(value: string): void;
        handleCreateShiftThursdayChange(e: Event): void;
        setCreateShiftFriday(value: string): void;
        handleCreateShiftFridayChange(e: Event): void;
        setCreateShiftSaturday(value: string): void;
        handleCreateShiftSaturdayChange(e: Event): void;
        setCreateShiftSunday(value: string): void;
        handleCreateShiftSundayChange(e: Event): void;
        setCreateShiftActive(value: string): void;
        handleCreateShiftActiveChange(e: Event): void;
        setUpdateShiftShiftId(value: string): void;
        handleUpdateShiftShiftIdChange(e: Event): void;
        setUpdateShiftName(value: string): void;
        handleUpdateShiftNameChange(e: Event): void;
        setUpdateShiftStartTime(value: string): void;
        handleUpdateShiftStartTimeChange(e: Event): void;
        setUpdateShiftEndTime(value: string): void;
        handleUpdateShiftEndTimeChange(e: Event): void;
        setUpdateShiftMonday(value: string): void;
        handleUpdateShiftMondayChange(e: Event): void;
        setUpdateShiftTuesday(value: string): void;
        handleUpdateShiftTuesdayChange(e: Event): void;
        setUpdateShiftWednesday(value: string): void;
        handleUpdateShiftWednesdayChange(e: Event): void;
        setUpdateShiftThursday(value: string): void;
        handleUpdateShiftThursdayChange(e: Event): void;
        setUpdateShiftFriday(value: string): void;
        handleUpdateShiftFridayChange(e: Event): void;
        setUpdateShiftSaturday(value: string): void;
        handleUpdateShiftSaturdayChange(e: Event): void;
        setUpdateShiftSunday(value: string): void;
        handleUpdateShiftSundayChange(e: Event): void;
        setUpdateShiftActive(value: string): void;
        handleUpdateShiftActiveChange(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/shiftManagement" {
    import { PetShopShiftManagementBase } from "_102049_/l2/petShop/web/shared/shiftManagement";
    export class PetShopDesktopPage11ShiftManagementPage extends PetShopShiftManagementBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/shared/adoptionGallery.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "adoptionGallery.section.title": string;
            "adoptionGallery.browse.title": string;
            "adoptionGallery.browse.empty": string;
            "adoptionGallery.details.title": string;
            "adoptionGallery.details.empty": string;
            "adoptionGallery.interestForm.title": string;
            "adoptionGallery.interestForm.empty": string;
            "adoptionGallery.summary.title": string;
            "adoptionGallery.summary.empty": string;
            "adoptionGallery.field.photoUrl": string;
            "adoptionGallery.field.name": string;
            "adoptionGallery.field.age": string;
            "adoptionGallery.field.description": string;
            "adoptionGallery.field.status": string;
            "adoptionGallery.field.adoptablePetId": string;
            "adoptionGallery.field.customerName": string;
            "adoptionGallery.field.customerEmail": string;
            "adoptionGallery.field.customerPhone": string;
            "adoptionGallery.field.adoptionInterestId": string;
            "adoptionGallery.field.interestStatus": string;
            "adoptionGallery.field.createdAt": string;
            "adoptionGallery.action.viewDetails": string;
            "adoptionGallery.action.expressInterest": string;
            "adoptionGallery.action.submitInterest": string;
            "action.expressAdoptionInterest.success": string;
            "action.expressAdoptionInterest.error": string;
            "org.browse.adoptable.pets.title": string;
            "org.view.pet.details.title": string;
            "org.express.interest.title": string;
            "org.adoption.summary.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "adoptionGallery__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/adoptionGallery.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/adoptionGallery.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/adoptionGallery.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["adoptionGallery__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/adoptionGallery.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/homePage.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: any[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
        }[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "homePage.title": string;
            "homePage.section.featuredProducts": string;
            "homePage.section.services": string;
            "homePage.section.adoptablePets": string;
            "homePage.productList.title": string;
            "homePage.productList.empty": string;
            "homePage.productDetail.title": string;
            "homePage.productDetail.empty": string;
            "homePage.productDetail.imageUrl": string;
            "homePage.productDetail.name": string;
            "homePage.productDetail.description": string;
            "homePage.productDetail.price": string;
            "homePage.product.productId": string;
            "homePage.product.name": string;
            "homePage.product.description": string;
            "homePage.product.price": string;
            "homePage.product.imageUrl": string;
            "homePage.product.featured": string;
            "homePage.product.status": string;
            "homePage.servicesList.title": string;
            "homePage.servicesList.empty": string;
            "homePage.service.serviceId": string;
            "homePage.service.name": string;
            "homePage.service.description": string;
            "homePage.service.estimatedDurationMinutes": string;
            "homePage.service.price": string;
            "homePage.service.status": string;
            "homePage.petsGallery.title": string;
            "homePage.petsGallery.empty": string;
            "homePage.pet.adoptablePetId": string;
            "homePage.pet.name": string;
            "homePage.pet.age": string;
            "homePage.pet.description": string;
            "homePage.pet.photoUrl": string;
            "homePage.pet.status": string;
            "homePage.action.browseHomePage": string;
            "homePage.action.browseHomePage.success": string;
            "homePage.action.browseHomePage.error": string;
            "org.featured.products.title": string;
            "org.services.title": string;
            "org.adoptable.pets.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "homePage__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/homePage.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/homePage.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/homePage.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["homePage__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/homePage.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/operatorManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "operatorManagement.browse.title": string;
            "operatorManagement.browse.empty": string;
            "operatorManagement.create.title": string;
            "operatorManagement.create.empty": string;
            "operatorManagement.update.title": string;
            "operatorManagement.update.empty": string;
            "operatorManagement.field.name": string;
            "operatorManagement.field.email": string;
            "operatorManagement.field.phone": string;
            "operatorManagement.field.active": string;
            "operatorManagement.field.updatedAt": string;
            "operatorManagement.field.operatorId": string;
            "operatorManagement.filter.active": string;
            "operatorManagement.action.create": string;
            "operatorManagement.action.create.submit": string;
            "operatorManagement.action.update": string;
            "operatorManagement.action.update.submit": string;
            "action.createOperator.success": string;
            "action.createOperator.error": string;
            "action.updateOperator.success": string;
            "action.updateOperator.error": string;
            "sec.operator.management.title": string;
            "org.browse.operators.title": string;
            "org.create.operator.title": string;
            "org.update.operator.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "operatorManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/operatorManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/operatorManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/operatorManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["operatorManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/operatorManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/operatorSchedule.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.title": string;
            "section.schedule.title": string;
            "section.payment.title": string;
            "organism.metrics.title": string;
            "organism.metrics.empty": string;
            "metric.confirmed": string;
            "metric.inProgress": string;
            "metric.completed": string;
            "metric.total": string;
            "organism.list.title": string;
            "organism.list.empty": string;
            "organism.details.title": string;
            "organism.details.empty": string;
            "organism.payment.title": string;
            "organism.payment.empty": string;
            "column.customerName": string;
            "column.customerPhone": string;
            "column.bookingDate": string;
            "column.bookingTime": string;
            "column.status": string;
            "column.notes": string;
            "filter.status": string;
            "filter.bookingDate": string;
            "field.serviceBookingId": string;
            "field.serviceId": string;
            "field.customerName": string;
            "field.customerPhone": string;
            "field.bookingDate": string;
            "field.bookingTime": string;
            "field.status": string;
            "field.notes": string;
            "field.completedAt": string;
            "field.cancelledAt": string;
            "field.cancelReason": string;
            "field.createdAt": string;
            "field.updatedAt": string;
            "field.paymentInfo": string;
            "field.paymentMethod": string;
            "action.viewDetails": string;
            "action.viewOperatorSchedule.success": string;
            "action.viewOperatorSchedule.error": string;
            "action.viewServiceBookingDetails.success": string;
            "action.viewServiceBookingDetails.error": string;
            "scheduleMetrics.title": string;
            "scheduleList.title": string;
            "bookingDetails.title": string;
            "paymentContext.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "operatorSchedule__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/operatorSchedule.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/operatorSchedule.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/operatorSchedule.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["operatorSchedule__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/operatorSchedule.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/petManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "petManagement.section.title": string;
            "petManagement.list.title": string;
            "petManagement.list.empty": string;
            "petManagement.create.title": string;
            "petManagement.create.empty": string;
            "petManagement.update.title": string;
            "petManagement.update.empty": string;
            "petManagement.summary.title": string;
            "petManagement.summary.sectionTitle": string;
            "petManagement.summary.empty": string;
            "petManagement.field.name": string;
            "petManagement.field.age": string;
            "petManagement.field.description": string;
            "petManagement.field.photoUrl": string;
            "petManagement.field.status": string;
            "petManagement.field.adoptablePetId": string;
            "petManagement.field.createdAt": string;
            "petManagement.field.updatedAt": string;
            "petManagement.filter.statusFilter": string;
            "petManagement.action.create": string;
            "petManagement.action.create.submit": string;
            "petManagement.action.update": string;
            "petManagement.action.update.submit": string;
            "action.createAdoptablePet.success": string;
            "action.createAdoptablePet.error": string;
            "action.updateAdoptablePet.success": string;
            "action.updateAdoptablePet.error": string;
            "org.browse.pets.title": string;
            "org.create.pet.title": string;
            "org.update.pet.title": string;
            "org.pet.summary.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "petManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/petManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/petManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/petManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["petManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/petManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/productCatalog.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.title": string;
            "section.catalog.title": string;
            "section.checkout.title": string;
            "organism.browse.title": string;
            "organism.details.title": string;
            "organism.cart.title": string;
            "organism.checkout.title": string;
            "organism.summary.title": string;
            "field.searchName": string;
            "field.productCategoryId": string;
            "field.productId": string;
            "field.name": string;
            "field.description": string;
            "field.price": string;
            "field.imageUrl": string;
            "field.featured": string;
            "field.status": string;
            "field.quantity": string;
            "field.unitPrice": string;
            "field.customerName": string;
            "field.customerPhone": string;
            "field.orderId": string;
            "field.createdAt": string;
            "column.imageUrl": string;
            "column.name": string;
            "column.price": string;
            "column.productCategoryId": string;
            "column.featured": string;
            "column.productId": string;
            "column.quantity": string;
            "column.unitPrice": string;
            "action.viewProductDetails": string;
            "action.placeStorePickupOrder": string;
            "empty.browse": string;
            "empty.details": string;
            "empty.cart": string;
            "empty.summary": string;
            "action.placeStorePickupOrder.success": string;
            "action.placeStorePickupOrder.error": string;
            "sec.catalog.title": string;
            "org.browse.catalog.title": string;
            "org.product.details.title": string;
            "org.cart.and.checkout.title": string;
            "org.order.result.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "productCatalog__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/productCatalog.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/productCatalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/productCatalog.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["productCatalog__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/productCatalog.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/productManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.title": string;
            "section.productManagement": string;
            "section.review": string;
            "organism.browseProducts.title": string;
            "organism.createProduct.title": string;
            "organism.updateProduct.title": string;
            "organism.review.title": string;
            "empty.browseProducts": string;
            "empty.createProduct": string;
            "empty.updateProduct": string;
            "empty.review": string;
            "column.name": string;
            "column.price": string;
            "column.productCategoryId": string;
            "column.featured": string;
            "column.status": string;
            "filter.searchName": string;
            "filter.filterStatus": string;
            "filter.filterProductCategoryId": string;
            "filter.filterFeatured": string;
            "field.name": string;
            "field.description": string;
            "field.price": string;
            "field.imageUrl": string;
            "field.productCategoryId": string;
            "field.featured": string;
            "field.status": string;
            "field.productId": string;
            "action.createProduct": string;
            "action.createProduct.submit": string;
            "action.updateProduct": string;
            "action.updateProduct.submit": string;
            "action.createProduct.success": string;
            "action.createProduct.error": string;
            "action.updateProduct.success": string;
            "action.updateProduct.error": string;
            "org.browseProducts.title": string;
            "org.createProduct.title": string;
            "org.updateProduct.title": string;
            "org.review.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "productManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/productManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/productManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/productManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["productManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/productManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/schedulingCapacity.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            targetRef: string;
            required: boolean;
            selector: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: {
            operationId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "section.schedulingCapacity.title": string;
            "intention.queryList.title": string;
            "intention.queryList.empty": string;
            "intention.commandForm.title": string;
            "intention.commandForm.empty": string;
            "intention.summary.title": string;
            "intention.summary.empty": string;
            "field.operatorId.label": string;
            "field.shiftId.label": string;
            "column.shiftAssignmentId.label": string;
            "column.name.label": string;
            "column.shiftId.label": string;
            "column.startTime.label": string;
            "column.endTime.label": string;
            "column.createdAt.label": string;
            "filter.shiftId.label": string;
            "action.assignOperatorToShift.label": string;
            "action.reviewSchedulingCapacity.label": string;
            "action.assignOperatorToShift.success": string;
            "action.assignOperatorToShift.error": string;
            "action.reviewSchedulingCapacity.success": string;
            "action.reviewSchedulingCapacity.error": string;
            "org.review.scheduling.capacity.title": string;
            "org.assign.operator.to.shift.title": string;
            "org.capacity.summary.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "schedulingCapacity__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/schedulingCapacity.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/schedulingCapacity.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/schedulingCapacity.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["schedulingCapacity__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/schedulingCapacity.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/serviceBooking.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: any[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.title": string;
            "section.catalog.title": string;
            "section.catalog.empty": string;
            "section.booking.title": string;
            "section.booking.empty": string;
            "section.confirmation.title": string;
            "section.confirmation.empty": string;
            "field.serviceId.label": string;
            "field.customerName.label": string;
            "field.customerPhone.label": string;
            "field.bookingDate.label": string;
            "field.bookingTime.label": string;
            "field.notes.label": string;
            "field.serviceBookingId.label": string;
            "field.status.label": string;
            "column.serviceId.label": string;
            "column.name.label": string;
            "column.description.label": string;
            "column.estimatedDurationMinutes.label": string;
            "column.price.label": string;
            "filter.name.label": string;
            "action.browseServiceCatalog.label": string;
            "action.createServiceBooking.label": string;
            "action.createServiceBooking.success": string;
            "action.createServiceBooking.error": string;
            "summary.paymentNotice": string;
            "sec.catalog.title": string;
            "org.browseCatalog.title": string;
            "sec.booking.title": string;
            "org.createBooking.title": string;
            "sec.confirmation.title": string;
            "org.bookingSummary.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "serviceBooking__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/serviceBooking.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/serviceBooking.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/serviceBooking.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["serviceBooking__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/serviceBooking.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/serviceExecution.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
        })[];
        initialLoads: any[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.title": string;
            "section.bookings.title": string;
            "section.bookings.empty": string;
            "section.start.title": string;
            "section.start.empty": string;
            "section.complete.title": string;
            "section.complete.empty": string;
            "section.review.title": string;
            "section.review.empty": string;
            "column.customerName": string;
            "column.bookingDate": string;
            "column.bookingTime": string;
            "column.status": string;
            "column.notes": string;
            "column.updatedAt": string;
            "column.completedAt": string;
            "filter.status": string;
            "field.serviceBookingId": string;
            "action.startServiceExecution": string;
            "action.completeServiceExecution": string;
            "action.startServiceExecution.success": string;
            "action.startServiceExecution.error": string;
            "action.completeServiceExecution.success": string;
            "action.completeServiceExecution.error": string;
            "intention.bookingQuery.title": string;
            "intention.workflowStatus.title": string;
            "intention.startForm.title": string;
            "intention.completeForm.title": string;
            "intention.review.title": string;
            "sec.bookings.title": string;
            "org.booking.list.title": string;
            "sec.start.service.title": string;
            "org.start.service.title": string;
            "sec.complete.service.title": string;
            "org.complete.service.title": string;
            "sec.review.title": string;
            "org.review.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "serviceExecution__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/serviceExecution.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/serviceExecution.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/serviceExecution.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["serviceExecution__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/serviceExecution.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/serviceManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "section.serviceManagement.title": string;
            "browseServices.title": string;
            "browseServices.empty": string;
            "createService.title": string;
            "createService.empty": string;
            "updateService.title": string;
            "updateService.empty": string;
            "field.name": string;
            "field.description": string;
            "field.estimatedDurationMinutes": string;
            "field.price": string;
            "field.status": string;
            "field.serviceId": string;
            "filter.statusFilter": string;
            "toolbar.createService": string;
            "rowAction.updateService": string;
            "action.createService.submit": string;
            "action.updateService.submit": string;
            "status.active": string;
            "status.inactive": string;
            "action.createService.success": string;
            "action.createService.error": string;
            "action.updateService.success": string;
            "action.updateService.error": string;
            "org.browse.services.title": string;
            "org.create.service.title": string;
            "org.update.service.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "serviceManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/serviceManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/serviceManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/serviceManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["serviceManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/serviceManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/shiftManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "shiftManagement.section.gestaoTurnos.title": string;
            "shiftManagement.organism.browseShifts.title": string;
            "shiftManagement.organism.createShift.title": string;
            "shiftManagement.organism.updateShift.title": string;
            "shiftManagement.intent.browseList.title": string;
            "shiftManagement.intent.browseList.empty": string;
            "shiftManagement.intent.createForm.title": string;
            "shiftManagement.intent.updateForm.title": string;
            "shiftManagement.field.name.label": string;
            "shiftManagement.field.startTime.label": string;
            "shiftManagement.field.endTime.label": string;
            "shiftManagement.field.monday.label": string;
            "shiftManagement.field.tuesday.label": string;
            "shiftManagement.field.wednesday.label": string;
            "shiftManagement.field.thursday.label": string;
            "shiftManagement.field.friday.label": string;
            "shiftManagement.field.saturday.label": string;
            "shiftManagement.field.sunday.label": string;
            "shiftManagement.field.active.label": string;
            "shiftManagement.filter.activeFilter.label": string;
            "shiftManagement.action.createShift.label": string;
            "shiftManagement.action.updateShift.label": string;
            "shiftManagement.action.createShift.submit": string;
            "shiftManagement.action.updateShift.submit": string;
            "action.createShift.success": string;
            "action.createShift.error": string;
            "action.updateShift.success": string;
            "action.updateShift.error": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "shiftManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/shiftManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/shiftManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/shiftManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["shiftManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/shiftManagement.test" {
    export {};
}

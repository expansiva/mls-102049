declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/catalog.defs" {
    export const catalogController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "catalog";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "catalog";
            readonly controllerName: "CatalogController";
            readonly ownerKind: "workspace";
            readonly workspaceId: "catalog";
            readonly actors: readonly ["cliente"];
            readonly allowedScopes: readonly ["petShop:cliente"];
            readonly handlers: readonly [{
                readonly handlerName: "catalogFeaturedProductsHandler";
                readonly command: "featuredProducts";
                readonly bffId: "featuredProducts";
                readonly route: "petShop.catalog.featuredProducts";
                readonly kind: "query";
                readonly usecaseRef: "browseFeaturedProducts";
                readonly usecaseRefs: readonly ["browseFeaturedProducts"];
                readonly inputTypeName: "BrowseFeaturedProductsInput";
                readonly inputContract: readonly [{
                    readonly inputId: "categoryId";
                    readonly fieldRef: "Product.categoryId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional por categoria do produto";
                }, {
                    readonly inputId: "petTypeId";
                    readonly fieldRef: "Product.petTypeId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional por tipo de pet associado ao produto";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "Product.name";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Termo de pesquisa opcional para filtrar produtos por nome (insensível a caixa)";
                }, {
                    readonly inputId: "priceMin";
                    readonly fieldRef: "Product.price";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Valor mínimo opcional para filtrar produtos por faixa de preço";
                }, {
                    readonly inputId: "priceMax";
                    readonly fieldRef: "Product.price";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Valor máximo opcional para filtrar produtos por faixa de preço";
                }, {
                    readonly inputId: "page";
                    readonly fieldRef: "";
                    readonly type: "number";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Número da página para paginação opcional dos resultados";
                }, {
                    readonly inputId: "pageSize";
                    readonly fieldRef: "";
                    readonly type: "number";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Quantidade de itens por página para paginação opcional dos resultados";
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "productId";
                        readonly operationId: "browseFeaturedProducts";
                        readonly path: readonly ["productId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "name";
                        readonly operationId: "browseFeaturedProducts";
                        readonly path: readonly ["name"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "price";
                        readonly operationId: "browseFeaturedProducts";
                        readonly path: readonly ["price"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "isFeatured";
                        readonly operationId: "browseFeaturedProducts";
                        readonly path: readonly ["isFeatured"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "categoryId";
                        readonly operationId: "browseFeaturedProducts";
                        readonly path: readonly ["categoryId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "petTypeId";
                        readonly operationId: "browseFeaturedProducts";
                        readonly path: readonly ["petTypeId"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "catalogBrowseCatalogHandler";
                readonly command: "browseCatalog";
                readonly bffId: "browseCatalog";
                readonly route: "petShop.catalog.browseCatalog";
                readonly kind: "query";
                readonly usecaseRef: "browseProducts";
                readonly usecaseRefs: readonly ["browseProducts"];
                readonly inputTypeName: "BrowseProductsInput";
                readonly inputContract: readonly [{
                    readonly inputId: "searchName";
                    readonly fieldRef: "";
                    readonly type: "string";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Texto parcial do nome do produto para pesquisa insensível a caixa";
                }, {
                    readonly inputId: "petTypeId";
                    readonly fieldRef: "";
                    readonly type: "string";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Identificador do tipo de pet para filtrar produtos adequados";
                }, {
                    readonly inputId: "categoryId";
                    readonly fieldRef: "";
                    readonly type: "string";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Identificador da categoria para filtrar produtos";
                }, {
                    readonly inputId: "minPrice";
                    readonly fieldRef: "";
                    readonly type: "string";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Valor mínimo da faixa de preço para filtrar produtos dentro do orçamento";
                }, {
                    readonly inputId: "maxPrice";
                    readonly fieldRef: "";
                    readonly type: "string";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Valor máximo da faixa de preço para filtrar produtos dentro do orçamento";
                }, {
                    readonly inputId: "page";
                    readonly fieldRef: "";
                    readonly type: "number";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Número da página atual para paginação dos resultados";
                }, {
                    readonly inputId: "pageSize";
                    readonly fieldRef: "";
                    readonly type: "number";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Quantidade de itens por página";
                }];
                readonly projection: {
                    readonly kind: "paginated";
                    readonly arrayFieldName: "items";
                    readonly itemFields: readonly [{
                        readonly name: "productId";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["productId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "name";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["name"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "price";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["price"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "isFeatured";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["isFeatured"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "categoryId";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["categoryId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "categoryName";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["categoryName"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "petTypeId";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["petTypeId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "petTypeName";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["petTypeName"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "createdAt";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["createdAt"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "updatedAt";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["updatedAt"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [{
                        readonly name: "total";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["total"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "page";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["page"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "pageSize";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["pageSize"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "catalogProductDetailsHandler";
                readonly command: "productDetails";
                readonly bffId: "productDetails";
                readonly route: "petShop.catalog.productDetails";
                readonly kind: "query";
                readonly usecaseRef: "viewProductDetails";
                readonly usecaseRefs: readonly ["viewProductDetails"];
                readonly inputTypeName: "ViewProductDetailsInput";
                readonly inputContract: readonly [{
                    readonly inputId: "productId";
                    readonly fieldRef: "Product.productId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identificador do produto selecionado pelo cliente na vitrine ou na lista do catálogo";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "productId";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["productId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "name";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["name"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "price";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["price"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "isFeatured";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["isFeatured"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "categoryId";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["categoryId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "categoryName";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["categoryName"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "petTypeId";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["petTypeId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "petTypeName";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["petTypeName"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "createdAt";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["createdAt"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "updatedAt";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["updatedAt"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "catalogReserveProductHandler";
                readonly command: "reserveProduct";
                readonly bffId: "reserveProduct";
                readonly route: "petShop.catalog.reserveProduct";
                readonly kind: "command";
                readonly usecaseRef: "createReservation";
                readonly usecaseRefs: readonly ["createReservation"];
                readonly inputTypeName: "CreateReservationInput";
                readonly inputContract: readonly [{
                    readonly inputId: "customerName";
                    readonly fieldRef: "Reservation.customerName";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do cliente que está fazendo a reserva";
                }, {
                    readonly inputId: "customerPhone";
                    readonly fieldRef: "Reservation.customerPhone";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Telefone de contato do cliente para identificação na loja";
                }, {
                    readonly inputId: "productId";
                    readonly fieldRef: "Product.productId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador do produto selecionado na tela de detalhes que o cliente deseja reservar";
                }, {
                    readonly inputId: "quantity";
                    readonly fieldRef: "";
                    readonly type: "number";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Quantidade de unidades do produto que o cliente deseja reservar";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "reservationId";
                        readonly operationId: "createReservation";
                        readonly path: readonly ["reservationId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "customerName";
                        readonly operationId: "createReservation";
                        readonly path: readonly ["customerName"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "customerPhone";
                        readonly operationId: "createReservation";
                        readonly path: readonly ["customerPhone"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "createReservation";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "expiresAt";
                        readonly operationId: "createReservation";
                        readonly path: readonly ["expiresAt"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "createdAt";
                        readonly operationId: "createReservation";
                        readonly path: readonly ["createdAt"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "items";
                        readonly operationId: "createReservation";
                        readonly path: readonly ["items"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }];
            readonly routes: readonly [{
                readonly key: "petShop.catalog.featuredProducts";
                readonly handlerName: "catalogFeaturedProductsHandler";
            }, {
                readonly key: "petShop.catalog.browseCatalog";
                readonly handlerName: "catalogBrowseCatalogHandler";
            }, {
                readonly key: "petShop.catalog.productDetails";
                readonly handlerName: "catalogProductDetailsHandler";
            }, {
                readonly key: "petShop.catalog.reserveProduct";
                readonly handlerName: "catalogReserveProductHandler";
            }];
        };
    };
    export default catalogController;
    export const pipeline: readonly [{
        readonly id: "catalog__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/catalog.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/catalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/browseFeaturedProducts.d.ts", "_102049_/l4/petShop/contracts/catalog.featuredProducts.defs.ts", "_102049_/l1/petShop/layer_2_application/usecases/browseProducts.d.ts", "_102049_/l4/petShop/contracts/catalog.browseCatalog.defs.ts", "_102049_/l1/petShop/layer_2_application/usecases/viewProductDetails.d.ts", "_102049_/l4/petShop/contracts/catalog.productDetails.defs.ts", "_102049_/l1/petShop/layer_2_application/usecases/createReservation.d.ts", "_102049_/l4/petShop/contracts/catalog.reserveProduct.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseFeaturedProducts" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseFeaturedProductsInput {
        categoryId?: string;
        petTypeId?: string;
        name?: string;
        priceMin?: number;
        priceMax?: number;
        page?: number;
        pageSize?: number;
    }
    export interface BrowseFeaturedProductItem {
        productId: string;
        name: string;
        price: number;
        isFeatured: boolean;
        categoryId: string;
        petTypeId: string;
    }
    export interface BrowseFeaturedProductsOutput {
        items: BrowseFeaturedProductItem[];
    }
    export function browseFeaturedProducts(ctx: RequestContext, input: BrowseFeaturedProductsInput): Promise<BrowseFeaturedProductsOutput>;
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseProducts" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseProductsInput {
        searchName?: string;
        petTypeId?: string;
        categoryId?: string;
        minPrice?: string;
        maxPrice?: string;
        page?: number;
        pageSize?: number;
    }
    export interface BrowseProductsItem {
        productId: string;
        name: string;
        price: number;
        isFeatured: boolean;
        categoryId: string;
        categoryName: string;
        petTypeId: string;
        petTypeName: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface BrowseProductsOutput {
        items: BrowseProductsItem[];
        total: number;
        page: number;
        pageSize: number;
    }
    export function browseProducts(ctx: RequestContext, input: BrowseProductsInput): Promise<BrowseProductsOutput>;
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/viewProductDetails" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewProductDetailsInput {
        productId: string;
    }
    export interface ViewProductDetailsOutput {
        productId: string;
        name: string;
        price: number;
        isFeatured: boolean;
        categoryId: string;
        categoryName: string;
        petTypeId: string;
        petTypeName: string;
        createdAt: string;
        updatedAt: string;
    }
    export function viewProductDetails(ctx: RequestContext, input: ViewProductDetailsInput): Promise<ViewProductDetailsOutput>;
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/reservation" {
    export type ReservationStatus = 'pending' | 'confirmed' | 'fulfilled' | 'cancelled';
    export interface ReservationItem {
        reservationItemId: string;
        reservationId: string;
        productId: string;
        quantity: number;
        createdAt: string;
        updatedAt: string;
    }
    export interface Reservation {
        reservationId: string;
        customerName: string;
        customerPhone: string;
        status: ReservationStatus;
        expiresAt: string;
        confirmedAt: string | null;
        fulfilledAt: string | null;
        cancelledAt: string | null;
        cancellationReason: string | null;
        paymentId: string | null;
        items: ReservationItem[];
        createdAt: string;
        updatedAt: string;
    }
    export const RESERVATION_STATUS_TRANSITIONS: Record<ReservationStatus, ReservationStatus[]>;
    export function canTransitionReservation(from: ReservationStatus, to: ReservationStatus): boolean;
    /** expiresAt must be exactly 24 hours after createdAt */
    export function reservationExpiresAtIsValid(reservation: Pick<Reservation, 'createdAt' | 'expiresAt'>): boolean;
    /** status='confirmed' implies confirmedAt is set */
    export function reservationConfirmedImpliesTimestamp(reservation: Pick<Reservation, 'status' | 'confirmedAt'>): boolean;
    /** status='fulfilled' implies fulfilledAt is set and paymentId is set */
    export function reservationFulfilledImpliesTimestampAndPayment(reservation: Pick<Reservation, 'status' | 'fulfilledAt' | 'paymentId'>): boolean;
    /** status='cancelled' implies cancelledAt is set and cancellationReason is set */
    export function reservationCancelledImpliesTimestampAndReason(reservation: Pick<Reservation, 'status' | 'cancelledAt' | 'cancellationReason'>): boolean;
    /** confirmedAt, fulfilledAt, cancelledAt (when present) must be on or after createdAt */
    export function reservationLifecycleTimestampsOnOrAfterCreatedAt(reservation: Pick<Reservation, 'createdAt' | 'confirmedAt' | 'fulfilledAt' | 'cancelledAt'>): boolean;
    /** fulfilledAt and cancelledAt are mutually exclusive */
    export function reservationFulfilledAndCancelledAreMutuallyExclusive(reservation: Pick<Reservation, 'fulfilledAt' | 'cancelledAt'>): boolean;
    export function reservationRequiresItem(reservation: Pick<Reservation, 'items'>): boolean;
}
declare module "_102049_/l1/petShop/layer_2_application/ports/reservationRepository" {
    import type { Reservation, ReservationStatus } from "_102049_/l1/petShop/layer_3_domain/entities/reservation";
    export type ReservationId = string;
    export interface DateRange {
        from: string;
        to: string;
    }
    export interface ReservationFilter {
        status?: ReservationStatus;
    }
    export interface IReservationRepository {
        getById(id: ReservationId): Promise<Reservation>;
        list(filter: ReservationFilter): Promise<Reservation[]>;
        save(reservation: Reservation): Promise<void>;
        listByPeriod(period: DateRange): Promise<Reservation[]>;
        existsById(id: ReservationId): Promise<boolean>;
    }
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/payment" {
    export type PaymentMethod = 'cash' | 'creditCard' | 'debitCard' | 'pix';
    export type PaymentStatus = 'posted' | 'voided';
    export interface Payment {
        paymentId: string;
        reservationId: string;
        amount: number;
        method: PaymentMethod;
        status: PaymentStatus;
        receivedBy: string;
        voidedAt: string | null;
        voidReason: string | null;
        createdAt: string;
    }
    export const PAYMENT_STATUS_TRANSITIONS: Record<PaymentStatus, PaymentStatus[]>;
    export function canTransitionPayment(from: PaymentStatus, to: PaymentStatus): boolean;
}
declare module "_102049_/l1/petShop/layer_2_application/ports/paymentRepository" {
    import type { Payment } from "_102049_/l1/petShop/layer_3_domain/entities/payment";
    /** Domain payment record treated as an immutable payment event in the append-only stream. */
    export type PaymentEvent = Payment;
    export type ReservationId = string;
    export interface DateRange {
        from: string;
        to: string;
    }
    export interface IPaymentRepository {
        /** Append a payment event to the append-only event stream */
        append(record: PaymentEvent): Promise<void>;
        /** Read finder: list payment events for the owning reservation */
        listByOwnerId(ownerId: ReservationId): Promise<PaymentEvent[]>;
        /** Read finder: list payment events that occurred within the given period */
        listByPeriod(period: DateRange): Promise<PaymentEvent[]>;
    }
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/createReservation" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateReservationInput {
        customerName: string;
        customerPhone: string;
        productId: string;
        quantity: number;
    }
    export interface CreateReservationOutputItem {
        productId: string;
        productName: string;
        quantity: number;
    }
    export interface CreateReservationOutput {
        reservationId: string;
        customerName: string;
        customerPhone: string;
        status: string;
        expiresAt: string;
        createdAt: string;
        items: CreateReservationOutputItem[];
    }
    export function createReservation(ctx: RequestContext, input: CreateReservationInput): Promise<CreateReservationOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/catalog" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const catalogFeaturedProductsHandler: BffHandler;
    export const catalogBrowseCatalogHandler: BffHandler;
    export const catalogProductDetailsHandler: BffHandler;
    export const catalogReserveProductHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/reservationManagement.defs" {
    export const reservationManagementController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "reservationManagement";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "reservationManagement";
            readonly controllerName: "ReservationManagementController";
            readonly ownerKind: "workspace";
            readonly workspaceId: "reservationManagement";
            readonly actors: readonly ["atendente"];
            readonly allowedScopes: readonly ["petShop:atendente"];
            readonly handlers: readonly [{
                readonly handlerName: "reservationManagementBrowseReservationsQueryHandler";
                readonly command: "browseReservationsQuery";
                readonly bffId: "browseReservationsQuery";
                readonly route: "petShop.reservationManagement.browseReservationsQuery";
                readonly kind: "query";
                readonly usecaseRef: "browseReservations";
                readonly usecaseRefs: readonly ["browseReservations"];
                readonly inputTypeName: "BrowseReservationsInput";
                readonly inputContract: readonly [{
                    readonly inputId: "searchTerm";
                    readonly fieldRef: "";
                    readonly type: "string";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Termo de busca para localizar reserva por nome do cliente, telefone ou número da reserva";
                }, {
                    readonly inputId: "statusFilter";
                    readonly fieldRef: "Reservation.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro de status da reserva (pendente, confirmada, atendida ou cancelada)";
                }, {
                    readonly inputId: "page";
                    readonly fieldRef: "";
                    readonly type: "number";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Número da página para paginação dos resultados";
                }, {
                    readonly inputId: "pageSize";
                    readonly fieldRef: "";
                    readonly type: "number";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Quantidade de reservas por página";
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "reservationId";
                        readonly operationId: "browseReservations";
                        readonly path: readonly ["reservationId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "customerName";
                        readonly operationId: "browseReservations";
                        readonly path: readonly ["customerName"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "customerPhone";
                        readonly operationId: "browseReservations";
                        readonly path: readonly ["customerPhone"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "status";
                        readonly operationId: "browseReservations";
                        readonly path: readonly ["status"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "expiresAt";
                        readonly operationId: "browseReservations";
                        readonly path: readonly ["expiresAt"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "createdAt";
                        readonly operationId: "browseReservations";
                        readonly path: readonly ["createdAt"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "updatedAt";
                        readonly operationId: "browseReservations";
                        readonly path: readonly ["updatedAt"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "reservationManagementUpdateReservationStatusCommandHandler";
                readonly command: "updateReservationStatusCommand";
                readonly bffId: "updateReservationStatusCommand";
                readonly route: "petShop.reservationManagement.updateReservationStatusCommand";
                readonly kind: "command";
                readonly usecaseRef: "updateReservationStatus";
                readonly usecaseRefs: readonly ["updateReservationStatus"];
                readonly inputTypeName: "UpdateReservationStatusInput";
                readonly inputContract: readonly [{
                    readonly inputId: "reservationId";
                    readonly fieldRef: "Reservation.reservationId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identificador da reserva a ser atualizada";
                }, {
                    readonly inputId: "newStatus";
                    readonly fieldRef: "Reservation.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Novo status da reserva: confirmed, fulfilled ou cancelled";
                }, {
                    readonly inputId: "cancellationReason";
                    readonly fieldRef: "Reservation.cancellationReason";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Motivo do cancelamento, obrigatório apenas quando o novo status for cancelled";
                }, {
                    readonly inputId: "paymentId";
                    readonly fieldRef: "Reservation.paymentId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Referência ao pagamento presencial associado, obrigatório apenas quando o novo status for fulfilled";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "reservationId";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["reservationId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "customerName";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["customerName"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "customerPhone";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["customerPhone"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "expiresAt";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["expiresAt"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "confirmedAt";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["confirmedAt"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "fulfilledAt";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["fulfilledAt"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "cancelledAt";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["cancelledAt"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "cancellationReason";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["cancellationReason"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "paymentId";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["paymentId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "updatedAt";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["updatedAt"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "reservationManagementProcessPaymentCommandHandler";
                readonly command: "processPaymentCommand";
                readonly bffId: "processPaymentCommand";
                readonly route: "petShop.reservationManagement.processPaymentCommand";
                readonly kind: "command";
                readonly usecaseRef: "processPayment";
                readonly usecaseRefs: readonly ["processPayment"];
                readonly inputTypeName: "ProcessPaymentInput";
                readonly inputContract: readonly [{
                    readonly inputId: "reservationId";
                    readonly fieldRef: "Payment.reservationId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Reserva atualmente selecionada pelo atendente na tela de retirada, associada a este pagamento presencial";
                }, {
                    readonly inputId: "method";
                    readonly fieldRef: "Payment.method";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Método de pagamento escolhido pelo cliente na loja: dinheiro, cartão de crédito, cartão de débito ou pix";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "paymentId";
                        readonly operationId: "processPayment";
                        readonly path: readonly ["paymentId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "reservationId";
                        readonly operationId: "processPayment";
                        readonly path: readonly ["reservationId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "amount";
                        readonly operationId: "processPayment";
                        readonly path: readonly ["amount"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "method";
                        readonly operationId: "processPayment";
                        readonly path: readonly ["method"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "processPayment";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "receivedBy";
                        readonly operationId: "processPayment";
                        readonly path: readonly ["receivedBy"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "createdAt";
                        readonly operationId: "processPayment";
                        readonly path: readonly ["createdAt"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "reservationStatus";
                        readonly operationId: "processPayment";
                        readonly path: readonly ["reservationStatus"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }];
            readonly routes: readonly [{
                readonly key: "petShop.reservationManagement.browseReservationsQuery";
                readonly handlerName: "reservationManagementBrowseReservationsQueryHandler";
            }, {
                readonly key: "petShop.reservationManagement.updateReservationStatusCommand";
                readonly handlerName: "reservationManagementUpdateReservationStatusCommandHandler";
            }, {
                readonly key: "petShop.reservationManagement.processPaymentCommand";
                readonly handlerName: "reservationManagementProcessPaymentCommandHandler";
            }];
        };
    };
    export default reservationManagementController;
    export const pipeline: readonly [{
        readonly id: "reservationManagement__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/reservationManagement.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/reservationManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/browseReservations.d.ts", "_102049_/l4/petShop/contracts/reservationManagement.browseReservationsQuery.defs.ts", "_102049_/l1/petShop/layer_2_application/usecases/updateReservationStatus.d.ts", "_102049_/l4/petShop/contracts/reservationManagement.updateReservationStatusCommand.defs.ts", "_102049_/l1/petShop/layer_2_application/usecases/processPayment.d.ts", "_102049_/l4/petShop/contracts/reservationManagement.processPaymentCommand.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseReservations" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseReservationsInput {
        searchTerm?: string;
        statusFilter?: string;
        page?: number;
        pageSize?: number;
    }
    export interface BrowseReservationsItem {
        reservationId: string;
        customerName: string;
        customerPhone: string;
        status: string;
        expiresAt: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface BrowseReservationsOutput {
        items: BrowseReservationsItem[];
    }
    export function browseReservations(ctx: RequestContext, input: BrowseReservationsInput): Promise<BrowseReservationsOutput>;
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/updateReservationStatus" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateReservationStatusInput {
        reservationId: string;
        newStatus: string;
        cancellationReason?: string;
        paymentId?: string;
    }
    export interface UpdateReservationStatusOutput {
        reservationId: string;
        customerName: string;
        customerPhone: string;
        status: string;
        expiresAt: string;
        confirmedAt?: string;
        fulfilledAt?: string;
        cancelledAt?: string;
        cancellationReason?: string;
        paymentId?: string;
        updatedAt: string;
    }
    export function updateReservationStatus(ctx: RequestContext, input: UpdateReservationStatusInput): Promise<UpdateReservationStatusOutput>;
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/processPayment" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ProcessPaymentInput {
        reservationId: string;
        method: string;
    }
    export interface ProcessPaymentOutput {
        paymentId: string;
        reservationId: string;
        amount: number;
        method: string;
        status: string;
        receivedBy: string;
        createdAt: string;
        reservationStatus: string;
    }
    export function processPayment(ctx: RequestContext, input: ProcessPaymentInput): Promise<ProcessPaymentOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/reservationManagement" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const reservationManagementBrowseReservationsQueryHandler: BffHandler;
    export const reservationManagementUpdateReservationStatusCommandHandler: BffHandler;
    export const reservationManagementProcessPaymentCommandHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/payment.defs" {
    export const paymentTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Payment";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Payment";
            readonly tableName: "payment";
            readonly columns: readonly [{
                readonly name: "payment_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK";
            }, {
                readonly name: "reservation_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "owner FK";
            }, {
                readonly name: "method";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "payment method";
            }, {
                readonly name: "status";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamptz";
                readonly nullable: false;
                readonly description: "ordering timestamp";
            }];
            readonly primaryKey: readonly ["payment_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_payment_reservation_id";
                readonly columns: readonly ["reservation_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_method";
                readonly columns: readonly ["method"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
            readonly appendOnly: true;
            readonly purpose: "controle";
            readonly retentionDays: 365;
        };
    };
    export default paymentTableDefinition;
    export const pipeline: readonly [{
        readonly id: "payment__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/payment.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/payment.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/payment" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const paymentTableDef: TableDefinition;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/paymentRepositoryAdapter.defs" {
    export const paymentRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "PaymentRepositoryAdapter";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "PaymentRepository";
            readonly entityId: "Payment";
            readonly portRef: "IPaymentRepository";
            readonly tableRef: "payments";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns: payment_id, reservation_id, method, status, created_at", "Details JSONB fields: amount, receivedBy, voidedAt, voidReason", "Append-only event adapter: append (insert one row) plus read finders; no update/delete", "No MDM refs; local table accessed via ctx.data.moduleData"];
        };
    };
    export default paymentRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "paymentRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/paymentRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/paymentRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/paymentRepository.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/persistence/payment.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/paymentRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IPaymentRepository } from "_102049_/l1/petShop/layer_2_application/ports/paymentRepository";
    export function createPaymentRepositoryAdapter(ctx: RequestContext): IPaymentRepository;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservationRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IReservationRepository } from "_102049_/l1/petShop/layer_2_application/ports/reservationRepository";
    export function createReservationRepositoryAdapter(ctx: RequestContext): IReservationRepository;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/registerRepositories" { }
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservation.defs" {
    export const reservationTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Reservation";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Reservation";
            readonly tableName: "reservation";
            readonly columns: readonly [{
                readonly name: "reservation_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK";
            }, {
                readonly name: "status";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "payment_id";
                readonly type: "uuid";
                readonly nullable: true;
                readonly description: "FK payment";
            }, {
                readonly name: "created_at";
                readonly type: "timestamptz";
                readonly nullable: false;
                readonly description: "ordering timestamp";
            }];
            readonly primaryKey: readonly ["reservation_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_reservation_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_reservation_payment_id";
                readonly columns: readonly ["payment_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_reservation_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["ReservationItem"];
            };
            readonly purpose: "reservation aggregate";
        };
    };
    export default reservationTableDefinition;
    export const pipeline: readonly [{
        readonly id: "reservation__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservation.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservation.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservation" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const reservationTableDef: TableDefinition;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservationRepositoryAdapter.defs" {
    export const reservationRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ReservationRepositoryAdapter";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ReservationRepository";
            readonly entityId: "Reservation";
            readonly portRef: "IReservationRepository";
            readonly tableRef: "reservations";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns: reservation_id, status, payment_id, created_at", "Details JSONB fields: customerName, customerPhone, expiresAt, confirmedAt, fulfilledAt, cancelledAt, cancellationReason, updatedAt", "Embedded member ReservationItem stored inside details JSONB as items array", "No MDM refs; local table accessed via ctx.data.moduleData"];
        };
    };
    export default reservationRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "reservationRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservationRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservationRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/reservationRepository.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservation.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/seeds" {
    import type { TableSeedRows } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const mdmEntityIndexSeeds: TableSeedRows;
    export const mdmDocumentSeeds: TableSeedRows;
}
declare module "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.defs" {
    export const paymentRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "PaymentRepository";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Payment";
            readonly interfaceName: "IPaymentRepository";
            readonly methods: readonly [{
                readonly name: "append";
                readonly params: readonly ["record: PaymentEvent"];
                readonly returns: "void";
                readonly description: "Append a payment event to the append-only event stream";
            }, {
                readonly name: "listByOwnerId";
                readonly params: readonly ["ownerId: ReservationId"];
                readonly returns: "List<PaymentEvent>";
                readonly description: "Read finder: list payment events for the owning reservation";
            }, {
                readonly name: "listByPeriod";
                readonly params: readonly ["period: DateRange"];
                readonly returns: "List<PaymentEvent>";
                readonly description: "Read finder: list payment events that occurred within the given period";
            }];
        };
    };
    export default paymentRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "paymentRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/ports/reservationRepository.defs" {
    export const reservationRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ReservationRepository";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Reservation";
            readonly interfaceName: "IReservationRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: ReservationId"];
                readonly returns: "Reservation";
                readonly description: "Retrieve a reservation by its unique identifier";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: ReservationFilter"];
                readonly returns: "List<Reservation>";
                readonly description: "List reservations matching the given domain filter";
            }, {
                readonly name: "save";
                readonly params: readonly ["reservation: Reservation"];
                readonly returns: "void";
                readonly description: "Persist the reservation aggregate root and its embedded items";
            }, {
                readonly name: "listByPeriod";
                readonly params: readonly ["period: DateRange"];
                readonly returns: "List<Reservation>";
                readonly description: "Domain finder: list reservations that fall within the given period";
            }, {
                readonly name: "existsById";
                readonly params: readonly ["id: ReservationId"];
                readonly returns: "boolean";
                readonly description: "Domain finder: verify whether a reservation exists";
            }];
        };
    };
    export default reservationRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "reservationRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/ports/reservationRepository.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/ports/reservationRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseFeaturedProducts.defs" {
    export const browseFeaturedProductsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseFeaturedProducts";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseFeaturedProducts";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "browseFeaturedProducts";
                readonly inputTypeName: "BrowseFeaturedProductsInput";
                readonly outputTypeName: "BrowseFeaturedProductsOutput";
                readonly input: readonly [{
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly fieldRef: "Product.categoryId";
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly fieldRef: "Product.petTypeId";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly fieldRef: "Product.name";
                }, {
                    readonly name: "priceMin";
                    readonly type: "number";
                    readonly required: false;
                    readonly fieldRef: "Product.price";
                }, {
                    readonly name: "priceMax";
                    readonly type: "number";
                    readonly required: false;
                    readonly fieldRef: "Product.price";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "isFeatured";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["featuredProductsOnly", "featuredOrderFlexible", "combinedFilters", "caseInsensitiveSearch"];
                readonly transactional: false;
                readonly steps: readonly ["list Product records via ctx.mdm.collection.listByType({ type: 'Product' })", "apply featuredProductsOnly: keep only products where isFeatured === true", "apply combinedFilters: when categoryId provided, filter by Product.categoryId; when petTypeId provided, filter by Product.petTypeId; when priceMin provided, keep price >= priceMin; when priceMax provided, keep price <= priceMax — all active filters combine with AND", "apply caseInsensitiveSearch: when name provided, keep products whose name includes the term case-insensitively", "apply featuredOrderFlexible: preserve a stable flexible order suitable for a featured showcase (no rigid sort required beyond featured set)", "apply optional pagination with page/pageSize when provided", "project each item to outputShape fields: productId, name, price, isFeatured, categoryId, petTypeId", "return the projected list"];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "productId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.productId";
                    }, {
                        readonly name: "name";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.name";
                    }, {
                        readonly name: "price";
                        readonly type: "number";
                        readonly required: true;
                        readonly fieldRef: "Product.price";
                    }, {
                        readonly name: "isFeatured";
                        readonly type: "boolean";
                        readonly required: true;
                        readonly fieldRef: "Product.isFeatured";
                    }, {
                        readonly name: "categoryId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.categoryId";
                    }, {
                        readonly name: "petTypeId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.petTypeId";
                    }];
                };
            }];
            readonly rulesApplied: readonly ["featuredProductsOnly", "featuredOrderFlexible", "combinedFilters", "caseInsensitiveSearch"];
            readonly mdmRefs: readonly ["Product"];
        };
    };
    export default browseFeaturedProductsUsecase;
    export const pipeline: readonly [{
        readonly id: "browseFeaturedProducts__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/browseFeaturedProducts.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/browseFeaturedProducts.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["featuredProductsOnly", "featuredOrderFlexible", "combinedFilters", "caseInsensitiveSearch"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseProducts.defs" {
    export const browseProductsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseProducts";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseProducts";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "browseProducts";
                readonly inputTypeName: "BrowseProductsInput";
                readonly outputTypeName: "BrowseProductsOutput";
                readonly input: readonly [{
                    readonly name: "searchName";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "minPrice";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "maxPrice";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "items";
                    readonly type: "array";
                    readonly required: true;
                }, {
                    readonly name: "total";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: true;
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["catalogShowsAll", "combinedFilters", "caseInsensitiveSearch"];
                readonly transactional: false;
                readonly steps: readonly ["default page to 1 and pageSize to a sensible page size when omitted", "list all Product records via ctx.mdm.collection.listByType (catalogShowsAll: do not filter by isFeatured)", "apply combinedFilters in memory: optional petTypeId equality, optional categoryId equality, optional minPrice/maxPrice numeric range on price (parse string inputs), optional searchName case-insensitive partial match on name (caseInsensitiveSearch)", "collect distinct categoryId and petTypeId from the filtered set; bulk-load ProductCategory and PetType via ctx.mdm.collection.getMany (plural-first, no per-item get)", "map each product to the output item shape joining categoryName and petTypeName from the hydrated MDM maps", "compute total as filtered length; slice items by page/pageSize; return { items, total, page, pageSize }"];
                readonly outputShape: {
                    readonly kind: "paginated";
                    readonly fields: readonly [{
                        readonly name: "items";
                        readonly type: "array";
                        readonly required: true;
                        readonly item: {
                            readonly fields: readonly [{
                                readonly name: "productId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.productId";
                            }, {
                                readonly name: "name";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.name";
                            }, {
                                readonly name: "price";
                                readonly type: "number";
                                readonly required: true;
                                readonly fieldRef: "Product.price";
                            }, {
                                readonly name: "isFeatured";
                                readonly type: "boolean";
                                readonly required: true;
                                readonly fieldRef: "Product.isFeatured";
                            }, {
                                readonly name: "categoryId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.categoryId";
                            }, {
                                readonly name: "categoryName";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "ProductCategory.name";
                            }, {
                                readonly name: "petTypeId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.petTypeId";
                            }, {
                                readonly name: "petTypeName";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "PetType.name";
                            }, {
                                readonly name: "createdAt";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.createdAt";
                            }, {
                                readonly name: "updatedAt";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.updatedAt";
                            }];
                        };
                    }, {
                        readonly name: "total";
                        readonly type: "number";
                        readonly required: true;
                    }, {
                        readonly name: "page";
                        readonly type: "number";
                        readonly required: true;
                    }, {
                        readonly name: "pageSize";
                        readonly type: "number";
                        readonly required: true;
                    }];
                };
            }];
            readonly rulesApplied: readonly ["catalogShowsAll", "combinedFilters", "caseInsensitiveSearch"];
            readonly mdmRefs: readonly ["Product", "ProductCategory", "PetType"];
        };
    };
    export default browseProductsUsecase;
    export const pipeline: readonly [{
        readonly id: "browseProducts__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/browseProducts.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/browseProducts.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["catalogShowsAll", "combinedFilters", "caseInsensitiveSearch"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseReservations.defs" {
    export const browseReservationsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseReservations";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseReservations";
            readonly ports: readonly ["Reservation", "Payment"];
            readonly functions: readonly [{
                readonly functionName: "browseReservations";
                readonly inputTypeName: "BrowseReservationsInput";
                readonly outputTypeName: "BrowseReservationsOutput";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "statusFilter";
                    readonly type: "string";
                    readonly required: false;
                    readonly fieldRef: "Reservation.status";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "customerPhone";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "expiresAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }];
                readonly ports: readonly ["Reservation"];
                readonly rulesApplied: readonly ["reservationStatuses", "reservationValidity24h"];
                readonly transactional: false;
                readonly steps: readonly ["Resolve actorId from ctx.sessionContext (actorSession) for audit context only; do not require it as input", "Load reservations via Reservation port (resolveRepository)", "Inline reservationStatuses: keep only items whose status is one of pending|confirmed|fulfilled|cancelled; if statusFilter is provided, validate it is one of those values (else validation error with rule id reservationStatuses) and retain only matching status", "When searchTerm is provided, filter where customerName, customerPhone or reservationId contains the term (case-insensitive)", "Inline reservationValidity24h: for each pending reservation, ensure expiresAt reflects createdAt + 24h (surface the stored expiresAt; do not invent a different validity window)", "Sort by createdAt descending", "Apply optional page/pageSize pagination", "Project each item to reservationId, customerName, customerPhone, status, expiresAt, createdAt, updatedAt and return the list"];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "reservationId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.reservationId";
                    }, {
                        readonly name: "customerName";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.customerName";
                    }, {
                        readonly name: "customerPhone";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.customerPhone";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.status";
                    }, {
                        readonly name: "expiresAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.expiresAt";
                    }, {
                        readonly name: "createdAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.createdAt";
                    }, {
                        readonly name: "updatedAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.updatedAt";
                    }];
                };
            }];
            readonly rulesApplied: readonly ["reservationStatuses", "reservationValidity24h"];
            readonly mdmRefs: readonly [];
        };
    };
    export default browseReservationsUsecase;
    export const pipeline: readonly [{
        readonly id: "browseReservations__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/browseReservations.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/browseReservations.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/reservationRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["reservationStatuses", "reservationValidity24h"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/createReservation.defs" {
    export const createReservationUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createReservation";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createReservation";
            readonly ports: readonly ["Reservation", "Payment"];
            readonly functions: readonly [{
                readonly functionName: "createReservation";
                readonly inputTypeName: "CreateReservationInput";
                readonly outputTypeName: "CreateReservationOutput";
                readonly input: readonly [{
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                    readonly fieldRef: "Reservation.customerName";
                }, {
                    readonly name: "customerPhone";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                    readonly fieldRef: "Reservation.customerPhone";
                }, {
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly fieldRef: "Product.productId";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "customerPhone";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "expiresAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "items";
                    readonly type: "array";
                    readonly required: true;
                }];
                readonly ports: readonly ["Reservation", "Payment"];
                readonly rulesApplied: readonly ["reservationRequiresContact", "reservationValidity24h", "reservationStatuses"];
                readonly transactional: true;
                readonly steps: readonly ["Validate reservationRequiresContact: customerName and customerPhone are non-empty after trim; reject with rule id if missing", "Validate quantity is a positive number; reject if invalid", "Load Product by productId via ctx.mdm.entity.get({ mdmId: productId }); reject if not found", "Generate reservationId via ctx.idGenerator and now via ctx.clock", "Apply reservationValidity24h: set expiresAt = now + 24 hours; set createdAt and updatedAt = now", "Apply reservationStatuses: set initial status to 'pending'", "Build Reservation aggregate with customerName, customerPhone, status pending, expiresAt, timestamps, and embedded ReservationItem (reservationItemId from ctx.idGenerator, productId, quantity, timestamps)", "Inside ctx.data.transaction: save Reservation via Reservation port; build and append audit Payment event record via Payment port (append-only, same tx)", "Return reservationId, customerName, customerPhone, status, expiresAt, createdAt, and items [{ productId, productName from MDM Product.name, quantity }]"];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "reservationId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.reservationId";
                    }, {
                        readonly name: "customerName";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.customerName";
                    }, {
                        readonly name: "customerPhone";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.customerPhone";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.status";
                    }, {
                        readonly name: "expiresAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.expiresAt";
                    }, {
                        readonly name: "createdAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.createdAt";
                    }, {
                        readonly name: "items";
                        readonly type: "array";
                        readonly required: true;
                        readonly item: {
                            readonly fields: readonly [{
                                readonly name: "productId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.productId";
                            }, {
                                readonly name: "productName";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.name";
                            }, {
                                readonly name: "quantity";
                                readonly type: "number";
                                readonly required: true;
                                readonly fieldRef: "ReservationItem.quantity";
                            }];
                        };
                    }];
                };
            }];
            readonly rulesApplied: readonly ["reservationRequiresContact", "reservationValidity24h", "reservationStatuses"];
            readonly mdmRefs: readonly ["Product"];
        };
    };
    export default createReservationUsecase;
    export const pipeline: readonly [{
        readonly id: "createReservation__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/createReservation.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/createReservation.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/reservationRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["reservationRequiresContact", "reservationValidity24h", "reservationStatuses"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/processPayment.defs" {
    export const processPaymentUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "processPayment";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "processPayment";
            readonly ports: readonly ["Reservation", "Payment"];
            readonly functions: readonly [{
                readonly functionName: "processPayment";
                readonly inputTypeName: "ProcessPaymentInput";
                readonly outputTypeName: "ProcessPaymentOutput";
                readonly input: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                    readonly fieldRef: "Payment.reservationId";
                }, {
                    readonly name: "method";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                    readonly fieldRef: "Payment.method";
                }];
                readonly output: readonly [{
                    readonly name: "paymentId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                }, {
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                }, {
                    readonly name: "amount";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                }, {
                    readonly name: "method";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                }, {
                    readonly name: "receivedBy";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                }, {
                    readonly name: "reservationStatus";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly ports: readonly ["Reservation", "Payment"];
                readonly rulesApplied: readonly ["inStorePaymentOnly", "totalFromPricesAndQuantities", "paymentRequiresReceipt"];
                readonly transactional: true;
                readonly steps: readonly ["Validate method is one of cash|creditCard|debitCard|pix (inStorePaymentOnly); reject otherwise with rule id in error details", "Resolve receivedBy from ctx.sessionContext.actorId (actorSession); reject if missing (paymentRequiresReceipt — presencial confirmation by logged attendant)", "Load Reservation by input.reservationId via Reservation port; reject if not found", "Validate reservation.status is confirmed (eligible for in-store payment/fulfillment); reject if already fulfilled/cancelled/pending", "Read embedded ReservationItem collection from the loaded reservation (parent aggregate); collect productIds", "Bulk-load Product MDM records via ctx.mdm.collection.getMany({ mdmIds: productIds })", "Compute amount = sum(item.quantity * product.price) for all items (totalFromPricesAndQuantities); reject if no items or any product missing price", "Generate paymentId via ctx.idGenerator and createdAt via ctx.clock; set status to posted", "Inside ctx.data transaction: append Payment audit event { paymentId, reservationId, amount, method, status: posted, receivedBy, createdAt } via Payment port; mutate reservation status to fulfilled, set paymentId, fulfilledAt=now, updatedAt=now; save Reservation via Reservation port", "Return paymentId, reservationId, amount, method, status, receivedBy, createdAt, reservationStatus (fulfilled)"];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "paymentId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Payment.paymentId";
                    }, {
                        readonly name: "reservationId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Payment.reservationId";
                    }, {
                        readonly name: "amount";
                        readonly type: "number";
                        readonly required: true;
                        readonly fieldRef: "Payment.amount";
                    }, {
                        readonly name: "method";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Payment.method";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Payment.status";
                    }, {
                        readonly name: "receivedBy";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Payment.receivedBy";
                    }, {
                        readonly name: "createdAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Payment.createdAt";
                    }, {
                        readonly name: "reservationStatus";
                        readonly type: "string";
                        readonly required: true;
                    }];
                };
            }];
            readonly rulesApplied: readonly ["inStorePaymentOnly", "totalFromPricesAndQuantities", "paymentRequiresReceipt"];
            readonly mdmRefs: readonly ["Product"];
        };
    };
    export default processPaymentUsecase;
    export const pipeline: readonly [{
        readonly id: "processPayment__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/processPayment.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/processPayment.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/reservationRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["inStorePaymentOnly", "totalFromPricesAndQuantities", "paymentRequiresReceipt"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/updateReservationStatus.defs" {
    export const updateReservationStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateReservationStatus";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateReservationStatus";
            readonly ports: readonly ["Reservation", "Payment"];
            readonly functions: readonly [{
                readonly functionName: "updateReservationStatus";
                readonly inputTypeName: "UpdateReservationStatusInput";
                readonly outputTypeName: "UpdateReservationStatusOutput";
                readonly input: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                    readonly fieldRef: "Reservation.reservationId";
                }, {
                    readonly name: "newStatus";
                    readonly type: "string";
                    readonly required: true;
                    readonly fieldRef: "Reservation.status";
                }, {
                    readonly name: "cancellationReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                    readonly fieldRef: "Reservation.cancellationReason";
                }, {
                    readonly name: "paymentId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                    readonly fieldRef: "Reservation.paymentId";
                }];
                readonly output: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "customerPhone";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "expiresAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "confirmedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "fulfilledAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "cancelledAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "cancellationReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "paymentId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }];
                readonly ports: readonly ["Reservation", "Payment"];
                readonly rulesApplied: readonly ["reservationStatuses", "reservationValidity24h"];
                readonly transactional: true;
                readonly steps: readonly ["resolve Reservation port and load reservation by input.reservationId; fail if not found", "apply reservationStatuses inline: newStatus must be one of pending|confirmed|fulfilled|cancelled; allow only valid transitions from current status (pending->confirmed|cancelled, confirmed->fulfilled|cancelled); include rule id in validation error details when blocked", "when newStatus is cancelled, require cancellationReason; when newStatus is fulfilled, require paymentId; otherwise reject with rule-aware validation error", "apply reservationValidity24h inline: if reservation.expiresAt is before ctx.clock.now(), only cancellation is allowed (attendant may cancel expired reservations); block confirm/fulfill of expired reservations with rule id in error details", "inside ctx.data transaction: set status to newStatus; set confirmedAt/fulfilledAt/cancelledAt from ctx.clock.now() according to the target status; set cancellationReason when cancelling; set paymentId when fulfilling; always set updatedAt to ctx.clock.now()", "save Reservation aggregate via Reservation port", "when transitioning to fulfilled with paymentId, build append-only Payment audit event record and append via Payment port in the same transaction (never update/delete)", "return outputShape fields from the updated Reservation"];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "reservationId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.reservationId";
                    }, {
                        readonly name: "customerName";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.customerName";
                    }, {
                        readonly name: "customerPhone";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.customerPhone";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.status";
                    }, {
                        readonly name: "expiresAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.expiresAt";
                    }, {
                        readonly name: "confirmedAt";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.confirmedAt";
                    }, {
                        readonly name: "fulfilledAt";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.fulfilledAt";
                    }, {
                        readonly name: "cancelledAt";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.cancelledAt";
                    }, {
                        readonly name: "cancellationReason";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.cancellationReason";
                    }, {
                        readonly name: "paymentId";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.paymentId";
                    }, {
                        readonly name: "updatedAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.updatedAt";
                    }];
                };
            }];
            readonly rulesApplied: readonly ["reservationStatuses", "reservationValidity24h"];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateReservationStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateReservationStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/updateReservationStatus.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/updateReservationStatus.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/reservationRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["reservationStatuses", "reservationValidity24h"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/viewProductDetails.defs" {
    export const viewProductDetailsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewProductDetails";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewProductDetails";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "viewProductDetails";
                readonly inputTypeName: "ViewProductDetailsInput";
                readonly outputTypeName: "ViewProductDetailsOutput";
                readonly input: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly fieldRef: "Product.productId";
                }];
                readonly output: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "isFeatured";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "categoryName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ProductCategory";
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "petTypeName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "PetType";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Load Product by input.productId via ctx.mdm.entity.get({ mdmId: productId })", "If product is not found, return not-found error indicating produto não encontrado", "Collect categoryId and petTypeId from the product; bulk-read ProductCategory and PetType via ctx.mdm.collection.getMany({ mdmIds: [categoryId, petTypeId] })", "Resolve categoryName from the ProductCategory record and petTypeName from the PetType record", "Return productId, name, price, isFeatured, categoryId, categoryName, petTypeId, petTypeName, createdAt, updatedAt"];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "productId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.productId";
                    }, {
                        readonly name: "name";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.name";
                    }, {
                        readonly name: "price";
                        readonly type: "number";
                        readonly required: true;
                        readonly fieldRef: "Product.price";
                    }, {
                        readonly name: "isFeatured";
                        readonly type: "boolean";
                        readonly required: true;
                        readonly fieldRef: "Product.isFeatured";
                    }, {
                        readonly name: "categoryId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.categoryId";
                    }, {
                        readonly name: "categoryName";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "ProductCategory.name";
                    }, {
                        readonly name: "petTypeId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.petTypeId";
                    }, {
                        readonly name: "petTypeName";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "PetType.name";
                    }, {
                        readonly name: "createdAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.createdAt";
                    }, {
                        readonly name: "updatedAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.updatedAt";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Product", "ProductCategory", "PetType"];
        };
    };
    export default viewProductDetailsUsecase;
    export const pipeline: readonly [{
        readonly id: "viewProductDetails__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/viewProductDetails.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/viewProductDetails.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/payment.defs" {
    export const paymentDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Payment";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Payment";
            readonly title: "Payment";
            readonly fields: readonly [{
                readonly fieldId: "paymentId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do registro de pagamento.";
            }, {
                readonly fieldId: "reservationId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência à reserva associada a este pagamento presencial.";
            }, {
                readonly fieldId: "amount";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor total recebido, calculado a partir dos preços dos produtos e quantidades reservadas.";
            }, {
                readonly fieldId: "method";
                readonly type: "string";
                readonly required: true;
                readonly description: "Método de pagamento utilizado pelo cliente na loja.";
                readonly enum: readonly ["cash", "creditCard", "debitCard", "pix"];
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação atual do registro de pagamento.";
                readonly enum: readonly ["posted", "voided"];
            }, {
                readonly fieldId: "receivedBy";
                readonly type: "string";
                readonly required: true;
                readonly description: "Identificador do atendente que confirmou o recebimento do pagamento.";
            }, {
                readonly fieldId: "voidedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que o pagamento foi cancelado ou estornado.";
            }, {
                readonly fieldId: "voidReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo do cancelamento ou estorno do pagamento.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora em que o pagamento foi registrado no sistema.";
            }];
            readonly invariants: readonly [];
            readonly statusEnum: readonly ["posted", "voided"];
        };
    };
    export default paymentDomainEntity;
    export const pipeline: readonly [{
        readonly id: "payment__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/petShop/layer_3_domain/entities/payment.ts";
        readonly defPath: "_102049_/l1/petShop/layer_3_domain/entities/payment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/reservation.defs" {
    export const reservationDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Reservation";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Reservation";
            readonly title: "Reservation";
            readonly fields: readonly [{
                readonly fieldId: "reservationId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único da reserva";
            }, {
                readonly fieldId: "customerName";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do cliente que fez a reserva";
            }, {
                readonly fieldId: "customerPhone";
                readonly type: "string";
                readonly required: true;
                readonly description: "Telefone de contato do cliente";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Status de atendimento da reserva controlado pelo atendente";
                readonly enum: readonly ["pending", "confirmed", "fulfilled", "cancelled"];
            }, {
                readonly fieldId: "expiresAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de validade da reserva, 24 horas após o registro";
            }, {
                readonly fieldId: "confirmedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que a reserva foi confirmada pelo atendente";
            }, {
                readonly fieldId: "fulfilledAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que a reserva foi atendida com retirada e pagamento confirmado";
            }, {
                readonly fieldId: "cancelledAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que a reserva foi cancelada";
            }, {
                readonly fieldId: "cancellationReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo do cancelamento da reserva registrado pelo atendente";
            }, {
                readonly fieldId: "paymentId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência ao pagamento presencial associado quando a reserva é atendida";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação da reserva";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização da reserva";
            }];
            readonly valueObjects: readonly [{
                readonly name: "ReservationItem";
                readonly collection: true;
                readonly fields: readonly [{
                    readonly fieldId: "reservationItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do item de reserva.";
                }, {
                    readonly fieldId: "reservationId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência à reserva à qual este item pertence.";
                }, {
                    readonly fieldId: "productId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao produto do catálogo que foi reservado.";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade do produto reservada pelo cliente.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do item de reserva.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do item de reserva.";
                }];
            }];
            readonly invariants: readonly ["expiresAt must be exactly 24 hours after createdAt", "status='confirmed' implies confirmedAt is set", "status='fulfilled' implies fulfilledAt is set and paymentId is set", "status='cancelled' implies cancelledAt is set and cancellationReason is set", "confirmedAt, fulfilledAt, cancelledAt (when present) must be on or after createdAt", "fulfilledAt and cancelledAt are mutually exclusive", "status transitions must be valid: pending -> confirmed|cancelled; confirmed -> fulfilled|cancelled; fulfilled and cancelled are terminal"];
            readonly statusEnum: readonly ["pending", "confirmed", "fulfilled", "cancelled"];
        };
    };
    export default reservationDomainEntity;
    export const pipeline: readonly [{
        readonly id: "reservation__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/petShop/layer_3_domain/entities/reservation.ts";
        readonly defPath: "_102049_/l1/petShop/layer_3_domain/entities/reservation.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l2/designSystem" {
    import { IDesignSystemTokens } from '_102029_/l2/designSystemBase';
    /**
     * Design system do projeto — vocabulário de tokens POR PAPEL (role-based).
     * Este vocabulário é o padrão para novos projetos; só os VALORES mudam por marca.
     *
     * Regras de nomenclatura (color):
     *  - O nome diz onde o token é usado; nunca deduza pelo valor.
     *  - Pares bg/text andam juntos: quem usa button-primary-bg escreve o rótulo
     *    com button-primary-text; quem usa status-error-bg usa status-error-text;
     *    nav-bg com nav-text; tooltip-bg com tooltip-text. Vale para todo par
     *    <papel>-bg / <papel>-text.
     *  - Superfícies: page-bg (fundo da página) > surface-bg (cards, painéis,
     *    modais) > surface-alt-bg (linhas zebradas, hover de linha, skeleton,
     *    cabeçalhos de seção). Texto sobre superfícies: text-strong (títulos),
     *    text-default (corpo), text-muted (secundário/placeholder).
     *  - Navegação (sidebar/topbar): nav-bg + nav-text; item ativo usa
     *    nav-active-bg + nav-active-text.
     *  - Overlay de modal: overlay-backdrop-bg atrás, surface-bg no modal.
     *  - Gráficos: séries usam chart-series-1..6 SEMPRE nesta ordem fixa (a ordem
     *    é o mecanismo de segurança para daltonismo — nunca embaralhar nem gerar
     *    cores novas); textos e eixos usam os tokens text-*, nunca a cor da série;
     *    status-* são reservados a estado e nunca viram série de gráfico.
     *  - Todo token base de cor tem as variantes -hover, -focus e -disabled
     *    (em chart-series, -disabled é a série apagada pela legenda).
     *  - Modo noite: cada chave tem par com prefixo _dark- (mesmo nome). O
     *    compilador gera o bloco dark automaticamente; paginas usam so o nome base.
     */
    export const tokens: IDesignSystemTokens[];
}
declare module "_102049_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102049_/l2/petShop/web/contracts/catalog.browseCatalog" {
    export interface BrowseCatalogInput {
        searchName?: string;
        petTypeId?: string;
        categoryId?: string;
        minPrice?: number;
        maxPrice?: number;
        page?: number;
        pageSize?: number;
    }
    export interface BrowseCatalogOutput {
        items: {
            productId: string;
            name: string;
            price: number;
            isFeatured: boolean;
            categoryId: string;
            categoryName: string;
            petTypeId: string;
            petTypeName: string;
            createdAt: string;
            updatedAt: string;
        }[];
        total: number;
        page: number;
        pageSize: number;
    }
    export const browseCatalogRoute: "petShop.catalog.browseCatalog";
}
declare module "_102049_/l2/petShop/web/contracts/catalog.featuredProducts" {
    export interface FeaturedProductsInput {
        categoryId?: string;
        petTypeId?: string;
        name?: string;
        priceMin?: number;
        priceMax?: number;
        page?: number;
        pageSize?: number;
    }
    export interface FeaturedProductsOutput {
        productId: string;
        name: string;
        price: number;
        isFeatured: boolean;
        categoryId: string;
        petTypeId: string;
    }
    export const featuredProductsRoute: "petShop.catalog.featuredProducts";
}
declare module "_102049_/l2/petShop/web/contracts/catalog.productDetails" {
    export interface ProductDetailsInput {
        productId: string;
    }
    export interface ProductDetailsOutput {
        productId: string;
        name: string;
        price: number;
        isFeatured: boolean;
        categoryId: string;
        categoryName: string;
        petTypeId: string;
        petTypeName: string;
        createdAt: string;
        updatedAt: string;
    }
    export const productDetailsRoute: "petShop.catalog.productDetails";
}
declare module "_102049_/l2/petShop/web/contracts/catalog.reserveProduct" {
    export interface ReserveProductInput {
        customerName: string;
        customerPhone: string;
        productId: string;
        quantity: number;
    }
    export interface ReserveProductOutput {
        reservationId: string;
        customerName: string;
        customerPhone: string;
        status: string;
        expiresAt: string;
        createdAt: string;
        items: {
            productId: string;
            productName: string;
            quantity: number;
        }[];
    }
    export const reserveProductRoute: "petShop.catalog.reserveProduct";
}
declare module "_102049_/l2/petShop/web/contracts/reservationManagement.browseReservationsQuery" {
    export interface BrowseReservationsQueryInput {
        searchTerm?: string;
        statusFilter?: string;
        page?: number;
        pageSize?: number;
    }
    export interface BrowseReservationsQueryOutput {
        reservationId: string;
        customerName: string;
        customerPhone: string;
        status: string;
        expiresAt: string;
        createdAt: string;
        updatedAt: string;
    }
    export const browseReservationsQueryRoute: "petShop.reservationManagement.browseReservationsQuery";
}
declare module "_102049_/l2/petShop/web/contracts/reservationManagement.processPaymentCommand" {
    export interface ProcessPaymentCommandInput {
        reservationId: string;
        method: string;
    }
    export interface ProcessPaymentCommandOutput {
        paymentId: string;
        reservationId: string;
        amount: number;
        method: string;
        status: string;
        receivedBy: string;
        createdAt: string;
        reservationStatus: string;
    }
    export const processPaymentCommandRoute: "petShop.reservationManagement.processPaymentCommand";
}
declare module "_102049_/l2/petShop/web/contracts/reservationManagement.updateReservationStatusCommand" {
    export interface UpdateReservationStatusCommandInput {
        reservationId: string;
        newStatus: string;
        cancellationReason?: string;
        paymentId?: string;
    }
    export interface UpdateReservationStatusCommandOutput {
        reservationId: string;
        customerName: string;
        customerPhone: string;
        status: string;
        expiresAt: string;
        confirmedAt: string;
        fulfilledAt: string;
        cancelledAt: string;
        cancellationReason: string;
        paymentId: string;
        updatedAt: string;
    }
    export const updateReservationStatusCommandRoute: "petShop.reservationManagement.updateReservationStatusCommand";
}
declare module "_102049_/l2/petShop/web/desktop/page11/catalog.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        emptyKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        emptyKey: string;
                        fields: any[];
                        columns: any[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                })[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        emptyKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        emptyKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            })[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "catalog__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/catalog.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/catalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/catalog.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["catalog__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Storefront-first, catálogo limpo com busca e filtros, fluxo de reserva simples, UI de gestão do atendente orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/desktop/page11/catalog.test" {
    export const pageTests: {
        readonly moduleName: "petShop";
        readonly page: "catalog";
        readonly variant: "page11";
        readonly cases: readonly [{
            readonly id: "featuredProducts.ok";
            readonly routine: "petShop.catalog.featuredProducts";
            readonly params: {};
            readonly expect: {
                readonly ok: true;
                readonly shape: "array";
                readonly minItems: 1;
            };
        }, {
            readonly id: "browseCatalog.ok";
            readonly routine: "petShop.catalog.browseCatalog";
            readonly params: {};
            readonly expect: {
                readonly ok: true;
                readonly shape: "paginated";
                readonly minItems: 1;
            };
        }, {
            readonly id: "productDetails.ok";
            readonly routine: "petShop.catalog.productDetails";
            readonly params: {
                readonly productId: "<seedRef>";
            };
            readonly expect: {
                readonly ok: true;
                readonly shape: "object";
            };
        }, {
            readonly id: "reserveProduct.ok";
            readonly routine: "petShop.catalog.reserveProduct";
            readonly params: {
                readonly customerName: "<seedRef>";
                readonly customerPhone: "<seedRef>";
                readonly productId: "<seedRef>";
                readonly quantity: "<seedRef>";
            };
            readonly expect: {
                readonly ok: true;
                readonly shape: "object";
            };
            readonly mutating: true;
        }, {
            readonly id: "reserveProduct.customerName.required";
            readonly routine: "petShop.catalog.reserveProduct";
            readonly params: {
                readonly customerPhone: "<seedRef>";
                readonly productId: "<seedRef>";
                readonly quantity: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }, {
            readonly id: "reserveProduct.customerPhone.required";
            readonly routine: "petShop.catalog.reserveProduct";
            readonly params: {
                readonly customerName: "<seedRef>";
                readonly productId: "<seedRef>";
                readonly quantity: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }, {
            readonly id: "reserveProduct.quantity.required";
            readonly routine: "petShop.catalog.reserveProduct";
            readonly params: {
                readonly customerName: "<seedRef>";
                readonly customerPhone: "<seedRef>";
                readonly productId: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }];
    };
}
declare module "_102049_/l2/petShop/web/shared/catalog" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { FeaturedProductsOutput } from "_102049_/l2/petShop/web/contracts/catalog.featuredProducts";
    import type { BrowseCatalogOutput } from "_102049_/l2/petShop/web/contracts/catalog.browseCatalog";
    import type { ProductDetailsOutput } from "_102049_/l2/petShop/web/contracts/catalog.productDetails";
    import type { ReserveProductOutput } from "_102049_/l2/petShop/web/contracts/catalog.reserveProduct";
    export type { FeaturedProductsInput, FeaturedProductsOutput } from "_102049_/l2/petShop/web/contracts/catalog.featuredProducts";
    export type { BrowseCatalogInput, BrowseCatalogOutput } from "_102049_/l2/petShop/web/contracts/catalog.browseCatalog";
    export type { ProductDetailsInput, ProductDetailsOutput } from "_102049_/l2/petShop/web/contracts/catalog.productDetails";
    export type { ReserveProductInput, ReserveProductOutput } from "_102049_/l2/petShop/web/contracts/catalog.reserveProduct";
    const message_pt: {
        "org.vitrine.cards.title": string;
        "int.vitrine.list.title": string;
        "int.vitrine.list.empty": string;
        "org.vitrine.filters.title": string;
        "int.vitrine.filters.title": string;
        "int.vitrine.filters.empty": string;
        "org.catalogo.cards.title": string;
        "int.catalogo.list.title": string;
        "int.catalogo.list.empty": string;
        "org.catalogo.filters.title": string;
        "int.catalogo.filters.title": string;
        "int.catalogo.filters.empty": string;
        "org.detalhe.card.title": string;
        "int.detalhe.view.title": string;
        "int.detalhe.view.empty": string;
        "org.reserva.form.title": string;
        "int.reserva.form.title": string;
        "int.reserva.form.empty": string;
        "field.name": string;
        "field.price": string;
        "field.isFeatured": string;
        "field.categoryId": string;
        "field.petTypeId": string;
        "field.priceMin": string;
        "field.priceMax": string;
        "field.page": string;
        "field.pageSize": string;
        "field.items": string;
        "field.searchName": string;
        "field.minPrice": string;
        "field.maxPrice": string;
        "field.categoryName": string;
        "field.petTypeName": string;
        "field.createdAt": string;
        "field.updatedAt": string;
        "field.productId": string;
        "field.quantity": string;
        "field.customerName": string;
        "field.customerPhone": string;
        "action.productDetails": string;
        "action.applyFilters": string;
        "action.reserveProduct": string;
        "action.reserveProduct.success": string;
        "action.reserveProduct.error": string;
        "sec.vitrine.title": string;
        "sec.catalogo.title": string;
        "sec.detalhe.reserva.title": string;
        "section.vitrine.title": string;
        "section.vitrine.featured.title": string;
        "section.vitrine.featured.empty": string;
        "organism.vitrine.featured.title": string;
        "section.catalogo.title": string;
        "section.catalogo.browse.title": string;
        "section.catalogo.browse.empty": string;
        "organism.catalogo.browse.title": string;
        "section.detalheReserva.title": string;
        "section.detalhe.product.title": string;
        "section.detalhe.product.empty": string;
        "organism.detalhe.product.title": string;
        "section.detalhe.reserve.title": string;
        "section.detalhe.reserve.empty": string;
        "organism.detalhe.reserve.title": string;
        "field.product.name": string;
        "field.product.price": string;
        "field.product.isFeatured": string;
        "field.product.categoryId": string;
        "field.product.petTypeId": string;
        "field.product.categoryName": string;
        "field.product.petTypeName": string;
        "field.reserve.quantity": string;
        "field.reserve.customerName": string;
        "field.reserve.customerPhone": string;
        "filter.featured.categoryId": string;
        "filter.featured.petTypeId": string;
        "filter.featured.name": string;
        "filter.featured.priceMin": string;
        "filter.featured.priceMax": string;
        "filter.browse.searchName": string;
        "filter.browse.petTypeId": string;
        "filter.browse.categoryId": string;
        "filter.browse.minPrice": string;
        "filter.browse.maxPrice": string;
    };
    type MessageType = typeof message_pt;
    type ActionStatus = "idle" | "loading" | "success" | "error";
    export class PetShopCatalogBase extends CollabLitElement {
        /** state ui.catalog.status — pageStatus */
        status: string;
        /** state ui.catalog.action.featuredProducts.status — actionStatus, values: idle|loading|success|error */
        featuredProductsState: ActionStatus;
        /** state ui.catalog.input.featuredProducts.categoryId — input */
        featuredProductsCategoryId: string;
        /** state ui.catalog.input.featuredProducts.petTypeId — input */
        featuredProductsPetTypeId: string;
        /** state ui.catalog.input.featuredProducts.name — input */
        featuredProductsName: string;
        /** state ui.catalog.input.featuredProducts.priceMin — input */
        featuredProductsPriceMin: string;
        /** state ui.catalog.input.featuredProducts.priceMax — input */
        featuredProductsPriceMax: string;
        /** state ui.catalog.input.featuredProducts.page — input */
        featuredProductsPage: string;
        /** state ui.catalog.input.featuredProducts.pageSize — input */
        featuredProductsPageSize: string;
        /** state ui.catalog.data.featuredProducts — queryResult, outputShape: array */
        featuredProductsData: FeaturedProductsOutput[];
        /** state ui.catalog.action.browseCatalog.status — actionStatus, values: idle|loading|success|error */
        browseCatalogState: ActionStatus;
        /** state ui.catalog.input.browseCatalog.searchName — input */
        browseCatalogSearchName: string;
        /** state ui.catalog.input.browseCatalog.petTypeId — input */
        browseCatalogPetTypeId: string;
        /** state ui.catalog.input.browseCatalog.categoryId — input */
        browseCatalogCategoryId: string;
        /** state ui.catalog.input.browseCatalog.minPrice — input */
        browseCatalogMinPrice: string;
        /** state ui.catalog.input.browseCatalog.maxPrice — input */
        browseCatalogMaxPrice: string;
        /** state ui.catalog.input.browseCatalog.page — input */
        browseCatalogPage: string;
        /** state ui.catalog.input.browseCatalog.pageSize — input */
        browseCatalogPageSize: string;
        /** state ui.catalog.data.browseCatalog — queryResult, outputShape: paginated */
        browseCatalogData: BrowseCatalogOutput;
        /** state ui.catalog.action.productDetails.status — actionStatus, values: idle|loading|success|error */
        productDetailsState: ActionStatus;
        /** state ui.catalog.input.productDetails.productId — input */
        productDetailsProductId: string;
        /** state ui.catalog.data.productDetails — queryResult, outputShape: object */
        productDetailsData: ProductDetailsOutput | null;
        /** state ui.catalog.action.reserveProduct.status — actionStatus, values: idle|loading|success|error */
        reserveProductState: ActionStatus;
        /** state ui.catalog.input.reserveProduct.customerName — input */
        reserveProductCustomerName: string;
        /** state ui.catalog.input.reserveProduct.customerPhone — input */
        reserveProductCustomerPhone: string;
        /** state ui.catalog.input.reserveProduct.productId — input */
        reserveProductProductId: string;
        /** state ui.catalog.input.reserveProduct.quantity — input */
        reserveProductQuantity: string;
        /** state ui.catalog.output.reserveProduct — commandOutput */
        reserveProductOutput: ReserveProductOutput | null;
        /** state ui.catalog.action.reserveProduct.error — actionError */
        reserveProductError: string;
        private readonly subscribedKeys;
        /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: unknown): void;
        private initStateValue;
        private applyRouteParams;
        private optionalNumber;
        private optionalString;
        /** action featuredProducts (query) — route petShop.catalog.featuredProducts; inputs: categoryId, petTypeId, name, priceMin, priceMax, page, pageSize; writes ui.catalog.data.featuredProducts; status ui.catalog.action.featuredProducts.status */
        loadFeaturedProducts(): Promise<void>;
        /** handler for action featuredProducts — bind UI events here */
        handleFeaturedProductsClick(event?: Event): void;
        /** action browseCatalog (query) — route petShop.catalog.browseCatalog; inputs: searchName, petTypeId, categoryId, minPrice, maxPrice, page, pageSize; writes ui.catalog.data.browseCatalog; status ui.catalog.action.browseCatalog.status */
        loadBrowseCatalog(): Promise<void>;
        /** handler for action browseCatalog — bind UI events here */
        handleBrowseCatalogClick(event?: Event): void;
        /** action productDetails (query) — route petShop.catalog.productDetails; inputs: productId; writes ui.catalog.data.productDetails; status ui.catalog.action.productDetails.status */
        loadProductDetails(): Promise<void>;
        /** handler for action productDetails — bind UI events here */
        handleProductDetailsClick(event?: Event): void;
        /** action reserveProduct (command) — route petShop.catalog.reserveProduct; inputs: customerName, customerPhone, productId, quantity; writes ui.catalog.output.reserveProduct; status ui.catalog.action.reserveProduct.status; feedback keys action.reserveProduct.success / action.reserveProduct.error */
        reserveProduct(signal?: AbortSignal): Promise<void>;
        /** handler for action reserveProduct — bind UI events here */
        handleReserveProductClick(event?: Event): void;
        /** setter for state ui.catalog.input.featuredProducts.categoryId */
        setFeaturedProductsCategoryId(value: string): void;
        /** handler for action set.featuredProductsCategoryId — bind UI events here */
        handleFeaturedProductsCategoryIdChange(event: Event): void;
        /** setter for state ui.catalog.input.featuredProducts.petTypeId */
        setFeaturedProductsPetTypeId(value: string): void;
        /** handler for action set.featuredProductsPetTypeId — bind UI events here */
        handleFeaturedProductsPetTypeIdChange(event: Event): void;
        /** setter for state ui.catalog.input.featuredProducts.name */
        setFeaturedProductsName(value: string): void;
        /** handler for action set.featuredProductsName — bind UI events here */
        handleFeaturedProductsNameChange(event: Event): void;
        /** setter for state ui.catalog.input.featuredProducts.priceMin */
        setFeaturedProductsPriceMin(value: string): void;
        /** handler for action set.featuredProductsPriceMin — bind UI events here */
        handleFeaturedProductsPriceMinChange(event: Event): void;
        /** setter for state ui.catalog.input.featuredProducts.priceMax */
        setFeaturedProductsPriceMax(value: string): void;
        /** handler for action set.featuredProductsPriceMax — bind UI events here */
        handleFeaturedProductsPriceMaxChange(event: Event): void;
        /** setter for state ui.catalog.input.featuredProducts.page */
        setFeaturedProductsPage(value: string): void;
        /** handler for action set.featuredProductsPage — bind UI events here */
        handleFeaturedProductsPageChange(event: Event): void;
        /** setter for state ui.catalog.input.featuredProducts.pageSize */
        setFeaturedProductsPageSize(value: string): void;
        /** handler for action set.featuredProductsPageSize — bind UI events here */
        handleFeaturedProductsPageSizeChange(event: Event): void;
        /** setter for state ui.catalog.input.browseCatalog.searchName */
        setBrowseCatalogSearchName(value: string): void;
        /** handler for action set.browseCatalogSearchName — bind UI events here */
        handleBrowseCatalogSearchNameChange(event: Event): void;
        /** setter for state ui.catalog.input.browseCatalog.petTypeId */
        setBrowseCatalogPetTypeId(value: string): void;
        /** handler for action set.browseCatalogPetTypeId — bind UI events here */
        handleBrowseCatalogPetTypeIdChange(event: Event): void;
        /** setter for state ui.catalog.input.browseCatalog.categoryId */
        setBrowseCatalogCategoryId(value: string): void;
        /** handler for action set.browseCatalogCategoryId — bind UI events here */
        handleBrowseCatalogCategoryIdChange(event: Event): void;
        /** setter for state ui.catalog.input.browseCatalog.minPrice */
        setBrowseCatalogMinPrice(value: string): void;
        /** handler for action set.browseCatalogMinPrice — bind UI events here */
        handleBrowseCatalogMinPriceChange(event: Event): void;
        /** setter for state ui.catalog.input.browseCatalog.maxPrice */
        setBrowseCatalogMaxPrice(value: string): void;
        /** handler for action set.browseCatalogMaxPrice — bind UI events here */
        handleBrowseCatalogMaxPriceChange(event: Event): void;
        /** setter for state ui.catalog.input.browseCatalog.page */
        setBrowseCatalogPage(value: string): void;
        /** handler for action set.browseCatalogPage — bind UI events here */
        handleBrowseCatalogPageChange(event: Event): void;
        /** setter for state ui.catalog.input.browseCatalog.pageSize */
        setBrowseCatalogPageSize(value: string): void;
        /** handler for action set.browseCatalogPageSize — bind UI events here */
        handleBrowseCatalogPageSizeChange(event: Event): void;
        /** setter for state ui.catalog.input.productDetails.productId */
        setProductDetailsProductId(value: string): void;
        /** handler for action set.productDetailsProductId — bind UI events here */
        handleProductDetailsProductIdChange(event: Event): void;
        /** setter for state ui.catalog.input.reserveProduct.customerName */
        setReserveProductCustomerName(value: string): void;
        /** handler for action set.reserveProductCustomerName — bind UI events here */
        handleReserveProductCustomerNameChange(event: Event): void;
        /** setter for state ui.catalog.input.reserveProduct.customerPhone */
        setReserveProductCustomerPhone(value: string): void;
        /** handler for action set.reserveProductCustomerPhone — bind UI events here */
        handleReserveProductCustomerPhoneChange(event: Event): void;
        /** setter for state ui.catalog.input.reserveProduct.productId */
        setReserveProductProductId(value: string): void;
        /** handler for action set.reserveProductProductId — bind UI events here */
        handleReserveProductProductIdChange(event: Event): void;
        /** setter for state ui.catalog.input.reserveProduct.quantity */
        setReserveProductQuantity(value: string): void;
        /** handler for action set.reserveProductQuantity — bind UI events here */
        handleReserveProductQuantityChange(event: Event): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/catalog" {
    import { PetShopCatalogBase } from "_102049_/l2/petShop/web/shared/catalog";
    export class PetShopDesktopPage11CatalogPage extends PetShopCatalogBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/reservationManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            }[];
        };
        dataBindings: ({
            id: string;
            source: string;
            entity: string;
            description: string;
            stateKey: string;
            command?: undefined;
            inputStateKeys?: undefined;
        } | {
            id: string;
            source: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
            entity?: undefined;
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "reservationManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/reservationManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/reservationManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/reservationManagement.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["reservationManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Storefront-first, catálogo limpo com busca e filtros, fluxo de reserva simples, UI de gestão do atendente orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/desktop/page11/reservationManagement.test" {
    export const pageTests: {
        readonly moduleName: "petShop";
        readonly page: "reservationManagement";
        readonly variant: "page11";
        readonly cases: readonly [{
            readonly id: "browseReservationsQuery.ok";
            readonly routine: "petShop.reservationManagement.browseReservationsQuery";
            readonly params: {};
            readonly expect: {
                readonly ok: true;
                readonly shape: "array";
                readonly minItems: 1;
            };
        }, {
            readonly id: "updateReservationStatusCommand.ok";
            readonly routine: "petShop.reservationManagement.updateReservationStatusCommand";
            readonly params: {
                readonly reservationId: "<seedRef>";
                readonly newStatus: "<seedRef>";
            };
            readonly expect: {
                readonly ok: true;
                readonly shape: "object";
            };
            readonly mutating: true;
        }, {
            readonly id: "updateReservationStatusCommand.newStatus.required";
            readonly routine: "petShop.reservationManagement.updateReservationStatusCommand";
            readonly params: {
                readonly reservationId: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }, {
            readonly id: "processPaymentCommand.ok";
            readonly routine: "petShop.reservationManagement.processPaymentCommand";
            readonly params: {
                readonly reservationId: "<seedRef>";
                readonly method: "<seedRef>";
            };
            readonly expect: {
                readonly ok: true;
                readonly shape: "object";
            };
            readonly mutating: true;
        }, {
            readonly id: "processPaymentCommand.method.required";
            readonly routine: "petShop.reservationManagement.processPaymentCommand";
            readonly params: {
                readonly reservationId: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }];
    };
}
declare module "_102049_/l2/petShop/web/shared/reservationManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { BrowseReservationsQueryOutput } from "_102049_/l2/petShop/web/contracts/reservationManagement.browseReservationsQuery";
    import type { UpdateReservationStatusCommandOutput } from "_102049_/l2/petShop/web/contracts/reservationManagement.updateReservationStatusCommand";
    import type { ProcessPaymentCommandOutput } from "_102049_/l2/petShop/web/contracts/reservationManagement.processPaymentCommand";
    export type { BrowseReservationsQueryInput, BrowseReservationsQueryOutput, } from "_102049_/l2/petShop/web/contracts/reservationManagement.browseReservationsQuery";
    export type { UpdateReservationStatusCommandInput, UpdateReservationStatusCommandOutput, } from "_102049_/l2/petShop/web/contracts/reservationManagement.updateReservationStatusCommand";
    export type { ProcessPaymentCommandInput, ProcessPaymentCommandOutput, } from "_102049_/l2/petShop/web/contracts/reservationManagement.processPaymentCommand";
    const message_pt: {
        "section.reservationList.title": string;
        "organism.reservationKanbanBoard.title": string;
        "intent.reservationKanban.title": string;
        "field.reservationId": string;
        "field.customerName": string;
        "field.customerPhone": string;
        "field.status": string;
        "field.expiresAt": string;
        "filter.searchTerm": string;
        "filter.statusFilter": string;
        "filter.page": string;
        "filter.pageSize": string;
        "action.refresh": string;
        "action.updateStatus": string;
        "action.processPayment": string;
        "empty.reservations": string;
        "organism.updateReservationStatusPanel.title": string;
        "intent.updateReservationStatus.title": string;
        "field.newStatus": string;
        "field.cancellationReason": string;
        "field.paymentId": string;
        "action.confirmUpdate": string;
        "organism.processPaymentPanel.title": string;
        "intent.processPayment.title": string;
        "field.method": string;
        "action.receivePayment": string;
        "action.updateReservationStatusCommand.success": string;
        "action.updateReservationStatusCommand.error": string;
        "action.processPaymentCommand.success": string;
        "action.processPaymentCommand.error": string;
        "reservation.queue.title": string;
        "reservation.list.title": string;
        "reservation.list.empty": string;
        "reservation.transition.title": string;
        "reservation.payment.title": string;
        "field.createdAt": string;
        "action.confirmReservation": string;
        "action.cancelReservation": string;
        "action.fulfillReservation": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopReservationManagementBase extends CollabLitElement {
        /** state status — pageStatus */
        status: string;
        /** state browseReservationsQueryState — actionStatus, values: idle, loading, success, error */
        browseReservationsQueryState: "idle" | "loading" | "success" | "error";
        /** state browseReservationsQuerySearchTerm — input */
        browseReservationsQuerySearchTerm: string;
        /** state browseReservationsQueryStatusFilter — input */
        browseReservationsQueryStatusFilter: string;
        /** state browseReservationsQueryPage — input */
        browseReservationsQueryPage: string;
        /** state browseReservationsQueryPageSize — input */
        browseReservationsQueryPageSize: string;
        /** state browseReservationsQueryData — queryResult, outputShape: array */
        browseReservationsQueryData: BrowseReservationsQueryOutput[];
        /** state updateReservationStatusCommandState — actionStatus, values: idle, loading, success, error */
        updateReservationStatusCommandState: "idle" | "loading" | "success" | "error";
        /** state updateReservationStatusCommandReservationId — input */
        updateReservationStatusCommandReservationId: string;
        /** state updateReservationStatusCommandNewStatus — input */
        updateReservationStatusCommandNewStatus: string;
        /** state updateReservationStatusCommandCancellationReason — input */
        updateReservationStatusCommandCancellationReason: string;
        /** state updateReservationStatusCommandPaymentId — input */
        updateReservationStatusCommandPaymentId: string;
        /** state updateReservationStatusCommandOutput — commandOutput */
        updateReservationStatusCommandOutput: UpdateReservationStatusCommandOutput | null;
        /** state updateReservationStatusCommandError — actionError */
        updateReservationStatusCommandError: string;
        /** state processPaymentCommandState — actionStatus, values: idle, loading, success, error */
        processPaymentCommandState: "idle" | "loading" | "success" | "error";
        /** state processPaymentCommandReservationId — input */
        processPaymentCommandReservationId: string;
        /** state processPaymentCommandMethod — input */
        processPaymentCommandMethod: string;
        /** state processPaymentCommandOutput — commandOutput */
        processPaymentCommandOutput: ProcessPaymentCommandOutput | null;
        /** state processPaymentCommandError — actionError */
        processPaymentCommandError: string;
        private readonly subscribedKeys;
        /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: unknown): void;
        private initStateValue;
        private applyRouteParams;
        /** action browseReservationsQuery (query) — route petShop.reservationManagement.browseReservationsQuery; inputs: searchTerm, statusFilter, page, pageSize; writes ui.reservationManagement.data.browseReservationsQuery; status ui.reservationManagement.action.browseReservationsQuery.status */
        loadBrowseReservationsQuery(): Promise<void>;
        /** handler for action browseReservationsQuery — bind UI events here */
        handleBrowseReservationsQueryClick(event?: Event): void;
        /** action updateReservationStatusCommand (command) — route petShop.reservationManagement.updateReservationStatusCommand; inputs: reservationId, newStatus, cancellationReason, paymentId; writes ui.reservationManagement.output.updateReservationStatusCommand; status ui.reservationManagement.action.updateReservationStatusCommand.status; feedback keys action.updateReservationStatusCommand.success / action.updateReservationStatusCommand.error */
        updateReservationStatusCommand(): Promise<void>;
        /** handler for action updateReservationStatusCommand — bind UI events here */
        handleUpdateReservationStatusCommandClick(event?: Event): void;
        /** action processPaymentCommand (command) — route petShop.reservationManagement.processPaymentCommand; inputs: reservationId, method; writes ui.reservationManagement.output.processPaymentCommand; status ui.reservationManagement.action.processPaymentCommand.status; feedback keys action.processPaymentCommand.success / action.processPaymentCommand.error */
        processPaymentCommand(): Promise<void>;
        /** handler for action processPaymentCommand — bind UI events here */
        handleProcessPaymentCommandClick(event?: Event): void;
        /** setter for state ui.reservationManagement.input.browseReservationsQuery.searchTerm */
        setBrowseReservationsQuerySearchTerm(value: string): void;
        /** handler for action set.browseReservationsQuerySearchTerm — bind UI events here */
        handleBrowseReservationsQuerySearchTermChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.browseReservationsQuery.statusFilter */
        setBrowseReservationsQueryStatusFilter(value: string): void;
        /** handler for action set.browseReservationsQueryStatusFilter — bind UI events here */
        handleBrowseReservationsQueryStatusFilterChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.browseReservationsQuery.page */
        setBrowseReservationsQueryPage(value: string): void;
        /** handler for action set.browseReservationsQueryPage — bind UI events here */
        handleBrowseReservationsQueryPageChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.browseReservationsQuery.pageSize */
        setBrowseReservationsQueryPageSize(value: string): void;
        /** handler for action set.browseReservationsQueryPageSize — bind UI events here */
        handleBrowseReservationsQueryPageSizeChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.updateReservationStatusCommand.reservationId */
        setUpdateReservationStatusCommandReservationId(value: string): void;
        /** handler for action set.updateReservationStatusCommandReservationId — bind UI events here */
        handleUpdateReservationStatusCommandReservationIdChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.updateReservationStatusCommand.newStatus */
        setUpdateReservationStatusCommandNewStatus(value: string): void;
        /** handler for action set.updateReservationStatusCommandNewStatus — bind UI events here */
        handleUpdateReservationStatusCommandNewStatusChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.updateReservationStatusCommand.cancellationReason */
        setUpdateReservationStatusCommandCancellationReason(value: string): void;
        /** handler for action set.updateReservationStatusCommandCancellationReason — bind UI events here */
        handleUpdateReservationStatusCommandCancellationReasonChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.updateReservationStatusCommand.paymentId */
        setUpdateReservationStatusCommandPaymentId(value: string): void;
        /** handler for action set.updateReservationStatusCommandPaymentId — bind UI events here */
        handleUpdateReservationStatusCommandPaymentIdChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.processPaymentCommand.reservationId */
        setProcessPaymentCommandReservationId(value: string): void;
        /** handler for action set.processPaymentCommandReservationId — bind UI events here */
        handleProcessPaymentCommandReservationIdChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.processPaymentCommand.method */
        setProcessPaymentCommandMethod(value: string): void;
        /** handler for action set.processPaymentCommandMethod — bind UI events here */
        handleProcessPaymentCommandMethodChange(event: Event): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/reservationManagement" {
    import { PetShopReservationManagementBase } from "_102049_/l2/petShop/web/shared/reservationManagement";
    export class PetShopDesktopPage11ReservationManagementPage extends PetShopReservationManagementBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page21/catalog.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format?: undefined;
                            stateKey?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            })[];
        };
        dataBindings: ({
            id: string;
            source: string;
            entity: string;
            description: string;
            stateKey: string;
            inputStateKeys?: undefined;
            command?: undefined;
        } | {
            id: string;
            source: string;
            entity: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
            command?: undefined;
        } | {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "catalog__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page21/catalog.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page21/catalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/catalog.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["catalog__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Storefront-first, catálogo limpo com busca e filtros, fluxo de reserva simples, UI de gestão do atendente orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/desktop/page21/catalog" {
    import { PetShopCatalogBase } from "_102049_/l2/petShop/web/shared/catalog";
    export class PetShopDesktopPage21CatalogPage extends PetShopCatalogBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page21/reservationManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                    submitAction?: undefined;
                } | {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                    stateKey?: undefined;
                    action?: undefined;
                })[];
            }[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                        submitAction?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        displayHint: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        source?: undefined;
                        binding?: undefined;
                        action?: undefined;
                        emptyKey?: undefined;
                        stateKey?: undefined;
                    })[];
                }[];
            }[];
        };
        dataBindings: ({
            id: string;
            source: string;
            entity: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
            command?: undefined;
        } | {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "reservationManagement__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page21/reservationManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page21/reservationManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/reservationManagement.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["reservationManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Storefront-first, catálogo limpo com busca e filtros, fluxo de reserva simples, UI de gestão do atendente orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/desktop/page21/reservationManagement" {
    import { PetShopReservationManagementBase } from "_102049_/l2/petShop/web/shared/reservationManagement";
    export class PetShopDesktopPage21ReservationManagementPage extends PetShopReservationManagementBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/shared/catalog.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            contracts: {
                commandName: string;
                tsPath: string;
                routeConst: string;
            }[];
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "org.vitrine.cards.title": string;
            "int.vitrine.list.title": string;
            "int.vitrine.list.empty": string;
            "org.vitrine.filters.title": string;
            "int.vitrine.filters.title": string;
            "int.vitrine.filters.empty": string;
            "org.catalogo.cards.title": string;
            "int.catalogo.list.title": string;
            "int.catalogo.list.empty": string;
            "org.catalogo.filters.title": string;
            "int.catalogo.filters.title": string;
            "int.catalogo.filters.empty": string;
            "org.detalhe.card.title": string;
            "int.detalhe.view.title": string;
            "int.detalhe.view.empty": string;
            "org.reserva.form.title": string;
            "int.reserva.form.title": string;
            "int.reserva.form.empty": string;
            "field.name": string;
            "field.price": string;
            "field.isFeatured": string;
            "field.categoryId": string;
            "field.petTypeId": string;
            "field.priceMin": string;
            "field.priceMax": string;
            "field.page": string;
            "field.pageSize": string;
            "field.items": string;
            "field.searchName": string;
            "field.minPrice": string;
            "field.maxPrice": string;
            "field.categoryName": string;
            "field.petTypeName": string;
            "field.createdAt": string;
            "field.updatedAt": string;
            "field.productId": string;
            "field.quantity": string;
            "field.customerName": string;
            "field.customerPhone": string;
            "action.productDetails": string;
            "action.applyFilters": string;
            "action.reserveProduct": string;
            "action.reserveProduct.success": string;
            "action.reserveProduct.error": string;
            "sec.vitrine.title": string;
            "sec.catalogo.title": string;
            "sec.detalhe.reserva.title": string;
            "section.vitrine.title": string;
            "section.vitrine.featured.title": string;
            "section.vitrine.featured.empty": string;
            "organism.vitrine.featured.title": string;
            "section.catalogo.title": string;
            "section.catalogo.browse.title": string;
            "section.catalogo.browse.empty": string;
            "organism.catalogo.browse.title": string;
            "section.detalheReserva.title": string;
            "section.detalhe.product.title": string;
            "section.detalhe.product.empty": string;
            "organism.detalhe.product.title": string;
            "section.detalhe.reserve.title": string;
            "section.detalhe.reserve.empty": string;
            "organism.detalhe.reserve.title": string;
            "field.product.name": string;
            "field.product.price": string;
            "field.product.isFeatured": string;
            "field.product.categoryId": string;
            "field.product.petTypeId": string;
            "field.product.categoryName": string;
            "field.product.petTypeName": string;
            "field.reserve.quantity": string;
            "field.reserve.customerName": string;
            "field.reserve.customerPhone": string;
            "filter.featured.categoryId": string;
            "filter.featured.petTypeId": string;
            "filter.featured.name": string;
            "filter.featured.priceMin": string;
            "filter.featured.priceMax": string;
            "filter.browse.searchName": string;
            "filter.browse.petTypeId": string;
            "filter.browse.categoryId": string;
            "filter.browse.minPrice": string;
            "filter.browse.maxPrice": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "catalog__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/catalog.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/catalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/catalog.featuredProducts.ts", "_102049_/l2/petShop/web/contracts/catalog.browseCatalog.ts", "_102049_/l2/petShop/web/contracts/catalog.productDetails.ts", "_102049_/l2/petShop/web/contracts/catalog.reserveProduct.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly ["featuredProductsOnly", "featuredOrderFlexible", "combinedFilters", "caseInsensitiveSearch", "catalogShowsAll", "reservationRequiresContact", "reservationValidity24h", "reservationStatuses"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/catalog.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/reservationManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            contracts: {
                commandName: string;
                tsPath: string;
                routeConst: string;
            }[];
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "section.reservationList.title": string;
            "organism.reservationKanbanBoard.title": string;
            "intent.reservationKanban.title": string;
            "field.reservationId": string;
            "field.customerName": string;
            "field.customerPhone": string;
            "field.status": string;
            "field.expiresAt": string;
            "filter.searchTerm": string;
            "filter.statusFilter": string;
            "filter.page": string;
            "filter.pageSize": string;
            "action.refresh": string;
            "action.updateStatus": string;
            "action.processPayment": string;
            "empty.reservations": string;
            "organism.updateReservationStatusPanel.title": string;
            "intent.updateReservationStatus.title": string;
            "field.newStatus": string;
            "field.cancellationReason": string;
            "field.paymentId": string;
            "action.confirmUpdate": string;
            "organism.processPaymentPanel.title": string;
            "intent.processPayment.title": string;
            "field.method": string;
            "action.receivePayment": string;
            "action.updateReservationStatusCommand.success": string;
            "action.updateReservationStatusCommand.error": string;
            "action.processPaymentCommand.success": string;
            "action.processPaymentCommand.error": string;
            "reservation.queue.title": string;
            "reservation.list.title": string;
            "reservation.list.empty": string;
            "reservation.transition.title": string;
            "reservation.payment.title": string;
            "field.createdAt": string;
            "action.confirmReservation": string;
            "action.cancelReservation": string;
            "action.fulfillReservation": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "reservationManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/reservationManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/reservationManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/reservationManagement.browseReservationsQuery.ts", "_102049_/l2/petShop/web/contracts/reservationManagement.updateReservationStatusCommand.ts", "_102049_/l2/petShop/web/contracts/reservationManagement.processPaymentCommand.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly ["reservationStatuses", "reservationValidity24h", "inStorePaymentOnly", "totalFromPricesAndQuantities", "paymentRequiresReceipt"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/reservationManagement.test" {
    export {};
}

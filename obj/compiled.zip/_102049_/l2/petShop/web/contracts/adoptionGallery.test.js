/// <mls fileReference="_102049_/l2/petShop/web/contracts/adoptionGallery.test.ts" enhancement="_blank"/>

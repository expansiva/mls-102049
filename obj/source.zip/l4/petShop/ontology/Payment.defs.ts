/// <mls fileReference="_102049_/l4/petShop/ontology/Payment.defs.ts" enhancement="_blank"/>

export const petShopEntityPayment = {
  "entityId": "Payment",
  "title": "Pagamento Presencial",
  "description": "Registro do pagamento recebido presencialmente na loja no momento da retirada da reserva, informando método e valor total.",
  "kind": "event",
  "ownership": "moduleOwned",
  "fields": [
    {
      "fieldId": "paymentId",
      "type": "uuid",
      "required": true,
      "description": "Identificador único do registro de pagamento."
    },
    {
      "fieldId": "reservationId",
      "type": "uuid",
      "required": true,
      "description": "Referência à reserva associada a este pagamento presencial."
    },
    {
      "fieldId": "amount",
      "type": "money",
      "required": true,
      "description": "Valor total recebido, calculado a partir dos preços dos produtos e quantidades reservadas."
    },
    {
      "fieldId": "method",
      "type": "string",
      "required": true,
      "description": "Método de pagamento utilizado pelo cliente na loja.",
      "enum": [
        "cash",
        "creditCard",
        "debitCard",
        "pix"
      ]
    },
    {
      "fieldId": "status",
      "type": "string",
      "required": true,
      "description": "Situação atual do registro de pagamento.",
      "enum": [
        "posted",
        "voided"
      ]
    },
    {
      "fieldId": "receivedBy",
      "type": "string",
      "required": true,
      "description": "Identificador do atendente que confirmou o recebimento do pagamento."
    },
    {
      "fieldId": "voidedAt",
      "type": "datetime",
      "required": false,
      "description": "Data e hora em que o pagamento foi cancelado ou estornado."
    },
    {
      "fieldId": "voidReason",
      "type": "text",
      "required": false,
      "description": "Motivo do cancelamento ou estorno do pagamento."
    },
    {
      "fieldId": "createdAt",
      "type": "datetime",
      "required": true,
      "description": "Data e hora em que o pagamento foi registrado no sistema."
    }
  ],
  "statusEnum": [
    "posted",
    "voided"
  ],
  "eventPolicy": {
    "purpose": "audit",
    "retentionDays": 365
  }
} as const;

export default petShopEntityPayment;

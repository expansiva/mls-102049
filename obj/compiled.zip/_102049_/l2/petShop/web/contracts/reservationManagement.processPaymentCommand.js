/// <mls fileReference="_102049_/l2/petShop/web/contracts/reservationManagement.processPaymentCommand.ts" enhancement="_blank"/>
export const processPaymentCommandRoute = 'petShop.reservationManagement.processPaymentCommand';

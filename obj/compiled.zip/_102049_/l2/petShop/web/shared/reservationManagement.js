/// <mls fileReference="_102049_/l2/petShop/web/shared/reservationManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
/// **collab_i18n_start**
const message_pt = {
    "page.reservationManagement.title": "Gestão de Reservas",
    "section.queue.title": "Reservas recebidas",
    "section.queue.empty": "Nenhuma reserva encontrada",
    "section.execute.title": "Ações da Reserva",
    "section.batch.title": "Operações em Lote",
    "section.review.title": "Resumo",
    "intention.queryReservations.title": "Reservas Recebidas",
    "intention.updateStatus.title": "Atualizar Status",
    "intention.payInStore.title": "Pagamento Presencial",
    "intention.expireReservations.title": "Expirar Reservas Vencidas",
    "intention.expireReservations.empty": "Nenhuma reserva vencida para expirar",
    "intention.summary.title": "Resumo das Ações",
    "column.reservationId": "Reserva",
    "column.customerId": "Cliente",
    "column.status": "Status",
    "column.expiresAt": "Expira em",
    "column.readyAt": "Pronta em",
    "column.items": "Itens",
    "filter.status": "Filtrar por status",
    "field.reservationId": "Reserva",
    "field.status": "Status",
    "field.cancelReason": "Motivo do cancelamento",
    "field.paymentId": "Pagamento (ID)",
    "field.paymentMethod": "Método de pagamento",
    "field.paymentAmount": "Valor pago",
    "action.refresh": "Atualizar",
    "action.selectForUpdate": "Gerenciar",
    "action.selectForPayment": "Selecionar para pagamento",
    "action.updateReservationStatus.submit": "Atualizar Status",
    "action.payInStore.submit": "Registrar Pagamento",
    "action.expireReservations.submit": "Expirar Reservas",
    "action.updateReservationStatus.success": "Status atualizado com sucesso",
    "action.updateReservationStatus.error": "Erro ao atualizar status",
    "action.payInStore.success": "Pagamento registrado com sucesso",
    "action.payInStore.error": "Erro ao registrar pagamento",
    "action.expireReservations.success": "Reservas expiradas com sucesso",
    "action.expireReservations.error": "Erro ao expirar reservas",
    "org.reservationQueue.title": "Listar reservas recebidas com status atual e itens, permitindo filtragem e seleção para ações subsequentes",
    "org.reservationTransitions.title": "Permitir à loja atualizar o status da reserva selecionada e registrar pagamento presencial, com formulários contextuais baseados na reserva selecionada na fila",
    "org.batchOperations.title": "Permitir à loja expirar em lote todas as reservas vencidas, restaurando a disponibilidade dos produtos associados",
    "org.reviewSummary.title": "Revisar o contexto e o resultado das ações principais da página após execução de comandos",
    "section.detail.title": "Ações da reserva",
    "organism.reservationBoard.title": "Fila de reservas",
    "organism.reservationTransitions.title": "Atualizar status",
    "organism.payInStore.title": "Pagamento presencial",
    "intent.listReservations.title": "Lista de reservas",
    "intent.updateReservationStatus.title": "Transições de status",
    "intent.payInStore.title": "Registrar pagamento",
    "field.customerId": "Cliente",
    "field.expiresAt": "Expira em",
    "field.readyAt": "Pronta em",
    "field.deliveredAt": "Entregue em",
    "field.items": "Itens",
    "action.listReservations": "Atualizar fila",
    "action.expireReservations": "Expirar vencidas",
    "action.selectReservation": "Selecionar para status",
    "action.updateReservationStatus.ready": "Marcar como pronta",
    "action.updateReservationStatus.delivered": "Marcar como entregue",
    "action.updateReservationStatus.cancelled": "Cancelar reserva",
    "action.payInStore": "Registrar pagamento"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class PetShopReservationManagementBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._stateKeys = [
            'ui.reservationManagement.status',
            'ui.reservationManagement.action.listReservations.status',
            'ui.reservationManagement.input.listReservations.status',
            'ui.reservationManagement.data.listReservations',
            'ui.reservationManagement.action.updateReservationStatus.status',
            'ui.reservationManagement.input.updateReservationStatus.reservationId',
            'ui.reservationManagement.input.updateReservationStatus.status',
            'ui.reservationManagement.input.updateReservationStatus.cancelReason',
            'ui.reservationManagement.input.updateReservationStatus.paymentId',
            'ui.reservationManagement.output.updateReservationStatus',
            'ui.reservationManagement.action.updateReservationStatus.error',
            'ui.reservationManagement.action.payInStore.status',
            'ui.reservationManagement.input.payInStore.reservationId',
            'ui.reservationManagement.input.payInStore.paymentMethod',
            'ui.reservationManagement.input.payInStore.paymentAmount',
            'ui.reservationManagement.output.payInStore',
            'ui.reservationManagement.action.payInStore.error',
            'ui.reservationManagement.action.expireReservations.status',
            'ui.reservationManagement.output.expireReservations',
            'ui.reservationManagement.action.expireReservations.error',
        ];
        /** state ui.reservationManagement.status — pageStatus */
        this.status = '';
        /** state ui.reservationManagement.action.listReservations.status — actionStatus, values: idle | loading | success | error */
        this.listReservationsState = 'idle';
        /** state ui.reservationManagement.input.listReservations.status — input, values: draft | active | ready | delivered | expired | cancelled */
        this.listReservationsStatus = '';
        /** state ui.reservationManagement.data.listReservations — queryResult, outputShape: array */
        this.listReservationsData = [];
        /** state ui.reservationManagement.action.updateReservationStatus.status — actionStatus, values: idle | loading | success | error */
        this.updateReservationStatusState = 'idle';
        /** state ui.reservationManagement.input.updateReservationStatus.reservationId — input */
        this.updateReservationStatusReservationId = '';
        /** state ui.reservationManagement.input.updateReservationStatus.status — input, values: draft | active | ready | delivered | expired | cancelled */
        this.updateReservationStatusStatus = '';
        /** state ui.reservationManagement.input.updateReservationStatus.cancelReason — input */
        this.updateReservationStatusCancelReason = '';
        /** state ui.reservationManagement.input.updateReservationStatus.paymentId — input */
        this.updateReservationStatusPaymentId = '';
        /** state ui.reservationManagement.output.updateReservationStatus — commandOutput */
        this.updateReservationStatusOutput = null;
        /** state ui.reservationManagement.action.updateReservationStatus.error — actionError */
        this.updateReservationStatusError = '';
        /** state ui.reservationManagement.action.payInStore.status — actionStatus, values: idle | loading | success | error */
        this.payInStoreState = 'idle';
        /** state ui.reservationManagement.input.payInStore.reservationId — input */
        this.payInStoreReservationId = '';
        /** state ui.reservationManagement.input.payInStore.paymentMethod — input */
        this.payInStorePaymentMethod = '';
        /** state ui.reservationManagement.input.payInStore.paymentAmount — input */
        this.payInStorePaymentAmount = '';
        /** state ui.reservationManagement.output.payInStore — commandOutput */
        this.payInStoreOutput = null;
        /** state ui.reservationManagement.action.payInStore.error — actionError */
        this.payInStoreError = '';
        /** state ui.reservationManagement.action.expireReservations.status — actionStatus, values: idle | loading | success | error */
        this.expireReservationsState = 'idle';
        /** state ui.reservationManagement.output.expireReservations — commandOutput */
        this.expireReservationsOutput = null;
        /** state ui.reservationManagement.action.expireReservations.error — actionError */
        this.expireReservationsError = '';
    }
    /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        const storedStatus = getState('ui.reservationManagement.status');
        if (storedStatus !== undefined) {
            this.status = storedStatus;
        }
        else {
            setState('ui.reservationManagement.status', this.status);
        }
        const storedListReservationsState = getState('ui.reservationManagement.action.listReservations.status');
        if (storedListReservationsState !== undefined) {
            this.listReservationsState = storedListReservationsState;
        }
        else {
            setState('ui.reservationManagement.action.listReservations.status', this.listReservationsState);
        }
        const storedListReservationsStatus = getState('ui.reservationManagement.input.listReservations.status');
        if (storedListReservationsStatus !== undefined) {
            this.listReservationsStatus = storedListReservationsStatus;
        }
        else {
            setState('ui.reservationManagement.input.listReservations.status', this.listReservationsStatus);
        }
        const storedListReservationsData = getState('ui.reservationManagement.data.listReservations');
        if (storedListReservationsData !== undefined) {
            this.listReservationsData = storedListReservationsData;
        }
        else {
            setState('ui.reservationManagement.data.listReservations', this.listReservationsData);
        }
        const storedUpdateReservationStatusState = getState('ui.reservationManagement.action.updateReservationStatus.status');
        if (storedUpdateReservationStatusState !== undefined) {
            this.updateReservationStatusState = storedUpdateReservationStatusState;
        }
        else {
            setState('ui.reservationManagement.action.updateReservationStatus.status', this.updateReservationStatusState);
        }
        const storedUpdateReservationStatusReservationId = getState('ui.reservationManagement.input.updateReservationStatus.reservationId');
        if (storedUpdateReservationStatusReservationId !== undefined) {
            this.updateReservationStatusReservationId = storedUpdateReservationStatusReservationId;
        }
        else {
            setState('ui.reservationManagement.input.updateReservationStatus.reservationId', this.updateReservationStatusReservationId);
        }
        const storedUpdateReservationStatusStatus = getState('ui.reservationManagement.input.updateReservationStatus.status');
        if (storedUpdateReservationStatusStatus !== undefined) {
            this.updateReservationStatusStatus = storedUpdateReservationStatusStatus;
        }
        else {
            setState('ui.reservationManagement.input.updateReservationStatus.status', this.updateReservationStatusStatus);
        }
        const storedUpdateReservationStatusCancelReason = getState('ui.reservationManagement.input.updateReservationStatus.cancelReason');
        if (storedUpdateReservationStatusCancelReason !== undefined) {
            this.updateReservationStatusCancelReason = storedUpdateReservationStatusCancelReason;
        }
        else {
            setState('ui.reservationManagement.input.updateReservationStatus.cancelReason', this.updateReservationStatusCancelReason);
        }
        const storedUpdateReservationStatusPaymentId = getState('ui.reservationManagement.input.updateReservationStatus.paymentId');
        if (storedUpdateReservationStatusPaymentId !== undefined) {
            this.updateReservationStatusPaymentId = storedUpdateReservationStatusPaymentId;
        }
        else {
            setState('ui.reservationManagement.input.updateReservationStatus.paymentId', this.updateReservationStatusPaymentId);
        }
        const storedUpdateReservationStatusOutput = getState('ui.reservationManagement.output.updateReservationStatus');
        if (storedUpdateReservationStatusOutput !== undefined) {
            this.updateReservationStatusOutput = storedUpdateReservationStatusOutput;
        }
        else {
            setState('ui.reservationManagement.output.updateReservationStatus', this.updateReservationStatusOutput);
        }
        const storedUpdateReservationStatusError = getState('ui.reservationManagement.action.updateReservationStatus.error');
        if (storedUpdateReservationStatusError !== undefined) {
            this.updateReservationStatusError = storedUpdateReservationStatusError;
        }
        else {
            setState('ui.reservationManagement.action.updateReservationStatus.error', this.updateReservationStatusError);
        }
        const storedPayInStoreState = getState('ui.reservationManagement.action.payInStore.status');
        if (storedPayInStoreState !== undefined) {
            this.payInStoreState = storedPayInStoreState;
        }
        else {
            setState('ui.reservationManagement.action.payInStore.status', this.payInStoreState);
        }
        const storedPayInStoreReservationId = getState('ui.reservationManagement.input.payInStore.reservationId');
        if (storedPayInStoreReservationId !== undefined) {
            this.payInStoreReservationId = storedPayInStoreReservationId;
        }
        else {
            setState('ui.reservationManagement.input.payInStore.reservationId', this.payInStoreReservationId);
        }
        const storedPayInStorePaymentMethod = getState('ui.reservationManagement.input.payInStore.paymentMethod');
        if (storedPayInStorePaymentMethod !== undefined) {
            this.payInStorePaymentMethod = storedPayInStorePaymentMethod;
        }
        else {
            setState('ui.reservationManagement.input.payInStore.paymentMethod', this.payInStorePaymentMethod);
        }
        const storedPayInStorePaymentAmount = getState('ui.reservationManagement.input.payInStore.paymentAmount');
        if (storedPayInStorePaymentAmount !== undefined) {
            this.payInStorePaymentAmount = storedPayInStorePaymentAmount;
        }
        else {
            setState('ui.reservationManagement.input.payInStore.paymentAmount', this.payInStorePaymentAmount);
        }
        const storedPayInStoreOutput = getState('ui.reservationManagement.output.payInStore');
        if (storedPayInStoreOutput !== undefined) {
            this.payInStoreOutput = storedPayInStoreOutput;
        }
        else {
            setState('ui.reservationManagement.output.payInStore', this.payInStoreOutput);
        }
        const storedPayInStoreError = getState('ui.reservationManagement.action.payInStore.error');
        if (storedPayInStoreError !== undefined) {
            this.payInStoreError = storedPayInStoreError;
        }
        else {
            setState('ui.reservationManagement.action.payInStore.error', this.payInStoreError);
        }
        const storedExpireReservationsState = getState('ui.reservationManagement.action.expireReservations.status');
        if (storedExpireReservationsState !== undefined) {
            this.expireReservationsState = storedExpireReservationsState;
        }
        else {
            setState('ui.reservationManagement.action.expireReservations.status', this.expireReservationsState);
        }
        const storedExpireReservationsOutput = getState('ui.reservationManagement.output.expireReservations');
        if (storedExpireReservationsOutput !== undefined) {
            this.expireReservationsOutput = storedExpireReservationsOutput;
        }
        else {
            setState('ui.reservationManagement.output.expireReservations', this.expireReservationsOutput);
        }
        const storedExpireReservationsError = getState('ui.reservationManagement.action.expireReservations.error');
        if (storedExpireReservationsError !== undefined) {
            this.expireReservationsError = storedExpireReservationsError;
        }
        else {
            setState('ui.reservationManagement.action.expireReservations.error', this.expireReservationsError);
        }
        subscribe(this._stateKeys, this);
        void this.loadListReservations();
    }
    disconnectedCallback() {
        unsubscribe(this._stateKeys, this);
        super.disconnectedCallback();
    }
    /** action listReservations (query) — route petShop.listReservations.listReservations; inputs: status; writes ui.reservationManagement.data.listReservations; status ui.reservationManagement.action.listReservations.status */
    async loadListReservations() {
        this.listReservationsState = 'loading';
        setState('ui.reservationManagement.action.listReservations.status', this.listReservationsState);
        const params = {};
        if (this.listReservationsStatus) {
            params.status = this.listReservationsStatus;
        }
        const options = { mode: 'silent' };
        const response = await execBff('petShop.listReservations.listReservations', params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.listReservationsData = Array.isArray(data) ? data : [];
            setState('ui.reservationManagement.data.listReservations', this.listReservationsData);
            this.listReservationsState = 'success';
            setState('ui.reservationManagement.action.listReservations.status', this.listReservationsState);
            return true;
        }
        this.listReservationsState = 'error';
        setState('ui.reservationManagement.action.listReservations.status', this.listReservationsState);
        if (response.error) {
            console.error(response.error);
        }
        return false;
    }
    /** handler for action listReservations — bind UI events here */
    handleListReservationsClick() {
        void this.loadListReservations();
    }
    /** action updateReservationStatus (command) — route petShop.reservationLifecycle.updateReservationStatus; inputs: reservationId, status, cancelReason, paymentId; writes ui.reservationManagement.output.updateReservationStatus; status ui.reservationManagement.action.updateReservationStatus.status; feedback keys action.updateReservationStatus.success / action.updateReservationStatus.error */
    async updateReservationStatus(signal) {
        this.updateReservationStatusState = 'loading';
        setState('ui.reservationManagement.action.updateReservationStatus.status', this.updateReservationStatusState);
        const params = {
            reservationId: this.updateReservationStatusReservationId,
            status: this.updateReservationStatusStatus,
            cancelReason: this.updateReservationStatusCancelReason || undefined,
            paymentId: this.updateReservationStatusPaymentId || undefined,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('petShop.reservationLifecycle.updateReservationStatus', params, options);
        if (!response.ok) {
            this.updateReservationStatusError = response.error?.message ?? '';
            setState('ui.reservationManagement.action.updateReservationStatus.error', this.updateReservationStatusError);
            this.updateReservationStatusState = 'error';
            setState('ui.reservationManagement.action.updateReservationStatus.status', this.updateReservationStatusState);
            return false;
        }
        this.updateReservationStatusOutput = response.data ?? null;
        setState('ui.reservationManagement.output.updateReservationStatus', this.updateReservationStatusOutput);
        const refreshOk = await this.loadListReservations();
        if (!refreshOk) {
            this.updateReservationStatusState = 'error';
            setState('ui.reservationManagement.action.updateReservationStatus.status', this.updateReservationStatusState);
            return false;
        }
        this.updateReservationStatusReservationId = '';
        setState('ui.reservationManagement.input.updateReservationStatus.reservationId', this.updateReservationStatusReservationId);
        this.updateReservationStatusStatus = '';
        setState('ui.reservationManagement.input.updateReservationStatus.status', this.updateReservationStatusStatus);
        this.updateReservationStatusCancelReason = '';
        setState('ui.reservationManagement.input.updateReservationStatus.cancelReason', this.updateReservationStatusCancelReason);
        this.updateReservationStatusPaymentId = '';
        setState('ui.reservationManagement.input.updateReservationStatus.paymentId', this.updateReservationStatusPaymentId);
        this.updateReservationStatusError = '';
        setState('ui.reservationManagement.action.updateReservationStatus.error', this.updateReservationStatusError);
        this.updateReservationStatusState = 'success';
        setState('ui.reservationManagement.action.updateReservationStatus.status', this.updateReservationStatusState);
        return true;
    }
    /** handler for action updateReservationStatus — bind UI events here */
    handleUpdateReservationStatusClick() {
        void runBlockingUiAction((signal) => this.updateReservationStatus(signal));
    }
    /** action payInStore (command) — route petShop.reservationLifecycle.payInStore; inputs: reservationId, paymentMethod, paymentAmount; writes ui.reservationManagement.output.payInStore; status ui.reservationManagement.action.payInStore.status; feedback keys action.payInStore.success / action.payInStore.error */
    async payInStore(signal) {
        this.payInStoreState = 'loading';
        setState('ui.reservationManagement.action.payInStore.status', this.payInStoreState);
        const params = {
            reservationId: this.payInStoreReservationId,
            paymentMethod: this.payInStorePaymentMethod,
            paymentAmount: this.payInStorePaymentAmount,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('petShop.reservationLifecycle.payInStore', params, options);
        if (!response.ok) {
            this.payInStoreError = response.error?.message ?? '';
            setState('ui.reservationManagement.action.payInStore.error', this.payInStoreError);
            this.payInStoreState = 'error';
            setState('ui.reservationManagement.action.payInStore.status', this.payInStoreState);
            return false;
        }
        this.payInStoreOutput = response.data ?? null;
        setState('ui.reservationManagement.output.payInStore', this.payInStoreOutput);
        const refreshOk = await this.loadListReservations();
        if (!refreshOk) {
            this.payInStoreState = 'error';
            setState('ui.reservationManagement.action.payInStore.status', this.payInStoreState);
            return false;
        }
        this.payInStoreReservationId = '';
        setState('ui.reservationManagement.input.payInStore.reservationId', this.payInStoreReservationId);
        this.payInStorePaymentMethod = '';
        setState('ui.reservationManagement.input.payInStore.paymentMethod', this.payInStorePaymentMethod);
        this.payInStorePaymentAmount = '';
        setState('ui.reservationManagement.input.payInStore.paymentAmount', this.payInStorePaymentAmount);
        this.payInStoreError = '';
        setState('ui.reservationManagement.action.payInStore.error', this.payInStoreError);
        this.payInStoreState = 'success';
        setState('ui.reservationManagement.action.payInStore.status', this.payInStoreState);
        return true;
    }
    /** handler for action payInStore — bind UI events here */
    handlePayInStoreClick() {
        void runBlockingUiAction((signal) => this.payInStore(signal));
    }
    /** action expireReservations (command) — route petShop.reservationLifecycle.expireReservations; inputs: none; writes ui.reservationManagement.output.expireReservations; status ui.reservationManagement.action.expireReservations.status; feedback keys action.expireReservations.success / action.expireReservations.error */
    async expireReservations(signal) {
        this.expireReservationsState = 'loading';
        setState('ui.reservationManagement.action.expireReservations.status', this.expireReservationsState);
        const params = {};
        const options = { mode: 'blocking', signal };
        const response = await execBff('petShop.reservationLifecycle.expireReservations', params, options);
        if (!response.ok) {
            this.expireReservationsError = response.error?.message ?? '';
            setState('ui.reservationManagement.action.expireReservations.error', this.expireReservationsError);
            this.expireReservationsState = 'error';
            setState('ui.reservationManagement.action.expireReservations.status', this.expireReservationsState);
            return false;
        }
        this.expireReservationsOutput = response.data ?? null;
        setState('ui.reservationManagement.output.expireReservations', this.expireReservationsOutput);
        const refreshOk = await this.loadListReservations();
        if (!refreshOk) {
            this.expireReservationsState = 'error';
            setState('ui.reservationManagement.action.expireReservations.status', this.expireReservationsState);
            return false;
        }
        this.expireReservationsError = '';
        setState('ui.reservationManagement.action.expireReservations.error', this.expireReservationsError);
        this.expireReservationsState = 'success';
        setState('ui.reservationManagement.action.expireReservations.status', this.expireReservationsState);
        return true;
    }
    /** handler for action expireReservations — bind UI events here */
    handleExpireReservationsClick() {
        void runBlockingUiAction((signal) => this.expireReservations(signal));
    }
    /** setter for state ui.reservationManagement.input.listReservations.status */
    setListReservationsStatus(value) {
        this.listReservationsStatus = value;
        setState('ui.reservationManagement.input.listReservations.status', this.listReservationsStatus);
    }
    /** handler for action set.listReservationsStatus — bind UI events here */
    handleListReservationsStatusChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setListReservationsStatus(target.value);
    }
    /** setter for state ui.reservationManagement.input.updateReservationStatus.reservationId */
    setUpdateReservationStatusReservationId(value) {
        this.updateReservationStatusReservationId = value;
        setState('ui.reservationManagement.input.updateReservationStatus.reservationId', this.updateReservationStatusReservationId);
        const sourceState = getState('ui.reservationManagement.data.listReservations');
        const collection = Array.isArray(sourceState) ? sourceState : this.listReservationsData;
        const match = collection.find((item) => {
            return String(item.reservationId) === String(value);
        });
        if (match && match.status !== undefined && match.status !== null) {
            const nextStatus = match.status;
            this.updateReservationStatusStatus = nextStatus;
            setState('ui.reservationManagement.input.updateReservationStatus.status', this.updateReservationStatusStatus);
        }
    }
    /** handler for action set.updateReservationStatusReservationId — bind UI events here */
    handleUpdateReservationStatusReservationIdChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setUpdateReservationStatusReservationId(target.value);
    }
    /** setter for state ui.reservationManagement.input.updateReservationStatus.status */
    setUpdateReservationStatusStatus(value) {
        this.updateReservationStatusStatus = value;
        setState('ui.reservationManagement.input.updateReservationStatus.status', this.updateReservationStatusStatus);
    }
    /** handler for action set.updateReservationStatusStatus — bind UI events here */
    handleUpdateReservationStatusStatusChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setUpdateReservationStatusStatus(target.value);
    }
    /** setter for state ui.reservationManagement.input.updateReservationStatus.cancelReason */
    setUpdateReservationStatusCancelReason(value) {
        this.updateReservationStatusCancelReason = value;
        setState('ui.reservationManagement.input.updateReservationStatus.cancelReason', this.updateReservationStatusCancelReason);
    }
    /** handler for action set.updateReservationStatusCancelReason — bind UI events here */
    handleUpdateReservationStatusCancelReasonChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setUpdateReservationStatusCancelReason(target.value);
    }
    /** setter for state ui.reservationManagement.input.updateReservationStatus.paymentId */
    setUpdateReservationStatusPaymentId(value) {
        this.updateReservationStatusPaymentId = value;
        setState('ui.reservationManagement.input.updateReservationStatus.paymentId', this.updateReservationStatusPaymentId);
    }
    /** handler for action set.updateReservationStatusPaymentId — bind UI events here */
    handleUpdateReservationStatusPaymentIdChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setUpdateReservationStatusPaymentId(target.value);
    }
    /** setter for state ui.reservationManagement.input.payInStore.reservationId */
    setPayInStoreReservationId(value) {
        this.payInStoreReservationId = value;
        setState('ui.reservationManagement.input.payInStore.reservationId', this.payInStoreReservationId);
    }
    /** handler for action set.payInStoreReservationId — bind UI events here */
    handlePayInStoreReservationIdChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setPayInStoreReservationId(target.value);
    }
    /** setter for state ui.reservationManagement.input.payInStore.paymentMethod */
    setPayInStorePaymentMethod(value) {
        this.payInStorePaymentMethod = value;
        setState('ui.reservationManagement.input.payInStore.paymentMethod', this.payInStorePaymentMethod);
    }
    /** handler for action set.payInStorePaymentMethod — bind UI events here */
    handlePayInStorePaymentMethodChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setPayInStorePaymentMethod(target.value);
    }
    /** setter for state ui.reservationManagement.input.payInStore.paymentAmount */
    setPayInStorePaymentAmount(value) {
        this.payInStorePaymentAmount = value;
        setState('ui.reservationManagement.input.payInStore.paymentAmount', this.payInStorePaymentAmount);
    }
    /** handler for action set.payInStorePaymentAmount — bind UI events here */
    handlePayInStorePaymentAmountChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        const rawValue = target.value;
        if (rawValue === '') {
            this.setPayInStorePaymentAmount('');
            return;
        }
        const parsedValue = Number(rawValue);
        if (!Number.isNaN(parsedValue)) {
            this.setPayInStorePaymentAmount(parsedValue);
        }
    }
}
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "status", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "listReservationsState", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "listReservationsStatus", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "listReservationsData", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "updateReservationStatusState", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "updateReservationStatusReservationId", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "updateReservationStatusStatus", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "updateReservationStatusCancelReason", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "updateReservationStatusPaymentId", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "updateReservationStatusOutput", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "updateReservationStatusError", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "payInStoreState", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "payInStoreReservationId", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "payInStorePaymentMethod", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "payInStorePaymentAmount", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "payInStoreOutput", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "payInStoreError", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "expireReservationsState", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "expireReservationsOutput", void 0);
__decorate([
    property()
], PetShopReservationManagementBase.prototype, "expireReservationsError", void 0);

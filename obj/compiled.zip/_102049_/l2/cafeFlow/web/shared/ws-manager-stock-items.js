/// <mls fileReference="_102049_/l2/cafeFlow/web/shared/ws-manager-stock-items.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
/// **collab_i18n_start**
const message_pt = {
    "wsManagerStockItems.section.main.title": "Gestão de Insumos de Estoque",
    "wsManagerStockItems.organism.query.title": "Consultar itens de estoque",
    "wsManagerStockItems.intent.queryList.title": "Query List",
    "wsManagerStockItems.queryList.empty": "Nenhum registro encontrado",
    "wsManagerStockItems.field.stockItemId": "Stock Item Id",
    "wsManagerStockItems.field.name": "Name",
    "wsManagerStockItems.field.unitOfMeasure": "Unit Of Measure",
    "wsManagerStockItems.field.minimumQuantity": "Minimum Quantity",
    "wsManagerStockItems.field.status": "Status",
    "wsManagerStockItems.field.createdAt": "Created At",
    "wsManagerStockItems.field.updatedAt": "Updated At",
    "wsManagerStockItems.action.query": "Query Stock Items",
    "wsManagerStockItems.action.update": "Update Stock Item",
    "wsManagerStockItems.action.delete": "Delete Stock Item",
    "wsManagerStockItems.organism.create.title": "Cadastrar item de estoque",
    "wsManagerStockItems.intent.create.title": "Command Form",
    "wsManagerStockItems.action.saveCreate": "Create Stock Item",
    "wsManagerStockItems.organism.update.title": "Editar item de estoque",
    "wsManagerStockItems.intent.update.title": "Command Form",
    "wsManagerStockItems.action.saveUpdate": "Update Stock Item",
    "wsManagerStockItems.organism.delete.title": "Remover item de estoque",
    "wsManagerStockItems.intent.delete.title": "Command Form",
    "wsManagerStockItems.action.confirmDelete": "Delete Stock Item",
    "wsManagerStockItems.intent.summary.title": "Summary"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowWsManagerStockItemsBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.queryStockItemsState = 'idle';
        this.queryStockItemsStockItemId = '';
        this.queryStockItemsName = '';
        this.queryStockItemsStatus = '';
        this.queryStockItemsCreatedAt = '';
        this.queryStockItemsUpdatedAt = '';
        this.queryStockItemsData = [];
        this.createStockItemState = 'idle';
        this.createStockItemName = '';
        this.createStockItemUnitOfMeasure = '';
        this.createStockItemMinimumQuantity = '';
        this.createStockItemStatus = '';
        this.updateStockItemState = 'idle';
        this.updateStockItemName = '';
        this.updateStockItemUnitOfMeasure = '';
        this.updateStockItemMinimumQuantity = '';
        this.updateStockItemStatus = '';
        this.deleteStockItemState = 'idle';
        this.deleteStockItemStockItemId = '';
        this.deleteStockItemName = '';
        this.deleteStockItemUnitOfMeasure = '';
        this.deleteStockItemMinimumQuantity = '';
        this.deleteStockItemStatus = '';
        this._stateKeys = [
            'ui.ws-manager-stock-items.status',
            'ui.ws-manager-stock-items.action.queryStockItems.status',
            'ui.ws-manager-stock-items.input.queryStockItems.stockItemId',
            'ui.ws-manager-stock-items.input.queryStockItems.name',
            'ui.ws-manager-stock-items.input.queryStockItems.status',
            'ui.ws-manager-stock-items.input.queryStockItems.createdAt',
            'ui.ws-manager-stock-items.input.queryStockItems.updatedAt',
            'ui.ws-manager-stock-items.data.queryStockItems',
            'ui.ws-manager-stock-items.action.createStockItem.status',
            'ui.ws-manager-stock-items.input.createStockItem.name',
            'ui.ws-manager-stock-items.input.createStockItem.unitOfMeasure',
            'ui.ws-manager-stock-items.input.createStockItem.minimumQuantity',
            'ui.ws-manager-stock-items.input.createStockItem.status',
            'ui.ws-manager-stock-items.action.updateStockItem.status',
            'ui.ws-manager-stock-items.input.updateStockItem.name',
            'ui.ws-manager-stock-items.input.updateStockItem.unitOfMeasure',
            'ui.ws-manager-stock-items.input.updateStockItem.minimumQuantity',
            'ui.ws-manager-stock-items.input.updateStockItem.status',
            'ui.ws-manager-stock-items.action.deleteStockItem.status',
            'ui.ws-manager-stock-items.input.deleteStockItem.stockItemId',
            'ui.ws-manager-stock-items.input.deleteStockItem.name',
            'ui.ws-manager-stock-items.input.deleteStockItem.unitOfMeasure',
            'ui.ws-manager-stock-items.input.deleteStockItem.minimumQuantity',
            'ui.ws-manager-stock-items.input.deleteStockItem.status',
        ];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initializeStateFromStore();
        subscribe(this._stateKeys, this);
        void this.loadQueryStockItems();
    }
    disconnectedCallback() {
        unsubscribe(this._stateKeys, this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.ws-manager-stock-items.status':
                this.status = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-stock-items.action.queryStockItems.status':
                if (value === 'idle' || value === 'loading' || value === 'success' || value === 'error') {
                    this.queryStockItemsState = value;
                }
                break;
            case 'ui.ws-manager-stock-items.input.queryStockItems.stockItemId':
                this.queryStockItemsStockItemId = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-stock-items.input.queryStockItems.name':
                this.queryStockItemsName = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-stock-items.input.queryStockItems.status':
                this.queryStockItemsStatus = (value === 'active' || value === 'inactive') ? value : '';
                break;
            case 'ui.ws-manager-stock-items.input.queryStockItems.createdAt':
                this.queryStockItemsCreatedAt = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-stock-items.input.queryStockItems.updatedAt':
                this.queryStockItemsUpdatedAt = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-stock-items.data.queryStockItems':
                this.queryStockItemsData = Array.isArray(value) ? value : [];
                break;
            case 'ui.ws-manager-stock-items.action.createStockItem.status':
                if (value === 'idle' || value === 'loading' || value === 'success' || value === 'error') {
                    this.createStockItemState = value;
                }
                break;
            case 'ui.ws-manager-stock-items.input.createStockItem.name':
                this.createStockItemName = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-stock-items.input.createStockItem.unitOfMeasure':
                this.createStockItemUnitOfMeasure = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-stock-items.input.createStockItem.minimumQuantity':
                this.createStockItemMinimumQuantity = typeof value === 'number' ? value : '';
                break;
            case 'ui.ws-manager-stock-items.input.createStockItem.status':
                this.createStockItemStatus = (value === 'active' || value === 'inactive') ? value : '';
                break;
            case 'ui.ws-manager-stock-items.action.updateStockItem.status':
                if (value === 'idle' || value === 'loading' || value === 'success' || value === 'error') {
                    this.updateStockItemState = value;
                }
                break;
            case 'ui.ws-manager-stock-items.input.updateStockItem.name':
                this.updateStockItemName = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-stock-items.input.updateStockItem.unitOfMeasure':
                this.updateStockItemUnitOfMeasure = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-stock-items.input.updateStockItem.minimumQuantity':
                this.updateStockItemMinimumQuantity = typeof value === 'number' ? value : '';
                break;
            case 'ui.ws-manager-stock-items.input.updateStockItem.status':
                this.updateStockItemStatus = (value === 'active' || value === 'inactive') ? value : '';
                break;
            case 'ui.ws-manager-stock-items.action.deleteStockItem.status':
                if (value === 'idle' || value === 'loading' || value === 'success' || value === 'error') {
                    this.deleteStockItemState = value;
                }
                break;
            case 'ui.ws-manager-stock-items.input.deleteStockItem.stockItemId':
                this.deleteStockItemStockItemId = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-stock-items.input.deleteStockItem.name':
                this.deleteStockItemName = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-stock-items.input.deleteStockItem.unitOfMeasure':
                this.deleteStockItemUnitOfMeasure = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-stock-items.input.deleteStockItem.minimumQuantity':
                this.deleteStockItemMinimumQuantity = typeof value === 'number' ? value : '';
                break;
            case 'ui.ws-manager-stock-items.input.deleteStockItem.status':
                this.deleteStockItemStatus = (value === 'active' || value === 'inactive') ? value : '';
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initializeStateFromStore() {
        const statusValue = getState('ui.ws-manager-stock-items.status');
        if (statusValue !== undefined) {
            this.status = statusValue;
        }
        else {
            setState('ui.ws-manager-stock-items.status', this.status);
        }
        const queryStateValue = getState('ui.ws-manager-stock-items.action.queryStockItems.status');
        if (queryStateValue !== undefined) {
            this.queryStockItemsState = queryStateValue;
        }
        else {
            setState('ui.ws-manager-stock-items.action.queryStockItems.status', this.queryStockItemsState);
        }
        const queryStockItemIdValue = getState('ui.ws-manager-stock-items.input.queryStockItems.stockItemId');
        if (queryStockItemIdValue !== undefined) {
            this.queryStockItemsStockItemId = queryStockItemIdValue;
        }
        else {
            setState('ui.ws-manager-stock-items.input.queryStockItems.stockItemId', this.queryStockItemsStockItemId);
        }
        const queryNameValue = getState('ui.ws-manager-stock-items.input.queryStockItems.name');
        if (queryNameValue !== undefined) {
            this.queryStockItemsName = queryNameValue;
        }
        else {
            setState('ui.ws-manager-stock-items.input.queryStockItems.name', this.queryStockItemsName);
        }
        const queryStatusValue = getState('ui.ws-manager-stock-items.input.queryStockItems.status');
        if (queryStatusValue !== undefined) {
            this.queryStockItemsStatus = (queryStatusValue === 'active' || queryStatusValue === 'inactive') ? queryStatusValue : '';
        }
        else {
            setState('ui.ws-manager-stock-items.input.queryStockItems.status', this.queryStockItemsStatus);
        }
        const queryCreatedAtValue = getState('ui.ws-manager-stock-items.input.queryStockItems.createdAt');
        if (queryCreatedAtValue !== undefined) {
            this.queryStockItemsCreatedAt = queryCreatedAtValue;
        }
        else {
            setState('ui.ws-manager-stock-items.input.queryStockItems.createdAt', this.queryStockItemsCreatedAt);
        }
        const queryUpdatedAtValue = getState('ui.ws-manager-stock-items.input.queryStockItems.updatedAt');
        if (queryUpdatedAtValue !== undefined) {
            this.queryStockItemsUpdatedAt = queryUpdatedAtValue;
        }
        else {
            setState('ui.ws-manager-stock-items.input.queryStockItems.updatedAt', this.queryStockItemsUpdatedAt);
        }
        const queryDataValue = getState('ui.ws-manager-stock-items.data.queryStockItems');
        if (queryDataValue !== undefined) {
            this.queryStockItemsData = Array.isArray(queryDataValue) ? queryDataValue : [];
        }
        else {
            setState('ui.ws-manager-stock-items.data.queryStockItems', this.queryStockItemsData);
        }
        const createStateValue = getState('ui.ws-manager-stock-items.action.createStockItem.status');
        if (createStateValue !== undefined) {
            this.createStockItemState = createStateValue;
        }
        else {
            setState('ui.ws-manager-stock-items.action.createStockItem.status', this.createStockItemState);
        }
        const createNameValue = getState('ui.ws-manager-stock-items.input.createStockItem.name');
        if (createNameValue !== undefined) {
            this.createStockItemName = createNameValue;
        }
        else {
            setState('ui.ws-manager-stock-items.input.createStockItem.name', this.createStockItemName);
        }
        const createUnitValue = getState('ui.ws-manager-stock-items.input.createStockItem.unitOfMeasure');
        if (createUnitValue !== undefined) {
            this.createStockItemUnitOfMeasure = createUnitValue;
        }
        else {
            setState('ui.ws-manager-stock-items.input.createStockItem.unitOfMeasure', this.createStockItemUnitOfMeasure);
        }
        const createMinValue = getState('ui.ws-manager-stock-items.input.createStockItem.minimumQuantity');
        if (createMinValue !== undefined) {
            this.createStockItemMinimumQuantity = typeof createMinValue === 'number' ? createMinValue : '';
        }
        else {
            setState('ui.ws-manager-stock-items.input.createStockItem.minimumQuantity', this.createStockItemMinimumQuantity);
        }
        const createStatusValue = getState('ui.ws-manager-stock-items.input.createStockItem.status');
        if (createStatusValue !== undefined) {
            this.createStockItemStatus = (createStatusValue === 'active' || createStatusValue === 'inactive') ? createStatusValue : '';
        }
        else {
            setState('ui.ws-manager-stock-items.input.createStockItem.status', this.createStockItemStatus);
        }
        const updateStateValue = getState('ui.ws-manager-stock-items.action.updateStockItem.status');
        if (updateStateValue !== undefined) {
            this.updateStockItemState = updateStateValue;
        }
        else {
            setState('ui.ws-manager-stock-items.action.updateStockItem.status', this.updateStockItemState);
        }
        const updateNameValue = getState('ui.ws-manager-stock-items.input.updateStockItem.name');
        if (updateNameValue !== undefined) {
            this.updateStockItemName = updateNameValue;
        }
        else {
            setState('ui.ws-manager-stock-items.input.updateStockItem.name', this.updateStockItemName);
        }
        const updateUnitValue = getState('ui.ws-manager-stock-items.input.updateStockItem.unitOfMeasure');
        if (updateUnitValue !== undefined) {
            this.updateStockItemUnitOfMeasure = updateUnitValue;
        }
        else {
            setState('ui.ws-manager-stock-items.input.updateStockItem.unitOfMeasure', this.updateStockItemUnitOfMeasure);
        }
        const updateMinValue = getState('ui.ws-manager-stock-items.input.updateStockItem.minimumQuantity');
        if (updateMinValue !== undefined) {
            this.updateStockItemMinimumQuantity = typeof updateMinValue === 'number' ? updateMinValue : '';
        }
        else {
            setState('ui.ws-manager-stock-items.input.updateStockItem.minimumQuantity', this.updateStockItemMinimumQuantity);
        }
        const updateStatusValue = getState('ui.ws-manager-stock-items.input.updateStockItem.status');
        if (updateStatusValue !== undefined) {
            this.updateStockItemStatus = (updateStatusValue === 'active' || updateStatusValue === 'inactive') ? updateStatusValue : '';
        }
        else {
            setState('ui.ws-manager-stock-items.input.updateStockItem.status', this.updateStockItemStatus);
        }
        const deleteStateValue = getState('ui.ws-manager-stock-items.action.deleteStockItem.status');
        if (deleteStateValue !== undefined) {
            this.deleteStockItemState = deleteStateValue;
        }
        else {
            setState('ui.ws-manager-stock-items.action.deleteStockItem.status', this.deleteStockItemState);
        }
        const deleteStockItemIdValue = getState('ui.ws-manager-stock-items.input.deleteStockItem.stockItemId');
        if (deleteStockItemIdValue !== undefined) {
            this.deleteStockItemStockItemId = deleteStockItemIdValue;
        }
        else {
            setState('ui.ws-manager-stock-items.input.deleteStockItem.stockItemId', this.deleteStockItemStockItemId);
        }
        const deleteNameValue = getState('ui.ws-manager-stock-items.input.deleteStockItem.name');
        if (deleteNameValue !== undefined) {
            this.deleteStockItemName = deleteNameValue;
        }
        else {
            setState('ui.ws-manager-stock-items.input.deleteStockItem.name', this.deleteStockItemName);
        }
        const deleteUnitValue = getState('ui.ws-manager-stock-items.input.deleteStockItem.unitOfMeasure');
        if (deleteUnitValue !== undefined) {
            this.deleteStockItemUnitOfMeasure = deleteUnitValue;
        }
        else {
            setState('ui.ws-manager-stock-items.input.deleteStockItem.unitOfMeasure', this.deleteStockItemUnitOfMeasure);
        }
        const deleteMinValue = getState('ui.ws-manager-stock-items.input.deleteStockItem.minimumQuantity');
        if (deleteMinValue !== undefined) {
            this.deleteStockItemMinimumQuantity = typeof deleteMinValue === 'number' ? deleteMinValue : '';
        }
        else {
            setState('ui.ws-manager-stock-items.input.deleteStockItem.minimumQuantity', this.deleteStockItemMinimumQuantity);
        }
        const deleteStatusValue = getState('ui.ws-manager-stock-items.input.deleteStockItem.status');
        if (deleteStatusValue !== undefined) {
            this.deleteStockItemStatus = (deleteStatusValue === 'active' || deleteStatusValue === 'inactive') ? deleteStatusValue : '';
        }
        else {
            setState('ui.ws-manager-stock-items.input.deleteStockItem.status', this.deleteStockItemStatus);
        }
    }
    setQueryStockItemsStockItemId(value) {
        this.queryStockItemsStockItemId = value;
        setState('ui.ws-manager-stock-items.input.queryStockItems.stockItemId', value);
        this.requestUpdate();
    }
    handleQueryStockItemsStockItemIdChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setQueryStockItemsStockItemId(value);
    }
    setQueryStockItemsName(value) {
        this.queryStockItemsName = value;
        setState('ui.ws-manager-stock-items.input.queryStockItems.name', value);
        this.requestUpdate();
    }
    handleQueryStockItemsNameChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setQueryStockItemsName(value);
    }
    setQueryStockItemsStatus(value) {
        this.queryStockItemsStatus = value;
        setState('ui.ws-manager-stock-items.input.queryStockItems.status', value);
        this.requestUpdate();
    }
    handleQueryStockItemsStatusChange(event) {
        const target = event.target;
        const rawValue = target?.value ?? '';
        const value = (rawValue === 'active' || rawValue === 'inactive') ? rawValue : '';
        this.setQueryStockItemsStatus(value);
    }
    setQueryStockItemsCreatedAt(value) {
        this.queryStockItemsCreatedAt = value;
        setState('ui.ws-manager-stock-items.input.queryStockItems.createdAt', value);
        this.requestUpdate();
    }
    handleQueryStockItemsCreatedAtChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setQueryStockItemsCreatedAt(value);
    }
    setQueryStockItemsUpdatedAt(value) {
        this.queryStockItemsUpdatedAt = value;
        setState('ui.ws-manager-stock-items.input.queryStockItems.updatedAt', value);
        this.requestUpdate();
    }
    handleQueryStockItemsUpdatedAtChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setQueryStockItemsUpdatedAt(value);
    }
    setCreateStockItemName(value) {
        this.createStockItemName = value;
        setState('ui.ws-manager-stock-items.input.createStockItem.name', value);
        this.requestUpdate();
    }
    handleCreateStockItemNameChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setCreateStockItemName(value);
    }
    setCreateStockItemUnitOfMeasure(value) {
        this.createStockItemUnitOfMeasure = value;
        setState('ui.ws-manager-stock-items.input.createStockItem.unitOfMeasure', value);
        this.requestUpdate();
    }
    handleCreateStockItemUnitOfMeasureChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setCreateStockItemUnitOfMeasure(value);
    }
    setCreateStockItemMinimumQuantity(value) {
        this.createStockItemMinimumQuantity = value;
        setState('ui.ws-manager-stock-items.input.createStockItem.minimumQuantity', value);
        this.requestUpdate();
    }
    handleCreateStockItemMinimumQuantityChange(event) {
        const target = event.target;
        const rawValue = target?.value ?? '';
        const value = rawValue === '' ? '' : Number(rawValue);
        if (value !== '' && Number.isNaN(value)) {
            return;
        }
        this.setCreateStockItemMinimumQuantity(value);
    }
    setCreateStockItemStatus(value) {
        this.createStockItemStatus = value;
        setState('ui.ws-manager-stock-items.input.createStockItem.status', value);
        this.requestUpdate();
    }
    handleCreateStockItemStatusChange(event) {
        const target = event.target;
        const rawValue = target?.value ?? '';
        const value = (rawValue === 'active' || rawValue === 'inactive') ? rawValue : '';
        this.setCreateStockItemStatus(value);
    }
    setUpdateStockItemName(value) {
        this.updateStockItemName = value;
        setState('ui.ws-manager-stock-items.input.updateStockItem.name', value);
        this.requestUpdate();
    }
    handleUpdateStockItemNameChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setUpdateStockItemName(value);
    }
    setUpdateStockItemUnitOfMeasure(value) {
        this.updateStockItemUnitOfMeasure = value;
        setState('ui.ws-manager-stock-items.input.updateStockItem.unitOfMeasure', value);
        this.requestUpdate();
    }
    handleUpdateStockItemUnitOfMeasureChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setUpdateStockItemUnitOfMeasure(value);
    }
    setUpdateStockItemMinimumQuantity(value) {
        this.updateStockItemMinimumQuantity = value;
        setState('ui.ws-manager-stock-items.input.updateStockItem.minimumQuantity', value);
        this.requestUpdate();
    }
    handleUpdateStockItemMinimumQuantityChange(event) {
        const target = event.target;
        const rawValue = target?.value ?? '';
        const value = rawValue === '' ? '' : Number(rawValue);
        if (value !== '' && Number.isNaN(value)) {
            return;
        }
        this.setUpdateStockItemMinimumQuantity(value);
    }
    setUpdateStockItemStatus(value) {
        this.updateStockItemStatus = value;
        setState('ui.ws-manager-stock-items.input.updateStockItem.status', value);
        this.requestUpdate();
    }
    handleUpdateStockItemStatusChange(event) {
        const target = event.target;
        const rawValue = target?.value ?? '';
        const value = (rawValue === 'active' || rawValue === 'inactive') ? rawValue : '';
        this.setUpdateStockItemStatus(value);
    }
    setDeleteStockItemStockItemId(value) {
        this.deleteStockItemStockItemId = value;
        setState('ui.ws-manager-stock-items.input.deleteStockItem.stockItemId', value);
        this.requestUpdate();
    }
    handleDeleteStockItemStockItemIdChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setDeleteStockItemStockItemId(value);
    }
    setDeleteStockItemName(value) {
        this.deleteStockItemName = value;
        setState('ui.ws-manager-stock-items.input.deleteStockItem.name', value);
        this.requestUpdate();
    }
    handleDeleteStockItemNameChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setDeleteStockItemName(value);
    }
    setDeleteStockItemUnitOfMeasure(value) {
        this.deleteStockItemUnitOfMeasure = value;
        setState('ui.ws-manager-stock-items.input.deleteStockItem.unitOfMeasure', value);
        this.requestUpdate();
    }
    handleDeleteStockItemUnitOfMeasureChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setDeleteStockItemUnitOfMeasure(value);
    }
    setDeleteStockItemMinimumQuantity(value) {
        this.deleteStockItemMinimumQuantity = value;
        setState('ui.ws-manager-stock-items.input.deleteStockItem.minimumQuantity', value);
        this.requestUpdate();
    }
    handleDeleteStockItemMinimumQuantityChange(event) {
        const target = event.target;
        const rawValue = target?.value ?? '';
        const value = rawValue === '' ? '' : Number(rawValue);
        if (value !== '' && Number.isNaN(value)) {
            return;
        }
        this.setDeleteStockItemMinimumQuantity(value);
    }
    setDeleteStockItemStatus(value) {
        this.deleteStockItemStatus = value;
        setState('ui.ws-manager-stock-items.input.deleteStockItem.status', value);
        this.requestUpdate();
    }
    handleDeleteStockItemStatusChange(event) {
        const target = event.target;
        const rawValue = target?.value ?? '';
        const value = (rawValue === 'active' || rawValue === 'inactive') ? rawValue : '';
        this.setDeleteStockItemStatus(value);
    }
    async loadQueryStockItems(options = {}) {
        this.queryStockItemsState = 'loading';
        setState('ui.ws-manager-stock-items.action.queryStockItems.status', 'loading');
        const params = {
            stockItemId: this.queryStockItemsStockItemId || undefined,
            name: this.queryStockItemsName || undefined,
            status: (this.queryStockItemsStatus === 'active' || this.queryStockItemsStatus === 'inactive') ? this.queryStockItemsStatus : undefined,
            createdAt: this.queryStockItemsCreatedAt || undefined,
            updatedAt: this.queryStockItemsUpdatedAt || undefined,
        };
        try {
            const response = await execBff('cafeFlow.queryStockItems.queryStockItems', params, { ...options, mode: 'silent' });
            if (response.ok) {
                const data = Array.isArray(response.data) ? response.data : [];
                this.queryStockItemsData = data;
                setState('ui.ws-manager-stock-items.data.queryStockItems', data);
                this.queryStockItemsState = 'success';
                setState('ui.ws-manager-stock-items.action.queryStockItems.status', 'success');
                return;
            }
            this.queryStockItemsState = 'error';
            setState('ui.ws-manager-stock-items.action.queryStockItems.status', 'error');
            throw new Error(response.error?.message ?? 'Erro ao consultar itens de estoque.');
        }
        catch (error) {
            this.queryStockItemsState = 'error';
            setState('ui.ws-manager-stock-items.action.queryStockItems.status', 'error');
            throw error;
        }
    }
    handleQueryStockItemsClick(event) {
        void event;
        void this.loadQueryStockItems({ mode: 'silent' });
    }
    async createStockItem(options = {}) {
        this.createStockItemState = 'loading';
        setState('ui.ws-manager-stock-items.action.createStockItem.status', 'loading');
        if (this.createStockItemStatus !== 'active' && this.createStockItemStatus !== 'inactive') {
            this.createStockItemState = 'error';
            setState('ui.ws-manager-stock-items.action.createStockItem.status', 'error');
            throw new Error('Status inválido para criação de item.');
        }
        if (this.createStockItemMinimumQuantity === '') {
            this.createStockItemState = 'error';
            setState('ui.ws-manager-stock-items.action.createStockItem.status', 'error');
            throw new Error('Quantidade mínima obrigatória.');
        }
        const params = {
            name: this.createStockItemName,
            unitOfMeasure: this.createStockItemUnitOfMeasure,
            minimumQuantity: this.createStockItemMinimumQuantity,
            status: this.createStockItemStatus,
        };
        try {
            const response = await execBff('cafeFlow.createStockItem.createStockItem', params, { ...options, mode: 'blocking' });
            if (response.ok) {
                this.createStockItemState = 'success';
                setState('ui.ws-manager-stock-items.action.createStockItem.status', 'success');
                return;
            }
            this.createStockItemState = 'error';
            setState('ui.ws-manager-stock-items.action.createStockItem.status', 'error');
            throw new Error(response.error?.message ?? 'Erro ao criar item de estoque.');
        }
        catch (error) {
            this.createStockItemState = 'error';
            setState('ui.ws-manager-stock-items.action.createStockItem.status', 'error');
            throw error;
        }
    }
    handleCreateStockItemClick(event) {
        void event;
        void runBlockingUiAction((signal) => this.createStockItem({ mode: 'blocking', signal }), { mode: 'blocking' });
    }
    async updateStockItem(options = {}) {
        this.updateStockItemState = 'loading';
        setState('ui.ws-manager-stock-items.action.updateStockItem.status', 'loading');
        if (this.updateStockItemStatus !== 'active' && this.updateStockItemStatus !== 'inactive') {
            this.updateStockItemState = 'error';
            setState('ui.ws-manager-stock-items.action.updateStockItem.status', 'error');
            throw new Error('Status inválido para atualização de item.');
        }
        if (this.updateStockItemMinimumQuantity === '') {
            this.updateStockItemState = 'error';
            setState('ui.ws-manager-stock-items.action.updateStockItem.status', 'error');
            throw new Error('Quantidade mínima obrigatória.');
        }
        const params = {
            name: this.updateStockItemName,
            unitOfMeasure: this.updateStockItemUnitOfMeasure,
            minimumQuantity: this.updateStockItemMinimumQuantity,
            status: this.updateStockItemStatus,
        };
        try {
            const response = await execBff('cafeFlow.updateStockItem.updateStockItem', params, { ...options, mode: 'blocking' });
            if (response.ok) {
                this.updateStockItemState = 'success';
                setState('ui.ws-manager-stock-items.action.updateStockItem.status', 'success');
                return;
            }
            this.updateStockItemState = 'error';
            setState('ui.ws-manager-stock-items.action.updateStockItem.status', 'error');
            throw new Error(response.error?.message ?? 'Erro ao atualizar item de estoque.');
        }
        catch (error) {
            this.updateStockItemState = 'error';
            setState('ui.ws-manager-stock-items.action.updateStockItem.status', 'error');
            throw error;
        }
    }
    handleUpdateStockItemClick(event) {
        void event;
        void runBlockingUiAction((signal) => this.updateStockItem({ mode: 'blocking', signal }), { mode: 'blocking' });
    }
    async deleteStockItem(options = {}) {
        this.deleteStockItemState = 'loading';
        setState('ui.ws-manager-stock-items.action.deleteStockItem.status', 'loading');
        if (this.deleteStockItemStatus !== 'active' && this.deleteStockItemStatus !== 'inactive') {
            this.deleteStockItemState = 'error';
            setState('ui.ws-manager-stock-items.action.deleteStockItem.status', 'error');
            throw new Error('Status inválido para exclusão de item.');
        }
        if (this.deleteStockItemMinimumQuantity === '') {
            this.deleteStockItemState = 'error';
            setState('ui.ws-manager-stock-items.action.deleteStockItem.status', 'error');
            throw new Error('Quantidade mínima obrigatória.');
        }
        const params = {
            stockItemId: this.deleteStockItemStockItemId || undefined,
            name: this.deleteStockItemName,
            unitOfMeasure: this.deleteStockItemUnitOfMeasure,
            minimumQuantity: this.deleteStockItemMinimumQuantity,
            status: this.deleteStockItemStatus,
        };
        try {
            const response = await execBff('cafeFlow.deleteStockItem.deleteStockItem', params, { ...options, mode: 'blocking' });
            if (response.ok) {
                this.deleteStockItemState = 'success';
                setState('ui.ws-manager-stock-items.action.deleteStockItem.status', 'success');
                return;
            }
            this.deleteStockItemState = 'error';
            setState('ui.ws-manager-stock-items.action.deleteStockItem.status', 'error');
            throw new Error(response.error?.message ?? 'Erro ao remover item de estoque.');
        }
        catch (error) {
            this.deleteStockItemState = 'error';
            setState('ui.ws-manager-stock-items.action.deleteStockItem.status', 'error');
            throw error;
        }
    }
    handleDeleteStockItemClick(event) {
        void event;
        void runBlockingUiAction((signal) => this.deleteStockItem({ mode: 'blocking', signal }), { mode: 'blocking' });
    }
}
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "queryStockItemsState", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "queryStockItemsStockItemId", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "queryStockItemsName", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "queryStockItemsStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "queryStockItemsCreatedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "queryStockItemsUpdatedAt", void 0);
__decorate([
    property({ type: Array })
], CafeFlowWsManagerStockItemsBase.prototype, "queryStockItemsData", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "createStockItemState", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "createStockItemName", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "createStockItemUnitOfMeasure", void 0);
__decorate([
    property({ type: Number })
], CafeFlowWsManagerStockItemsBase.prototype, "createStockItemMinimumQuantity", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "createStockItemStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "updateStockItemState", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "updateStockItemName", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "updateStockItemUnitOfMeasure", void 0);
__decorate([
    property({ type: Number })
], CafeFlowWsManagerStockItemsBase.prototype, "updateStockItemMinimumQuantity", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "updateStockItemStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "deleteStockItemState", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "deleteStockItemStockItemId", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "deleteStockItemName", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "deleteStockItemUnitOfMeasure", void 0);
__decorate([
    property({ type: Number })
], CafeFlowWsManagerStockItemsBase.prototype, "deleteStockItemMinimumQuantity", void 0);
__decorate([
    property({ type: String })
], CafeFlowWsManagerStockItemsBase.prototype, "deleteStockItemStatus", void 0);

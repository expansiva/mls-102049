/// <mls fileReference="_102049_/l2/cafeFlow/web/contracts/ws-attendant-pos.ts" enhancement="_blank"/>
export {};

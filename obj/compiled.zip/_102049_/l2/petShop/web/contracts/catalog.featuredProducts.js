/// <mls fileReference="_102049_/l2/petShop/web/contracts/catalog.featuredProducts.ts" enhancement="_blank"/>
export const featuredProductsRoute = 'petShop.catalog.featuredProducts';

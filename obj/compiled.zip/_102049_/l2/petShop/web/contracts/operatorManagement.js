/// <mls fileReference="_102049_/l2/petShop/web/contracts/operatorManagement.ts" enhancement="_blank"/>
export {};

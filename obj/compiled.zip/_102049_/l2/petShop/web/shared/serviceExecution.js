/// <mls fileReference="_102049_/l2/petShop/web/shared/serviceExecution.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "page.title": "Execução de serviço agendado",
    "section.bookings.title": "Agenda de atendimentos",
    "section.bookings.empty": "Selecione um agendamento para iniciar ou concluir o atendimento.",
    "section.start.title": "Iniciar atendimento",
    "section.start.empty": "Selecione um agendamento confirmado na agenda acima para iniciar o atendimento.",
    "section.complete.title": "Concluir serviço",
    "section.complete.empty": "Selecione um agendamento em andamento na agenda acima para concluir o serviço.",
    "section.review.title": "Resumo da execução",
    "section.review.empty": "Nenhuma ação executada ainda. Selecione um agendamento e execute uma ação para visualizar o resumo.",
    "column.customerName": "Cliente",
    "column.bookingDate": "Data",
    "column.bookingTime": "Horário",
    "column.status": "Status",
    "column.notes": "Observações",
    "column.updatedAt": "Atualizado em",
    "column.completedAt": "Concluído em",
    "filter.status": "Filtrar por status",
    "field.serviceBookingId": "Agendamento selecionado",
    "action.startServiceExecution": "Iniciar atendimento",
    "action.completeServiceExecution": "Concluir serviço",
    "action.startServiceExecution.success": "Atendimento iniciado com sucesso. O agendamento está em andamento.",
    "action.startServiceExecution.error": "Não foi possível iniciar o atendimento. Verifique se você é o operador atribuído e tente novamente.",
    "action.completeServiceExecution.success": "Serviço concluído com sucesso. A capacidade do operador foi liberada para novos agendamentos.",
    "action.completeServiceExecution.error": "Não foi possível concluir o serviço. Verifique se o agendamento está em andamento e tente novamente.",
    "intention.bookingQuery.title": "Agendamentos atribuídos",
    "intention.workflowStatus.title": "Status do agendamento selecionado",
    "intention.startForm.title": "Confirmar início do atendimento",
    "intention.completeForm.title": "Confirmar conclusão do serviço",
    "intention.review.title": "Resultado da última ação",
    "sec.bookings.title": "Agenda de atendimentos",
    "org.booking.list.title": "Listar agendamentos atribuídos ao operador para seleção e execução",
    "sec.start.service.title": "Iniciar atendimento",
    "org.start.service.title": "Iniciar atendimento do serviço agendado",
    "sec.complete.service.title": "Concluir serviço",
    "org.complete.service.title": "Concluir serviço agendado",
    "sec.review.title": "Resumo da execução",
    "org.review.title": "Revisar o contexto e o resultado das ações principais da página"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class PetShopServiceExecutionBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = "";
        this.startServiceExecutionState = "idle";
        this.startServiceExecutionServiceBookingId = "";
        this.startServiceExecutionOutput = null;
        this.startServiceExecutionError = "";
        this.completeServiceExecutionState = "idle";
        this.completeServiceExecutionServiceBookingId = "";
        this.completeServiceExecutionOutput = null;
        this.completeServiceExecutionError = "";
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        const existingStatus = getState("ui.serviceExecution.status");
        if (existingStatus !== undefined) {
            this.status = existingStatus;
        }
        const existingStartBookingId = getState("ui.serviceExecution.input.startServiceExecution.serviceBookingId");
        if (existingStartBookingId !== undefined) {
            this.startServiceExecutionServiceBookingId = existingStartBookingId;
        }
        const existingCompleteBookingId = getState("ui.serviceExecution.input.completeServiceExecution.serviceBookingId");
        if (existingCompleteBookingId !== undefined) {
            this.completeServiceExecutionServiceBookingId = existingCompleteBookingId;
        }
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    // --- State setters ---
    setStartServiceExecutionServiceBookingId(value) {
        this.startServiceExecutionServiceBookingId = value;
        setState("ui.serviceExecution.input.startServiceExecution.serviceBookingId", value);
        this.requestUpdate();
    }
    handleStartServiceExecutionServiceBookingIdChange(e) {
        const target = e.target;
        if (!target)
            return;
        const value = target.value ?? "";
        this.setStartServiceExecutionServiceBookingId(value);
    }
    setCompleteServiceExecutionServiceBookingId(value) {
        this.completeServiceExecutionServiceBookingId = value;
        setState("ui.serviceExecution.input.completeServiceExecution.serviceBookingId", value);
        this.requestUpdate();
    }
    handleCompleteServiceExecutionServiceBookingIdChange(e) {
        const target = e.target;
        if (!target)
            return;
        const value = target.value ?? "";
        this.setCompleteServiceExecutionServiceBookingId(value);
    }
    // --- Command: startServiceExecution ---
    async startServiceExecution() {
        if (!this.startServiceExecutionServiceBookingId) {
            this.startServiceExecutionState = "idle";
            setState("ui.serviceExecution.action.startServiceExecution.status", "idle");
            this.requestUpdate();
            return;
        }
        this.startServiceExecutionState = "loading";
        setState("ui.serviceExecution.action.startServiceExecution.status", "loading");
        this.requestUpdate();
        const params = {
            serviceBookingId: this.startServiceExecutionServiceBookingId,
        };
        const options = { mode: "blocking" };
        const response = await execBff("petShop.serviceBookingLifecycle.startServiceExecution", params, options);
        if (response.ok) {
            const outputData = response.data ?? null;
            this.startServiceExecutionOutput = outputData;
            setState("ui.serviceExecution.output.startServiceExecution", outputData);
            // Clear input state keys on success
            this.startServiceExecutionServiceBookingId = "";
            setState("ui.serviceExecution.input.startServiceExecution.serviceBookingId", "");
            this.startServiceExecutionError = "";
            setState("ui.serviceExecution.action.startServiceExecution.error", "");
            this.startServiceExecutionState = "success";
            setState("ui.serviceExecution.action.startServiceExecution.status", "success");
        }
        else {
            const errorMsg = response.error?.message ?? this.msg["action.startServiceExecution.error"];
            this.startServiceExecutionError = errorMsg;
            setState("ui.serviceExecution.action.startServiceExecution.error", errorMsg);
            this.startServiceExecutionState = "error";
            setState("ui.serviceExecution.action.startServiceExecution.status", "error");
        }
        this.requestUpdate();
    }
    handleStartServiceExecutionClick() {
        runBlockingUiAction(async (_signal) => {
            await this.startServiceExecution();
        }, { mode: "blocking" });
    }
    // --- Command: completeServiceExecution ---
    async completeServiceExecution() {
        if (!this.completeServiceExecutionServiceBookingId) {
            this.completeServiceExecutionState = "idle";
            setState("ui.serviceExecution.action.completeServiceExecution.status", "idle");
            this.requestUpdate();
            return;
        }
        this.completeServiceExecutionState = "loading";
        setState("ui.serviceExecution.action.completeServiceExecution.status", "loading");
        this.requestUpdate();
        const params = {
            serviceBookingId: this.completeServiceExecutionServiceBookingId,
        };
        const options = { mode: "blocking" };
        const response = await execBff("petShop.serviceBookingLifecycle.completeServiceExecution", params, options);
        if (response.ok) {
            const outputData = response.data ?? null;
            this.completeServiceExecutionOutput = outputData;
            setState("ui.serviceExecution.output.completeServiceExecution", outputData);
            // Clear input state keys on success
            this.completeServiceExecutionServiceBookingId = "";
            setState("ui.serviceExecution.input.completeServiceExecution.serviceBookingId", "");
            this.completeServiceExecutionError = "";
            setState("ui.serviceExecution.action.completeServiceExecution.error", "");
            this.completeServiceExecutionState = "success";
            setState("ui.serviceExecution.action.completeServiceExecution.status", "success");
        }
        else {
            const errorMsg = response.error?.message ?? this.msg["action.completeServiceExecution.error"];
            this.completeServiceExecutionError = errorMsg;
            setState("ui.serviceExecution.action.completeServiceExecution.error", errorMsg);
            this.completeServiceExecutionState = "error";
            setState("ui.serviceExecution.action.completeServiceExecution.status", "error");
        }
        this.requestUpdate();
    }
    handleCompleteServiceExecutionClick() {
        runBlockingUiAction(async (_signal) => {
            await this.completeServiceExecution();
        }, { mode: "blocking" });
    }
}
__decorate([
    property({ type: String })
], PetShopServiceExecutionBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], PetShopServiceExecutionBase.prototype, "startServiceExecutionState", void 0);
__decorate([
    property({ type: String })
], PetShopServiceExecutionBase.prototype, "startServiceExecutionServiceBookingId", void 0);
__decorate([
    property({ type: Object })
], PetShopServiceExecutionBase.prototype, "startServiceExecutionOutput", void 0);
__decorate([
    property({ type: String })
], PetShopServiceExecutionBase.prototype, "startServiceExecutionError", void 0);
__decorate([
    property({ type: String })
], PetShopServiceExecutionBase.prototype, "completeServiceExecutionState", void 0);
__decorate([
    property({ type: String })
], PetShopServiceExecutionBase.prototype, "completeServiceExecutionServiceBookingId", void 0);
__decorate([
    property({ type: Object })
], PetShopServiceExecutionBase.prototype, "completeServiceExecutionOutput", void 0);
__decorate([
    property({ type: String })
], PetShopServiceExecutionBase.prototype, "completeServiceExecutionError", void 0);

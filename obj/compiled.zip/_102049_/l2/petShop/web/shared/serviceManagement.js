/// <mls fileReference="_102049_/l2/petShop/web/shared/serviceManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "section.serviceManagement.title": "Gestão de serviços",
    "browseServices.title": "Serviços cadastrados",
    "browseServices.empty": "Nenhum serviço cadastrado ainda. Clique em \"Cadastrar serviço\" para adicionar o primeiro.",
    "createService.title": "Cadastrar novo serviço",
    "createService.empty": "Preencha os campos abaixo para cadastrar um novo serviço.",
    "updateService.title": "Editar serviço",
    "updateService.empty": "Selecione um serviço na lista para editar seus dados.",
    "field.name": "Nome",
    "field.description": "Descrição",
    "field.estimatedDurationMinutes": "Duração estimada (min)",
    "field.price": "Preço",
    "field.status": "Status",
    "field.serviceId": "ID do serviço",
    "filter.statusFilter": "Filtrar por status",
    "toolbar.createService": "Cadastrar serviço",
    "rowAction.updateService": "Editar",
    "action.createService.submit": "Confirmar cadastro",
    "action.updateService.submit": "Salvar alterações",
    "status.active": "Ativo",
    "status.inactive": "Inativo",
    "action.createService.success": "Serviço cadastrado com sucesso e disponível para agendamento.",
    "action.createService.error": "Não foi possível cadastrar o serviço. Verifique os dados e tente novamente.",
    "action.updateService.success": "Serviço atualizado com sucesso.",
    "action.updateService.error": "Não foi possível atualizar o serviço. Verifique os dados e tente novamente.",
    "org.browse.services.title": "Listar serviços cadastrados com filtros e ações por linha",
    "org.create.service.title": "Formulário de cadastro de novo serviço",
    "org.update.service.title": "Formulário de edição e ativação/desativação de serviço existente"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class PetShopServiceManagementBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.browseServicesState = "idle";
        this.browseServicesStatusFilter = '';
        this.browseServicesData = { items: [], total: 0 };
        this.createServiceState = "idle";
        this.createServiceName = '';
        this.createServiceDescription = '';
        this.createServiceEstimatedDurationMinutes = '';
        this.createServicePrice = '';
        this.createServiceOutput = null;
        this.createServiceError = '';
        this.updateServiceState = "idle";
        this.updateServiceServiceId = '';
        this.updateServiceName = '';
        this.updateServiceDescription = '';
        this.updateServiceEstimatedDurationMinutes = '';
        this.updateServicePrice = '';
        this.updateServiceStatus = '';
        this.updateServiceOutput = null;
        this.updateServiceError = '';
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    /* ---------- State setters ---------- */
    setBrowseServicesStatusFilter(value) {
        this.browseServicesStatusFilter = value;
        setState('ui.serviceManagement.input.browseServices.statusFilter', value);
        this.requestUpdate();
    }
    handleBrowseServicesStatusFilterChange(e) {
        const target = e.target;
        if (!target)
            return;
        this.setBrowseServicesStatusFilter(target.value);
    }
    setCreateServiceName(value) {
        this.createServiceName = value;
        setState('ui.serviceManagement.input.createService.name', value);
        this.requestUpdate();
    }
    handleCreateServiceNameChange(e) {
        const target = e.target;
        if (!target)
            return;
        this.setCreateServiceName(target.value);
    }
    setCreateServiceDescription(value) {
        this.createServiceDescription = value;
        setState('ui.serviceManagement.input.createService.description', value);
        this.requestUpdate();
    }
    handleCreateServiceDescriptionChange(e) {
        const target = e.target;
        if (!target)
            return;
        this.setCreateServiceDescription(target.value);
    }
    setCreateServiceEstimatedDurationMinutes(value) {
        this.createServiceEstimatedDurationMinutes = value;
        setState('ui.serviceManagement.input.createService.estimatedDurationMinutes', value);
        this.requestUpdate();
    }
    handleCreateServiceEstimatedDurationMinutesChange(e) {
        const target = e.target;
        if (!target)
            return;
        this.setCreateServiceEstimatedDurationMinutes(target.value);
    }
    setCreateServicePrice(value) {
        this.createServicePrice = value;
        setState('ui.serviceManagement.input.createService.price', value);
        this.requestUpdate();
    }
    handleCreateServicePriceChange(e) {
        const target = e.target;
        if (!target)
            return;
        this.setCreateServicePrice(target.value);
    }
    setUpdateServiceServiceId(value) {
        this.updateServiceServiceId = value;
        setState('ui.serviceManagement.input.updateService.serviceId', value);
        this.requestUpdate();
    }
    handleUpdateServiceServiceIdChange(e) {
        const target = e.target;
        if (!target)
            return;
        this.setUpdateServiceServiceId(target.value);
    }
    setUpdateServiceName(value) {
        this.updateServiceName = value;
        setState('ui.serviceManagement.input.updateService.name', value);
        this.requestUpdate();
    }
    handleUpdateServiceNameChange(e) {
        const target = e.target;
        if (!target)
            return;
        this.setUpdateServiceName(target.value);
    }
    setUpdateServiceDescription(value) {
        this.updateServiceDescription = value;
        setState('ui.serviceManagement.input.updateService.description', value);
        this.requestUpdate();
    }
    handleUpdateServiceDescriptionChange(e) {
        const target = e.target;
        if (!target)
            return;
        this.setUpdateServiceDescription(target.value);
    }
    setUpdateServiceEstimatedDurationMinutes(value) {
        this.updateServiceEstimatedDurationMinutes = value;
        setState('ui.serviceManagement.input.updateService.estimatedDurationMinutes', value);
        this.requestUpdate();
    }
    handleUpdateServiceEstimatedDurationMinutesChange(e) {
        const target = e.target;
        if (!target)
            return;
        this.setUpdateServiceEstimatedDurationMinutes(target.value);
    }
    setUpdateServicePrice(value) {
        this.updateServicePrice = value;
        setState('ui.serviceManagement.input.updateService.price', value);
        this.requestUpdate();
    }
    handleUpdateServicePriceChange(e) {
        const target = e.target;
        if (!target)
            return;
        this.setUpdateServicePrice(target.value);
    }
    setUpdateServiceStatus(value) {
        this.updateServiceStatus = value;
        setState('ui.serviceManagement.input.updateService.status', value);
        this.requestUpdate();
    }
    handleUpdateServiceStatusChange(e) {
        const target = e.target;
        if (!target)
            return;
        this.setUpdateServiceStatus(target.value);
    }
    /* ---------- Query / Command actions ---------- */
    async loadBrowseServices() {
        this.browseServicesState = 'loading';
        setState('ui.serviceManagement.action.browseServices.status', 'loading');
        this.requestUpdate();
        const params = {};
        if (this.browseServicesStatusFilter === 'active' || this.browseServicesStatusFilter === 'inactive') {
            params.statusFilter = this.browseServicesStatusFilter;
        }
        const options = { mode: 'silent' };
        const response = await execBff('petShop.browseServices.browseServices', params, options);
        if (response.ok) {
            const data = response.data ?? { items: [], total: 0 };
            this.browseServicesData = data;
            setState('ui.serviceManagement.data.browseServices', data);
            this.browseServicesState = 'success';
            setState('ui.serviceManagement.action.browseServices.status', 'success');
        }
        else {
            this.browseServicesData = { items: [], total: 0 };
            setState('ui.serviceManagement.data.browseServices', { items: [], total: 0 });
            this.browseServicesState = 'error';
            setState('ui.serviceManagement.action.browseServices.status', 'error');
            if (response.error) {
                console.error('[browseServices]', response.error.message);
            }
        }
        this.requestUpdate();
    }
    handleBrowseServicesClick() {
        this.loadBrowseServices();
    }
    async createService() {
        this.createServiceState = 'loading';
        setState('ui.serviceManagement.action.createService.status', 'loading');
        this.createServiceError = '';
        setState('ui.serviceManagement.action.createService.error', '');
        this.requestUpdate();
        const estimatedDuration = parseInt(this.createServiceEstimatedDurationMinutes, 10);
        const price = parseFloat(this.createServicePrice);
        const params = {
            name: this.createServiceName,
            description: this.createServiceDescription,
            estimatedDurationMinutes: isNaN(estimatedDuration) ? 0 : estimatedDuration,
            price: isNaN(price) ? 0 : price,
        };
        const options = { mode: 'blocking' };
        const response = await execBff('petShop.createService.createService', params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.createServiceOutput = data;
            setState('ui.serviceManagement.output.createService', data);
            // Refresh browseServices before setting success
            await this.loadBrowseServices();
            if (this.browseServicesState === 'error') {
                this.createServiceState = 'error';
                setState('ui.serviceManagement.action.createService.status', 'error');
                this.requestUpdate();
                return;
            }
            // Clear inputs
            this.createServiceName = '';
            setState('ui.serviceManagement.input.createService.name', '');
            this.createServiceDescription = '';
            setState('ui.serviceManagement.input.createService.description', '');
            this.createServiceEstimatedDurationMinutes = '';
            setState('ui.serviceManagement.input.createService.estimatedDurationMinutes', '');
            this.createServicePrice = '';
            setState('ui.serviceManagement.input.createService.price', '');
            this.createServiceState = 'success';
            setState('ui.serviceManagement.action.createService.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? this.msg['action.createService.error'];
            this.createServiceError = errorMsg;
            setState('ui.serviceManagement.action.createService.error', errorMsg);
            this.createServiceState = 'error';
            setState('ui.serviceManagement.action.createService.status', 'error');
        }
        this.requestUpdate();
    }
    handleCreateServiceClick() {
        runBlockingUiAction(async (_signal) => {
            await this.createService();
        }, { mode: 'blocking' });
    }
    async updateService() {
        this.updateServiceState = 'loading';
        setState('ui.serviceManagement.action.updateService.status', 'loading');
        this.updateServiceError = '';
        setState('ui.serviceManagement.action.updateService.error', '');
        this.requestUpdate();
        const estimatedDuration = parseInt(this.updateServiceEstimatedDurationMinutes, 10);
        const price = parseFloat(this.updateServicePrice);
        const params = {
            serviceId: this.updateServiceServiceId,
            name: this.updateServiceName,
            description: this.updateServiceDescription,
            estimatedDurationMinutes: isNaN(estimatedDuration) ? 0 : estimatedDuration,
            price: isNaN(price) ? 0 : price,
            status: (this.updateServiceStatus === 'active' || this.updateServiceStatus === 'inactive')
                ? this.updateServiceStatus
                : 'active',
        };
        const options = { mode: 'blocking' };
        const response = await execBff('petShop.updateService.updateService', params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.updateServiceOutput = data;
            setState('ui.serviceManagement.output.updateService', data);
            // Refresh browseServices before setting success
            await this.loadBrowseServices();
            if (this.browseServicesState === 'error') {
                this.updateServiceState = 'error';
                setState('ui.serviceManagement.action.updateService.status', 'error');
                this.requestUpdate();
                return;
            }
            // Clear inputs
            this.updateServiceServiceId = '';
            setState('ui.serviceManagement.input.updateService.serviceId', '');
            this.updateServiceName = '';
            setState('ui.serviceManagement.input.updateService.name', '');
            this.updateServiceDescription = '';
            setState('ui.serviceManagement.input.updateService.description', '');
            this.updateServiceEstimatedDurationMinutes = '';
            setState('ui.serviceManagement.input.updateService.estimatedDurationMinutes', '');
            this.updateServicePrice = '';
            setState('ui.serviceManagement.input.updateService.price', '');
            this.updateServiceStatus = '';
            setState('ui.serviceManagement.input.updateService.status', '');
            this.updateServiceState = 'success';
            setState('ui.serviceManagement.action.updateService.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? this.msg['action.updateService.error'];
            this.updateServiceError = errorMsg;
            setState('ui.serviceManagement.action.updateService.error', errorMsg);
            this.updateServiceState = 'error';
            setState('ui.serviceManagement.action.updateService.status', 'error');
        }
        this.requestUpdate();
    }
    handleUpdateServiceClick() {
        runBlockingUiAction(async (_signal) => {
            await this.updateService();
        }, { mode: 'blocking' });
    }
    /* ---------- Lifecycle ---------- */
    connectedCallback() {
        super.connectedCallback();
        // Initialize state from global store where useful
        const savedStatusFilter = getState('ui.serviceManagement.input.browseServices.statusFilter');
        if (savedStatusFilter !== undefined && savedStatusFilter !== null) {
            this.browseServicesStatusFilter = savedStatusFilter;
        }
        const savedBrowseData = getState('ui.serviceManagement.data.browseServices');
        if (savedBrowseData) {
            this.browseServicesData = savedBrowseData;
        }
        // Subscribe to shared states
        subscribe([
            'ui.serviceManagement.input.browseServices.statusFilter',
            'ui.serviceManagement.data.browseServices',
        ], this);
        // Run initial loads
        this.loadBrowseServices();
    }
    disconnectedCallback() {
        unsubscribe([
            'ui.serviceManagement.input.browseServices.statusFilter',
            'ui.serviceManagement.data.browseServices',
        ], this);
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], PetShopServiceManagementBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], PetShopServiceManagementBase.prototype, "browseServicesState", void 0);
__decorate([
    property({ type: String })
], PetShopServiceManagementBase.prototype, "browseServicesStatusFilter", void 0);
__decorate([
    property({ type: Object })
], PetShopServiceManagementBase.prototype, "browseServicesData", void 0);
__decorate([
    property({ type: String })
], PetShopServiceManagementBase.prototype, "createServiceState", void 0);
__decorate([
    property({ type: String })
], PetShopServiceManagementBase.prototype, "createServiceName", void 0);
__decorate([
    property({ type: String })
], PetShopServiceManagementBase.prototype, "createServiceDescription", void 0);
__decorate([
    property({ type: String })
], PetShopServiceManagementBase.prototype, "createServiceEstimatedDurationMinutes", void 0);
__decorate([
    property({ type: String })
], PetShopServiceManagementBase.prototype, "createServicePrice", void 0);
__decorate([
    property({ type: Object })
], PetShopServiceManagementBase.prototype, "createServiceOutput", void 0);
__decorate([
    property({ type: String })
], PetShopServiceManagementBase.prototype, "createServiceError", void 0);
__decorate([
    property({ type: String })
], PetShopServiceManagementBase.prototype, "updateServiceState", void 0);
__decorate([
    property({ type: String })
], PetShopServiceManagementBase.prototype, "updateServiceServiceId", void 0);
__decorate([
    property({ type: String })
], PetShopServiceManagementBase.prototype, "updateServiceName", void 0);
__decorate([
    property({ type: String })
], PetShopServiceManagementBase.prototype, "updateServiceDescription", void 0);
__decorate([
    property({ type: String })
], PetShopServiceManagementBase.prototype, "updateServiceEstimatedDurationMinutes", void 0);
__decorate([
    property({ type: String })
], PetShopServiceManagementBase.prototype, "updateServicePrice", void 0);
__decorate([
    property({ type: String })
], PetShopServiceManagementBase.prototype, "updateServiceStatus", void 0);
__decorate([
    property({ type: Object })
], PetShopServiceManagementBase.prototype, "updateServiceOutput", void 0);
__decorate([
    property({ type: String })
], PetShopServiceManagementBase.prototype, "updateServiceError", void 0);

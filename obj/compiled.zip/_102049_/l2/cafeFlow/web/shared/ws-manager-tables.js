/// <mls fileReference="_102049_/l2/cafeFlow/web/shared/ws-manager-tables.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "ws-manager-tables.section.gestaoMesas.title": "Gestão de Mesas",
    "ws-manager-tables.organism.queryTables.title": "Consultar mesas",
    "ws-manager-tables.intent.queryTables.title": "Query List",
    "ws-manager-tables.table.tableId": "Table Id",
    "ws-manager-tables.table.number": "Number",
    "ws-manager-tables.table.name": "Name",
    "ws-manager-tables.table.status": "Status",
    "ws-manager-tables.table.createdAt": "Created At",
    "ws-manager-tables.table.updatedAt": "Updated At",
    "ws-manager-tables.filter.tableId": "Table Id",
    "ws-manager-tables.filter.name": "Name",
    "ws-manager-tables.filter.status": "Status",
    "ws-manager-tables.filter.createdAt": "Created At",
    "ws-manager-tables.filter.updatedAt": "Updated At",
    "ws-manager-tables.action.queryTables": "Query Tables",
    "ws-manager-tables.organism.createTable.title": "Cadastrar mesa",
    "ws-manager-tables.intent.createTable.title": "Command Form",
    "ws-manager-tables.field.number": "Number",
    "ws-manager-tables.field.name": "Name",
    "ws-manager-tables.field.status": "Status",
    "ws-manager-tables.action.createTable": "Create Table",
    "ws-manager-tables.organism.updateTable.title": "Editar mesa",
    "ws-manager-tables.intent.updateTable.title": "Command Form",
    "ws-manager-tables.action.updateTable": "Update Table",
    "ws-manager-tables.organism.deleteTable.title": "Remover mesa",
    "ws-manager-tables.intent.deleteTable.title": "Command Form",
    "ws-manager-tables.field.tableId": "Table Id",
    "ws-manager-tables.action.deleteTable": "Delete Table",
    "ws-manager-tables.organism.summary.title": "Revisar contexto e resultados",
    "ws-manager-tables.intent.summary.title": "Summary"
};
const messages = { pt: message_pt };
export class CafeFlowWsManagerTablesBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.queryTablesState = 'idle';
        this.queryTablesTableId = '';
        this.queryTablesName = '';
        this.queryTablesStatus = '';
        this.queryTablesCreatedAt = '';
        this.queryTablesUpdatedAt = '';
        this.queryTablesData = [];
        this.createTableState = 'idle';
        this.createTableNumber = '';
        this.createTableName = '';
        this.createTableStatus = '';
        this.updateTableState = 'idle';
        this.updateTableNumber = '';
        this.updateTableName = '';
        this.updateTableStatus = '';
        this.deleteTableState = 'idle';
        this.deleteTableTableId = '';
        this.deleteTableNumber = '';
        this.deleteTableName = '';
        this.deleteTableStatus = '';
        this.stateKeys = [
            'ui.ws-manager-tables.status',
            'ui.ws-manager-tables.action.queryTables.status',
            'ui.ws-manager-tables.input.queryTables.tableId',
            'ui.ws-manager-tables.input.queryTables.name',
            'ui.ws-manager-tables.input.queryTables.status',
            'ui.ws-manager-tables.input.queryTables.createdAt',
            'ui.ws-manager-tables.input.queryTables.updatedAt',
            'ui.ws-manager-tables.data.queryTables',
            'ui.ws-manager-tables.action.createTable.status',
            'ui.ws-manager-tables.input.createTable.number',
            'ui.ws-manager-tables.input.createTable.name',
            'ui.ws-manager-tables.input.createTable.status',
            'ui.ws-manager-tables.action.updateTable.status',
            'ui.ws-manager-tables.input.updateTable.number',
            'ui.ws-manager-tables.input.updateTable.name',
            'ui.ws-manager-tables.input.updateTable.status',
            'ui.ws-manager-tables.action.deleteTable.status',
            'ui.ws-manager-tables.input.deleteTable.tableId',
            'ui.ws-manager-tables.input.deleteTable.number',
            'ui.ws-manager-tables.input.deleteTable.name',
            'ui.ws-manager-tables.input.deleteTable.status',
        ];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.stateKeys.forEach((key) => {
            const value = getState(key);
            this.applyStateValue(key, value);
        });
        subscribe(this.stateKeys, this);
        void this.loadQueryTables();
    }
    disconnectedCallback() {
        unsubscribe(this.stateKeys, this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(stateKey, value) {
        this.applyStateValue(stateKey, value);
    }
    applyStateValue(stateKey, value) {
        switch (stateKey) {
            case 'ui.ws-manager-tables.status':
                this.status = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-tables.action.queryTables.status':
                this.queryTablesState = value ?? 'idle';
                break;
            case 'ui.ws-manager-tables.input.queryTables.tableId':
                this.queryTablesTableId = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-tables.input.queryTables.name':
                this.queryTablesName = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-tables.input.queryTables.status':
                this.queryTablesStatus = (typeof value === 'string' ? value : '');
                break;
            case 'ui.ws-manager-tables.input.queryTables.createdAt':
                this.queryTablesCreatedAt = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-tables.input.queryTables.updatedAt':
                this.queryTablesUpdatedAt = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-tables.data.queryTables':
                this.queryTablesData = Array.isArray(value) ? value : [];
                break;
            case 'ui.ws-manager-tables.action.createTable.status':
                this.createTableState = value ?? 'idle';
                break;
            case 'ui.ws-manager-tables.input.createTable.number':
                this.createTableNumber = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-tables.input.createTable.name':
                this.createTableName = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-tables.input.createTable.status':
                this.createTableStatus = (typeof value === 'string' ? value : '');
                break;
            case 'ui.ws-manager-tables.action.updateTable.status':
                this.updateTableState = value ?? 'idle';
                break;
            case 'ui.ws-manager-tables.input.updateTable.number':
                this.updateTableNumber = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-tables.input.updateTable.name':
                this.updateTableName = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-tables.input.updateTable.status':
                this.updateTableStatus = (typeof value === 'string' ? value : '');
                break;
            case 'ui.ws-manager-tables.action.deleteTable.status':
                this.deleteTableState = value ?? 'idle';
                break;
            case 'ui.ws-manager-tables.input.deleteTable.tableId':
                this.deleteTableTableId = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-tables.input.deleteTable.number':
                this.deleteTableNumber = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-tables.input.deleteTable.name':
                this.deleteTableName = typeof value === 'string' ? value : '';
                break;
            case 'ui.ws-manager-tables.input.deleteTable.status':
                this.deleteTableStatus = (typeof value === 'string' ? value : '');
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    getInputValue(event) {
        const target = event.target;
        if (!target) {
            return null;
        }
        return target.value;
    }
    setQueryTablesTableId(value) {
        this.queryTablesTableId = value;
        setState('ui.ws-manager-tables.input.queryTables.tableId', value);
        this.requestUpdate();
    }
    handleQueryTablesTableIdChange(event) {
        const value = this.getInputValue(event);
        if (value === null) {
            return;
        }
        this.setQueryTablesTableId(value);
    }
    setQueryTablesName(value) {
        this.queryTablesName = value;
        setState('ui.ws-manager-tables.input.queryTables.name', value);
        this.requestUpdate();
    }
    handleQueryTablesNameChange(event) {
        const value = this.getInputValue(event);
        if (value === null) {
            return;
        }
        this.setQueryTablesName(value);
    }
    setQueryTablesStatus(value) {
        this.queryTablesStatus = value;
        setState('ui.ws-manager-tables.input.queryTables.status', value);
        this.requestUpdate();
    }
    handleQueryTablesStatusChange(event) {
        const value = this.getInputValue(event);
        if (value === null) {
            return;
        }
        this.setQueryTablesStatus(value);
    }
    setQueryTablesCreatedAt(value) {
        this.queryTablesCreatedAt = value;
        setState('ui.ws-manager-tables.input.queryTables.createdAt', value);
        this.requestUpdate();
    }
    handleQueryTablesCreatedAtChange(event) {
        const value = this.getInputValue(event);
        if (value === null) {
            return;
        }
        this.setQueryTablesCreatedAt(value);
    }
    setQueryTablesUpdatedAt(value) {
        this.queryTablesUpdatedAt = value;
        setState('ui.ws-manager-tables.input.queryTables.updatedAt', value);
        this.requestUpdate();
    }
    handleQueryTablesUpdatedAtChange(event) {
        const value = this.getInputValue(event);
        if (value === null) {
            return;
        }
        this.setQueryTablesUpdatedAt(value);
    }
    setCreateTableNumber(value) {
        this.createTableNumber = value;
        setState('ui.ws-manager-tables.input.createTable.number', value);
        this.requestUpdate();
    }
    handleCreateTableNumberChange(event) {
        const value = this.getInputValue(event);
        if (value === null) {
            return;
        }
        this.setCreateTableNumber(value);
    }
    setCreateTableName(value) {
        this.createTableName = value;
        setState('ui.ws-manager-tables.input.createTable.name', value);
        this.requestUpdate();
    }
    handleCreateTableNameChange(event) {
        const value = this.getInputValue(event);
        if (value === null) {
            return;
        }
        this.setCreateTableName(value);
    }
    setCreateTableStatus(value) {
        this.createTableStatus = value;
        setState('ui.ws-manager-tables.input.createTable.status', value);
        this.requestUpdate();
    }
    handleCreateTableStatusChange(event) {
        const value = this.getInputValue(event);
        if (value === null) {
            return;
        }
        this.setCreateTableStatus(value);
    }
    setUpdateTableNumber(value) {
        this.updateTableNumber = value;
        setState('ui.ws-manager-tables.input.updateTable.number', value);
        this.requestUpdate();
    }
    handleUpdateTableNumberChange(event) {
        const value = this.getInputValue(event);
        if (value === null) {
            return;
        }
        this.setUpdateTableNumber(value);
    }
    setUpdateTableName(value) {
        this.updateTableName = value;
        setState('ui.ws-manager-tables.input.updateTable.name', value);
        this.requestUpdate();
    }
    handleUpdateTableNameChange(event) {
        const value = this.getInputValue(event);
        if (value === null) {
            return;
        }
        this.setUpdateTableName(value);
    }
    setUpdateTableStatus(value) {
        this.updateTableStatus = value;
        setState('ui.ws-manager-tables.input.updateTable.status', value);
        this.requestUpdate();
    }
    handleUpdateTableStatusChange(event) {
        const value = this.getInputValue(event);
        if (value === null) {
            return;
        }
        this.setUpdateTableStatus(value);
    }
    setDeleteTableTableId(value) {
        this.deleteTableTableId = value;
        setState('ui.ws-manager-tables.input.deleteTable.tableId', value);
        this.requestUpdate();
    }
    handleDeleteTableTableIdChange(event) {
        const value = this.getInputValue(event);
        if (value === null) {
            return;
        }
        this.setDeleteTableTableId(value);
    }
    setDeleteTableNumber(value) {
        this.deleteTableNumber = value;
        setState('ui.ws-manager-tables.input.deleteTable.number', value);
        this.requestUpdate();
    }
    handleDeleteTableNumberChange(event) {
        const value = this.getInputValue(event);
        if (value === null) {
            return;
        }
        this.setDeleteTableNumber(value);
    }
    setDeleteTableName(value) {
        this.deleteTableName = value;
        setState('ui.ws-manager-tables.input.deleteTable.name', value);
        this.requestUpdate();
    }
    handleDeleteTableNameChange(event) {
        const value = this.getInputValue(event);
        if (value === null) {
            return;
        }
        this.setDeleteTableName(value);
    }
    setDeleteTableStatus(value) {
        this.deleteTableStatus = value;
        setState('ui.ws-manager-tables.input.deleteTable.status', value);
        this.requestUpdate();
    }
    handleDeleteTableStatusChange(event) {
        const value = this.getInputValue(event);
        if (value === null) {
            return;
        }
        this.setDeleteTableStatus(value);
    }
    async loadQueryTables(signal) {
        this.queryTablesState = 'loading';
        setState('ui.ws-manager-tables.action.queryTables.status', 'loading');
        const params = {
            tableId: this.queryTablesTableId || undefined,
            name: this.queryTablesName || undefined,
            status: (this.queryTablesStatus || undefined),
            createdAt: this.queryTablesCreatedAt || undefined,
            updatedAt: this.queryTablesUpdatedAt || undefined,
        };
        const options = { mode: 'silent', signal };
        const response = await execBff('cafeFlow.queryTables.queryTables', params, options);
        if (!response.ok) {
            this.queryTablesState = 'error';
            setState('ui.ws-manager-tables.action.queryTables.status', 'error');
            return;
        }
        const data = response.data ?? [];
        this.queryTablesData = Array.isArray(data) ? data : [];
        setState('ui.ws-manager-tables.data.queryTables', this.queryTablesData);
        this.queryTablesState = 'success';
        setState('ui.ws-manager-tables.action.queryTables.status', 'success');
    }
    handleQueryTablesClick(event) {
        event.preventDefault();
        void this.loadQueryTables();
    }
    async createTable(signal) {
        if (!this.createTableStatus) {
            this.createTableState = 'error';
            setState('ui.ws-manager-tables.action.createTable.status', 'error');
            throw new Error('Status obrigatório');
        }
        this.createTableState = 'loading';
        setState('ui.ws-manager-tables.action.createTable.status', 'loading');
        const params = {
            number: this.createTableNumber,
            name: this.createTableName || undefined,
            status: this.createTableStatus,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('cafeFlow.createTable.createTable', params, options);
        if (!response.ok) {
            this.createTableState = 'error';
            setState('ui.ws-manager-tables.action.createTable.status', 'error');
            throw new Error(response.error?.message ?? 'Erro ao criar mesa');
        }
        this.createTableState = 'success';
        setState('ui.ws-manager-tables.action.createTable.status', 'success');
    }
    handleCreateTableClick(event) {
        event.preventDefault();
        void runBlockingUiAction((signal) => this.createTable(signal));
    }
    async updateTable(signal) {
        if (!this.updateTableStatus) {
            this.updateTableState = 'error';
            setState('ui.ws-manager-tables.action.updateTable.status', 'error');
            throw new Error('Status obrigatório');
        }
        this.updateTableState = 'loading';
        setState('ui.ws-manager-tables.action.updateTable.status', 'loading');
        const params = {
            number: this.updateTableNumber,
            name: this.updateTableName || undefined,
            status: this.updateTableStatus,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('cafeFlow.updateTable.updateTable', params, options);
        if (!response.ok) {
            this.updateTableState = 'error';
            setState('ui.ws-manager-tables.action.updateTable.status', 'error');
            throw new Error(response.error?.message ?? 'Erro ao atualizar mesa');
        }
        this.updateTableState = 'success';
        setState('ui.ws-manager-tables.action.updateTable.status', 'success');
    }
    handleUpdateTableClick(event) {
        event.preventDefault();
        void runBlockingUiAction((signal) => this.updateTable(signal));
    }
    async deleteTable(signal) {
        if (!this.deleteTableStatus) {
            this.deleteTableState = 'error';
            setState('ui.ws-manager-tables.action.deleteTable.status', 'error');
            throw new Error('Status obrigatório');
        }
        this.deleteTableState = 'loading';
        setState('ui.ws-manager-tables.action.deleteTable.status', 'loading');
        const params = {
            tableId: this.deleteTableTableId || undefined,
            number: this.deleteTableNumber,
            name: this.deleteTableName || undefined,
            status: this.deleteTableStatus,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('cafeFlow.deleteTable.deleteTable', params, options);
        if (!response.ok) {
            this.deleteTableState = 'error';
            setState('ui.ws-manager-tables.action.deleteTable.status', 'error');
            throw new Error(response.error?.message ?? 'Erro ao remover mesa');
        }
        this.deleteTableState = 'success';
        setState('ui.ws-manager-tables.action.deleteTable.status', 'success');
    }
    handleDeleteTableClick(event) {
        event.preventDefault();
        void runBlockingUiAction((signal) => this.deleteTable(signal));
    }
}
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "queryTablesState", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "queryTablesTableId", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "queryTablesName", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "queryTablesStatus", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "queryTablesCreatedAt", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "queryTablesUpdatedAt", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "queryTablesData", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "createTableState", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "createTableNumber", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "createTableName", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "createTableStatus", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "updateTableState", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "updateTableNumber", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "updateTableName", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "updateTableStatus", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "deleteTableState", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "deleteTableTableId", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "deleteTableNumber", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "deleteTableName", void 0);
__decorate([
    property()
], CafeFlowWsManagerTablesBase.prototype, "deleteTableStatus", void 0);

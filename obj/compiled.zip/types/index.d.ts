declare module "_102049_/l1/cafeFlow/layer_1_external/dailySalesMetrics.defs" {
    export const dailySalesMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "dailySalesMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 50;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "dailySalesMetrics";
                readonly tableName: "daily_sales_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Métricas de vendas do dia";
                readonly purpose: "Acompanhar receita, quantidade de pedidos e ticket médio em tempo real durante o turno.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "recorded_at";
                readonly columns: readonly [{
                    readonly name: "recorded_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da medição registrada.";
                }, {
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do pedido.";
                }, {
                    readonly name: "order_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do item do pedido.";
                }, {
                    readonly name: "menu_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do item do cardápio.";
                }, {
                    readonly name: "menu_category_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador da categoria do cardápio.";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do turno diário.";
                }, {
                    readonly name: "table_seat_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador da mesa/comanda.";
                }, {
                    readonly name: "order_status_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do status do pedido.";
                }, {
                    readonly name: "inventory_item_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador do item de estoque associado ao item do cardápio.";
                }, {
                    readonly name: "revenue";
                    readonly type: "decimal";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Receita gerada no registro.";
                }, {
                    readonly name: "order_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de pedidos no registro.";
                }, {
                    readonly name: "items_sold";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de itens vendidos no registro.";
                }, {
                    readonly name: "average_ticket";
                    readonly type: "decimal";
                    readonly nullable: true;
                    readonly description: "Ticket médio calculado para o período do registro.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "orderId";
                    readonly column: "order_id";
                    readonly type: "string";
                    readonly description: "Identificador do pedido";
                }, {
                    readonly dimensionId: "orderItemId";
                    readonly column: "order_item_id";
                    readonly type: "string";
                    readonly description: "Identificador do item do pedido";
                }, {
                    readonly dimensionId: "menuItemId";
                    readonly column: "menu_item_id";
                    readonly type: "string";
                    readonly description: "Identificador do item do cardápio";
                }, {
                    readonly dimensionId: "menuCategoryId";
                    readonly column: "menu_category_id";
                    readonly type: "string";
                    readonly description: "Identificador da categoria do cardápio";
                }, {
                    readonly dimensionId: "dailyShiftId";
                    readonly column: "daily_shift_id";
                    readonly type: "string";
                    readonly description: "Identificador do turno diário";
                }, {
                    readonly dimensionId: "tableSeatId";
                    readonly column: "table_seat_id";
                    readonly type: "string";
                    readonly description: "Identificador da mesa/comanda";
                }, {
                    readonly dimensionId: "orderStatusId";
                    readonly column: "order_status_id";
                    readonly type: "string";
                    readonly description: "Identificador do status do pedido";
                }, {
                    readonly dimensionId: "inventoryItemId";
                    readonly column: "inventory_item_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship menuItemInventory (MenuItem -> InventoryItem)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "revenue";
                    readonly column: "revenue";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Receita gerada";
                }, {
                    readonly measureId: "orderCount";
                    readonly column: "order_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de pedidos";
                }, {
                    readonly measureId: "itemsSold";
                    readonly column: "items_sold";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de itens vendidos";
                }, {
                    readonly measureId: "averageTicket";
                    readonly column: "average_ticket";
                    readonly aggregation: "avg";
                    readonly unit: "BRL";
                    readonly description: "Ticket médio";
                }];
                readonly sourceWriteEvents: readonly ["order.created", "order.statusUpdated", "orderItem.created"];
                readonly hypertable: {
                    readonly timeColumn: "recorded_at";
                    readonly chunkTimeInterval: "1 day";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_daily_sales_metrics_recorded_at";
                        readonly columns: readonly ["recorded_at"];
                        readonly purpose: "Filtrar e ordenar por tempo.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_shift_time";
                        readonly columns: readonly ["daily_shift_id", "recorded_at"];
                        readonly purpose: "Consultas por turno e período.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_order_status_time";
                        readonly columns: readonly ["order_status_id", "recorded_at"];
                        readonly purpose: "Filtrar por status e período.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_menu_item_time";
                        readonly columns: readonly ["menu_item_id", "recorded_at"];
                        readonly purpose: "Agrupar por item do cardápio no tempo.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_table_seat_time";
                        readonly columns: readonly ["table_seat_id", "recorded_at"];
                        readonly purpose: "Filtrar por mesa/comanda e período.";
                    }, {
                        readonly indexName: "idx_daily_sales_metrics_inventory_item_time";
                        readonly columns: readonly ["inventory_item_id", "recorded_at"];
                        readonly purpose: "Filtrar por item de estoque e período.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["viewDashboard", "closeDailyShift"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderStatusLifecycle", "inventoryDecrementRule"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/dailySalesMetrics.defs.ts";
                readonly exportName: "dailySalesMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default dailySalesMetricsMetricTableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/dailyShift.defs" {
    export const dailyShiftTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "dailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 48;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "dailyShift";
                readonly tableName: "daily_shifts";
                readonly moduleId: "cafeFlow";
                readonly title: "Turnos Diários";
                readonly purpose: "Controlar abertura e fechamento de turnos.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "DailyShift";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do turno diário.";
                }, {
                    readonly name: "business_date";
                    readonly type: "date";
                    readonly nullable: false;
                    readonly description: "Data de referência do turno.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Estado atual do turno diário.";
                }, {
                    readonly name: "opened_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de abertura do turno.";
                }, {
                    readonly name: "closed_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly description: "Data e hora de fechamento do turno.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["daily_shift_id"];
                readonly indexes: readonly [{
                    readonly indexName: "idx_daily_shifts_business_date";
                    readonly columns: readonly ["business_date"];
                    readonly unique: false;
                    readonly reason: "Filtrar e localizar turno por data.";
                }, {
                    readonly indexName: "idx_daily_shifts_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Filtrar turnos por estado.";
                }, {
                    readonly indexName: "idx_daily_shifts_business_date_status";
                    readonly columns: readonly ["business_date", "status"];
                    readonly unique: false;
                    readonly reason: "Relatórios e fluxo de fechamento por data e estado.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["shiftClosureRule"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/dailyShift.defs.ts";
                readonly exportName: "dailyShiftTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default dailyShiftTableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/inventoryAlertMetrics.defs" {
    export const inventoryAlertMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "inventoryAlertMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 52;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "inventoryAlertMetrics";
                readonly tableName: "inventory_alert_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Alertas de estoque baixo";
                readonly purpose: "Monitorar níveis de estoque e disparar alertas quando itens atingirem quantidade mínima.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "recorded_at";
                readonly columns: readonly [{
                    readonly name: "recorded_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp de registro da métrica.";
                }, {
                    readonly name: "inventory_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do item de estoque.";
                }, {
                    readonly name: "stock_unit_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador da unidade de medida.";
                }, {
                    readonly name: "movement_type";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Tipo de movimentação.";
                }, {
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador do pedido relacionado.";
                }, {
                    readonly name: "table_seat_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador da mesa/comanda relacionada ao pedido.";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador do turno diário relacionado ao pedido.";
                }, {
                    readonly name: "order_status_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador do status do pedido.";
                }, {
                    readonly name: "current_stock";
                    readonly type: "decimal";
                    readonly nullable: false;
                    readonly description: "Estoque atual do item.";
                }, {
                    readonly name: "low_stock_alert_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Contagem de alertas de estoque baixo.";
                }, {
                    readonly name: "quantity_delta";
                    readonly type: "decimal";
                    readonly nullable: false;
                    readonly description: "Variação de quantidade em movimentações.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "inventoryItemId";
                    readonly column: "inventory_item_id";
                    readonly type: "string";
                    readonly description: "Identificador do item de estoque";
                }, {
                    readonly dimensionId: "stockUnitId";
                    readonly column: "stock_unit_id";
                    readonly type: "string";
                    readonly description: "Identificador da unidade de medida";
                }, {
                    readonly dimensionId: "movementType";
                    readonly column: "movement_type";
                    readonly type: "string";
                    readonly description: "Tipo de movimentação";
                }, {
                    readonly dimensionId: "orderId";
                    readonly column: "order_id";
                    readonly type: "string";
                    readonly description: "Identificador do pedido relacionado";
                }, {
                    readonly dimensionId: "tableSeatId";
                    readonly column: "table_seat_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship orderTableSeat (Order -> TableSeat)";
                }, {
                    readonly dimensionId: "dailyShiftId";
                    readonly column: "daily_shift_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship shiftOrders (Order -> DailyShift)";
                }, {
                    readonly dimensionId: "orderStatusId";
                    readonly column: "order_status_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship orderStatusRef (Order -> OrderStatus)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "currentStock";
                    readonly column: "current_stock";
                    readonly aggregation: "last";
                    readonly unit: "unit";
                    readonly description: "Estoque atual do item";
                }, {
                    readonly measureId: "lowStockAlertCount";
                    readonly column: "low_stock_alert_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Contagem de alertas de estoque baixo";
                }, {
                    readonly measureId: "quantityDelta";
                    readonly column: "quantity_delta";
                    readonly aggregation: "sum";
                    readonly unit: "unit";
                    readonly description: "Variação de quantidade em movimentações";
                }];
                readonly sourceWriteEvents: readonly ["inventoryMovement.created", "inventoryItem.updated"];
                readonly hypertable: {
                    readonly timeColumn: "recorded_at";
                    readonly chunkTimeInterval: "1 day";
                    readonly retentionPolicy: "90 days";
                    readonly compressionPolicy: "7 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_inventory_alert_metrics_recorded_at";
                        readonly columns: readonly ["recorded_at"];
                        readonly purpose: "Filtro temporal padrão para métricas de alerta.";
                    }, {
                        readonly indexName: "idx_inventory_alert_metrics_item_time";
                        readonly columns: readonly ["inventory_item_id", "recorded_at"];
                        readonly purpose: "Análise temporal por item de estoque.";
                    }, {
                        readonly indexName: "idx_inventory_alert_metrics_stock_unit_time";
                        readonly columns: readonly ["stock_unit_id", "recorded_at"];
                        readonly purpose: "Agrupamentos por unidade de medida no tempo.";
                    }, {
                        readonly indexName: "idx_inventory_alert_metrics_movement_type_time";
                        readonly columns: readonly ["movement_type", "recorded_at"];
                        readonly purpose: "Filtrar por tipo de movimentação ao longo do tempo.";
                    }, {
                        readonly indexName: "idx_inventory_alert_metrics_order_time";
                        readonly columns: readonly ["order_id", "recorded_at"];
                        readonly purpose: "Rastreio temporal por pedido relacionado.";
                    }, {
                        readonly indexName: "idx_inventory_alert_metrics_table_seat_time";
                        readonly columns: readonly ["table_seat_id", "recorded_at"];
                        readonly purpose: "Rastreio temporal por mesa/comanda.";
                    }, {
                        readonly indexName: "idx_inventory_alert_metrics_daily_shift_time";
                        readonly columns: readonly ["daily_shift_id", "recorded_at"];
                        readonly purpose: "Rastreio temporal por turno diário.";
                    }, {
                        readonly indexName: "idx_inventory_alert_metrics_order_status_time";
                        readonly columns: readonly ["order_status_id", "recorded_at"];
                        readonly purpose: "Rastreio temporal por status do pedido.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["manageInventory", "recordInventoryMovement"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["lowStockAlertRule", "inventoryDecrementRule"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/inventoryAlertMetrics.defs.ts";
                readonly exportName: "inventoryAlertMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default inventoryAlertMetricsTableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/inventoryItem.defs" {
    export const inventoryItemTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "inventoryItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 49;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "inventoryItem";
                readonly tableName: "inventory_items";
                readonly moduleId: "cafeFlow";
                readonly title: "Itens de Estoque";
                readonly purpose: "Manter saldo e parâmetros de estoque por item.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "InventoryItem";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "inventory_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do item de estoque.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Nome do ingrediente ou insumo.";
                }, {
                    readonly name: "description";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Descrição complementar do item de estoque.";
                }, {
                    readonly name: "stock_unit_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Unidade de medida usada para o item de estoque.";
                }, {
                    readonly name: "current_stock";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Quantidade atual em estoque.";
                }, {
                    readonly name: "minimum_stock";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Quantidade mínima para alerta de estoque baixo.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly default: "active";
                    readonly description: "Status do item de estoque (active, inactive).";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["inventory_item_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "stock_unit_id";
                    readonly targetEntity: "StockUnit";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Unidade de medida é domínio MDM.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_inventory_items_name";
                    readonly columns: readonly ["name"];
                    readonly unique: false;
                    readonly reason: "Busca por nome na gestão de estoque.";
                }, {
                    readonly indexName: "idx_inventory_items_stock_unit";
                    readonly columns: readonly ["stock_unit_id"];
                    readonly unique: false;
                    readonly reason: "Filtragem por unidade de medida.";
                }, {
                    readonly indexName: "idx_inventory_items_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Filtragem por itens ativos/inativos.";
                }, {
                    readonly indexName: "idx_inventory_items_updated_at";
                    readonly columns: readonly ["updated_at"];
                    readonly unique: false;
                    readonly reason: "Ordenação e filtros por última atualização.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["inventoryDecrementRule", "lowStockAlertRule"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/inventoryItem.defs.ts";
                readonly exportName: "inventoryItemTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default inventoryItemTableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/inventoryMovement.defs" {
    export const inventoryMovementTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "inventoryMovement";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 50;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "inventoryMovement";
                readonly tableName: "inventory_movements";
                readonly moduleId: "cafeFlow";
                readonly title: "Movimentos de Estoque";
                readonly purpose: "Registrar eventos de entrada e saída de estoque.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "InventoryMovement";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do movimento de estoque.";
                }, {
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência ao item de estoque movimentado.";
                }, {
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Pedido associado à baixa automática, quando aplicável.";
                }, {
                    readonly name: "movementType";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Tipo de movimento (entrada, saida, ajuste).";
                }, {
                    readonly name: "movementStatus";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly default: "registrado";
                    readonly description: "Status do movimento para controle de estorno e auditoria.";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Quantidade movimentada no estoque.";
                }, {
                    readonly name: "unitCost";
                    readonly type: "number";
                    readonly nullable: true;
                    readonly description: "Custo unitário no momento do movimento, quando aplicável.";
                }, {
                    readonly name: "reason";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Motivo do ajuste manual, quando aplicável.";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "inventoryItemId";
                    readonly targetEntity: "InventoryItem";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Movimento pertence a um item de estoque.";
                }, {
                    readonly fieldName: "orderId";
                    readonly targetEntity: "Order";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Baixa automática por pedido, quando aplicável.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_inventory_movements_inventory_item";
                    readonly columns: readonly ["inventoryItemId", "createdAt"];
                    readonly unique: false;
                    readonly reason: "Consulta por item e período em relatórios de estoque.";
                }, {
                    readonly indexName: "idx_inventory_movements_order";
                    readonly columns: readonly ["orderId"];
                    readonly unique: false;
                    readonly reason: "Rastreio de baixas por pedido.";
                }, {
                    readonly indexName: "idx_inventory_movements_type_status";
                    readonly columns: readonly ["movementType", "movementStatus"];
                    readonly unique: false;
                    readonly reason: "Filtros por tipo e status do movimento.";
                }, {
                    readonly indexName: "idx_inventory_movements_created_at";
                    readonly columns: readonly ["createdAt"];
                    readonly unique: false;
                    readonly reason: "Filtro temporal padrão.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                    readonly reason: "Campos necessários para filtros e auditoria estão normalizados.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly [];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["inventoryDecrementRule"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/inventoryMovement.defs.ts";
                readonly exportName: "inventoryMovementTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default inventoryMovementTableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/operationalMetrics.defs" {
    export const operationalMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "operationalMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 54;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "operationalMetrics";
                readonly tableName: "operational_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Tabela de métricas operacionais";
                readonly purpose: "Consolidar indicadores de eficiência operacional como tempo de preparo e cancelamentos.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "recorded_at";
                readonly columns: readonly [{
                    readonly name: "recorded_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp de registro da métrica.";
                }, {
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador do pedido.";
                }, {
                    readonly name: "menu_item_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador do item do cardápio.";
                }, {
                    readonly name: "inventory_item_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador do item de estoque.";
                }, {
                    readonly name: "stock_unit_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador da unidade de medida.";
                }, {
                    readonly name: "order_status_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador do status do pedido.";
                }, {
                    readonly name: "menu_category_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Identificador da categoria do cardápio.";
                }, {
                    readonly name: "table_seat_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador da mesa/comanda.";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador do turno diário.";
                }, {
                    readonly name: "cancellation_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de pedidos cancelados.";
                }, {
                    readonly name: "avg_preparation_time";
                    readonly type: "integer";
                    readonly nullable: true;
                    readonly description: "Tempo médio de preparo em segundos.";
                }, {
                    readonly name: "low_stock_item_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de itens com estoque baixo.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "orderId";
                    readonly column: "order_id";
                    readonly type: "string";
                    readonly description: "Identificador do pedido";
                }, {
                    readonly dimensionId: "menuItemId";
                    readonly column: "menu_item_id";
                    readonly type: "string";
                    readonly description: "Identificador do item do cardápio";
                }, {
                    readonly dimensionId: "inventoryItemId";
                    readonly column: "inventory_item_id";
                    readonly type: "string";
                    readonly description: "Identificador do item de estoque";
                }, {
                    readonly dimensionId: "stockUnitId";
                    readonly column: "stock_unit_id";
                    readonly type: "string";
                    readonly description: "Identificador da unidade de medida";
                }, {
                    readonly dimensionId: "orderStatusId";
                    readonly column: "order_status_id";
                    readonly type: "string";
                    readonly description: "Identificador do status do pedido";
                }, {
                    readonly dimensionId: "menuCategoryId";
                    readonly column: "menu_category_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship menuItemCategory (MenuItem -> MenuCategory)";
                }, {
                    readonly dimensionId: "tableSeatId";
                    readonly column: "table_seat_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship orderTableSeat (Order -> TableSeat)";
                }, {
                    readonly dimensionId: "dailyShiftId";
                    readonly column: "daily_shift_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship shiftOrders (Order -> DailyShift)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "cancellationCount";
                    readonly column: "cancellation_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de pedidos cancelados";
                }, {
                    readonly measureId: "avgPreparationTime";
                    readonly column: "avg_preparation_time";
                    readonly aggregation: "avg";
                    readonly unit: "seconds";
                    readonly description: "Tempo médio de preparo em segundos";
                }, {
                    readonly measureId: "lowStockItemCount";
                    readonly column: "low_stock_item_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade de itens com estoque baixo";
                }];
                readonly sourceWriteEvents: readonly ["order.created", "order.statusUpdated", "order.cancelled", "inventoryItem.updated"];
                readonly hypertable: {
                    readonly timeColumn: "recorded_at";
                    readonly chunkTimeInterval: "1 day";
                    readonly retentionPolicy: "90 days";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_operational_metrics_recorded_at";
                        readonly columns: readonly ["recorded_at"];
                        readonly purpose: "Consulta temporal principal por período.";
                    }, {
                        readonly indexName: "idx_operational_metrics_recorded_at_order";
                        readonly columns: readonly ["recorded_at", "order_id"];
                        readonly purpose: "Filtro por pedido e período.";
                    }, {
                        readonly indexName: "idx_operational_metrics_recorded_at_menu_item";
                        readonly columns: readonly ["recorded_at", "menu_item_id"];
                        readonly purpose: "Filtro por item do cardápio e período.";
                    }, {
                        readonly indexName: "idx_operational_metrics_recorded_at_inventory_item";
                        readonly columns: readonly ["recorded_at", "inventory_item_id"];
                        readonly purpose: "Filtro por item de estoque e período.";
                    }, {
                        readonly indexName: "idx_operational_metrics_recorded_at_shift";
                        readonly columns: readonly ["recorded_at", "daily_shift_id"];
                        readonly purpose: "Filtro por turno diário e período.";
                    }, {
                        readonly indexName: "idx_operational_metrics_recorded_at_status";
                        readonly columns: readonly ["recorded_at", "order_status_id"];
                        readonly purpose: "Filtro por status do pedido e período.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderStatusLifecycle", "lowStockAlertRule"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/operationalMetrics.defs.ts";
                readonly exportName: "operationalMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default operationalMetricsTableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 46;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "order";
                readonly tableName: "orders";
                readonly moduleId: "cafeFlow";
                readonly title: "Pedidos";
                readonly purpose: "Persistir pedidos do POS e seu ciclo de status.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "Order";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do pedido.";
                }, {
                    readonly name: "origin_type";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Origem do pedido (mesa ou takeout).";
                }, {
                    readonly name: "table_seat_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Referência opcional à mesa/comanda associada ao pedido.";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Turno diário ao qual o pedido pertence.";
                }, {
                    readonly name: "order_status_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Status padronizado atual do pedido.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do pedido.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do pedido.";
                }];
                readonly primaryKey: readonly ["order_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "table_seat_id";
                    readonly targetEntity: "TableSeat";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Vincular pedido à mesa/comanda quando aplicável.";
                }, {
                    readonly fieldName: "daily_shift_id";
                    readonly targetEntity: "DailyShift";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Filtrar pedidos por turno diário e métricas operacionais.";
                }, {
                    readonly fieldName: "order_status_id";
                    readonly targetEntity: "OrderStatus";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Status padronizado do pedido definido em MDM.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_orders_daily_shift_id_created_at";
                    readonly columns: readonly ["daily_shift_id", "created_at"];
                    readonly reason: "Consultas por turno e período no dashboard e fluxo de pedido.";
                }, {
                    readonly indexName: "idx_orders_order_status_id";
                    readonly columns: readonly ["order_status_id"];
                    readonly reason: "Filtrar por status no painel da cozinha e fluxo de preparo.";
                }, {
                    readonly indexName: "idx_orders_table_seat_id";
                    readonly columns: readonly ["table_seat_id"];
                    readonly reason: "Recuperar pedidos ativos por mesa/comanda.";
                }, {
                    readonly indexName: "idx_orders_origin_type_created_at";
                    readonly columns: readonly ["origin_type", "created_at"];
                    readonly reason: "Filtrar pedidos por origem em consultas rápidas do POS.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["dailySalesMetricsTable", "topSellingItemsMetricsTable"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderStatusLifecycle"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/order.defs.ts";
                readonly exportName: "orderTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default orderTableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/orderItem.defs" {
    export const orderItemTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "orderItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 47;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "orderItem";
                readonly tableName: "order_items";
                readonly moduleId: "cafeFlow";
                readonly title: "Itens do Pedido";
                readonly purpose: "Registrar itens de cada pedido para preparo e baixa de estoque.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "OrderItem";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "orderItemId";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do item do pedido.";
                }, {
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência ao pedido ao qual este item pertence.";
                }, {
                    readonly name: "menuItemId";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência ao item do cardápio associado.";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Quantidade solicitada do item do cardápio.";
                }, {
                    readonly name: "itemStatus";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly default: "ativo";
                    readonly description: "Status operacional do item do pedido para preparo e cancelamento.";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do item do pedido.";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do item do pedido.";
                }];
                readonly primaryKey: readonly ["orderItemId"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "orderId";
                    readonly targetEntity: "Order";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Itens pertencem a um pedido e precisam de consulta por pedido.";
                }, {
                    readonly fieldName: "menuItemId";
                    readonly targetEntity: "MenuItem";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Vincula o item vendido ao item do cardápio.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_order_items_order_id";
                    readonly columns: readonly ["orderId"];
                    readonly unique: false;
                    readonly reason: "Leituras rápidas por pedido no fluxo de pedido e cozinha.";
                }, {
                    readonly indexName: "idx_order_items_menu_item_id";
                    readonly columns: readonly ["menuItemId"];
                    readonly unique: false;
                    readonly reason: "Consulta por item do cardápio para baixa de estoque e análises.";
                }, {
                    readonly indexName: "idx_order_items_order_status";
                    readonly columns: readonly ["orderId", "itemStatus"];
                    readonly unique: false;
                    readonly reason: "Filtrar itens por status no painel da cozinha.";
                }, {
                    readonly indexName: "idx_order_items_created_at";
                    readonly columns: readonly ["createdAt"];
                    readonly unique: false;
                    readonly reason: "Filtros por período em relatórios operacionais.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["inventoryDecrementRule"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/orderItem.defs.ts";
                readonly exportName: "orderItemTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default orderItemTableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/promotionSuggestion.defs" {
    export const promotionSuggestionTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "promotionSuggestion";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 46;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "promotionSuggestion";
                readonly tableName: "promotion_suggestions";
                readonly moduleId: "cafeFlow";
                readonly title: "Sugestões de Promoção";
                readonly purpose: "Guardar sugestões geradas por IA para o gerente.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "PromotionSuggestion";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "promotion_suggestion_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da sugestão de promoção.";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Título curto da sugestão de promoção.";
                }, {
                    readonly name: "suggestion_text";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Descrição detalhada da promoção sugerida.";
                }, {
                    readonly name: "period_start";
                    readonly type: "date";
                    readonly nullable: false;
                    readonly description: "Data inicial do período analisado para a sugestão.";
                }, {
                    readonly name: "period_end";
                    readonly type: "date";
                    readonly nullable: false;
                    readonly description: "Data final do período analisado para a sugestão.";
                }, {
                    readonly name: "rationale";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Justificativa com base nas métricas agregadas.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly default: "ativa";
                    readonly description: "Status atual da sugestão (ativa, arquivada).";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["promotion_suggestion_id"];
                readonly foreignRefs: readonly [];
                readonly indexes: readonly [{
                    readonly indexName: "idx_promotion_suggestions_period";
                    readonly columns: readonly ["period_start", "period_end"];
                    readonly unique: false;
                    readonly reason: "Filtro por período analisado nas leituras do dashboard e IA.";
                }, {
                    readonly indexName: "idx_promotion_suggestions_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Listagem rápida por status.";
                }, {
                    readonly indexName: "idx_promotion_suggestions_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly unique: false;
                    readonly reason: "Ordenação e filtragem por data de criação.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "PromotionSuggestionDetails";
                    readonly reason: "Armazenar métricas agregadas e dados auxiliares da IA sem impacto em filtros principais.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["PromotionSuggestion"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["aiSummarySourceRule"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/promotionSuggestion.defs.ts";
                readonly exportName: "promotionSuggestionTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default promotionSuggestionTableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/salesSummary.defs" {
    export const salesSummaryTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "salesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 47;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "salesSummary";
                readonly tableName: "sales_summaries";
                readonly moduleId: "cafeFlow";
                readonly title: "Resumos de Vendas";
                readonly purpose: "Persistir resumos gerados por IA para consulta do gerente.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "SalesSummary";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "sales_summary_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do resumo de vendas.";
                }, {
                    readonly name: "summary_date";
                    readonly type: "date";
                    readonly nullable: false;
                    readonly description: "Data do resumo de vendas.";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Referência opcional ao turno do dia relacionado ao resumo.";
                }, {
                    readonly name: "total_sales";
                    readonly type: "money";
                    readonly nullable: false;
                    readonly description: "Total de vendas do dia.";
                }, {
                    readonly name: "total_orders";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Quantidade total de pedidos do dia.";
                }, {
                    readonly name: "average_ticket";
                    readonly type: "money";
                    readonly nullable: true;
                    readonly description: "Ticket médio do dia.";
                }, {
                    readonly name: "highlights";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Destaques e observações geradas pela IA.";
                }, {
                    readonly name: "summary_status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly default: "gerado";
                    readonly description: "Estado atual do resumo de vendas.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["sales_summary_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "daily_shift_id";
                    readonly targetEntity: "DailyShift";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Vincular o resumo ao turno diário consolidado.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_sales_summaries_summary_date";
                    readonly columns: readonly ["summary_date"];
                    readonly reason: "Filtrar e listar resumos por data.";
                }, {
                    readonly indexName: "idx_sales_summaries_daily_shift";
                    readonly columns: readonly ["daily_shift_id"];
                    readonly reason: "Buscar resumos associados a um turno.";
                }, {
                    readonly indexName: "ux_sales_summaries_date_shift";
                    readonly columns: readonly ["summary_date", "daily_shift_id"];
                    readonly unique: true;
                    readonly reason: "Evitar duplicidade de resumo por data e turno.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly reason: "Armazenar dados adicionais do resumo gerado pela IA sem impacto em filtros principais.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["aiSummarySourceRule"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/salesSummary.defs.ts";
                readonly exportName: "salesSummaryTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default salesSummaryTableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/shiftClosureReport.defs" {
    export const shiftClosureReportTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "shiftClosureReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 49;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "shiftClosureReport";
                readonly tableName: "shift_closure_reports";
                readonly moduleId: "cafeFlow";
                readonly title: "Relatórios de Fechamento";
                readonly purpose: "Armazenar detalhes consolidados do fechamento de turno.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "ShiftClosureReport";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "shift_closure_report_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do relatório de fechamento.";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência ao turno diário consolidado pelo relatório.";
                }, {
                    readonly name: "business_date";
                    readonly type: "date";
                    readonly nullable: false;
                    readonly description: "Data de referência do turno consolidado.";
                }, {
                    readonly name: "shift_status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Estado do turno diário no momento do fechamento.";
                }, {
                    readonly name: "total_sales";
                    readonly type: "money";
                    readonly nullable: false;
                    readonly description: "Valor total de vendas consolidadas no turno.";
                }, {
                    readonly name: "total_orders";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly description: "Quantidade total de pedidos consolidados no turno.";
                }, {
                    readonly name: "cash_total";
                    readonly type: "money";
                    readonly nullable: true;
                    readonly description: "Total recebido em dinheiro no turno.";
                }, {
                    readonly name: "card_total";
                    readonly type: "money";
                    readonly nullable: true;
                    readonly description: "Total recebido em cartão no turno.";
                }, {
                    readonly name: "summary_notes";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Observações e resumo textual do fechamento.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do relatório.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do relatório.";
                }];
                readonly primaryKey: readonly ["shift_closure_report_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "daily_shift_id";
                    readonly targetEntity: "DailyShift";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Relatório consolida um turno diário específico.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "ix_shift_closure_reports_daily_shift_id";
                    readonly columns: readonly ["daily_shift_id"];
                    readonly unique: true;
                    readonly reason: "Garantir um relatório por turno e facilitar consulta por turno.";
                }, {
                    readonly indexName: "ix_shift_closure_reports_business_date";
                    readonly columns: readonly ["business_date"];
                    readonly unique: false;
                    readonly reason: "Filtrar relatórios por data do turno.";
                }, {
                    readonly indexName: "ix_shift_closure_reports_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly unique: false;
                    readonly reason: "Ordenação e auditoria por data de criação.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details_json";
                    readonly jsonSchemaRef: "ShiftClosureReportDetails";
                    readonly reason: "Armazenar detalhes consolidados de pedidos e movimentos de estoque por turno.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly [];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["shiftClosureRule"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/shiftClosureReport.defs.ts";
                readonly exportName: "shiftClosureReportTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default shiftClosureReportTableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/tableSeat.defs" {
    export const tableSeatTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "tableSeat";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 48;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "tableSeat";
                readonly tableName: "table_seats";
                readonly moduleId: "cafeFlow";
                readonly title: "Mesas/Comandas";
                readonly purpose: "Controlar identificação de mesas/comandas ativas.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "TableSeat";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "table_seat_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da mesa/comanda.";
                }, {
                    readonly name: "label";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Nome curto ou código exibido da mesa/comanda.";
                }, {
                    readonly name: "seat_type";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Tipo de referência usada no salão.";
                }, {
                    readonly name: "capacity";
                    readonly type: "number";
                    readonly nullable: true;
                    readonly description: "Quantidade máxima de pessoas associadas à mesa.";
                }, {
                    readonly name: "is_active";
                    readonly type: "boolean";
                    readonly nullable: false;
                    readonly default: true;
                    readonly description: "Indica se a mesa/comanda está ativa para uso.";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["table_seat_id"];
                readonly indexes: readonly [{
                    readonly indexName: "idx_table_seats_label";
                    readonly columns: readonly ["label"];
                    readonly unique: false;
                    readonly reason: "Busca rápida por código exibido no POS.";
                }, {
                    readonly indexName: "idx_table_seats_seat_type";
                    readonly columns: readonly ["seat_type"];
                    readonly unique: false;
                    readonly reason: "Filtrar mesas vs. comandas.";
                }, {
                    readonly indexName: "idx_table_seats_is_active";
                    readonly columns: readonly ["is_active"];
                    readonly unique: false;
                    readonly reason: "Listar apenas mesas/comandas ativas.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly [];
            };
            readonly defsPlan: {
                readonly fileName: "tables/tableSeat.defs.ts";
                readonly exportName: "tableSeatTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default tableSeatTableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs" {
    export const topSellingItemsMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "topSellingItemsMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 51;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "topSellingItemsMetrics";
                readonly tableName: "top_selling_items_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Itens mais vendidos";
                readonly purpose: "Identificar quais produtos do cardápio têm maior saída por período.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "recorded_at";
                readonly columns: readonly [{
                    readonly name: "recorded_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly description: "Momento de registro da métrica.";
                }, {
                    readonly name: "menu_item_id";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Identificador do item do cardápio";
                }, {
                    readonly name: "menu_category_id";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Identificador da categoria";
                }, {
                    readonly name: "order_id";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Identificador do pedido";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Identificador do turno diário";
                }, {
                    readonly name: "table_seat_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderTableSeat (Order -> TableSeat)";
                }, {
                    readonly name: "inventory_item_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship menuItemInventory (MenuItem -> InventoryItem)";
                }, {
                    readonly name: "order_status_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderStatusRef (Order -> OrderStatus)";
                }, {
                    readonly name: "quantity_sold";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly description: "Quantidade vendida do item";
                }, {
                    readonly name: "revenue";
                    readonly type: "decimal";
                    readonly nullable: false;
                    readonly description: "Receita gerada pelo item";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "menuItemId";
                    readonly column: "menu_item_id";
                    readonly type: "string";
                    readonly description: "Identificador do item do cardápio";
                }, {
                    readonly dimensionId: "menuCategoryId";
                    readonly column: "menu_category_id";
                    readonly type: "string";
                    readonly description: "Identificador da categoria";
                }, {
                    readonly dimensionId: "orderId";
                    readonly column: "order_id";
                    readonly type: "string";
                    readonly description: "Identificador do pedido";
                }, {
                    readonly dimensionId: "dailyShiftId";
                    readonly column: "daily_shift_id";
                    readonly type: "string";
                    readonly description: "Identificador do turno diário";
                }, {
                    readonly dimensionId: "tableSeatId";
                    readonly column: "table_seat_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship orderTableSeat (Order -> TableSeat)";
                }, {
                    readonly dimensionId: "inventoryItemId";
                    readonly column: "inventory_item_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship menuItemInventory (MenuItem -> InventoryItem)";
                }, {
                    readonly dimensionId: "orderStatusId";
                    readonly column: "order_status_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship orderStatusRef (Order -> OrderStatus)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "quantitySold";
                    readonly column: "quantity_sold";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Quantidade vendida do item";
                }, {
                    readonly measureId: "revenue";
                    readonly column: "revenue";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Receita gerada pelo item";
                }];
                readonly sourceWriteEvents: readonly ["orderItem.created", "order.statusUpdated"];
                readonly hypertable: {
                    readonly timeColumn: "recorded_at";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_top_selling_items_metrics_recorded_at";
                        readonly columns: readonly ["recorded_at"];
                        readonly purpose: "Ordenação e filtros temporais.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_menu_item_time";
                        readonly columns: readonly ["menu_item_id", "recorded_at"];
                        readonly purpose: "Consulta por item do cardápio por período.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_menu_category_time";
                        readonly columns: readonly ["menu_category_id", "recorded_at"];
                        readonly purpose: "Consulta por categoria por período.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_order_time";
                        readonly columns: readonly ["order_id", "recorded_at"];
                        readonly purpose: "Consulta por pedido e período.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_daily_shift_time";
                        readonly columns: readonly ["daily_shift_id", "recorded_at"];
                        readonly purpose: "Consulta por turno diário e período.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_table_seat_time";
                        readonly columns: readonly ["table_seat_id", "recorded_at"];
                        readonly purpose: "Consulta por mesa/comanda e período.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_inventory_item_time";
                        readonly columns: readonly ["inventory_item_id", "recorded_at"];
                        readonly purpose: "Consulta por item de estoque associado ao item vendido.";
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_order_status_time";
                        readonly columns: readonly ["order_status_id", "recorded_at"];
                        readonly purpose: "Consulta por status do pedido no período.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["manageOrders", "updateOrderStatus", "cancelOrder"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderStatusLifecycle"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/topSellingItemsMetrics.defs.ts";
                readonly exportName: "topSellingItemsMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default topSellingItemsMetricsTableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_1_external/weeklySalesMetrics.defs" {
    export const weeklySalesMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "weeklySalesMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 53;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "weeklySalesMetrics";
                readonly tableName: "weekly_sales_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Vendas dos últimos 7 dias";
                readonly purpose: "Analisar tendência de vendas e comparar desempenho semanal.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "recorded_at";
                readonly columns: readonly [{
                    readonly name: "recorded_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora do registro da métrica.";
                }, {
                    readonly name: "order_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Identificador do pedido.";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Identificador do turno diário.";
                }, {
                    readonly name: "menu_item_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Identificador do item do cardápio.";
                }, {
                    readonly name: "menu_category_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Identificador da categoria do cardápio.";
                }, {
                    readonly name: "order_status_id";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Identificador do status do pedido.";
                }, {
                    readonly name: "table_seat_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Identificador da mesa/comanda.";
                }, {
                    readonly name: "inventory_item_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Identificador do item de estoque vinculado ao item do cardápio.";
                }, {
                    readonly name: "revenue";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Receita total no intervalo.";
                }, {
                    readonly name: "order_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Total de pedidos no intervalo.";
                }, {
                    readonly name: "items_sold";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Total de itens vendidos no intervalo.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "orderId";
                    readonly column: "order_id";
                    readonly type: "string";
                    readonly description: "Identificador do pedido";
                }, {
                    readonly dimensionId: "dailyShiftId";
                    readonly column: "daily_shift_id";
                    readonly type: "string";
                    readonly description: "Identificador do turno diário";
                }, {
                    readonly dimensionId: "menuItemId";
                    readonly column: "menu_item_id";
                    readonly type: "string";
                    readonly description: "Identificador do item do cardápio";
                }, {
                    readonly dimensionId: "menuCategoryId";
                    readonly column: "menu_category_id";
                    readonly type: "string";
                    readonly description: "Identificador da categoria";
                }, {
                    readonly dimensionId: "orderStatusId";
                    readonly column: "order_status_id";
                    readonly type: "string";
                    readonly description: "Identificador do status do pedido";
                }, {
                    readonly dimensionId: "tableSeatId";
                    readonly column: "table_seat_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship orderTableSeat (Order -> TableSeat)";
                }, {
                    readonly dimensionId: "inventoryItemId";
                    readonly column: "inventory_item_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship menuItemInventory (MenuItem -> InventoryItem)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "revenue";
                    readonly column: "revenue";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Receita total";
                }, {
                    readonly measureId: "orderCount";
                    readonly column: "order_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Total de pedidos";
                }, {
                    readonly measureId: "itemsSold";
                    readonly column: "items_sold";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Total de itens vendidos";
                }];
                readonly sourceWriteEvents: readonly ["order.created", "orderItem.created", "order.statusUpdated"];
                readonly hypertable: {
                    readonly timeColumn: "recorded_at";
                    readonly chunkTimeInterval: "1 day";
                    readonly retentionPolicy: "1 year";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_weekly_sales_metrics_recorded_at";
                        readonly columns: readonly ["recorded_at"];
                        readonly purpose: "Leitura temporal padrão das métricas.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_weekly_sales_metrics_daily_shift_time";
                        readonly columns: readonly ["daily_shift_id", "recorded_at"];
                        readonly purpose: "Filtrar por turno e período.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_weekly_sales_metrics_menu_item_time";
                        readonly columns: readonly ["menu_item_id", "recorded_at"];
                        readonly purpose: "Consultas por item do cardápio no período.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_weekly_sales_metrics_menu_category_time";
                        readonly columns: readonly ["menu_category_id", "recorded_at"];
                        readonly purpose: "Consultas por categoria no período.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_weekly_sales_metrics_order_status_time";
                        readonly columns: readonly ["order_status_id", "recorded_at"];
                        readonly purpose: "Análise por status do pedido no período.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_weekly_sales_metrics_table_seat_time";
                        readonly columns: readonly ["table_seat_id", "recorded_at"];
                        readonly purpose: "Consultas por mesa/comanda no período.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_weekly_sales_metrics_inventory_item_time";
                        readonly columns: readonly ["inventory_item_id", "recorded_at"];
                        readonly purpose: "Consultas por item de estoque no período.";
                        readonly unique: false;
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderStatusLifecycle"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/weeklySalesMetrics.defs.ts";
                readonly exportName: "weeklySalesMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default weeklySalesMetricsTableDefinition;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/abrirTurno.defs" {
    export const useCase: {
        readonly usecaseId: "abrirTurno";
        readonly title: "Abrir turno diário";
        readonly purpose: "Inicia um novo turno de operações";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["dailyShiftEntity"];
        readonly outputEntities: readonly ["dailyShiftEntity"];
        readonly readsTables: readonly [];
        readonly writesTables: readonly [{
            readonly tableName: "daily_shifts";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["shiftClosureRule"];
        readonly entityRefs: readonly ["dailyShift"];
        readonly commands: readonly [{
            readonly commandId: "abrirTurno";
            readonly input: readonly [{
                readonly name: "dailyShift";
                readonly type: "dailyShiftEntity";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "dailyShift";
                readonly type: "dailyShiftEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/atualizarItemCardapio.defs" {
    export const useCase: {
        readonly usecaseId: "atualizarItemCardapio";
        readonly title: "Atualizar item do cardápio";
        readonly purpose: "Edita um item existente no cardápio";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["menuEntity"];
        readonly outputEntities: readonly ["menuEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "MenuItem";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "MenuCategory";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "MenuItem";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["menuItem"];
        readonly commands: readonly [{
            readonly commandId: "atualizarItemCardapio";
            readonly input: readonly [{
                readonly name: "menuItemId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "name";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "description";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "price";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "categoryId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "isAvailable";
                readonly type: "boolean";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "menuItemId";
                readonly type: "string";
            }, {
                readonly name: "name";
                readonly type: "string";
            }, {
                readonly name: "description";
                readonly type: "string";
            }, {
                readonly name: "price";
                readonly type: "number";
            }, {
                readonly name: "categoryId";
                readonly type: "string";
            }, {
                readonly name: "isAvailable";
                readonly type: "boolean";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/atualizarItemEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "atualizarItemEstoque";
        readonly title: "Atualizar item de estoque";
        readonly purpose: "Edita quantidade, alertas ou unidade de um item de estoque";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["inventoryEntity"];
        readonly outputEntities: readonly ["inventoryEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_items";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "StockUnit";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "inventory_items";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["lowStockAlertRule"];
        readonly entityRefs: readonly ["inventoryItem"];
        readonly commands: readonly [{
            readonly commandId: "atualizarItemEstoque";
            readonly input: readonly [{
                readonly name: "inventoryItemId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "quantity";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "lowStockAlert";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "unitId";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "inventoryItem";
                readonly type: "inventoryEntity";
            }];
        }];
        readonly pendingQuestions: readonly ["Quais são os campos exatos de inventoryEntity que podem ser atualizados (nomes e tipos)?", "O alerta de estoque baixo é numérico ou booleano? Qual o nome correto do campo?", "A unidade deve ser referenciada por unitId (StockUnit) ou outro identificador?"];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/atualizarMesa.defs" {
    export const useCase: {
        readonly usecaseId: "atualizarMesa";
        readonly title: "Atualizar mesa/comanda";
        readonly purpose: "Atualiza dados de uma mesa ou comanda";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["orderEntity"];
        readonly outputEntities: readonly ["orderEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "table_seats";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "table_seats";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["order"];
        readonly commands: readonly [{
            readonly commandId: "atualizarMesa";
            readonly input: readonly [{
                readonly name: "order";
                readonly type: "orderEntity";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "order";
                readonly type: "orderEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/atualizarStatusPedido.defs" {
    export const useCase: {
        readonly usecaseId: "atualizarStatusPedido";
        readonly title: "Atualizar status do pedido";
        readonly purpose: "Avança o status do pedido no fluxo de preparo";
        readonly actor: "kitchen";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["orderEntity"];
        readonly outputEntities: readonly ["orderEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_items";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "OrderStatus";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderStatusLifecycle"];
        readonly entityRefs: readonly ["order"];
        readonly commands: readonly [{
            readonly commandId: "atualizarStatusPedido";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "order";
                readonly type: "orderEntity";
            }];
        }];
        readonly pendingQuestions: readonly ["Qual é o identificador usado para localizar o pedido (ex.: orderId, código do pedido)?", "Há necessidade de informar o status desejado ou o avanço é sempre para o próximo status do ciclo?", "Quais campos do orderEntity devem ser retornados obrigatoriamente na saída?"];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/buscarPedidoPorId.defs" {
    export const useCase: {
        readonly usecaseId: "buscarPedidoPorId";
        readonly title: "Buscar pedido por ID";
        readonly purpose: "Retorna detalhes completos de um pedido";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["orderEntity"];
        readonly outputEntities: readonly ["orderEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_items";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "table_seats";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "MenuItem";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "buscarPedidoPorId";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "order";
                readonly type: "orderEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/buscarRelatorioFechamento.defs" {
    export const useCase: {
        readonly usecaseId: "buscarRelatorioFechamento";
        readonly title: "Buscar relatório de fechamento";
        readonly purpose: "Retorna o relatório de fechamento de um turno";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["dailyShiftEntity"];
        readonly outputEntities: readonly ["dailyShiftEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "shift_closure_reports";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_shifts";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["dailyShift"];
        readonly commands: readonly [{
            readonly commandId: "buscarRelatorioFechamento";
            readonly input: readonly [{
                readonly name: "dailyShiftId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "dailyShift";
                readonly type: "dailyShiftEntity";
            }];
        }];
        readonly pendingQuestions: readonly ["Qual é o identificador de entrada esperado para localizar o relatório de fechamento? (ex.: dailyShiftId, shiftId ou outro)"];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/cancelarPedido.defs" {
    export const useCase: {
        readonly usecaseId: "cancelarPedido";
        readonly title: "Cancelar pedido";
        readonly purpose: "Cancela um pedido e reverte métricas de vendas";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["orderEntity"];
        readonly outputEntities: readonly ["orderEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_items";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_items";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_movements";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "weekly_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "operational_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderStatusLifecycle", "inventoryDecrementRule"];
        readonly entityRefs: readonly ["inventoryItem", "order", "salesSummary"];
        readonly commands: readonly [{
            readonly commandId: "cancelOrder";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "order";
                readonly type: "orderEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/criarItemCardapio.defs" {
    export const useCase: {
        readonly usecaseId: "criarItemCardapio";
        readonly title: "Criar item do cardápio";
        readonly purpose: "Cadastra um novo item no cardápio via MDM";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["menuEntity"];
        readonly outputEntities: readonly ["menuEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "MenuCategory";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "MenuItem";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["menuItem"];
        readonly commands: readonly [{
            readonly commandId: "createMenuItem";
            readonly input: readonly [{
                readonly name: "menuEntity";
                readonly type: "menuEntity";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "menuEntity";
                readonly type: "menuEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/criarItemEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "criarItemEstoque";
        readonly title: "Criar item de estoque";
        readonly purpose: "Cadastra um novo insumo ou produto no estoque";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["inventoryEntity"];
        readonly outputEntities: readonly ["inventoryEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "StockUnit";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "inventory_items";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["lowStockAlertRule"];
        readonly entityRefs: readonly ["inventoryItem"];
        readonly commands: readonly [{
            readonly commandId: "criarItemEstoque";
            readonly input: readonly [{
                readonly name: "nomeItem";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "tipoItem";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "stockUnitId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "quantidadeInicial";
                readonly type: "number";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "inventoryItemId";
                readonly type: "string";
            }, {
                readonly name: "nomeItem";
                readonly type: "string";
            }, {
                readonly name: "tipoItem";
                readonly type: "string";
            }, {
                readonly name: "stockUnitId";
                readonly type: "string";
            }, {
                readonly name: "quantidade";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/criarMesa.defs" {
    export const useCase: {
        readonly usecaseId: "criarMesa";
        readonly title: "Criar mesa/comanda";
        readonly purpose: "Cadastra uma nova mesa ou comanda";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["orderEntity"];
        readonly outputEntities: readonly ["orderEntity"];
        readonly readsTables: readonly [];
        readonly writesTables: readonly [{
            readonly tableName: "table_seats";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["order"];
        readonly commands: readonly [{
            readonly commandId: "criarMesa";
            readonly input: readonly [{
                readonly name: "orderEntity";
                readonly type: "orderEntity";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "orderEntity";
                readonly type: "orderEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/criarPedido.defs" {
    export const useCase: {
        readonly usecaseId: "criarPedido";
        readonly title: "Criar pedido";
        readonly purpose: "Registra um novo pedido com seus itens e atualiza métricas de vendas";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["orderEntity"];
        readonly outputEntities: readonly ["orderEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "table_seats";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "MenuItem";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "OrderStatus";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_items";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "weekly_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "operational_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderStatusLifecycle", "inventoryDecrementRule"];
        readonly entityRefs: readonly ["menuItem", "order", "salesSummary"];
        readonly commands: readonly [{
            readonly commandId: "criarPedido";
            readonly input: readonly [{
                readonly name: "order";
                readonly type: "orderEntity";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "order";
                readonly type: "orderEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/fecharTurno.defs" {
    export const useCase: {
        readonly usecaseId: "fecharTurno";
        readonly title: "Fechar turno diário";
        readonly purpose: "Finaliza o turno, gera relatório e consolida métricas";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["dailyShiftEntity"];
        readonly outputEntities: readonly ["dailyShiftEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_shifts";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_items";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_movements";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "daily_shifts";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "shift_closure_reports";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "operational_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["shiftClosureRule"];
        readonly entityRefs: readonly ["dailyShift", "inventoryItem", "order", "salesSummary"];
        readonly commands: readonly [{
            readonly commandId: "fecharTurno";
            readonly input: readonly [{
                readonly name: "dailyShiftId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "dailyShiftId";
                readonly type: "string";
            }, {
                readonly name: "shiftClosureReportId";
                readonly type: "string";
            }, {
                readonly name: "dailySalesMetricsId";
                readonly type: "string";
            }, {
                readonly name: "operationalMetricsId";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/gerarResumoVendas.defs" {
    export const useCase: {
        readonly usecaseId: "gerarResumoVendas";
        readonly title: "Gerar resumo de vendas (IA)";
        readonly purpose: "Gera resumo analítico de vendas via assistente IA";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["salesAIEntity"];
        readonly outputEntities: readonly ["salesAIEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_items";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_shifts";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_items";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "MenuItem";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "sales_summaries";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["aiSummarySourceRule"];
        readonly entityRefs: readonly ["dailyShift", "inventoryItem", "menuItem", "order", "salesSummary"];
        readonly commands: readonly [{
            readonly commandId: "gerarResumoVendas";
            readonly input: readonly [{
                readonly name: "salesAIEntityId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "salesAIEntityId";
                readonly type: "string";
            }, {
                readonly name: "summaryText";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/listarItensCardapio.defs" {
    export const useCase: {
        readonly usecaseId: "listarItensCardapio";
        readonly title: "Listar itens do cardápio";
        readonly purpose: "Lista itens do cardápio com categorias";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["menuEntity"];
        readonly outputEntities: readonly ["menuEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "MenuItem";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "MenuCategory";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["menuItem"];
        readonly commands: readonly [{
            readonly commandId: "listarItensCardapio";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "itensCardapio";
                readonly type: "menuEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/listarItensEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "listarItensEstoque";
        readonly title: "Listar itens de estoque";
        readonly purpose: "Lista itens de estoque com saldo e unidades";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["inventoryEntity"];
        readonly outputEntities: readonly ["inventoryEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_items";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "StockUnit";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["inventoryItem"];
        readonly commands: readonly [{
            readonly commandId: "listarItensEstoque";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "itens";
                readonly type: "inventoryEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/listarMesas.defs" {
    export const useCase: {
        readonly usecaseId: "listarMesas";
        readonly title: "Listar mesas/comandas";
        readonly purpose: "Lista mesas e comandas disponíveis";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["orderEntity"];
        readonly outputEntities: readonly ["orderEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "table_seats";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["order"];
        readonly commands: readonly [{
            readonly commandId: "listarMesas";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "mesas";
                readonly type: "orderEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/listarMovimentosEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "listarMovimentosEstoque";
        readonly title: "Listar movimentos de estoque";
        readonly purpose: "Lista histórico de movimentações de estoque";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["inventoryEntity"];
        readonly outputEntities: readonly ["inventoryEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_movements";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_items";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "StockUnit";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["inventoryItem"];
        readonly commands: readonly [{
            readonly commandId: "listInventoryMovements";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "movements";
                readonly type: "inventoryEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/listarPedidos.defs" {
    export const useCase: {
        readonly usecaseId: "listarPedidos";
        readonly title: "Listar pedidos";
        readonly purpose: "Lista pedidos com filtros e paginação";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["orderEntity"];
        readonly outputEntities: readonly ["orderEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_items";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "table_seats";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "MenuItem";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "listarPedidos";
            readonly input: readonly [{
                readonly name: "page";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "pageSize";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "fromDate";
                readonly type: "date";
                readonly required: false;
            }, {
                readonly name: "toDate";
                readonly type: "date";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "orders";
                readonly type: "orderEntity[]";
            }, {
                readonly name: "totalCount";
                readonly type: "number";
            }];
        }];
        readonly pendingQuestions: readonly ["Quais filtros são suportados para listar pedidos (ex.: status, intervalo de datas, mesa, atendente, itens)?"];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/listarResumosVendas.defs" {
    export const useCase: {
        readonly usecaseId: "listarResumosVendas";
        readonly title: "Listar resumos de vendas";
        readonly purpose: "Lista resumos de vendas gerados";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["salesAIEntity"];
        readonly outputEntities: readonly ["salesAIEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "sales_summaries";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["salesSummary"];
        readonly commands: readonly [{
            readonly commandId: "listarResumosVendas";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "resumosVendas";
                readonly type: "salesAIEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/listarSugestoesPromocoes.defs" {
    export const useCase: {
        readonly usecaseId: "listarSugestoesPromocoes";
        readonly title: "Listar sugestões de promoção";
        readonly purpose: "Lista sugestões de promoção geradas";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["salesAIEntity"];
        readonly outputEntities: readonly ["salesAIEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "promotion_suggestions";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["salesSummary"];
        readonly commands: readonly [{
            readonly commandId: "listarSugestoesPromocoes";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "sugestoesPromocoes";
                readonly type: "salesAIEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/listarTurnos.defs" {
    export const useCase: {
        readonly usecaseId: "listarTurnos";
        readonly title: "Listar turnos diários";
        readonly purpose: "Lista turnos com status e datas";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["dailyShiftEntity"];
        readonly outputEntities: readonly ["dailyShiftEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_shifts";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["dailyShift"];
        readonly commands: readonly [{
            readonly commandId: "listarTurnos";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "turnos";
                readonly type: "dailyShiftEntity[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/registrarMovimentoEstoque.defs" {
    export const useCase: {
        readonly usecaseId: "registrarMovimentoEstoque";
        readonly title: "Registrar movimento de estoque";
        readonly purpose: "Registra entrada, saída ou ajuste de estoque";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["inventoryEntity"];
        readonly outputEntities: readonly ["inventoryEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_items";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_items";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "StockUnit";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "inventory_movements";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_items";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_alert_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "operational_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["inventoryDecrementRule", "lowStockAlertRule"];
        readonly entityRefs: readonly ["inventoryItem", "order", "salesSummary"];
        readonly commands: readonly [{
            readonly commandId: "registrarMovimentoEstoque";
            readonly input: readonly [{
                readonly name: "inventoryItemId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "movementType";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "quantity";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "orderId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "reason";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "movementId";
                readonly type: "string";
            }, {
                readonly name: "inventoryItemId";
                readonly type: "string";
            }, {
                readonly name: "newQuantity";
                readonly type: "number";
            }, {
                readonly name: "lowStockAlert";
                readonly type: "boolean";
            }];
        }];
        readonly pendingQuestions: readonly ["Quais são os campos obrigatórios do inventoryEntity para registrar o movimento (por exemplo: stockUnitId, warehouseId)?", "movementType é um enum específico (entrada/saida/ajuste) ou livre?", "Precisamos retornar mais dados do inventoryEntity atualizado além de newQuantity?", "orderId é obrigatório quando o movimento é saída vinculada a pedido?", "Há necessidade de informar lote/validadade ou localização?"];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/sugerirPromocoes.defs" {
    export const useCase: {
        readonly usecaseId: "sugerirPromocoes";
        readonly title: "Sugerir itens para promoção (IA)";
        readonly purpose: "Sugere promoções baseadas em vendas e estoque";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["salesAIEntity"];
        readonly outputEntities: readonly ["salesAIEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_items";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_items";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "MenuItem";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "promotion_suggestions";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["aiSummarySourceRule"];
        readonly entityRefs: readonly ["inventoryItem", "menuItem", "order", "salesSummary"];
        readonly commands: readonly [{
            readonly commandId: "sugerirPromocoes";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "salesAIEntityId";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_3_usecases/visualizarDashboard.defs" {
    export const useCase: {
        readonly usecaseId: "visualizarDashboard";
        readonly title: "Visualizar dashboard";
        readonly purpose: "Apresenta métricas operacionais e de vendas";
        readonly actor: "manager";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["salesAIEntity", "orderEntity", "inventoryEntity"];
        readonly outputEntities: readonly ["salesAIEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_alert_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "weekly_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "operational_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_shifts";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["dailyShift", "order", "salesSummary"];
        readonly commands: readonly [{
            readonly commandId: "getDashboardMetrics";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "dailySalesMetrics";
                readonly type: "dailySalesMetrics[]";
            }, {
                readonly name: "topSellingItemsMetrics";
                readonly type: "topSellingItemsMetrics[]";
            }, {
                readonly name: "inventoryAlertMetrics";
                readonly type: "inventoryAlertMetrics[]";
            }, {
                readonly name: "weeklySalesMetrics";
                readonly type: "weeklySalesMetrics[]";
            }, {
                readonly name: "operationalMetrics";
                readonly type: "operationalMetrics[]";
            }, {
                readonly name: "orders";
                readonly type: "order[]";
            }, {
                readonly name: "dailyShifts";
                readonly type: "dailyShift[]";
            }, {
                readonly name: "salesAIEntity";
                readonly type: "salesAIEntity";
            }];
        }];
    };
    export default useCase;
}
declare module "_102049_/l1/cafeFlow/layer_4_entities/dailyShift.defs" {
    export const entity: {
        readonly entityId: "dailyShift";
        readonly title: "Entidade de Turno Diário";
        readonly purpose: "Agrupa turnos diários e relatórios de fechamento";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "dailyShiftId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do turno diário.";
        }, {
            readonly fieldId: "businessDate";
            readonly type: "date";
            readonly required: true;
            readonly description: "Data de referência do turno.";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Estado atual do turno diário.";
            readonly enum: readonly ["aberto", "fechado"];
        }, {
            readonly fieldId: "openedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de abertura do turno.";
        }, {
            readonly fieldId: "closedAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora de fechamento do turno.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro.";
        }];
        readonly statusEnum: readonly ["aberto", "fechado"];
        readonly lifecycleStates: readonly ["aberto", "fechado"];
        readonly ontologyEntities: readonly ["DailyShift", "ShiftClosureReport"];
        readonly sourceTables: readonly [{
            readonly tableName: "daily_shifts";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "shift_closure_reports";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "dailyShift";
            readonly tableName: "daily_shifts";
            readonly fileRef: "_102049_/l1/cafeFlow/layer_1_external/dailyShift.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "shiftClosureReport";
            readonly tableName: "shift_closure_reports";
            readonly fileRef: "_102049_/l1/cafeFlow/layer_1_external/shiftClosureReport.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "update", "list", "search"];
        readonly rulesApplied: readonly ["shiftClosureRule"];
        readonly usecaseRefs: readonly ["abrirTurno", "fecharTurno", "listarTurnos", "buscarRelatorioFechamento", "visualizarDashboard", "gerarResumoVendas"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/DailyShiftEntity.ts";
            readonly className: "DailyShiftEntity";
            readonly contractName: "IDailyShiftEntity";
        };
    };
    export default entity;
}
declare module "_102049_/l1/cafeFlow/layer_4_entities/inventoryItem.defs" {
    export const entity: {
        readonly entityId: "inventoryItem";
        readonly title: "Entidade de Estoque";
        readonly purpose: "Agrupa itens de estoque, movimentações e unidades de medida";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "inventoryItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do item de estoque.";
        }, {
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nome do ingrediente ou insumo.";
        }, {
            readonly fieldId: "description";
            readonly type: "text";
            readonly required: false;
            readonly description: "Descrição complementar do item de estoque.";
        }, {
            readonly fieldId: "stockUnitId";
            readonly type: "StockUnit";
            readonly required: true;
            readonly description: "Unidade de medida usada para o item de estoque.";
        }, {
            readonly fieldId: "currentStock";
            readonly type: "number";
            readonly required: true;
            readonly description: "Quantidade atual em estoque.";
        }, {
            readonly fieldId: "minimumStock";
            readonly type: "number";
            readonly required: true;
            readonly description: "Quantidade mínima para alerta de estoque baixo.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro.";
        }];
        readonly ontologyEntities: readonly ["InventoryItem", "InventoryMovement", "StockUnit"];
        readonly sourceTables: readonly [{
            readonly tableName: "inventory_items";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_movements";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "StockUnit";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "inventoryItem";
            readonly tableName: "inventory_items";
            readonly fileRef: "_102049_/l1/cafeFlow/layer_1_external/inventoryItem.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "inventoryMovement";
            readonly tableName: "inventory_movements";
            readonly fileRef: "_102049_/l1/cafeFlow/layer_1_external/inventoryMovement.defs.ts";
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "StockUnit";
            readonly domainId: "stockUnit";
            readonly sourceOfTruth: "project 102034";
            readonly governanceRules: readonly ["Apenas o perfil gerente pode cadastrar ou alterar unidades de medida.", "Unidades devem ser padronizadas para garantir consistência na baixa de estoque e movimentações.", "Itens de estoque só podem usar unidades previamente cadastradas no MDM."];
        }];
        readonly allowedOperations: readonly ["create", "read", "update", "list", "search"];
        readonly rulesApplied: readonly ["inventoryDecrementRule", "lowStockAlertRule"];
        readonly usecaseRefs: readonly ["cancelarPedido", "criarItemEstoque", "atualizarItemEstoque", "listarItensEstoque", "registrarMovimentoEstoque", "listarMovimentosEstoque", "fecharTurno", "gerarResumoVendas", "sugerirPromocoes"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/InventoryItemEntity.ts";
            readonly className: "InventoryItemEntity";
            readonly contractName: "IInventoryItemEntity";
        };
    };
    export default entity;
}
declare module "_102049_/l1/cafeFlow/layer_4_entities/menuItem.defs" {
    export const entity: {
        readonly entityId: "menuItem";
        readonly title: "Entidade de Cardápio";
        readonly purpose: "Agrupa itens e categorias do cardápio gerenciados via MDM";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "menuItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do item do cardápio.";
        }, {
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nome exibido do item do cardápio.";
        }, {
            readonly fieldId: "description";
            readonly type: "text";
            readonly required: false;
            readonly description: "Descrição detalhada do item do cardápio.";
        }, {
            readonly fieldId: "price";
            readonly type: "money";
            readonly required: true;
            readonly description: "Preço de venda do item do cardápio.";
        }, {
            readonly fieldId: "menuCategoryId";
            readonly type: "MenuCategory";
            readonly required: true;
            readonly description: "Categoria à qual o item do cardápio pertence.";
        }, {
            readonly fieldId: "isActive";
            readonly type: "boolean";
            readonly required: true;
            readonly description: "Indica se o item do cardápio está disponível para venda.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro do item do cardápio.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro do item do cardápio.";
        }];
        readonly ontologyEntities: readonly ["MenuItem", "MenuCategory"];
        readonly sourceTables: readonly [{
            readonly tableName: "MenuItem";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "MenuCategory";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuItem";
            readonly domainId: "menuItem";
            readonly sourceOfTruth: "project 102034";
            readonly governanceRules: readonly ["Apenas o perfil gerente pode cadastrar, editar ou desativar itens do cardápio.", "Cada item deve estar vinculado a uma categoria do MDM de categorias.", "Itens podem ter vínculo com ingredientes de estoque para controle de insumos.", "Alterações de preço e disponibilidade devem ser auditadas no MDM."];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuCategory";
            readonly domainId: "menuCategory";
            readonly sourceOfTruth: "project 102034";
            readonly governanceRules: readonly ["Apenas o perfil gerente pode criar, editar ou desativar categorias.", "Categorias devem ser únicas e padronizadas para garantir consistência em relatórios e filtros.", "Itens do cardápio só podem ser associados a categorias ativas no MDM."];
        }];
        readonly allowedOperations: readonly ["create", "read", "update", "list", "search"];
        readonly rulesApplied: readonly [];
        readonly usecaseRefs: readonly ["criarPedido", "listarPedidos", "buscarPedidoPorId", "criarItemCardapio", "atualizarItemCardapio", "listarItensCardapio", "gerarResumoVendas", "sugerirPromocoes"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/MenuItemEntity.ts";
            readonly className: "MenuItemEntity";
            readonly contractName: "IMenuItemEntity";
        };
    };
    export default entity;
}
declare module "_102049_/l1/cafeFlow/layer_4_entities/order.defs" {
    export const entity: {
        readonly entityId: "order";
        readonly title: "Entidade de Pedido";
        readonly purpose: "Agrupa pedidos, itens de pedido, mesas/comandas e status de pedido";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "orderId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do pedido.";
        }, {
            readonly fieldId: "originType";
            readonly type: "string";
            readonly required: true;
            readonly description: "Origem do pedido (mesa ou takeout).";
            readonly enum: readonly ["mesa", "takeout"];
        }, {
            readonly fieldId: "tableSeatId";
            readonly type: "TableSeat";
            readonly required: false;
            readonly description: "Referência opcional à mesa/comanda associada ao pedido.";
        }, {
            readonly fieldId: "dailyShiftId";
            readonly type: "DailyShift";
            readonly required: true;
            readonly description: "Turno diário ao qual o pedido pertence.";
        }, {
            readonly fieldId: "orderStatusId";
            readonly type: "OrderStatus";
            readonly required: true;
            readonly description: "Status padronizado atual do pedido.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do pedido.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do pedido.";
        }];
        readonly statusEnum: readonly ["recebido", "preparando", "pronto", "entregue", "cancelado"];
        readonly ontologyEntities: readonly ["Order", "OrderItem", "TableSeat", "OrderStatus"];
        readonly sourceTables: readonly [{
            readonly tableName: "orders";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_items";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "table_seats";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "OrderStatus";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "order";
            readonly tableName: "orders";
            readonly fileRef: "_102049_/l1/cafeFlow/layer_1_external/order.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "orderItem";
            readonly tableName: "order_items";
            readonly fileRef: "_102049_/l1/cafeFlow/layer_1_external/orderItem.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "tableSeat";
            readonly tableName: "table_seats";
            readonly fileRef: "_102049_/l1/cafeFlow/layer_1_external/tableSeat.defs.ts";
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "OrderStatus";
            readonly domainId: "orderStatus";
            readonly sourceOfTruth: "project 102034";
            readonly governanceRules: readonly ["Status seguem o fluxo padronizado obrigatório: recebido → preparando → pronto → entregue.", "Cancelado é um estado terminal que encerra o fluxo do pedido sem permitir retorno.", "Transições de status são controladas exclusivamente pelos workflows de pedido e cozinha."];
        }];
        readonly allowedOperations: readonly ["create", "read", "update", "list", "search"];
        readonly rulesApplied: readonly ["orderStatusLifecycle", "inventoryDecrementRule"];
        readonly usecaseRefs: readonly ["criarPedido", "atualizarStatusPedido", "cancelarPedido", "listarPedidos", "buscarPedidoPorId", "criarMesa", "atualizarMesa", "listarMesas", "registrarMovimentoEstoque", "fecharTurno", "visualizarDashboard", "gerarResumoVendas", "sugerirPromocoes"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/OrderEntity.ts";
            readonly className: "OrderEntity";
            readonly contractName: "IOrderEntity";
        };
    };
    export default entity;
}
declare module "_102049_/l1/cafeFlow/layer_4_entities/salesSummary.defs" {
    export const entity: {
        readonly entityId: "salesSummary";
        readonly title: "Entidade de IA e Métricas de Vendas";
        readonly purpose: "Agrupa resumos de vendas, sugestões de promoção e tabelas de métricas operacionais";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "salesSummaryId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do resumo de vendas.";
        }, {
            readonly fieldId: "summaryDate";
            readonly type: "date";
            readonly required: true;
            readonly description: "Data do resumo de vendas.";
        }, {
            readonly fieldId: "totalSales";
            readonly type: "money";
            readonly required: true;
            readonly description: "Total de vendas do dia.";
        }, {
            readonly fieldId: "totalOrders";
            readonly type: "number";
            readonly required: true;
            readonly description: "Quantidade total de pedidos do dia.";
        }, {
            readonly fieldId: "averageTicket";
            readonly type: "money";
            readonly required: false;
            readonly description: "Ticket médio do dia.";
        }, {
            readonly fieldId: "highlights";
            readonly type: "text";
            readonly required: false;
            readonly description: "Destaques e observações geradas pela IA.";
        }, {
            readonly fieldId: "dailyShiftId";
            readonly type: "DailyShift";
            readonly required: false;
            readonly description: "Referência opcional ao turno do dia relacionado ao resumo.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro.";
        }];
        readonly ontologyEntities: readonly ["SalesSummary", "PromotionSuggestion"];
        readonly sourceTables: readonly [{
            readonly tableName: "sales_summaries";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "promotion_suggestions";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_alert_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "weekly_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "operational_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "salesSummary";
            readonly tableName: "sales_summaries";
            readonly fileRef: "_102049_/l1/cafeFlow/layer_1_external/salesSummary.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "promotionSuggestion";
            readonly tableName: "promotion_suggestions";
            readonly fileRef: "_102049_/l1/cafeFlow/layer_1_external/promotionSuggestion.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "dailySalesMetrics";
            readonly tableName: "daily_sales_metrics";
            readonly fileRef: "_102049_/l1/cafeFlow/layer_1_external/dailySalesMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "topSellingItemsMetrics";
            readonly tableName: "top_selling_items_metrics";
            readonly fileRef: "_102049_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "inventoryAlertMetrics";
            readonly tableName: "inventory_alert_metrics";
            readonly fileRef: "_102049_/l1/cafeFlow/layer_1_external/inventoryAlertMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "weeklySalesMetrics";
            readonly tableName: "weekly_sales_metrics";
            readonly fileRef: "_102049_/l1/cafeFlow/layer_1_external/weeklySalesMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "operationalMetrics";
            readonly tableName: "operational_metrics";
            readonly fileRef: "_102049_/l1/cafeFlow/layer_1_external/operationalMetrics.defs.ts";
        }];
        readonly allowedOperations: readonly ["create", "read", "list"];
        readonly rulesApplied: readonly ["aiSummarySourceRule"];
        readonly usecaseRefs: readonly ["criarPedido", "cancelarPedido", "registrarMovimentoEstoque", "fecharTurno", "visualizarDashboard", "gerarResumoVendas", "sugerirPromocoes", "listarResumosVendas", "listarSugestoesPromocoes"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/SalesSummaryEntity.ts";
            readonly className: "SalesSummaryEntity";
            readonly contractName: "ISalesSummaryEntity";
        };
    };
    export default entity;
}
declare module "_102049_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102049_/l2/cafeFlow/cardapioEstoque.defs" {
    export const cardapioEstoquePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "cardapioEstoque";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 64;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "cardapioEstoque";
                readonly pageName: "Cardápio e estoque";
                readonly actor: "manager";
                readonly purpose: "Gerenciar itens do cardápio e controle de estoque.";
                readonly capabilities: readonly ["manageMenu", "manageInventory"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["menuManagement"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["inventoryDecrement"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["menuItem", "menuCategory", "stockUnit"];
                readonly pageInputs: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "MenuItem";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "selection"];
                    readonly description: "Identificador do item do cardápio para edição contextual.";
                }, {
                    readonly name: "inventoryItemId";
                    readonly type: "InventoryItem";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "selection"];
                    readonly description: "Identificador do item de estoque para edição ou movimentação contextual.";
                    readonly entityRef: "InventoryItem";
                    readonly fieldRef: "inventoryItemId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "centralNotificacoes";
                    readonly trigger: "ver alertas de estoque baixo";
                    readonly description: "Acessar alertas de estoque baixo e notificações operacionais.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Gestão de cardápio";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "Lista de itens do cardápio";
                        readonly purpose: "Visualizar itens do cardápio com categorias e status.";
                        readonly userActions: readonly ["filtrar por categoria", "selecionar item", "iniciar criação de item", "iniciar edição de item"];
                        readonly requiredEntities: readonly ["MenuItem", "MenuCategory"];
                        readonly readsFields: readonly ["menuItemId", "name", "description", "price", "menuCategoryId", "isActive"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "Editor de item do cardápio";
                        readonly purpose: "Cadastrar ou atualizar item do cardápio.";
                        readonly userActions: readonly ["salvar novo item", "salvar alterações", "ativar/desativar item"];
                        readonly requiredEntities: readonly ["MenuItem", "MenuCategory"];
                        readonly readsFields: readonly ["menuItemId", "name", "description", "price", "menuCategoryId", "isActive"];
                        readonly writesFields: readonly ["name", "description", "price", "menuCategoryId", "isActive"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Gestão de estoque";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "Lista de itens de estoque";
                        readonly purpose: "Acompanhar saldo, unidade e alertas de itens de estoque.";
                        readonly userActions: readonly ["filtrar por unidade", "selecionar item", "iniciar criação de item", "iniciar edição de item"];
                        readonly requiredEntities: readonly ["InventoryItem", "StockUnit"];
                        readonly readsFields: readonly ["inventoryItemId", "name", "description", "stockUnitId", "currentStock", "minimumStock", "updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["lowStockAlertRule"];
                    }, {
                        readonly organismName: "Editor de item de estoque";
                        readonly purpose: "Cadastrar ou atualizar item de estoque e parâmetros de alerta.";
                        readonly userActions: readonly ["salvar novo item", "salvar alterações", "ajustar níveis mínimos"];
                        readonly requiredEntities: readonly ["InventoryItem", "StockUnit"];
                        readonly readsFields: readonly ["inventoryItemId", "name", "description", "stockUnitId", "currentStock", "minimumStock", "status"];
                        readonly writesFields: readonly ["name", "description", "stockUnitId", "currentStock", "minimumStock", "status"];
                        readonly rulesApplied: readonly ["lowStockAlertRule"];
                    }];
                }, {
                    readonly sectionName: "Movimentos de estoque";
                    readonly mode: "interactive";
                    readonly organisms: readonly [{
                        readonly organismName: "Histórico de movimentos";
                        readonly purpose: "Consultar entradas, saídas e ajustes de estoque.";
                        readonly userActions: readonly ["filtrar por item", "filtrar por período", "ver detalhes do movimento"];
                        readonly requiredEntities: readonly ["InventoryMovement", "InventoryItem", "StockUnit"];
                        readonly readsFields: readonly ["id", "inventoryItemId", "movementType", "movementStatus", "quantity", "unitCost", "reason", "createdAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["inventoryDecrementRule"];
                    }, {
                        readonly organismName: "Registrar movimento manual";
                        readonly purpose: "Registrar entrada, saída ou ajuste de estoque manual.";
                        readonly userActions: readonly ["registrar entrada", "registrar saída", "registrar ajuste"];
                        readonly requiredEntities: readonly ["InventoryMovement", "InventoryItem", "StockUnit"];
                        readonly readsFields: readonly ["inventoryItemId", "currentStock", "stockUnitId"];
                        readonly writesFields: readonly ["inventoryItemId", "movementType", "quantity", "unitCost", "reason"];
                        readonly rulesApplied: readonly ["inventoryDecrementRule", "lowStockAlertRule"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarItensCardapio";
                readonly purpose: "Exibir itens e categorias do cardápio.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "menuCategoryId";
                    readonly type: "MenuCategory";
                    readonly required: false;
                }, {
                    readonly name: "isActive";
                    readonly type: "boolean";
                    readonly required: false;
                }, {
                    readonly name: "search";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "menuItems";
                    readonly type: "MenuItem[]";
                }];
                readonly readsEntities: readonly ["menuEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarItensCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "criarItemCardapio";
                readonly purpose: "Cadastrar novo item de cardápio.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "menuCategoryId";
                    readonly type: "MenuCategory";
                    readonly required: true;
                }, {
                    readonly name: "isActive";
                    readonly type: "boolean";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "MenuItem";
                }];
                readonly readsEntities: readonly ["menuEntity"];
                readonly writesEntities: readonly ["menuEntity"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["criarItemCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "atualizarItemCardapio";
                readonly purpose: "Editar item de cardápio existente.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "MenuItem";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "menuCategoryId";
                    readonly type: "MenuCategory";
                    readonly required: false;
                }, {
                    readonly name: "isActive";
                    readonly type: "boolean";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "MenuItem";
                }];
                readonly readsEntities: readonly ["menuEntity"];
                readonly writesEntities: readonly ["menuEntity"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["atualizarItemCardapio"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listarItensEstoque";
                readonly purpose: "Exibir itens de estoque e saldos.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "stockUnitId";
                    readonly type: "StockUnit";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "search";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryItems";
                    readonly type: "InventoryItem[]";
                }];
                readonly readsEntities: readonly ["inventoryEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["inventory_items"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarItensEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "criarItemEstoque";
                readonly purpose: "Cadastrar item de estoque.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "stockUnitId";
                    readonly type: "StockUnit";
                    readonly required: true;
                }, {
                    readonly name: "currentStock";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "minimumStock";
                    readonly type: "number";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "InventoryItem";
                }];
                readonly readsEntities: readonly ["inventoryEntity"];
                readonly writesEntities: readonly ["inventoryEntity"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["inventory_items"];
                readonly usecaseRefs: readonly ["criarItemEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["lowStockAlertRule"];
            }, {
                readonly commandName: "atualizarItemEstoque";
                readonly purpose: "Editar item de estoque.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "InventoryItem";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "stockUnitId";
                    readonly type: "StockUnit";
                    readonly required: false;
                }, {
                    readonly name: "currentStock";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "minimumStock";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "InventoryItem";
                }];
                readonly readsEntities: readonly ["inventoryEntity"];
                readonly writesEntities: readonly ["inventoryEntity"];
                readonly readsTables: readonly ["inventory_items"];
                readonly writesTables: readonly ["inventory_items"];
                readonly usecaseRefs: readonly ["atualizarItemEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["lowStockAlertRule"];
            }, {
                readonly commandName: "registrarMovimentoEstoque";
                readonly purpose: "Registrar entrada ou saída de estoque.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "InventoryItem";
                    readonly required: true;
                }, {
                    readonly name: "movementType";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "unitCost";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "movementId";
                    readonly type: "InventoryMovement";
                }, {
                    readonly name: "updatedStock";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["inventoryEntity", "orderEntity"];
                readonly writesEntities: readonly ["inventoryEntity"];
                readonly readsTables: readonly ["inventory_items", "orders", "order_items"];
                readonly writesTables: readonly ["inventory_movements", "inventory_items", "inventory_alert_metrics", "operational_metrics"];
                readonly usecaseRefs: readonly ["registrarMovimentoEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["inventoryDecrementRule", "lowStockAlertRule"];
            }, {
                readonly commandName: "listarMovimentosEstoque";
                readonly purpose: "Listar histórico de movimentações de estoque.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "InventoryItem";
                    readonly required: false;
                }, {
                    readonly name: "dateStart";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "dateEnd";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "movementType";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryMovements";
                    readonly type: "InventoryMovement[]";
                }];
                readonly readsEntities: readonly ["inventoryEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["inventory_movements", "inventory_items"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarMovimentosEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["inventoryDecrementRule"];
            }];
        };
    };
    export default cardapioEstoquePagePlan;
}
declare module "_102049_/l2/cafeFlow/centralNotificacoes.defs" {
    export const centralNotificacoesPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "centralNotificacoes";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 65;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "centralNotificacoes";
                readonly pageName: "Central de notificações";
                readonly actor: "manager";
                readonly purpose: "Visualizar alertas operacionais, especialmente estoque baixo.";
                readonly capabilities: readonly ["manageInventory"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "cardapioEstoque";
                    readonly trigger: "alertas de estoque baixo";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "cardapioEstoque";
                    readonly trigger: "ajustar item de estoque";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Alertas de estoque baixo";
                    readonly mode: "list";
                    readonly organisms: readonly [{
                        readonly organismName: "Lista de itens com estoque baixo";
                        readonly purpose: "Exibir itens com alerta de estoque baixo para ação rápida.";
                        readonly userActions: readonly ["visualizar detalhe do item", "ir para ajuste de estoque"];
                        readonly requiredEntities: readonly ["InventoryItem"];
                        readonly readsFields: readonly ["inventoryItemId", "name", "currentStock", "minimumStock", "stockUnitId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["lowStockAlertRule"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarItensEstoque";
                readonly purpose: "Listar itens com baixo estoque para ação.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "filtroBaixoEstoque";
                    readonly type: "boolean";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "currentStock";
                    readonly type: "number";
                }, {
                    readonly name: "minimumStock";
                    readonly type: "number";
                }, {
                    readonly name: "stockUnitId";
                    readonly type: "StockUnit";
                }];
                readonly readsEntities: readonly ["InventoryItem"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["inventory_items"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarItensEstoque"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["lowStockAlertRule"];
            }];
        };
    };
    export default centralNotificacoesPagePlan;
}
declare module "_102049_/l2/cafeFlow/dashboardGerente.defs" {
    export const dashboardGerentePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "dashboardGerente";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 65;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "dashboardGerente";
                readonly pageName: "Dashboard do gerente";
                readonly actor: "manager";
                readonly purpose: "Acompanhar métricas de vendas e alertas operacionais.";
                readonly capabilities: readonly ["viewDashboard"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "periodoFiltro";
                    readonly type: "dateRange";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Intervalo de datas para filtrar métricas, resumos e sugestões.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "fechamentoTurno";
                    readonly trigger: "resumo pós-fechamento";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Filtro de período";
                    readonly mode: "filter";
                    readonly organisms: readonly [{
                        readonly organismName: "FiltroPeriodo";
                        readonly purpose: "Definir o intervalo de datas do dashboard.";
                        readonly userActions: readonly ["ajustarPeriodo", "limparFiltro"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Visão geral de métricas";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "CardsMetricaVendas";
                        readonly purpose: "Exibir indicadores principais de vendas e operação.";
                        readonly userActions: readonly ["visualizarDetalhesMetricas", "atualizarDashboard"];
                        readonly requiredEntities: readonly ["salesAIEntity"];
                        readonly readsFields: readonly ["dailyRevenue", "dailyOrderCount", "dailyAverageTicket", "weeklySalesTrend", "operationalHighlights"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "TabelaItensMaisVendidos";
                        readonly purpose: "Mostrar itens mais vendidos no período.";
                        readonly userActions: readonly ["visualizarItem", "ordenarItens"];
                        readonly requiredEntities: readonly ["salesAIEntity"];
                        readonly readsFields: readonly ["topSellingItems"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "AlertasOperacionais";
                        readonly purpose: "Apresentar alertas de estoque baixo e gargalos operacionais.";
                        readonly userActions: readonly ["abrirCentralNotificacoes"];
                        readonly requiredEntities: readonly ["salesAIEntity"];
                        readonly readsFields: readonly ["inventoryAlerts", "operationalAlerts"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Resumos de vendas";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "ListaResumosVendas";
                        readonly purpose: "Listar resumos diários gerados pela IA.";
                        readonly userActions: readonly ["visualizarResumo"];
                        readonly requiredEntities: readonly ["SalesSummary"];
                        readonly readsFields: readonly ["salesSummaryId", "summaryDate", "totalSales", "totalOrders", "averageTicket", "highlights"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["aiSummarySourceRule"];
                    }];
                }, {
                    readonly sectionName: "Sugestões de promoção";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "ListaSugestoesPromocoes";
                        readonly purpose: "Listar sugestões de promoção geradas pela IA.";
                        readonly userActions: readonly ["visualizarSugestao"];
                        readonly requiredEntities: readonly ["PromotionSuggestion"];
                        readonly readsFields: readonly ["promotionSuggestionId", "title", "suggestionText", "periodStart", "periodEnd", "rationale"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["aiSummarySourceRule"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "visualizarDashboard";
                readonly purpose: "Carregar visão geral de métricas do dia e indicadores operacionais.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "periodStart";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "periodEnd";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "dailyRevenue";
                    readonly type: "number";
                }, {
                    readonly name: "dailyOrderCount";
                    readonly type: "number";
                }, {
                    readonly name: "dailyAverageTicket";
                    readonly type: "number";
                }, {
                    readonly name: "topSellingItems";
                    readonly type: "TopSellingItemMetric[]";
                }, {
                    readonly name: "inventoryAlerts";
                    readonly type: "InventoryAlertMetric[]";
                }, {
                    readonly name: "weeklySalesTrend";
                    readonly type: "WeeklySalesMetric[]";
                }, {
                    readonly name: "operationalAlerts";
                    readonly type: "OperationalMetric[]";
                }];
                readonly readsEntities: readonly ["salesAIEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["visualizarDashboard"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listarResumosVendas";
                readonly purpose: "Listar resumos de vendas por período.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "periodStart";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "periodEnd";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "salesSummaries";
                    readonly type: "SalesSummary[]";
                }];
                readonly readsEntities: readonly ["salesAIEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarResumosVendas"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["aiSummarySourceRule"];
            }, {
                readonly commandName: "listarSugestoesPromocoes";
                readonly purpose: "Listar sugestões de promoção geradas por IA.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "periodStart";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "periodEnd";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "promotionSuggestions";
                    readonly type: "PromotionSuggestion[]";
                }];
                readonly readsEntities: readonly ["salesAIEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarSugestoesPromocoes"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["aiSummarySourceRule"];
            }];
        };
    };
    export default dashboardGerentePagePlan;
}
declare module "_102049_/l2/cafeFlow/fechamentoTurno.defs" {
    export const fechamentoTurnoPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "fechamentoTurno";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 66;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "fechamentoTurno";
                readonly pageName: "Fechamento de turno";
                readonly actor: "manager";
                readonly purpose: "Abrir turno diário, acompanhar resumo e realizar fechamento com conferência.";
                readonly capabilities: readonly ["closeDailyShift"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["dailyShiftClosure"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "dashboardGerente";
                    readonly trigger: "ver métricas do dia após fechamento";
                    readonly description: "Acessar dashboard do gerente após fechar o turno.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Turnos do dia";
                    readonly mode: "list";
                    readonly organisms: readonly [{
                        readonly organismName: "listaTurnos";
                        readonly purpose: "Listar turnos ativos e históricos para seleção.";
                        readonly userActions: readonly ["selecionarTurno", "atualizarLista"];
                        readonly requiredEntities: readonly ["DailyShift"];
                        readonly readsFields: readonly ["DailyShift.dailyShiftId", "DailyShift.businessDate", "DailyShift.status", "DailyShift.openedAt", "DailyShift.closedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["shiftClosureRule"];
                    }];
                }, {
                    readonly sectionName: "Abertura de turno";
                    readonly mode: "create";
                    readonly organisms: readonly [{
                        readonly organismName: "abrirTurnoForm";
                        readonly purpose: "Iniciar um novo turno diário.";
                        readonly userActions: readonly ["abrirTurno"];
                        readonly requiredEntities: readonly ["DailyShift"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["DailyShift.businessDate", "DailyShift.openedAt"];
                        readonly rulesApplied: readonly ["shiftClosureRule"];
                    }];
                }, {
                    readonly sectionName: "Resumo para conferência";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "relatorioFechamentoResumo";
                        readonly purpose: "Exibir relatório consolidado do turno selecionado.";
                        readonly userActions: readonly ["visualizarRelatorioFechamento"];
                        readonly requiredEntities: readonly ["ShiftClosureReport", "DailyShift"];
                        readonly readsFields: readonly ["ShiftClosureReport.shiftClosureReportId", "ShiftClosureReport.dailyShiftId", "ShiftClosureReport.totalSales", "ShiftClosureReport.totalOrders", "ShiftClosureReport.cashTotal", "ShiftClosureReport.cardTotal", "ShiftClosureReport.summaryNotes", "ShiftClosureReport.createdAt", "DailyShift.businessDate", "DailyShift.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["shiftClosureRule"];
                    }];
                }, {
                    readonly sectionName: "Fechamento do turno";
                    readonly mode: "confirm";
                    readonly organisms: readonly [{
                        readonly organismName: "fecharTurnoConfirmacao";
                        readonly purpose: "Confirmar fechamento do turno com totais conferidos.";
                        readonly userActions: readonly ["fecharTurno", "confirmarFechamento"];
                        readonly requiredEntities: readonly ["DailyShift", "ShiftClosureReport"];
                        readonly readsFields: readonly ["DailyShift.dailyShiftId", "DailyShift.status", "ShiftClosureReport.totalSales", "ShiftClosureReport.totalOrders", "ShiftClosureReport.cashTotal", "ShiftClosureReport.cardTotal"];
                        readonly writesFields: readonly ["DailyShift.status", "DailyShift.closedAt", "ShiftClosureReport.totalSales", "ShiftClosureReport.totalOrders", "ShiftClosureReport.cashTotal", "ShiftClosureReport.cardTotal", "ShiftClosureReport.summaryNotes"];
                        readonly rulesApplied: readonly ["shiftClosureRule"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarTurnos";
                readonly purpose: "Consultar turnos ativos e históricos.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "businessDate";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "uuid";
                }, {
                    readonly name: "businessDate";
                    readonly type: "date";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "openedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "closedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["dailyShiftEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["daily_shifts"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarTurnos"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "abrirTurno";
                readonly purpose: "Iniciar turno diário.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "businessDate";
                    readonly type: "date";
                    readonly required: true;
                }, {
                    readonly name: "responsavel";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "uuid";
                }, {
                    readonly name: "businessDate";
                    readonly type: "date";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "openedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly [];
                readonly writesEntities: readonly ["dailyShiftEntity"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["daily_shifts"];
                readonly usecaseRefs: readonly ["abrirTurno"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["shiftClosureRule"];
            }, {
                readonly commandName: "buscarRelatorioFechamento";
                readonly purpose: "Exibir dados consolidados para conferência.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "shiftClosureReportId";
                    readonly type: "uuid";
                }, {
                    readonly name: "dailyShiftId";
                    readonly type: "uuid";
                }, {
                    readonly name: "totalSales";
                    readonly type: "money";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                }, {
                    readonly name: "cashTotal";
                    readonly type: "money";
                }, {
                    readonly name: "cardTotal";
                    readonly type: "money";
                }, {
                    readonly name: "summaryNotes";
                    readonly type: "text";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["dailyShiftEntity"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["shift_closure_reports", "daily_shifts"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["buscarRelatorioFechamento"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "fecharTurno";
                readonly purpose: "Encerrar turno com valores conferidos.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "totalSales";
                    readonly type: "money";
                    readonly required: true;
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "cashTotal";
                    readonly type: "money";
                    readonly required: false;
                }, {
                    readonly name: "cardTotal";
                    readonly type: "money";
                    readonly required: false;
                }, {
                    readonly name: "summaryNotes";
                    readonly type: "text";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "closedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "shiftClosureReportId";
                    readonly type: "uuid";
                }];
                readonly readsEntities: readonly ["dailyShiftEntity", "orderEntity", "inventoryEntity"];
                readonly writesEntities: readonly ["dailyShiftEntity", "salesAIEntity"];
                readonly readsTables: readonly ["daily_shifts", "orders", "order_items", "inventory_movements"];
                readonly writesTables: readonly ["daily_shifts", "shift_closure_reports", "daily_sales_metrics", "operational_metrics"];
                readonly usecaseRefs: readonly ["fecharTurno"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["shiftClosureRule"];
            }];
        };
    };
    export default fechamentoTurnoPagePlan;
}
declare module "_102049_/l2/cafeFlow/painelCozinha.defs" {
    export const painelCozinhaPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "painelCozinha";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 63;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "painelCozinha";
                readonly pageName: "Painel da cozinha";
                readonly actor: "kitchen";
                readonly purpose: "Acompanhar fila de pedidos e atualizar status de preparo.";
                readonly capabilities: readonly ["updateKitchenStatus"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly ["kitchenPreparation"];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["orderStatus"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "posRapido";
                    readonly trigger: "pedido confirmado para cozinha";
                    readonly description: "Abrir painel quando um pedido é confirmado para preparo.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Fila de pedidos";
                    readonly mode: "list";
                    readonly organisms: readonly [{
                        readonly organismName: "Lista de pedidos por status";
                        readonly purpose: "Exibir pedidos da cozinha com status atual, tempo e itens.";
                        readonly userActions: readonly ["filtrar por status", "selecionar pedido para atualizar status"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.orderId", "Order.originType", "Order.tableSeatId", "Order.orderStatusId", "Order.createdAt", "Order.updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["orderStatusLifecycle"];
                    }];
                }, {
                    readonly sectionName: "Atualização de status";
                    readonly mode: "detail";
                    readonly organisms: readonly [{
                        readonly organismName: "Ações de status do pedido";
                        readonly purpose: "Avançar ou cancelar o status conforme o preparo.";
                        readonly userActions: readonly ["iniciarPreparo", "marcarPronto", "marcarEntregue", "cancelarPedido"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.orderId", "Order.orderStatusId"];
                        readonly writesFields: readonly ["Order.orderStatusId", "Order.updatedAt"];
                        readonly rulesApplied: readonly ["orderStatusLifecycle"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarPedidos";
                readonly purpose: "Exibir fila de pedidos por status para preparo.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "statusFiltro";
                    readonly type: "OrderStatus";
                    readonly required: false;
                }, {
                    readonly name: "originType";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "limit";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "offset";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "originType";
                    readonly type: "string";
                }, {
                    readonly name: "tableSeatId";
                    readonly type: "TableSeat";
                }, {
                    readonly name: "orderStatusId";
                    readonly type: "OrderStatus";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["orders", "order_items", "table_seats"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarPedidos"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "atualizarStatusPedido";
                readonly purpose: "Atualizar status do pedido conforme preparo.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "novoStatusId";
                    readonly type: "OrderStatus";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "orderStatusId";
                    readonly type: "OrderStatus";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly ["Order"];
                readonly readsTables: readonly ["orders", "order_items"];
                readonly writesTables: readonly ["orders"];
                readonly usecaseRefs: readonly ["atualizarStatusPedido"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderStatusLifecycle"];
            }];
        };
    };
    export default painelCozinhaPagePlan;
}
declare module "_102049_/l2/cafeFlow/posRapido.defs" {
    export const posRapidoPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "posRapido";
        readonly moduleName: "cafeFlow";
        readonly status: "incomplete";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 62;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "posRapido";
                readonly pageName: "POS rápido";
                readonly actor: "attendantCashier";
                readonly purpose: "Lançar, revisar e acompanhar pedidos rápidos no balcão ou mesa.";
                readonly capabilities: readonly ["manageOrders"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["menuItem", "menuCategory", "orderStatus"];
                readonly pageInputs: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do pedido para abrir e cancelar.";
                    readonly entityRef: "Order";
                    readonly fieldRef: "orderId";
                }, {
                    readonly name: "tableSeatId";
                    readonly type: "TableSeat";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Mesa/comanda pré-selecionada, quando aplicável.";
                    readonly entityRef: "TableSeat";
                    readonly fieldRef: "tableSeatId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "painelCozinha";
                    readonly trigger: "pedido confirmado para cozinha";
                    readonly description: "Ao confirmar pedido, acompanhar fila na cozinha.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "pedidosAtivos";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "listaPedidosAtivos";
                        readonly purpose: "Exibir pedidos ativos para seleção e acompanhamento.";
                        readonly userActions: readonly ["selecionarPedido", "filtrarPorStatus", "visualizarMesaComanda"];
                        readonly requiredEntities: readonly ["Order", "TableSeat"];
                        readonly readsFields: readonly ["Order.orderId", "Order.orderStatusId", "Order.tableSeatId", "Order.originType", "Order.createdAt", "TableSeat.label"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["orderStatusLifecycle"];
                    }];
                }, {
                    readonly sectionName: "selecaoMesaComanda";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "seletorMesaComanda";
                        readonly purpose: "Selecionar mesa/comanda ativa para o novo pedido.";
                        readonly userActions: readonly ["listarMesasAtivas", "selecionarMesaComanda"];
                        readonly requiredEntities: readonly ["TableSeat"];
                        readonly readsFields: readonly ["TableSeat.tableSeatId", "TableSeat.label", "TableSeat.seatType", "TableSeat.isActive"];
                        readonly writesFields: readonly ["Order.tableSeatId", "Order.originType"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "itensDoPedido";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "seletorItensCardapio";
                        readonly purpose: "Selecionar itens do cardápio e quantidades para o pedido.";
                        readonly userActions: readonly ["listarItensCardapio", "adicionarItem", "ajustarQuantidade", "removerItem"];
                        readonly requiredEntities: readonly ["OrderItem", "MenuItem", "MenuCategory"];
                        readonly readsFields: readonly ["MenuItem.menuItemId", "MenuItem.name", "MenuItem.price", "MenuCategory.menuCategoryId", "MenuCategory.name"];
                        readonly writesFields: readonly ["OrderItem.menuItemId", "OrderItem.quantity"];
                        readonly rulesApplied: readonly ["inventoryDecrementRule"];
                    }];
                }, {
                    readonly sectionName: "resumoEConfirmacao";
                    readonly mode: "confirm";
                    readonly organisms: readonly [{
                        readonly organismName: "resumoPedido";
                        readonly purpose: "Revisar dados do pedido antes da confirmação.";
                        readonly userActions: readonly ["revisarPedido"];
                        readonly requiredEntities: readonly ["Order", "OrderItem", "TableSeat"];
                        readonly readsFields: readonly ["Order.originType", "Order.tableSeatId", "OrderItem.menuItemId", "OrderItem.quantity", "TableSeat.label"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["orderStatusLifecycle"];
                    }, {
                        readonly organismName: "acoesPedido";
                        readonly purpose: "Confirmar criação ou cancelar pedido selecionado.";
                        readonly userActions: readonly ["confirmarCriacao", "cancelarPedido"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.orderId", "Order.orderStatusId"];
                        readonly writesFields: readonly ["Order.orderStatusId"];
                        readonly rulesApplied: readonly ["orderStatusLifecycle", "inventoryDecrementRule"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listarPedidos";
                readonly purpose: "Listar pedidos ativos para seleção e acompanhamento.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "orderStatusId";
                    readonly type: "OrderStatus";
                    readonly required: false;
                }, {
                    readonly name: "originType";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                }, {
                    readonly name: "orderStatusId";
                    readonly type: "OrderStatus";
                }, {
                    readonly name: "tableSeatId";
                    readonly type: "TableSeat";
                }, {
                    readonly name: "originType";
                    readonly type: "string";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "tableSeatLabel";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Order", "OrderItem", "TableSeat"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["orders", "order_items", "table_seats"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarPedidos"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "buscarPedidoPorId";
                readonly purpose: "Buscar detalhes completos do pedido selecionado.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                }, {
                    readonly name: "originType";
                    readonly type: "string";
                }, {
                    readonly name: "tableSeatId";
                    readonly type: "TableSeat";
                }, {
                    readonly name: "orderStatusId";
                    readonly type: "OrderStatus";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "orderItemId";
                    readonly type: "OrderItem";
                }, {
                    readonly name: "menuItemId";
                    readonly type: "MenuItem";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Order", "OrderItem", "TableSeat"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["orders", "order_items", "table_seats"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["buscarPedidoPorId"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listarMesas";
                readonly purpose: "Listar mesas e comandas disponíveis para seleção.";
                readonly kind: "query";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "tableSeatId";
                    readonly type: "TableSeat";
                }, {
                    readonly name: "label";
                    readonly type: "string";
                }, {
                    readonly name: "seatType";
                    readonly type: "string";
                }, {
                    readonly name: "isActive";
                    readonly type: "boolean";
                }];
                readonly readsEntities: readonly ["TableSeat"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["table_seats"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listarMesas"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "criarPedido";
                readonly purpose: "Criar pedido com itens selecionados.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "originType";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "tableSeatId";
                    readonly type: "TableSeat";
                    readonly required: false;
                }, {
                    readonly name: "orderItems";
                    readonly type: "OrderItemInput[]";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                }, {
                    readonly name: "orderStatusId";
                    readonly type: "OrderStatus";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Order", "OrderItem", "TableSeat"];
                readonly writesEntities: readonly ["Order", "OrderItem"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["orders", "order_items", "daily_sales_metrics", "top_selling_items_metrics", "weekly_sales_metrics", "operational_metrics"];
                readonly usecaseRefs: readonly ["criarPedido"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderStatusLifecycle", "inventoryDecrementRule"];
            }, {
                readonly commandName: "cancelarPedido";
                readonly purpose: "Cancelar pedido antes da produção.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                    readonly required: true;
                }, {
                    readonly name: "motivo";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "Order";
                }, {
                    readonly name: "orderStatusId";
                    readonly type: "OrderStatus";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Order", "OrderItem"];
                readonly writesEntities: readonly ["Order"];
                readonly readsTables: readonly ["orders", "order_items", "inventory_items"];
                readonly writesTables: readonly ["orders", "inventory_movements", "daily_sales_metrics", "top_selling_items_metrics", "weekly_sales_metrics", "operational_metrics"];
                readonly usecaseRefs: readonly ["cancelarPedido"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderStatusLifecycle", "inventoryDecrementRule"];
            }];
            readonly pendingQuestions: readonly ["Existe um caso de uso/BFF para listar itens do cardápio e categorias (MenuItem/MenuCategory) para compor o seletor de itens? Se sim, informe o usecaseId e os campos esperados."];
        };
    };
    export default posRapidoPagePlan;
}
declare module "_102049_/l2/cafeFlow/plugins/llm.defs" {
    export const llmPluginConnectionPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginConnection";
        readonly artifactId: "llm";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 16;
            readonly planId: "plan-plugins";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "llm";
                readonly provider: "LLM.";
                readonly priority: "soon";
                readonly reason: "Habilitar o assistente IA de vendas e o resumo diário com sugestões, conforme artefatos aprovados de IA.";
                readonly events: readonly ["Geração de resumo diário", "Sugestões de promoção"];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["Resumo de vendas do dia", "Histórico de vendas dos últimos 7 dias"];
                readonly outputData: readonly ["Resumo de vendas com insights", "Sugestões de promoção"];
                readonly webhooks: readonly [];
                readonly risks: readonly ["Dependência de LLM pode introduzir variação na qualidade das sugestões."];
                readonly questions: readonly [];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102049_/l2/plugins/llm/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102049_/l2/cafeFlow/plugins/llm.defs.ts";
            };
        };
    };
    export default llmPluginConnectionPlan;
}
declare module "_102049_/l2/plugins/llm/plugin.defs" {
    export const llmPluginPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginDraft";
        readonly artifactId: "llm";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 16;
            readonly planId: "plan-plugins";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "llm";
                readonly provider: "LLM.";
                readonly priority: "soon";
                readonly reason: "Habilitar o assistente IA de vendas e o resumo diário com sugestões, conforme artefatos aprovados de IA.";
                readonly events: readonly ["Geração de resumo diário", "Sugestões de promoção"];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly ["Resumo de vendas do dia", "Histórico de vendas dos últimos 7 dias"];
                readonly outputData: readonly ["Resumo de vendas com insights", "Sugestões de promoção"];
                readonly webhooks: readonly [];
                readonly risks: readonly ["Dependência de LLM pode introduzir variação na qualidade das sugestões."];
                readonly questions: readonly [];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102049_/l2/plugins/llm/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102049_/l2/cafeFlow/plugins/llm.defs.ts";
            };
        };
    };
    export default llmPluginPlan;
}

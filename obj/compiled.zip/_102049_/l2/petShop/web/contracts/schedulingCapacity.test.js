/// <mls fileReference="_102049_/l2/petShop/web/contracts/schedulingCapacity.test.ts" enhancement="_blank"/>

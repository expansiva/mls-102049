/// <mls fileReference="_102049_/l2/petShop/web/shared/productManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "page.title": "Gestão de produtos",
    "section.productManagement": "Gestão de produtos",
    "section.review": "Resumo",
    "organism.browseProducts.title": "Produtos cadastrados",
    "organism.createProduct.title": "Cadastrar novo produto",
    "organism.updateProduct.title": "Editar produto",
    "organism.review.title": "Resumo da gestão",
    "empty.browseProducts": "Nenhum produto encontrado. Ajuste os filtros ou cadastre um novo produto.",
    "empty.createProduct": "Preencha os dados do produto para cadastrá-lo no catálogo.",
    "empty.updateProduct": "Selecione um produto na lista para editar seus dados.",
    "empty.review": "Nenhuma ação realizada ainda. Gerencie produtos acima para ver o resumo aqui.",
    "column.name": "Nome",
    "column.price": "Preço",
    "column.productCategoryId": "Categoria",
    "column.featured": "Destaque",
    "column.status": "Status",
    "filter.searchName": "Buscar por nome",
    "filter.filterStatus": "Status",
    "filter.filterProductCategoryId": "Categoria",
    "filter.filterFeatured": "Apenas destaques",
    "field.name": "Nome",
    "field.description": "Descrição",
    "field.price": "Preço",
    "field.imageUrl": "URL da imagem",
    "field.productCategoryId": "Categoria",
    "field.featured": "Destaque na página inicial",
    "field.status": "Status",
    "field.productId": "Produto",
    "action.createProduct": "Cadastrar produto",
    "action.createProduct.submit": "Salvar produto",
    "action.updateProduct": "Editar",
    "action.updateProduct.submit": "Salvar alterações",
    "action.createProduct.success": "Produto cadastrado com sucesso no catálogo.",
    "action.createProduct.error": "Não foi possível cadastrar o produto. Verifique os dados e tente novamente.",
    "action.updateProduct.success": "Produto atualizado com sucesso no catálogo.",
    "action.updateProduct.error": "Não foi possível atualizar o produto. Verifique os dados e tente novamente.",
    "org.browseProducts.title": "Listar produtos cadastrados com filtros e seleção para edição",
    "org.createProduct.title": "Cadastrar novo produto no catálogo",
    "org.updateProduct.title": "Editar produto existente e definir destaque",
    "org.review.title": "Revisar o contexto e o resultado das ações principais da página"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class PetShopProductManagementBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.browseProductsState = "idle";
        this.browseProductsSearchName = '';
        this.browseProductsFilterStatus = '';
        this.browseProductsFilterProductCategoryId = '';
        this.browseProductsFilterFeatured = '';
        this.browseProductsData = { items: [], total: 0 };
        this.createProductState = "idle";
        this.createProductName = '';
        this.createProductDescription = '';
        this.createProductPrice = '';
        this.createProductImageUrl = '';
        this.createProductProductCategoryId = '';
        this.createProductFeatured = '';
        this.createProductOutput = null;
        this.createProductError = '';
        this.updateProductState = "idle";
        this.updateProductProductId = '';
        this.updateProductName = '';
        this.updateProductDescription = '';
        this.updateProductPrice = '';
        this.updateProductImageUrl = '';
        this.updateProductProductCategoryId = '';
        this.updateProductFeatured = '';
        this.updateProductStatus = '';
        this.updateProductOutput = null;
        this.updateProductError = '';
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    // ---- State setters: browseProducts filters ----
    setBrowseProductsSearchName(value) {
        this.browseProductsSearchName = value;
        setState('ui.productManagement.input.browseProducts.searchName', value);
        this.requestUpdate();
    }
    handleBrowseProductsSearchNameChange(e) {
        const target = e.target;
        this.setBrowseProductsSearchName(target.value);
    }
    setBrowseProductsFilterStatus(value) {
        this.browseProductsFilterStatus = value;
        setState('ui.productManagement.input.browseProducts.filterStatus', value);
        this.requestUpdate();
    }
    handleBrowseProductsFilterStatusChange(e) {
        const target = e.target;
        this.setBrowseProductsFilterStatus(target.value);
    }
    setBrowseProductsFilterProductCategoryId(value) {
        this.browseProductsFilterProductCategoryId = value;
        setState('ui.productManagement.input.browseProducts.filterProductCategoryId', value);
        this.requestUpdate();
    }
    handleBrowseProductsFilterProductCategoryIdChange(e) {
        const target = e.target;
        this.setBrowseProductsFilterProductCategoryId(target.value);
    }
    setBrowseProductsFilterFeatured(value) {
        this.browseProductsFilterFeatured = value;
        setState('ui.productManagement.input.browseProducts.filterFeatured', value);
        this.requestUpdate();
    }
    handleBrowseProductsFilterFeaturedChange(e) {
        const target = e.target;
        this.setBrowseProductsFilterFeatured(target.value);
    }
    // ---- State setters: createProduct form ----
    setCreateProductName(value) {
        this.createProductName = value;
        setState('ui.productManagement.input.createProduct.name', value);
        this.requestUpdate();
    }
    handleCreateProductNameChange(e) {
        const target = e.target;
        this.setCreateProductName(target.value);
    }
    setCreateProductDescription(value) {
        this.createProductDescription = value;
        setState('ui.productManagement.input.createProduct.description', value);
        this.requestUpdate();
    }
    handleCreateProductDescriptionChange(e) {
        const target = e.target;
        this.setCreateProductDescription(target.value);
    }
    setCreateProductPrice(value) {
        this.createProductPrice = value;
        setState('ui.productManagement.input.createProduct.price', value);
        this.requestUpdate();
    }
    handleCreateProductPriceChange(e) {
        const target = e.target;
        this.setCreateProductPrice(target.value);
    }
    setCreateProductImageUrl(value) {
        this.createProductImageUrl = value;
        setState('ui.productManagement.input.createProduct.imageUrl', value);
        this.requestUpdate();
    }
    handleCreateProductImageUrlChange(e) {
        const target = e.target;
        this.setCreateProductImageUrl(target.value);
    }
    setCreateProductProductCategoryId(value) {
        this.createProductProductCategoryId = value;
        setState('ui.productManagement.input.createProduct.productCategoryId', value);
        this.requestUpdate();
    }
    handleCreateProductProductCategoryIdChange(e) {
        const target = e.target;
        this.setCreateProductProductCategoryId(target.value);
    }
    setCreateProductFeatured(value) {
        this.createProductFeatured = value;
        setState('ui.productManagement.input.createProduct.featured', value);
        this.requestUpdate();
    }
    handleCreateProductFeaturedChange(e) {
        const target = e.target;
        this.setCreateProductFeatured(target.value);
    }
    // ---- State setters: updateProduct form ----
    setUpdateProductProductId(value) {
        this.updateProductProductId = value;
        setState('ui.productManagement.input.updateProduct.productId', value);
        this.requestUpdate();
    }
    handleUpdateProductProductIdChange(e) {
        const target = e.target;
        this.setUpdateProductProductId(target.value);
    }
    setUpdateProductName(value) {
        this.updateProductName = value;
        setState('ui.productManagement.input.updateProduct.name', value);
        this.requestUpdate();
    }
    handleUpdateProductNameChange(e) {
        const target = e.target;
        this.setUpdateProductName(target.value);
    }
    setUpdateProductDescription(value) {
        this.updateProductDescription = value;
        setState('ui.productManagement.input.updateProduct.description', value);
        this.requestUpdate();
    }
    handleUpdateProductDescriptionChange(e) {
        const target = e.target;
        this.setUpdateProductDescription(target.value);
    }
    setUpdateProductPrice(value) {
        this.updateProductPrice = value;
        setState('ui.productManagement.input.updateProduct.price', value);
        this.requestUpdate();
    }
    handleUpdateProductPriceChange(e) {
        const target = e.target;
        this.setUpdateProductPrice(target.value);
    }
    setUpdateProductImageUrl(value) {
        this.updateProductImageUrl = value;
        setState('ui.productManagement.input.updateProduct.imageUrl', value);
        this.requestUpdate();
    }
    handleUpdateProductImageUrlChange(e) {
        const target = e.target;
        this.setUpdateProductImageUrl(target.value);
    }
    setUpdateProductProductCategoryId(value) {
        this.updateProductProductCategoryId = value;
        setState('ui.productManagement.input.updateProduct.productCategoryId', value);
        this.requestUpdate();
    }
    handleUpdateProductProductCategoryIdChange(e) {
        const target = e.target;
        this.setUpdateProductProductCategoryId(target.value);
    }
    setUpdateProductFeatured(value) {
        this.updateProductFeatured = value;
        setState('ui.productManagement.input.updateProduct.featured', value);
        this.requestUpdate();
    }
    handleUpdateProductFeaturedChange(e) {
        const target = e.target;
        this.setUpdateProductFeatured(target.value);
    }
    setUpdateProductStatus(value) {
        this.updateProductStatus = value;
        setState('ui.productManagement.input.updateProduct.status', value);
        this.requestUpdate();
    }
    handleUpdateProductStatusChange(e) {
        const target = e.target;
        this.setUpdateProductStatus(target.value);
    }
    // ---- Query action: browseProducts ----
    async loadBrowseProducts() {
        this.browseProductsState = 'loading';
        setState('ui.productManagement.action.browseProducts.status', 'loading');
        this.requestUpdate();
        const params = {};
        if (this.browseProductsSearchName) {
            params.searchName = this.browseProductsSearchName;
        }
        if (this.browseProductsFilterStatus === 'active' || this.browseProductsFilterStatus === 'inactive') {
            params.filterStatus = this.browseProductsFilterStatus;
        }
        if (this.browseProductsFilterProductCategoryId) {
            params.filterProductCategoryId = this.browseProductsFilterProductCategoryId;
        }
        if (this.browseProductsFilterFeatured === 'true' || this.browseProductsFilterFeatured === 'false') {
            params.filterFeatured = this.browseProductsFilterFeatured === 'true';
        }
        const options = { mode: 'silent' };
        const response = await execBff('petShop.browseProducts.browseProducts', params, options);
        if (response.ok) {
            const data = response.data ?? { items: [], total: 0 };
            this.browseProductsData = data;
            setState('ui.productManagement.data.browseProducts', data);
            this.browseProductsState = 'success';
            setState('ui.productManagement.action.browseProducts.status', 'success');
        }
        else {
            this.browseProductsData = { items: [], total: 0 };
            setState('ui.productManagement.data.browseProducts', { items: [], total: 0 });
            this.browseProductsState = 'error';
            setState('ui.productManagement.action.browseProducts.status', 'error');
            if (response.error) {
                console.error('browseProducts error:', response.error.message);
            }
        }
        this.requestUpdate();
    }
    handleBrowseProductsClick(e) {
        e.preventDefault();
        this.loadBrowseProducts();
    }
    // ---- Command action: createProduct ----
    async createProduct() {
        this.createProductState = 'loading';
        setState('ui.productManagement.action.createProduct.status', 'loading');
        this.createProductError = '';
        setState('ui.productManagement.action.createProduct.error', '');
        this.requestUpdate();
        const priceNum = parseFloat(this.createProductPrice);
        const featuredBool = this.createProductFeatured === 'true' || this.createProductFeatured === 'true';
        const params = {
            name: this.createProductName,
            price: isNaN(priceNum) ? 0 : priceNum,
            productCategoryId: this.createProductProductCategoryId,
            featured: featuredBool,
        };
        if (this.createProductDescription) {
            params.description = this.createProductDescription;
        }
        if (this.createProductImageUrl) {
            params.imageUrl = this.createProductImageUrl;
        }
        const options = { mode: 'blocking' };
        const response = await execBff('petShop.createProduct.createProduct', params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.createProductOutput = data;
            setState('ui.productManagement.output.createProduct', data);
            // Refresh browseProducts before setting success
            await this.loadBrowseProducts();
            if (this.browseProductsState === 'error') {
                this.createProductState = 'error';
                setState('ui.productManagement.action.createProduct.status', 'error');
                this.requestUpdate();
                return;
            }
            // Clear form inputs
            this.createProductName = '';
            setState('ui.productManagement.input.createProduct.name', '');
            this.createProductDescription = '';
            setState('ui.productManagement.input.createProduct.description', '');
            this.createProductPrice = '';
            setState('ui.productManagement.input.createProduct.price', '');
            this.createProductImageUrl = '';
            setState('ui.productManagement.input.createProduct.imageUrl', '');
            this.createProductProductCategoryId = '';
            setState('ui.productManagement.input.createProduct.productCategoryId', '');
            this.createProductFeatured = '';
            setState('ui.productManagement.input.createProduct.featured', '');
            this.createProductState = 'success';
            setState('ui.productManagement.action.createProduct.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? this.msg['action.createProduct.error'];
            this.createProductError = errorMsg;
            setState('ui.productManagement.action.createProduct.error', errorMsg);
            this.createProductState = 'error';
            setState('ui.productManagement.action.createProduct.status', 'error');
        }
        this.requestUpdate();
    }
    handleCreateProductClick(e) {
        e.preventDefault();
        runBlockingUiAction(async (_signal) => {
            await this.createProduct();
        }, { mode: 'blocking' });
    }
    // ---- Command action: updateProduct ----
    async updateProduct() {
        if (!this.updateProductProductId) {
            this.updateProductState = 'idle';
            setState('ui.productManagement.action.updateProduct.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.updateProductState = 'loading';
        setState('ui.productManagement.action.updateProduct.status', 'loading');
        this.updateProductError = '';
        setState('ui.productManagement.action.updateProduct.error', '');
        this.requestUpdate();
        const priceNum = parseFloat(this.updateProductPrice);
        const featuredBool = this.updateProductFeatured === 'true';
        const statusVal = this.updateProductStatus === 'inactive' ? 'inactive' : 'active';
        const params = {
            productId: this.updateProductProductId,
            name: this.updateProductName,
            price: isNaN(priceNum) ? 0 : priceNum,
            productCategoryId: this.updateProductProductCategoryId,
            featured: featuredBool,
            status: statusVal,
        };
        if (this.updateProductDescription) {
            params.description = this.updateProductDescription;
        }
        if (this.updateProductImageUrl) {
            params.imageUrl = this.updateProductImageUrl;
        }
        const options = { mode: 'blocking' };
        const response = await execBff('petShop.updateProduct.updateProduct', params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.updateProductOutput = data;
            setState('ui.productManagement.output.updateProduct', data);
            // Refresh browseProducts before setting success
            await this.loadBrowseProducts();
            if (this.browseProductsState === 'error') {
                this.updateProductState = 'error';
                setState('ui.productManagement.action.updateProduct.status', 'error');
                this.requestUpdate();
                return;
            }
            // Clear form inputs
            this.updateProductProductId = '';
            setState('ui.productManagement.input.updateProduct.productId', '');
            this.updateProductName = '';
            setState('ui.productManagement.input.updateProduct.name', '');
            this.updateProductDescription = '';
            setState('ui.productManagement.input.updateProduct.description', '');
            this.updateProductPrice = '';
            setState('ui.productManagement.input.updateProduct.price', '');
            this.updateProductImageUrl = '';
            setState('ui.productManagement.input.updateProduct.imageUrl', '');
            this.updateProductProductCategoryId = '';
            setState('ui.productManagement.input.updateProduct.productCategoryId', '');
            this.updateProductFeatured = '';
            setState('ui.productManagement.input.updateProduct.featured', '');
            this.updateProductStatus = '';
            setState('ui.productManagement.input.updateProduct.status', '');
            this.updateProductState = 'success';
            setState('ui.productManagement.action.updateProduct.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? this.msg['action.updateProduct.error'];
            this.updateProductError = errorMsg;
            setState('ui.productManagement.action.updateProduct.error', errorMsg);
            this.updateProductState = 'error';
            setState('ui.productManagement.action.updateProduct.status', 'error');
        }
        this.requestUpdate();
    }
    handleUpdateProductClick(e) {
        e.preventDefault();
        runBlockingUiAction(async (_signal) => {
            await this.updateProduct();
        }, { mode: 'blocking' });
    }
    // ---- Lifecycle ----
    connectedCallback() {
        super.connectedCallback();
        // Initialize state from global store where useful
        const savedSearchName = getState('ui.productManagement.input.browseProducts.searchName');
        if (savedSearchName !== undefined && savedSearchName !== null) {
            this.browseProductsSearchName = savedSearchName;
        }
        const savedFilterStatus = getState('ui.productManagement.input.browseProducts.filterStatus');
        if (savedFilterStatus !== undefined && savedFilterStatus !== null) {
            this.browseProductsFilterStatus = savedFilterStatus;
        }
        const savedFilterCategory = getState('ui.productManagement.input.browseProducts.filterProductCategoryId');
        if (savedFilterCategory !== undefined && savedFilterCategory !== null) {
            this.browseProductsFilterProductCategoryId = savedFilterCategory;
        }
        const savedFilterFeatured = getState('ui.productManagement.input.browseProducts.filterFeatured');
        if (savedFilterFeatured !== undefined && savedFilterFeatured !== null) {
            this.browseProductsFilterFeatured = savedFilterFeatured;
        }
        // Run initial loads
        this.loadBrowseProducts();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "browseProductsState", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "browseProductsSearchName", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "browseProductsFilterStatus", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "browseProductsFilterProductCategoryId", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "browseProductsFilterFeatured", void 0);
__decorate([
    property({ type: Object })
], PetShopProductManagementBase.prototype, "browseProductsData", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "createProductState", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "createProductName", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "createProductDescription", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "createProductPrice", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "createProductImageUrl", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "createProductProductCategoryId", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "createProductFeatured", void 0);
__decorate([
    property({ type: Object })
], PetShopProductManagementBase.prototype, "createProductOutput", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "createProductError", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "updateProductState", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "updateProductProductId", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "updateProductName", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "updateProductDescription", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "updateProductPrice", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "updateProductImageUrl", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "updateProductProductCategoryId", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "updateProductFeatured", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "updateProductStatus", void 0);
__decorate([
    property({ type: Object })
], PetShopProductManagementBase.prototype, "updateProductOutput", void 0);
__decorate([
    property({ type: String })
], PetShopProductManagementBase.prototype, "updateProductError", void 0);

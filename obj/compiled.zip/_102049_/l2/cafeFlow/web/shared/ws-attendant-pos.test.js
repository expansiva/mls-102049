/// <mls fileReference="_102049_/l2/cafeFlow/web/shared/ws-attendant-pos.test.ts" enhancement="_102020_/l2/enhancementAura"/>
export {};

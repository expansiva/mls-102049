/// <mls fileReference="_102049_/l2/cafeFlow/web/shared/ws-attendant-pos.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "ws-attendant-pos.section.main.title": "POS – Lançamento e Finalização de Pedidos",
    "ws-attendant-pos.organism.createOrder.title": "Lançar pedido no POS",
    "ws-attendant-pos.organism.settleOrder.title": "Finalizar pedido",
    "ws-attendant-pos.createOrder.step.selectTable.title": "Selecionar mesa ou informar número",
    "ws-attendant-pos.createOrder.step.addItems.title": "Adicionar itens do cardápio ao pedido",
    "ws-attendant-pos.createOrder.step.applyCombos.title": "Aplicar regras de combo e substituições",
    "ws-attendant-pos.createOrder.step.confirmSend.title": "Confirmar e enviar pedido para a cozinha",
    "ws-attendant-pos.settleOrder.step.verifyReady.title": "Verificar pedido pronto pela cozinha",
    "ws-attendant-pos.settleOrder.step.confirmDelivery.title": "Confirmar entrega ou pagamento",
    "ws-attendant-pos.settleOrder.step.finalize.title": "Marcar pedido como finalizado",
    "ws-attendant-pos.field.orderType.label": "Modalidade do pedido",
    "ws-attendant-pos.field.status.label": "Status do pedido",
    "ws-attendant-pos.field.total.label": "Total do pedido",
    "ws-attendant-pos.action.createOrder.label": "Enviar pedido para a cozinha",
    "ws-attendant-pos.action.settleOrder.label": "Finalizar pedido"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowWsAttendantPosBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.createOrderState = 'idle';
        this.createOrderOrderType = '';
        this.createOrderStatus = '';
        this.createOrderTotal = '';
        this.settleOrderState = 'idle';
        this.settleOrderStatus = '';
        this.stateKeys = [
            'ui.ws-attendant-pos.status',
            'ui.ws-attendant-pos.action.createOrder.status',
            'ui.ws-attendant-pos.input.createOrder.orderType',
            'ui.ws-attendant-pos.input.createOrder.status',
            'ui.ws-attendant-pos.input.createOrder.total',
            'ui.ws-attendant-pos.action.settleOrder.status',
            'ui.ws-attendant-pos.input.settleOrder.status',
        ];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        const statusValue = getState('ui.ws-attendant-pos.status');
        this.status = statusValue !== undefined ? statusValue : '';
        const createOrderStateValue = getState('ui.ws-attendant-pos.action.createOrder.status');
        this.createOrderState = createOrderStateValue !== undefined
            ? createOrderStateValue
            : 'idle';
        const createOrderOrderTypeValue = getState('ui.ws-attendant-pos.input.createOrder.orderType');
        this.createOrderOrderType = createOrderOrderTypeValue !== undefined
            ? createOrderOrderTypeValue
            : '';
        const createOrderStatusValue = getState('ui.ws-attendant-pos.input.createOrder.status');
        this.createOrderStatus = createOrderStatusValue !== undefined
            ? createOrderStatusValue
            : '';
        const createOrderTotalValue = getState('ui.ws-attendant-pos.input.createOrder.total');
        this.createOrderTotal = createOrderTotalValue !== undefined
            ? createOrderTotalValue
            : '';
        const settleOrderStateValue = getState('ui.ws-attendant-pos.action.settleOrder.status');
        this.settleOrderState = settleOrderStateValue !== undefined
            ? settleOrderStateValue
            : 'idle';
        const settleOrderStatusValue = getState('ui.ws-attendant-pos.input.settleOrder.status');
        this.settleOrderStatus = settleOrderStatusValue !== undefined
            ? settleOrderStatusValue
            : '';
        subscribe(this.stateKeys, this);
    }
    disconnectedCallback() {
        unsubscribe(this.stateKeys, this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(stateKey, value) {
        switch (stateKey) {
            case 'ui.ws-attendant-pos.status':
                this.status = value;
                break;
            case 'ui.ws-attendant-pos.action.createOrder.status':
                this.createOrderState = value;
                break;
            case 'ui.ws-attendant-pos.input.createOrder.orderType':
                this.createOrderOrderType = value;
                break;
            case 'ui.ws-attendant-pos.input.createOrder.status':
                this.createOrderStatus = value;
                break;
            case 'ui.ws-attendant-pos.input.createOrder.total':
                this.createOrderTotal = value;
                break;
            case 'ui.ws-attendant-pos.action.settleOrder.status':
                this.settleOrderState = value;
                break;
            case 'ui.ws-attendant-pos.input.settleOrder.status':
                this.settleOrderStatus = value;
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    setCreateOrderOrderType(value) {
        this.createOrderOrderType = value;
        setState('ui.ws-attendant-pos.input.createOrder.orderType', value);
        this.requestUpdate();
    }
    handleCreateOrderOrderTypeChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setCreateOrderOrderType(value);
    }
    setCreateOrderStatus(value) {
        this.createOrderStatus = value;
        setState('ui.ws-attendant-pos.input.createOrder.status', value);
        this.requestUpdate();
    }
    handleCreateOrderStatusChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setCreateOrderStatus(value);
    }
    setCreateOrderTotal(value) {
        this.createOrderTotal = value;
        setState('ui.ws-attendant-pos.input.createOrder.total', value);
        this.requestUpdate();
    }
    handleCreateOrderTotalChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        const nextValue = value === '' ? '' : Number(value);
        this.setCreateOrderTotal(nextValue);
    }
    setSettleOrderStatus(value) {
        this.settleOrderStatus = value;
        setState('ui.ws-attendant-pos.input.settleOrder.status', value);
        this.requestUpdate();
    }
    handleSettleOrderStatusChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setSettleOrderStatus(value);
    }
    async createOrder(signal) {
        this.createOrderState = 'loading';
        setState('ui.ws-attendant-pos.action.createOrder.status', 'loading');
        const params = {
            orderType: this.createOrderOrderType,
            status: this.createOrderStatus,
            total: typeof this.createOrderTotal === 'number' ? this.createOrderTotal : Number(this.createOrderTotal),
        };
        const options = {
            mode: 'blocking',
            signal,
        };
        try {
            const response = await execBff('cafeFlow.orderLifecycle.createOrder', params, options);
            if (!response.ok) {
                this.createOrderState = 'error';
                setState('ui.ws-attendant-pos.action.createOrder.status', 'error');
                throw new Error(response.error?.message ?? 'Erro ao executar createOrder');
            }
            this.createOrderState = 'success';
            setState('ui.ws-attendant-pos.action.createOrder.status', 'success');
        }
        catch (error) {
            this.createOrderState = 'error';
            setState('ui.ws-attendant-pos.action.createOrder.status', 'error');
            throw error;
        }
    }
    async handleCreateOrderClick() {
        await runBlockingUiAction(async (signal) => {
            await this.createOrder(signal);
        });
    }
    async settleOrder(signal) {
        this.settleOrderState = 'loading';
        setState('ui.ws-attendant-pos.action.settleOrder.status', 'loading');
        const params = {
            status: this.settleOrderStatus,
        };
        const options = {
            mode: 'blocking',
            signal,
        };
        try {
            const response = await execBff('cafeFlow.orderLifecycle.settleOrder', params, options);
            if (!response.ok) {
                this.settleOrderState = 'error';
                setState('ui.ws-attendant-pos.action.settleOrder.status', 'error');
                throw new Error(response.error?.message ?? 'Erro ao executar settleOrder');
            }
            this.settleOrderState = 'success';
            setState('ui.ws-attendant-pos.action.settleOrder.status', 'success');
        }
        catch (error) {
            this.settleOrderState = 'error';
            setState('ui.ws-attendant-pos.action.settleOrder.status', 'error');
            throw error;
        }
    }
    async handleSettleOrderClick() {
        await runBlockingUiAction(async (signal) => {
            await this.settleOrder(signal);
        });
    }
}
__decorate([
    property()
], CafeFlowWsAttendantPosBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowWsAttendantPosBase.prototype, "createOrderState", void 0);
__decorate([
    property()
], CafeFlowWsAttendantPosBase.prototype, "createOrderOrderType", void 0);
__decorate([
    property()
], CafeFlowWsAttendantPosBase.prototype, "createOrderStatus", void 0);
__decorate([
    property()
], CafeFlowWsAttendantPosBase.prototype, "createOrderTotal", void 0);
__decorate([
    property()
], CafeFlowWsAttendantPosBase.prototype, "settleOrderState", void 0);
__decorate([
    property()
], CafeFlowWsAttendantPosBase.prototype, "settleOrderStatus", void 0);

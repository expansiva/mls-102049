/// <mls fileReference="_102049_/l2/petShop/web/shared/productCatalog.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "page.productCatalog.title": "Catálogo de Produtos",
    "section.overview.title": "Visão Geral",
    "section.catalog.title": "Catálogo de Produtos",
    "section.details.title": "Detalhes do Produto",
    "organism.highlightsCards.title": "Produtos em Destaque",
    "organism.catalogSummary.title": "Resumo do Catálogo",
    "organism.catalogBrowser.title": "Navegar Catálogo",
    "organism.productDetails.title": "Detalhes do Produto",
    "intention.viewHighlights.title": "Produtos em Destaque",
    "intention.browseCatalogSummary.title": "Estatísticas do Catálogo",
    "intention.browseCatalogFilter.title": "Filtros do Catálogo",
    "intention.searchProductsFilter.title": "Buscar Produtos",
    "intention.filterProductsFilter.title": "Filtrar Produtos",
    "intention.searchProductsList.title": "Resultados da Busca",
    "intention.filterProductsList.title": "Resultados Filtrados",
    "intention.viewProductDetails.title": "Detalhes do Produto",
    "intention.viewHighlights.empty": "Nenhum produto em destaque disponível",
    "intention.browseCatalogSummary.empty": "Catálogo vazio",
    "intention.searchProductsList.empty": "Nenhum produto encontrado para a sua busca",
    "intention.filterProductsList.empty": "Nenhum produto corresponde aos filtros selecionados",
    "intention.viewProductDetails.empty": "Selecione um produto para ver os detalhes",
    "field.searchTerm.label": "Buscar por nome",
    "field.petTypeId.label": "Tipo de Pet",
    "field.categoryId.label": "Categoria",
    "field.minPrice.label": "Preço Mínimo",
    "field.maxPrice.label": "Preço Máximo",
    "field.productId.label": "ID",
    "field.name.label": "Nome",
    "field.description.label": "Descrição",
    "field.price.label": "Preço",
    "field.petTypeName.label": "Tipo de Pet",
    "field.categoryName.label": "Categoria",
    "field.highlighted.label": "Destaque",
    "field.status.label": "Status",
    "field.products.label": "Produtos",
    "field.total.label": "Total",
    "field.page.label": "Página",
    "field.pageSize.label": "Itens por Página",
    "field.createdAt.label": "Criado em",
    "field.updatedAt.label": "Atualizado em",
    "action.browseCatalog.label": "Navegar Catálogo",
    "action.searchProducts.label": "Buscar Produtos",
    "action.filterProducts.label": "Filtrar",
    "action.viewProductDetails.label": "Ver Detalhes",
    "action.viewHighlights.label": "Ver Destaques",
    "sec.overview.title": "Sec overview",
    "org.highlights.title": "Display highlighted products as summary cards for at a glance browsing",
    "org.catalog.summary.title": "Show catalog overview metrics including total products and pagination info",
    "sec.catalog.title": "Sec catalog",
    "org.catalog.browser.title": "Search, filter and browse products in the catalog with combined criteria",
    "sec.details.title": "Sec details",
    "org.product.details.title": "Display detailed information about a selected product including pet type and category names",
    "page.title": "Catálogo de Produtos",
    "section.highlights.title": "Produtos em Destaque",
    "section.detail.title": "Detalhes do Produto",
    "empty.highlights": "Nenhum produto em destaque no momento",
    "empty.catalog": "Nenhum produto encontrado",
    "empty.detail": "Selecione um produto para ver os detalhes"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class PetShopProductCatalogBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.subscribedKeys = [
            'ui.productCatalog.status',
            'ui.productCatalog.action.viewHighlights.status',
            'ui.productCatalog.data.viewHighlights',
            'ui.productCatalog.action.browseCatalog.status',
            'ui.productCatalog.input.browseCatalog.searchTerm',
            'ui.productCatalog.input.browseCatalog.petTypeId',
            'ui.productCatalog.input.browseCatalog.categoryId',
            'ui.productCatalog.input.browseCatalog.minPrice',
            'ui.productCatalog.input.browseCatalog.maxPrice',
            'ui.productCatalog.data.browseCatalog',
            'ui.productCatalog.action.searchProducts.status',
            'ui.productCatalog.input.searchProducts.searchTerm',
            'ui.productCatalog.input.searchProducts.petTypeId',
            'ui.productCatalog.input.searchProducts.categoryId',
            'ui.productCatalog.input.searchProducts.minPrice',
            'ui.productCatalog.input.searchProducts.maxPrice',
            'ui.productCatalog.data.searchProducts',
            'ui.productCatalog.action.filterProducts.status',
            'ui.productCatalog.input.filterProducts.petTypeId',
            'ui.productCatalog.input.filterProducts.categoryId',
            'ui.productCatalog.input.filterProducts.minPrice',
            'ui.productCatalog.input.filterProducts.maxPrice',
            'ui.productCatalog.data.filterProducts',
            'ui.productCatalog.action.viewProductDetails.status',
            'ui.productCatalog.input.viewProductDetails.productId',
            'ui.productCatalog.data.viewProductDetails'
        ];
        /** state ui.productCatalog.status — pageStatus */
        this.status = '';
        /** state ui.productCatalog.action.viewHighlights.status — actionStatus, values: idle | loading | success | error */
        this.viewHighlightsState = 'idle';
        /** state ui.productCatalog.data.viewHighlights — queryResult, outputShape: array */
        this.viewHighlightsData = [];
        /** state ui.productCatalog.action.browseCatalog.status — actionStatus, values: idle | loading | success | error */
        this.browseCatalogState = 'idle';
        /** state ui.productCatalog.input.browseCatalog.searchTerm — input */
        this.browseCatalogSearchTerm = '';
        /** state ui.productCatalog.input.browseCatalog.petTypeId — input */
        this.browseCatalogPetTypeId = '';
        /** state ui.productCatalog.input.browseCatalog.categoryId — input */
        this.browseCatalogCategoryId = '';
        /** state ui.productCatalog.input.browseCatalog.minPrice — input */
        this.browseCatalogMinPrice = '';
        /** state ui.productCatalog.input.browseCatalog.maxPrice — input */
        this.browseCatalogMaxPrice = '';
        /** state ui.productCatalog.data.browseCatalog — queryResult, outputShape: paginated */
        this.browseCatalogData = {
            products: [],
            total: 0,
            page: 0,
            pageSize: 0
        };
        /** state ui.productCatalog.action.searchProducts.status — actionStatus, values: idle | loading | success | error */
        this.searchProductsState = 'idle';
        /** state ui.productCatalog.input.searchProducts.searchTerm — input */
        this.searchProductsSearchTerm = '';
        /** state ui.productCatalog.input.searchProducts.petTypeId — input */
        this.searchProductsPetTypeId = '';
        /** state ui.productCatalog.input.searchProducts.categoryId — input */
        this.searchProductsCategoryId = '';
        /** state ui.productCatalog.input.searchProducts.minPrice — input */
        this.searchProductsMinPrice = '';
        /** state ui.productCatalog.input.searchProducts.maxPrice — input */
        this.searchProductsMaxPrice = '';
        /** state ui.productCatalog.data.searchProducts — queryResult, outputShape: array */
        this.searchProductsData = [];
        /** state ui.productCatalog.action.filterProducts.status — actionStatus, values: idle | loading | success | error */
        this.filterProductsState = 'idle';
        /** state ui.productCatalog.input.filterProducts.petTypeId — input */
        this.filterProductsPetTypeId = '';
        /** state ui.productCatalog.input.filterProducts.categoryId — input */
        this.filterProductsCategoryId = '';
        /** state ui.productCatalog.input.filterProducts.minPrice — input */
        this.filterProductsMinPrice = '';
        /** state ui.productCatalog.input.filterProducts.maxPrice — input */
        this.filterProductsMaxPrice = '';
        /** state ui.productCatalog.data.filterProducts — queryResult, outputShape: array */
        this.filterProductsData = [];
        /** state ui.productCatalog.action.viewProductDetails.status — actionStatus, values: idle | loading | success | error */
        this.viewProductDetailsState = 'idle';
        /** state ui.productCatalog.input.viewProductDetails.productId — input */
        this.viewProductDetailsProductId = '';
        /** state ui.productCatalog.data.viewProductDetails — queryResult, outputShape: object */
        this.viewProductDetailsData = null;
    }
    /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    /** lifecycle connectedCallback — init state, subscribe and load data */
    connectedCallback() {
        super.connectedCallback();
        this.status = this.initStateValue('ui.productCatalog.status', '');
        this.viewHighlightsState = this.initStateValue('ui.productCatalog.action.viewHighlights.status', 'idle');
        this.viewHighlightsData = this.initStateValue('ui.productCatalog.data.viewHighlights', []);
        this.browseCatalogState = this.initStateValue('ui.productCatalog.action.browseCatalog.status', 'idle');
        this.browseCatalogSearchTerm = this.initStateValue('ui.productCatalog.input.browseCatalog.searchTerm', '');
        this.browseCatalogPetTypeId = this.initStateValue('ui.productCatalog.input.browseCatalog.petTypeId', '');
        this.browseCatalogCategoryId = this.initStateValue('ui.productCatalog.input.browseCatalog.categoryId', '');
        this.browseCatalogMinPrice = this.initStateValue('ui.productCatalog.input.browseCatalog.minPrice', '');
        this.browseCatalogMaxPrice = this.initStateValue('ui.productCatalog.input.browseCatalog.maxPrice', '');
        this.browseCatalogData = this.initStateValue('ui.productCatalog.data.browseCatalog', {
            products: [],
            total: 0,
            page: 0,
            pageSize: 0
        });
        this.searchProductsState = this.initStateValue('ui.productCatalog.action.searchProducts.status', 'idle');
        this.searchProductsSearchTerm = this.initStateValue('ui.productCatalog.input.searchProducts.searchTerm', '');
        this.searchProductsPetTypeId = this.initStateValue('ui.productCatalog.input.searchProducts.petTypeId', '');
        this.searchProductsCategoryId = this.initStateValue('ui.productCatalog.input.searchProducts.categoryId', '');
        this.searchProductsMinPrice = this.initStateValue('ui.productCatalog.input.searchProducts.minPrice', '');
        this.searchProductsMaxPrice = this.initStateValue('ui.productCatalog.input.searchProducts.maxPrice', '');
        this.searchProductsData = this.initStateValue('ui.productCatalog.data.searchProducts', []);
        this.filterProductsState = this.initStateValue('ui.productCatalog.action.filterProducts.status', 'idle');
        this.filterProductsPetTypeId = this.initStateValue('ui.productCatalog.input.filterProducts.petTypeId', '');
        this.filterProductsCategoryId = this.initStateValue('ui.productCatalog.input.filterProducts.categoryId', '');
        this.filterProductsMinPrice = this.initStateValue('ui.productCatalog.input.filterProducts.minPrice', '');
        this.filterProductsMaxPrice = this.initStateValue('ui.productCatalog.input.filterProducts.maxPrice', '');
        this.filterProductsData = this.initStateValue('ui.productCatalog.data.filterProducts', []);
        this.viewProductDetailsState = this.initStateValue('ui.productCatalog.action.viewProductDetails.status', 'idle');
        this.viewProductDetailsProductId = this.initStateValue('ui.productCatalog.input.viewProductDetails.productId', '');
        this.viewProductDetailsData = this.initStateValue('ui.productCatalog.data.viewProductDetails', null);
        subscribe(this.subscribedKeys, this);
        void this.loadViewHighlights();
        void this.loadBrowseCatalog();
        void this.loadSearchProducts();
        void this.loadFilterProducts();
        void this.loadViewProductDetails();
    }
    /** lifecycle disconnectedCallback — cleanup subscriptions */
    disconnectedCallback() {
        unsubscribe(this.subscribedKeys, this);
        super.disconnectedCallback();
    }
    /** action viewHighlights (query) — route petShop.viewHighlights.viewHighlights; inputs: none; writes ui.productCatalog.data.viewHighlights; status ui.productCatalog.action.viewHighlights.status */
    async loadViewHighlights() {
        this.viewHighlightsState = 'loading';
        setState('ui.productCatalog.action.viewHighlights.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff('petShop.viewHighlights.viewHighlights', params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.viewHighlightsData = data;
            setState('ui.productCatalog.data.viewHighlights', data);
            this.viewHighlightsState = 'success';
            setState('ui.productCatalog.action.viewHighlights.status', 'success');
            return;
        }
        console.error(response.error);
        this.viewHighlightsState = 'error';
        setState('ui.productCatalog.action.viewHighlights.status', 'error');
    }
    /** handler for action viewHighlights — bind UI events here */
    handleViewHighlightsClick(event) {
        void event;
        void this.loadViewHighlights();
    }
    /** action browseCatalog (query) — route petShop.browseCatalog.browseCatalog; inputs: ui.productCatalog.input.browseCatalog.searchTerm, ui.productCatalog.input.browseCatalog.petTypeId, ui.productCatalog.input.browseCatalog.categoryId, ui.productCatalog.input.browseCatalog.minPrice, ui.productCatalog.input.browseCatalog.maxPrice; writes ui.productCatalog.data.browseCatalog; status ui.productCatalog.action.browseCatalog.status */
    async loadBrowseCatalog() {
        this.browseCatalogState = 'loading';
        setState('ui.productCatalog.action.browseCatalog.status', 'loading');
        const params = {
            searchTerm: this.normalizeOptionalString(this.browseCatalogSearchTerm),
            petTypeId: this.normalizeOptionalString(this.browseCatalogPetTypeId),
            categoryId: this.normalizeOptionalString(this.browseCatalogCategoryId),
            minPrice: this.normalizeOptionalNumber(this.browseCatalogMinPrice),
            maxPrice: this.normalizeOptionalNumber(this.browseCatalogMaxPrice)
        };
        const options = { mode: 'silent' };
        const response = await execBff('petShop.browseCatalog.browseCatalog', params, options);
        if (response.ok) {
            const data = response.data ?? {
                products: [],
                total: 0,
                page: 0,
                pageSize: 0
            };
            this.browseCatalogData = data;
            setState('ui.productCatalog.data.browseCatalog', data);
            this.browseCatalogState = 'success';
            setState('ui.productCatalog.action.browseCatalog.status', 'success');
            return;
        }
        console.error(response.error);
        this.browseCatalogState = 'error';
        setState('ui.productCatalog.action.browseCatalog.status', 'error');
    }
    /** handler for action browseCatalog — bind UI events here */
    handleBrowseCatalogClick(event) {
        void event;
        void this.loadBrowseCatalog();
    }
    /** action searchProducts (query) — route petShop.searchProducts.searchProducts; inputs: ui.productCatalog.input.searchProducts.searchTerm, ui.productCatalog.input.searchProducts.petTypeId, ui.productCatalog.input.searchProducts.categoryId, ui.productCatalog.input.searchProducts.minPrice, ui.productCatalog.input.searchProducts.maxPrice; writes ui.productCatalog.data.searchProducts; status ui.productCatalog.action.searchProducts.status */
    async loadSearchProducts() {
        this.searchProductsState = 'loading';
        setState('ui.productCatalog.action.searchProducts.status', 'loading');
        const params = {
            searchTerm: this.searchProductsSearchTerm,
            petTypeId: this.normalizeOptionalString(this.searchProductsPetTypeId),
            categoryId: this.normalizeOptionalString(this.searchProductsCategoryId),
            minPrice: this.normalizeOptionalNumber(this.searchProductsMinPrice),
            maxPrice: this.normalizeOptionalNumber(this.searchProductsMaxPrice)
        };
        const options = { mode: 'silent' };
        const response = await execBff('petShop.searchProducts.searchProducts', params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.searchProductsData = data;
            setState('ui.productCatalog.data.searchProducts', data);
            this.searchProductsState = 'success';
            setState('ui.productCatalog.action.searchProducts.status', 'success');
            return;
        }
        console.error(response.error);
        this.searchProductsState = 'error';
        setState('ui.productCatalog.action.searchProducts.status', 'error');
    }
    /** handler for action searchProducts — bind UI events here */
    handleSearchProductsClick(event) {
        void event;
        void this.loadSearchProducts();
    }
    /** action filterProducts (query) — route petShop.filterProducts.filterProducts; inputs: ui.productCatalog.input.filterProducts.petTypeId, ui.productCatalog.input.filterProducts.categoryId, ui.productCatalog.input.filterProducts.minPrice, ui.productCatalog.input.filterProducts.maxPrice; writes ui.productCatalog.data.filterProducts; status ui.productCatalog.action.filterProducts.status */
    async loadFilterProducts() {
        this.filterProductsState = 'loading';
        setState('ui.productCatalog.action.filterProducts.status', 'loading');
        const params = {
            petTypeId: this.normalizeOptionalString(this.filterProductsPetTypeId),
            categoryId: this.normalizeOptionalString(this.filterProductsCategoryId),
            minPrice: this.normalizeOptionalNumber(this.filterProductsMinPrice),
            maxPrice: this.normalizeOptionalNumber(this.filterProductsMaxPrice)
        };
        const options = { mode: 'silent' };
        const response = await execBff('petShop.filterProducts.filterProducts', params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.filterProductsData = data;
            setState('ui.productCatalog.data.filterProducts', data);
            this.filterProductsState = 'success';
            setState('ui.productCatalog.action.filterProducts.status', 'success');
            return;
        }
        console.error(response.error);
        this.filterProductsState = 'error';
        setState('ui.productCatalog.action.filterProducts.status', 'error');
    }
    /** handler for action filterProducts — bind UI events here */
    handleFilterProductsClick(event) {
        void event;
        void this.loadFilterProducts();
    }
    /** action viewProductDetails (query) — route petShop.viewProductDetails.viewProductDetails; inputs: ui.productCatalog.input.viewProductDetails.productId; writes ui.productCatalog.data.viewProductDetails; status ui.productCatalog.action.viewProductDetails.status */
    async loadViewProductDetails() {
        const routeParams = this.getRouteParams('/petShop/productCatalog/:productId?', window.location.pathname);
        const routeProductId = routeParams.productId;
        if (routeProductId !== undefined && routeProductId !== '') {
            this.viewProductDetailsProductId = routeProductId;
            setState('ui.productCatalog.input.viewProductDetails.productId', routeProductId);
        }
        if (this.viewProductDetailsProductId === '') {
            this.viewProductDetailsState = 'idle';
            setState('ui.productCatalog.action.viewProductDetails.status', 'idle');
            this.viewProductDetailsData = null;
            setState('ui.productCatalog.data.viewProductDetails', null);
            return;
        }
        this.viewProductDetailsState = 'loading';
        setState('ui.productCatalog.action.viewProductDetails.status', 'loading');
        const params = {
            productId: this.viewProductDetailsProductId
        };
        const options = { mode: 'silent' };
        const response = await execBff('petShop.viewProductDetails.viewProductDetails', params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.viewProductDetailsData = data;
            setState('ui.productCatalog.data.viewProductDetails', data);
            this.viewProductDetailsState = 'success';
            setState('ui.productCatalog.action.viewProductDetails.status', 'success');
            return;
        }
        console.error(response.error);
        this.viewProductDetailsState = 'error';
        setState('ui.productCatalog.action.viewProductDetails.status', 'error');
    }
    /** handler for action viewProductDetails — bind UI events here */
    handleViewProductDetailsClick(event) {
        void event;
        void this.loadViewProductDetails();
    }
    /** setter for state ui.productCatalog.input.browseCatalog.searchTerm */
    setBrowseCatalogSearchTerm(value) {
        this.browseCatalogSearchTerm = value;
        setState('ui.productCatalog.input.browseCatalog.searchTerm', value);
    }
    /** handler for action set.browseCatalogSearchTerm — bind UI events here */
    handleBrowseCatalogSearchTermChange(event) {
        const target = event.target;
        if (target) {
            this.setBrowseCatalogSearchTerm(target.value);
        }
    }
    /** setter for state ui.productCatalog.input.browseCatalog.petTypeId */
    setBrowseCatalogPetTypeId(value) {
        this.browseCatalogPetTypeId = value;
        setState('ui.productCatalog.input.browseCatalog.petTypeId', value);
    }
    /** handler for action set.browseCatalogPetTypeId — bind UI events here */
    handleBrowseCatalogPetTypeIdChange(event) {
        const target = event.target;
        if (target) {
            this.setBrowseCatalogPetTypeId(target.value);
        }
    }
    /** setter for state ui.productCatalog.input.browseCatalog.categoryId */
    setBrowseCatalogCategoryId(value) {
        this.browseCatalogCategoryId = value;
        setState('ui.productCatalog.input.browseCatalog.categoryId', value);
    }
    /** handler for action set.browseCatalogCategoryId — bind UI events here */
    handleBrowseCatalogCategoryIdChange(event) {
        const target = event.target;
        if (target) {
            this.setBrowseCatalogCategoryId(target.value);
        }
    }
    /** setter for state ui.productCatalog.input.browseCatalog.minPrice */
    setBrowseCatalogMinPrice(value) {
        this.browseCatalogMinPrice = value;
        setState('ui.productCatalog.input.browseCatalog.minPrice', value);
    }
    /** handler for action set.browseCatalogMinPrice — bind UI events here */
    handleBrowseCatalogMinPriceChange(event) {
        const target = event.target;
        if (target) {
            const rawValue = target.value;
            const parsedValue = rawValue === '' ? '' : Number(rawValue);
            this.setBrowseCatalogMinPrice(parsedValue);
        }
    }
    /** setter for state ui.productCatalog.input.browseCatalog.maxPrice */
    setBrowseCatalogMaxPrice(value) {
        this.browseCatalogMaxPrice = value;
        setState('ui.productCatalog.input.browseCatalog.maxPrice', value);
    }
    /** handler for action set.browseCatalogMaxPrice — bind UI events here */
    handleBrowseCatalogMaxPriceChange(event) {
        const target = event.target;
        if (target) {
            const rawValue = target.value;
            const parsedValue = rawValue === '' ? '' : Number(rawValue);
            this.setBrowseCatalogMaxPrice(parsedValue);
        }
    }
    /** setter for state ui.productCatalog.input.searchProducts.searchTerm */
    setSearchProductsSearchTerm(value) {
        this.searchProductsSearchTerm = value;
        setState('ui.productCatalog.input.searchProducts.searchTerm', value);
    }
    /** handler for action set.searchProductsSearchTerm — bind UI events here */
    handleSearchProductsSearchTermChange(event) {
        const target = event.target;
        if (target) {
            this.setSearchProductsSearchTerm(target.value);
        }
    }
    /** setter for state ui.productCatalog.input.searchProducts.petTypeId */
    setSearchProductsPetTypeId(value) {
        this.searchProductsPetTypeId = value;
        setState('ui.productCatalog.input.searchProducts.petTypeId', value);
    }
    /** handler for action set.searchProductsPetTypeId — bind UI events here */
    handleSearchProductsPetTypeIdChange(event) {
        const target = event.target;
        if (target) {
            this.setSearchProductsPetTypeId(target.value);
        }
    }
    /** setter for state ui.productCatalog.input.searchProducts.categoryId */
    setSearchProductsCategoryId(value) {
        this.searchProductsCategoryId = value;
        setState('ui.productCatalog.input.searchProducts.categoryId', value);
    }
    /** handler for action set.searchProductsCategoryId — bind UI events here */
    handleSearchProductsCategoryIdChange(event) {
        const target = event.target;
        if (target) {
            this.setSearchProductsCategoryId(target.value);
        }
    }
    /** setter for state ui.productCatalog.input.searchProducts.minPrice */
    setSearchProductsMinPrice(value) {
        this.searchProductsMinPrice = value;
        setState('ui.productCatalog.input.searchProducts.minPrice', value);
    }
    /** handler for action set.searchProductsMinPrice — bind UI events here */
    handleSearchProductsMinPriceChange(event) {
        const target = event.target;
        if (target) {
            const rawValue = target.value;
            const parsedValue = rawValue === '' ? '' : Number(rawValue);
            this.setSearchProductsMinPrice(parsedValue);
        }
    }
    /** setter for state ui.productCatalog.input.searchProducts.maxPrice */
    setSearchProductsMaxPrice(value) {
        this.searchProductsMaxPrice = value;
        setState('ui.productCatalog.input.searchProducts.maxPrice', value);
    }
    /** handler for action set.searchProductsMaxPrice — bind UI events here */
    handleSearchProductsMaxPriceChange(event) {
        const target = event.target;
        if (target) {
            const rawValue = target.value;
            const parsedValue = rawValue === '' ? '' : Number(rawValue);
            this.setSearchProductsMaxPrice(parsedValue);
        }
    }
    /** setter for state ui.productCatalog.input.filterProducts.petTypeId */
    setFilterProductsPetTypeId(value) {
        this.filterProductsPetTypeId = value;
        setState('ui.productCatalog.input.filterProducts.petTypeId', value);
    }
    /** handler for action set.filterProductsPetTypeId — bind UI events here */
    handleFilterProductsPetTypeIdChange(event) {
        const target = event.target;
        if (target) {
            this.setFilterProductsPetTypeId(target.value);
        }
    }
    /** setter for state ui.productCatalog.input.filterProducts.categoryId */
    setFilterProductsCategoryId(value) {
        this.filterProductsCategoryId = value;
        setState('ui.productCatalog.input.filterProducts.categoryId', value);
    }
    /** handler for action set.filterProductsCategoryId — bind UI events here */
    handleFilterProductsCategoryIdChange(event) {
        const target = event.target;
        if (target) {
            this.setFilterProductsCategoryId(target.value);
        }
    }
    /** setter for state ui.productCatalog.input.filterProducts.minPrice */
    setFilterProductsMinPrice(value) {
        this.filterProductsMinPrice = value;
        setState('ui.productCatalog.input.filterProducts.minPrice', value);
    }
    /** handler for action set.filterProductsMinPrice — bind UI events here */
    handleFilterProductsMinPriceChange(event) {
        const target = event.target;
        if (target) {
            const rawValue = target.value;
            const parsedValue = rawValue === '' ? '' : Number(rawValue);
            this.setFilterProductsMinPrice(parsedValue);
        }
    }
    /** setter for state ui.productCatalog.input.filterProducts.maxPrice */
    setFilterProductsMaxPrice(value) {
        this.filterProductsMaxPrice = value;
        setState('ui.productCatalog.input.filterProducts.maxPrice', value);
    }
    /** handler for action set.filterProductsMaxPrice — bind UI events here */
    handleFilterProductsMaxPriceChange(event) {
        const target = event.target;
        if (target) {
            const rawValue = target.value;
            const parsedValue = rawValue === '' ? '' : Number(rawValue);
            this.setFilterProductsMaxPrice(parsedValue);
        }
    }
    /** setter for state ui.productCatalog.input.viewProductDetails.productId */
    setViewProductDetailsProductId(value) {
        this.viewProductDetailsProductId = value;
        setState('ui.productCatalog.input.viewProductDetails.productId', value);
    }
    /** handler for action set.viewProductDetailsProductId — bind UI events here */
    handleViewProductDetailsProductIdChange(event) {
        const target = event.target;
        if (target) {
            this.setViewProductDetailsProductId(target.value);
        }
    }
    initStateValue(key, defaultValue) {
        const stored = getState(key);
        const value = stored ?? defaultValue;
        if (stored === undefined) {
            setState(key, value);
        }
        return value;
    }
    normalizeOptionalString(value) {
        return value === '' ? undefined : value;
    }
    normalizeOptionalNumber(value) {
        return value === '' ? undefined : Number(value);
    }
    getRouteParams(pattern, path) {
        const params = {};
        const patternParts = pattern.split('/').filter(Boolean);
        const pathParts = path.split('/').filter(Boolean);
        let pathIndex = 0;
        for (const part of patternParts) {
            if (part.startsWith(':')) {
                const isOptional = part.endsWith('?');
                const key = part.slice(1, isOptional ? -1 : undefined);
                const value = pathParts[pathIndex];
                if (value === undefined) {
                    if (!isOptional) {
                        params[key] = undefined;
                    }
                }
                else {
                    params[key] = decodeURIComponent(value);
                    pathIndex += 1;
                }
            }
            else if (part === pathParts[pathIndex]) {
                pathIndex += 1;
            }
        }
        return params;
    }
}
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "status", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "viewHighlightsState", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "viewHighlightsData", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "browseCatalogState", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "browseCatalogSearchTerm", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "browseCatalogPetTypeId", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "browseCatalogCategoryId", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "browseCatalogMinPrice", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "browseCatalogMaxPrice", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "browseCatalogData", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "searchProductsState", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "searchProductsSearchTerm", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "searchProductsPetTypeId", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "searchProductsCategoryId", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "searchProductsMinPrice", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "searchProductsMaxPrice", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "searchProductsData", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "filterProductsState", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "filterProductsPetTypeId", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "filterProductsCategoryId", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "filterProductsMinPrice", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "filterProductsMaxPrice", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "filterProductsData", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "viewProductDetailsState", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "viewProductDetailsProductId", void 0);
__decorate([
    property()
], PetShopProductCatalogBase.prototype, "viewProductDetailsData", void 0);

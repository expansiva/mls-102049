/// <mls fileReference="_102049_/l4/petShop/ontology/Reservation.defs.ts" enhancement="_blank"/>

export const petShopEntityReservation = {
  "entityId": "Reservation",
  "title": "Reserva",
  "description": "Reserva de produtos criada pelo cliente para retirada na loja física. Possui ciclo de vida desde o rascunho até a entrega, expiração ou cancelamento, com prazo de validade de 24 horas.",
  "kind": "core",
  "ownership": "moduleOwned",
  "fields": [
    {
      "fieldId": "reservationId",
      "type": "uuid",
      "required": true,
      "description": "Identificador único da reserva"
    },
    {
      "fieldId": "customerId",
      "type": "uuid",
      "required": true,
      "description": "Cliente autenticado que criou a reserva"
    },
    {
      "fieldId": "status",
      "type": "string",
      "required": true,
      "description": "Estágio atual da reserva no ciclo de vida",
      "enum": [
        "draft",
        "active",
        "ready",
        "delivered",
        "expired",
        "cancelled"
      ]
    },
    {
      "fieldId": "confirmedAt",
      "type": "datetime",
      "required": false,
      "description": "Momento em que a reserva saiu de rascunho e foi confirmada como ativa"
    },
    {
      "fieldId": "expiresAt",
      "type": "datetime",
      "required": true,
      "description": "Data e hora limite para retirada, 24 horas após a confirmação"
    },
    {
      "fieldId": "readyAt",
      "type": "datetime",
      "required": false,
      "description": "Momento em que a loja marcou a reserva como pronta para retirada após separar os produtos"
    },
    {
      "fieldId": "deliveredAt",
      "type": "datetime",
      "required": false,
      "description": "Momento em que o cliente retirou os produtos na loja física"
    },
    {
      "fieldId": "expiredAt",
      "type": "datetime",
      "required": false,
      "description": "Momento em que a reserva expirou automaticamente por não retirada em 24 horas"
    },
    {
      "fieldId": "cancelledAt",
      "type": "datetime",
      "required": false,
      "description": "Momento em que a reserva foi cancelada pelo cliente ou pela loja"
    },
    {
      "fieldId": "cancelReason",
      "type": "text",
      "required": false,
      "description": "Motivo informado no cancelamento da reserva"
    },
    {
      "fieldId": "paymentId",
      "type": "uuid",
      "required": false,
      "description": "Referência ao pagamento presencial associado quando a reserva é entregue"
    },
    {
      "fieldId": "createdAt",
      "type": "datetime",
      "required": true,
      "description": "Momento de criação da reserva"
    },
    {
      "fieldId": "updatedAt",
      "type": "datetime",
      "required": true,
      "description": "Momento da última atualização da reserva"
    }
  ],
  "statusEnum": [
    "draft",
    "active",
    "ready",
    "delivered",
    "expired",
    "cancelled"
  ],
  "lifecycleStates": [
    "draft",
    "active",
    "ready",
    "delivered",
    "expired",
    "cancelled"
  ]
} as const;

export default petShopEntityReservation;

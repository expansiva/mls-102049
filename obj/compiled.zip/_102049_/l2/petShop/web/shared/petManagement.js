/// <mls fileReference="_102049_/l2/petShop/web/shared/petManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
/// **collab_i18n_start**
const message_pt = {
    "petManagement.section.title": "Gestão de pets para adoção",
    "petManagement.list.title": "Pets cadastrados",
    "petManagement.list.empty": "Nenhum pet cadastrado ainda. Clique em \"Cadastrar pet\" para adicionar o primeiro.",
    "petManagement.create.title": "Cadastrar novo pet",
    "petManagement.create.empty": "Preencha os dados do pet para cadastrá-lo como disponível para adoção.",
    "petManagement.update.title": "Editar pet",
    "petManagement.update.empty": "Selecione um pet na lista para editar suas informações e disponibilidade.",
    "petManagement.summary.title": "Resumo",
    "petManagement.summary.sectionTitle": "Resumo da gestão",
    "petManagement.summary.empty": "Nenhuma ação realizada nesta sessão ainda.",
    "petManagement.field.name": "Nome",
    "petManagement.field.age": "Idade (anos)",
    "petManagement.field.description": "Descrição",
    "petManagement.field.photoUrl": "Foto (URL)",
    "petManagement.field.status": "Status",
    "petManagement.field.adoptablePetId": "ID do pet",
    "petManagement.field.createdAt": "Cadastrado em",
    "petManagement.field.updatedAt": "Atualizado em",
    "petManagement.filter.statusFilter": "Filtrar por status",
    "petManagement.action.create": "Cadastrar pet",
    "petManagement.action.create.submit": "Salvar cadastro",
    "petManagement.action.update": "Editar",
    "petManagement.action.update.submit": "Salvar alterações",
    "action.createAdoptablePet.success": "Pet cadastrado com sucesso e disponível na galeria pública.",
    "action.createAdoptablePet.error": "Não foi possível cadastrar o pet. Verifique os dados e tente novamente.",
    "action.updateAdoptablePet.success": "Pet atualizado com sucesso. A disponibilidade na galeria pública foi ajustada.",
    "action.updateAdoptablePet.error": "Não foi possível atualizar o pet. Verifique os dados e tente novamente.",
    "org.browse.pets.title": "Listar pets para adoção cadastrados com filtros de status e ações por linha",
    "org.create.pet.title": "Cadastrar novo pet para adoção com nome, idade, descrição e foto",
    "org.update.pet.title": "Editar dados do pet selecionado e controlar disponibilidade na galeria pública",
    "org.pet.summary.title": "Revisar o contexto e o resultado das ações principais da página"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class PetShopPetManagementBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.browseAdoptablePetsAdminState = 'idle';
        this.browseAdoptablePetsAdminStatusFilter = '';
        this.browseAdoptablePetsAdminData = this.createBrowseAdoptablePetsAdminDefault();
        this.createAdoptablePetState = 'idle';
        this.createAdoptablePetName = '';
        this.createAdoptablePetAge = '';
        this.createAdoptablePetDescription = '';
        this.createAdoptablePetPhotoUrl = '';
        this.createAdoptablePetOutput = null;
        this.createAdoptablePetError = '';
        this.updateAdoptablePetState = 'idle';
        this.updateAdoptablePetAdoptablePetId = '';
        this.updateAdoptablePetName = '';
        this.updateAdoptablePetAge = '';
        this.updateAdoptablePetDescription = '';
        this.updateAdoptablePetPhotoUrl = '';
        this.updateAdoptablePetStatus = '';
        this.updateAdoptablePetOutput = null;
        this.updateAdoptablePetError = '';
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.petManagement.status') ?? '';
        this.browseAdoptablePetsAdminState = getState('ui.petManagement.action.browseAdoptablePetsAdmin.status') ?? 'idle';
        this.browseAdoptablePetsAdminStatusFilter = getState('ui.petManagement.input.browseAdoptablePetsAdmin.statusFilter') ?? '';
        const browseData = getState('ui.petManagement.data.browseAdoptablePetsAdmin');
        this.browseAdoptablePetsAdminData = browseData ?? this.createBrowseAdoptablePetsAdminDefault();
        this.createAdoptablePetState = getState('ui.petManagement.action.createAdoptablePet.status') ?? 'idle';
        this.createAdoptablePetName = getState('ui.petManagement.input.createAdoptablePet.name') ?? '';
        this.createAdoptablePetAge = getState('ui.petManagement.input.createAdoptablePet.age') ?? '';
        this.createAdoptablePetDescription = getState('ui.petManagement.input.createAdoptablePet.description') ?? '';
        this.createAdoptablePetPhotoUrl = getState('ui.petManagement.input.createAdoptablePet.photoUrl') ?? '';
        this.createAdoptablePetOutput = getState('ui.petManagement.output.createAdoptablePet') ?? null;
        this.createAdoptablePetError = getState('ui.petManagement.action.createAdoptablePet.error') ?? '';
        this.updateAdoptablePetState = getState('ui.petManagement.action.updateAdoptablePet.status') ?? 'idle';
        this.updateAdoptablePetAdoptablePetId = getState('ui.petManagement.input.updateAdoptablePet.adoptablePetId') ?? '';
        this.updateAdoptablePetName = getState('ui.petManagement.input.updateAdoptablePet.name') ?? '';
        this.updateAdoptablePetAge = getState('ui.petManagement.input.updateAdoptablePet.age') ?? '';
        this.updateAdoptablePetDescription = getState('ui.petManagement.input.updateAdoptablePet.description') ?? '';
        this.updateAdoptablePetPhotoUrl = getState('ui.petManagement.input.updateAdoptablePet.photoUrl') ?? '';
        this.updateAdoptablePetStatus = getState('ui.petManagement.input.updateAdoptablePet.status') ?? '';
        this.updateAdoptablePetOutput = getState('ui.petManagement.output.updateAdoptablePet') ?? null;
        this.updateAdoptablePetError = getState('ui.petManagement.action.updateAdoptablePet.error') ?? '';
        subscribe([
            'ui.petManagement.status',
            'ui.petManagement.action.browseAdoptablePetsAdmin.status',
            'ui.petManagement.input.browseAdoptablePetsAdmin.statusFilter',
            'ui.petManagement.data.browseAdoptablePetsAdmin',
            'ui.petManagement.action.createAdoptablePet.status',
            'ui.petManagement.input.createAdoptablePet.name',
            'ui.petManagement.input.createAdoptablePet.age',
            'ui.petManagement.input.createAdoptablePet.description',
            'ui.petManagement.input.createAdoptablePet.photoUrl',
            'ui.petManagement.output.createAdoptablePet',
            'ui.petManagement.action.createAdoptablePet.error',
            'ui.petManagement.action.updateAdoptablePet.status',
            'ui.petManagement.input.updateAdoptablePet.adoptablePetId',
            'ui.petManagement.input.updateAdoptablePet.name',
            'ui.petManagement.input.updateAdoptablePet.age',
            'ui.petManagement.input.updateAdoptablePet.description',
            'ui.petManagement.input.updateAdoptablePet.photoUrl',
            'ui.petManagement.input.updateAdoptablePet.status',
            'ui.petManagement.output.updateAdoptablePet',
            'ui.petManagement.action.updateAdoptablePet.error',
        ], this);
        void this.loadBrowseAdoptablePetsAdmin();
    }
    disconnectedCallback() {
        unsubscribe([
            'ui.petManagement.status',
            'ui.petManagement.action.browseAdoptablePetsAdmin.status',
            'ui.petManagement.input.browseAdoptablePetsAdmin.statusFilter',
            'ui.petManagement.data.browseAdoptablePetsAdmin',
            'ui.petManagement.action.createAdoptablePet.status',
            'ui.petManagement.input.createAdoptablePet.name',
            'ui.petManagement.input.createAdoptablePet.age',
            'ui.petManagement.input.createAdoptablePet.description',
            'ui.petManagement.input.createAdoptablePet.photoUrl',
            'ui.petManagement.output.createAdoptablePet',
            'ui.petManagement.action.createAdoptablePet.error',
            'ui.petManagement.action.updateAdoptablePet.status',
            'ui.petManagement.input.updateAdoptablePet.adoptablePetId',
            'ui.petManagement.input.updateAdoptablePet.name',
            'ui.petManagement.input.updateAdoptablePet.age',
            'ui.petManagement.input.updateAdoptablePet.description',
            'ui.petManagement.input.updateAdoptablePet.photoUrl',
            'ui.petManagement.input.updateAdoptablePet.status',
            'ui.petManagement.output.updateAdoptablePet',
            'ui.petManagement.action.updateAdoptablePet.error',
        ], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(stateKey, value) {
        switch (stateKey) {
            case 'ui.petManagement.status':
                this.status = value;
                break;
            case 'ui.petManagement.action.browseAdoptablePetsAdmin.status':
                this.browseAdoptablePetsAdminState = value;
                break;
            case 'ui.petManagement.input.browseAdoptablePetsAdmin.statusFilter':
                this.browseAdoptablePetsAdminStatusFilter = value;
                break;
            case 'ui.petManagement.data.browseAdoptablePetsAdmin':
                this.browseAdoptablePetsAdminData = value ?? this.createBrowseAdoptablePetsAdminDefault();
                break;
            case 'ui.petManagement.action.createAdoptablePet.status':
                this.createAdoptablePetState = value;
                break;
            case 'ui.petManagement.input.createAdoptablePet.name':
                this.createAdoptablePetName = value;
                break;
            case 'ui.petManagement.input.createAdoptablePet.age':
                this.createAdoptablePetAge = value;
                break;
            case 'ui.petManagement.input.createAdoptablePet.description':
                this.createAdoptablePetDescription = value;
                break;
            case 'ui.petManagement.input.createAdoptablePet.photoUrl':
                this.createAdoptablePetPhotoUrl = value;
                break;
            case 'ui.petManagement.output.createAdoptablePet':
                this.createAdoptablePetOutput = value;
                break;
            case 'ui.petManagement.action.createAdoptablePet.error':
                this.createAdoptablePetError = value;
                break;
            case 'ui.petManagement.action.updateAdoptablePet.status':
                this.updateAdoptablePetState = value;
                break;
            case 'ui.petManagement.input.updateAdoptablePet.adoptablePetId':
                this.updateAdoptablePetAdoptablePetId = value;
                break;
            case 'ui.petManagement.input.updateAdoptablePet.name':
                this.updateAdoptablePetName = value;
                break;
            case 'ui.petManagement.input.updateAdoptablePet.age':
                this.updateAdoptablePetAge = value;
                break;
            case 'ui.petManagement.input.updateAdoptablePet.description':
                this.updateAdoptablePetDescription = value;
                break;
            case 'ui.petManagement.input.updateAdoptablePet.photoUrl':
                this.updateAdoptablePetPhotoUrl = value;
                break;
            case 'ui.petManagement.input.updateAdoptablePet.status':
                this.updateAdoptablePetStatus = value;
                break;
            case 'ui.petManagement.output.updateAdoptablePet':
                this.updateAdoptablePetOutput = value;
                break;
            case 'ui.petManagement.action.updateAdoptablePet.error':
                this.updateAdoptablePetError = value;
                break;
            default:
                return;
        }
        this.requestUpdate();
    }
    setBrowseAdoptablePetsAdminStatusFilter(value) {
        this.browseAdoptablePetsAdminStatusFilter = value;
        setState('ui.petManagement.input.browseAdoptablePetsAdmin.statusFilter', value);
        this.requestUpdate();
    }
    handleBrowseAdoptablePetsAdminStatusFilterChange(event) {
        const value = this.readTextValue(event);
        this.setBrowseAdoptablePetsAdminStatusFilter(value);
    }
    setCreateAdoptablePetName(value) {
        this.createAdoptablePetName = value;
        setState('ui.petManagement.input.createAdoptablePet.name', value);
        this.requestUpdate();
    }
    handleCreateAdoptablePetNameChange(event) {
        const value = this.readTextValue(event);
        this.setCreateAdoptablePetName(value);
    }
    setCreateAdoptablePetAge(value) {
        this.createAdoptablePetAge = value;
        setState('ui.petManagement.input.createAdoptablePet.age', value);
        this.requestUpdate();
    }
    handleCreateAdoptablePetAgeChange(event) {
        const value = this.readNumberValue(event);
        this.setCreateAdoptablePetAge(value);
    }
    setCreateAdoptablePetDescription(value) {
        this.createAdoptablePetDescription = value;
        setState('ui.petManagement.input.createAdoptablePet.description', value);
        this.requestUpdate();
    }
    handleCreateAdoptablePetDescriptionChange(event) {
        const value = this.readTextValue(event);
        this.setCreateAdoptablePetDescription(value);
    }
    setCreateAdoptablePetPhotoUrl(value) {
        this.createAdoptablePetPhotoUrl = value;
        setState('ui.petManagement.input.createAdoptablePet.photoUrl', value);
        this.requestUpdate();
    }
    handleCreateAdoptablePetPhotoUrlChange(event) {
        const value = this.readTextValue(event);
        this.setCreateAdoptablePetPhotoUrl(value);
    }
    setUpdateAdoptablePetAdoptablePetId(value) {
        this.updateAdoptablePetAdoptablePetId = value;
        setState('ui.petManagement.input.updateAdoptablePet.adoptablePetId', value);
        this.requestUpdate();
    }
    handleUpdateAdoptablePetAdoptablePetIdChange(event) {
        const value = this.readTextValue(event);
        this.setUpdateAdoptablePetAdoptablePetId(value);
    }
    setUpdateAdoptablePetName(value) {
        this.updateAdoptablePetName = value;
        setState('ui.petManagement.input.updateAdoptablePet.name', value);
        this.requestUpdate();
    }
    handleUpdateAdoptablePetNameChange(event) {
        const value = this.readTextValue(event);
        this.setUpdateAdoptablePetName(value);
    }
    setUpdateAdoptablePetAge(value) {
        this.updateAdoptablePetAge = value;
        setState('ui.petManagement.input.updateAdoptablePet.age', value);
        this.requestUpdate();
    }
    handleUpdateAdoptablePetAgeChange(event) {
        const value = this.readNumberValue(event);
        this.setUpdateAdoptablePetAge(value);
    }
    setUpdateAdoptablePetDescription(value) {
        this.updateAdoptablePetDescription = value;
        setState('ui.petManagement.input.updateAdoptablePet.description', value);
        this.requestUpdate();
    }
    handleUpdateAdoptablePetDescriptionChange(event) {
        const value = this.readTextValue(event);
        this.setUpdateAdoptablePetDescription(value);
    }
    setUpdateAdoptablePetPhotoUrl(value) {
        this.updateAdoptablePetPhotoUrl = value;
        setState('ui.petManagement.input.updateAdoptablePet.photoUrl', value);
        this.requestUpdate();
    }
    handleUpdateAdoptablePetPhotoUrlChange(event) {
        const value = this.readTextValue(event);
        this.setUpdateAdoptablePetPhotoUrl(value);
    }
    setUpdateAdoptablePetStatus(value) {
        this.updateAdoptablePetStatus = value;
        setState('ui.petManagement.input.updateAdoptablePet.status', value);
        this.requestUpdate();
    }
    handleUpdateAdoptablePetStatusChange(event) {
        const value = this.readTextValue(event);
        this.setUpdateAdoptablePetStatus(value);
    }
    async loadBrowseAdoptablePetsAdmin(signal) {
        this.browseAdoptablePetsAdminState = 'loading';
        setState('ui.petManagement.action.browseAdoptablePetsAdmin.status', 'loading');
        const params = {};
        if (this.browseAdoptablePetsAdminStatusFilter) {
            params.statusFilter = this.browseAdoptablePetsAdminStatusFilter;
        }
        const options = { mode: 'silent', signal };
        const response = await execBff('petShop.browseAdoptablePetsAdmin.browseAdoptablePetsAdmin', params, options);
        if (response.ok) {
            const data = response.data ?? this.createBrowseAdoptablePetsAdminDefault();
            this.browseAdoptablePetsAdminData = data;
            setState('ui.petManagement.data.browseAdoptablePetsAdmin', data);
            this.browseAdoptablePetsAdminState = 'success';
            setState('ui.petManagement.action.browseAdoptablePetsAdmin.status', 'success');
            return true;
        }
        console.error(response.error);
        this.browseAdoptablePetsAdminState = 'error';
        setState('ui.petManagement.action.browseAdoptablePetsAdmin.status', 'error');
        return false;
    }
    handleBrowseAdoptablePetsAdminClick() {
        void this.loadBrowseAdoptablePetsAdmin();
    }
    async createAdoptablePet(signal) {
        this.createAdoptablePetState = 'loading';
        setState('ui.petManagement.action.createAdoptablePet.status', 'loading');
        const ageValue = this.createAdoptablePetAge;
        let age = typeof ageValue === 'number' ? ageValue : Number(ageValue || 0);
        if (!Number.isFinite(age)) {
            age = 0;
        }
        const params = {
            name: this.createAdoptablePetName,
            age,
            description: this.createAdoptablePetDescription,
            photoUrl: this.createAdoptablePetPhotoUrl,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('petShop.createAdoptablePet.createAdoptablePet', params, options);
        if (!response.ok) {
            const message = response.error?.message ?? this.msg['action.createAdoptablePet.error'];
            this.createAdoptablePetError = message;
            setState('ui.petManagement.action.createAdoptablePet.error', message);
            this.createAdoptablePetState = 'error';
            setState('ui.petManagement.action.createAdoptablePet.status', 'error');
            return false;
        }
        const data = response.data ?? null;
        this.createAdoptablePetOutput = data;
        setState('ui.petManagement.output.createAdoptablePet', data);
        const refreshed = await this.loadBrowseAdoptablePetsAdmin(signal);
        if (!refreshed) {
            const message = this.msg['action.createAdoptablePet.error'];
            this.createAdoptablePetError = message;
            setState('ui.petManagement.action.createAdoptablePet.error', message);
            this.createAdoptablePetState = 'error';
            setState('ui.petManagement.action.createAdoptablePet.status', 'error');
            return false;
        }
        this.setCreateAdoptablePetName('');
        this.setCreateAdoptablePetAge('');
        this.setCreateAdoptablePetDescription('');
        this.setCreateAdoptablePetPhotoUrl('');
        this.createAdoptablePetError = '';
        setState('ui.petManagement.action.createAdoptablePet.error', '');
        this.createAdoptablePetState = 'success';
        setState('ui.petManagement.action.createAdoptablePet.status', 'success');
        return true;
    }
    handleCreateAdoptablePetClick() {
        void runBlockingUiAction((signal) => this.createAdoptablePet(signal));
    }
    async updateAdoptablePet(signal) {
        this.updateAdoptablePetState = 'loading';
        setState('ui.petManagement.action.updateAdoptablePet.status', 'loading');
        const ageValue = this.updateAdoptablePetAge;
        let age = typeof ageValue === 'number' ? ageValue : Number(ageValue || 0);
        if (!Number.isFinite(age)) {
            age = 0;
        }
        const params = {
            adoptablePetId: this.updateAdoptablePetAdoptablePetId,
            name: this.updateAdoptablePetName,
            age,
            description: this.updateAdoptablePetDescription,
            photoUrl: this.updateAdoptablePetPhotoUrl,
            status: this.updateAdoptablePetStatus,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('petShop.updateAdoptablePet.updateAdoptablePet', params, options);
        if (!response.ok) {
            const message = response.error?.message ?? this.msg['action.updateAdoptablePet.error'];
            this.updateAdoptablePetError = message;
            setState('ui.petManagement.action.updateAdoptablePet.error', message);
            this.updateAdoptablePetState = 'error';
            setState('ui.petManagement.action.updateAdoptablePet.status', 'error');
            return false;
        }
        const data = response.data ?? null;
        this.updateAdoptablePetOutput = data;
        setState('ui.petManagement.output.updateAdoptablePet', data);
        const refreshed = await this.loadBrowseAdoptablePetsAdmin(signal);
        if (!refreshed) {
            const message = this.msg['action.updateAdoptablePet.error'];
            this.updateAdoptablePetError = message;
            setState('ui.petManagement.action.updateAdoptablePet.error', message);
            this.updateAdoptablePetState = 'error';
            setState('ui.petManagement.action.updateAdoptablePet.status', 'error');
            return false;
        }
        this.setUpdateAdoptablePetAdoptablePetId('');
        this.setUpdateAdoptablePetName('');
        this.setUpdateAdoptablePetAge('');
        this.setUpdateAdoptablePetDescription('');
        this.setUpdateAdoptablePetPhotoUrl('');
        this.setUpdateAdoptablePetStatus('');
        this.updateAdoptablePetError = '';
        setState('ui.petManagement.action.updateAdoptablePet.error', '');
        this.updateAdoptablePetState = 'success';
        setState('ui.petManagement.action.updateAdoptablePet.status', 'success');
        return true;
    }
    handleUpdateAdoptablePetClick() {
        void runBlockingUiAction((signal) => this.updateAdoptablePet(signal));
    }
    readTextValue(event) {
        const target = event.target;
        return target?.value ?? '';
    }
    readNumberValue(event) {
        const raw = this.readTextValue(event);
        if (!raw) {
            return '';
        }
        const parsed = Number(raw);
        return Number.isFinite(parsed) ? parsed : '';
    }
    createBrowseAdoptablePetsAdminDefault() {
        return { items: [], total: 0 };
    }
}
__decorate([
    property()
], PetShopPetManagementBase.prototype, "status", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "browseAdoptablePetsAdminState", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "browseAdoptablePetsAdminStatusFilter", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "browseAdoptablePetsAdminData", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "createAdoptablePetState", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "createAdoptablePetName", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "createAdoptablePetAge", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "createAdoptablePetDescription", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "createAdoptablePetPhotoUrl", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "createAdoptablePetOutput", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "createAdoptablePetError", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "updateAdoptablePetState", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "updateAdoptablePetAdoptablePetId", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "updateAdoptablePetName", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "updateAdoptablePetAge", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "updateAdoptablePetDescription", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "updateAdoptablePetPhotoUrl", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "updateAdoptablePetStatus", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "updateAdoptablePetOutput", void 0);
__decorate([
    property()
], PetShopPetManagementBase.prototype, "updateAdoptablePetError", void 0);

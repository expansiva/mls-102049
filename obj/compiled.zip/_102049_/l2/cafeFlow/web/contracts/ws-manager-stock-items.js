/// <mls fileReference="_102049_/l2/cafeFlow/web/contracts/ws-manager-stock-items.ts" enhancement="_blank"/>
export {};

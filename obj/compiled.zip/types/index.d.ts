declare module "_102049_/l2/designSystem" {
    import { IDesignSystemTokens } from '_102029_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102049_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102049_/l2/petShop/web/contracts/adoptionGallery.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "adoptionGallery__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/adoptionGallery.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/adoptionGallery.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/adoptionGallery" {
    export interface PetShopBrowseAdoptablePetsInput {
    }
    export interface PetShopBrowseAdoptablePetsOutputItem {
        adoptablePetId: string;
        name: string;
        age: number;
        description: string;
        photoUrl: string;
    }
    export interface PetShopBrowseAdoptablePetsOutput {
        items: PetShopBrowseAdoptablePetsOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopViewAdoptablePetDetailsInput {
        adoptablePetId: string;
    }
    export interface PetShopViewAdoptablePetDetailsOutputItem {
        name: string;
        age: number;
        description: string;
        photoUrl: string;
        status: "available" | "unavailable";
    }
    export type PetShopViewAdoptablePetDetailsOutput = PetShopViewAdoptablePetDetailsOutputItem;
    export interface PetShopExpressAdoptionInterestInput {
        adoptablePetId: string;
        customerName: string;
        customerEmail: string;
        customerPhone?: string;
    }
    export interface PetShopExpressAdoptionInterestOutput {
        adoptionInterestId: string;
        status: "registered" | "completed" | "cancelled";
        adoptablePetId: string;
        customerName: string;
        createdAt: string;
    }
}
declare module "_102049_/l2/petShop/web/contracts/adoptionGallery.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/homePage.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: any[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "homePage__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/homePage.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/homePage.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/homePage" {
    export interface PetShopBrowseHomePageInput {
    }
    export interface PetShopBrowseHomePageOutputItem {
        productId: string;
        name: string;
        description: string;
        price: number;
        imageUrl: string;
        productCategoryId: string;
        featured: boolean;
        status: "active" | "inactive";
    }
    export interface PetShopBrowseHomePageOutput {
        items: PetShopBrowseHomePageOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
}
declare module "_102049_/l2/petShop/web/contracts/homePage.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/operatorManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "operatorManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/operatorManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/operatorManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/operatorManagement" {
    export interface PetShopBrowseOperatorsInput {
        activeFilter?: boolean;
    }
    export interface PetShopBrowseOperatorsOutputItem {
        operatorId: string;
        name: string;
        email: string;
        phone: string;
        active: boolean;
        createdAt: string;
        updatedAt: string;
    }
    export interface PetShopBrowseOperatorsOutput {
        items: PetShopBrowseOperatorsOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopCreateOperatorInput {
        name: string;
        email?: string;
        phone?: string;
        active: boolean;
    }
    export interface PetShopCreateOperatorOutput {
        operatorId: string;
        name: string;
        email: string;
        phone: string;
        active: boolean;
        createdAt: string;
    }
    export interface PetShopUpdateOperatorInput {
        operatorId: string;
        name: string;
        email?: string;
        phone?: string;
        active: boolean;
    }
    export interface PetShopUpdateOperatorOutput {
        operatorId: string;
        name: string;
        email: string;
        phone: string;
        active: boolean;
        updatedAt: string;
    }
}
declare module "_102049_/l2/petShop/web/contracts/operatorManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/operatorSchedule.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "operatorSchedule__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/operatorSchedule.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/operatorSchedule.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/operatorSchedule" {
    export interface PetShopViewOperatorScheduleInput {
    }
    export interface PetShopViewOperatorScheduleOutputItem {
        serviceBookingId: string;
        serviceId: string;
        customerName: string;
        customerPhone: string;
        bookingDate: string;
        bookingTime: string;
        status: "confirmed" | "inProgress" | "completed" | "cancelled";
        notes: string;
    }
    export interface PetShopViewOperatorScheduleOutput {
        items: PetShopViewOperatorScheduleOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopViewServiceBookingDetailsInput {
        serviceBookingId: string;
    }
    export interface PetShopViewServiceBookingDetailsOutputItem {
        serviceBookingId: string;
        serviceId: string;
        operatorId: string;
        shiftId: string;
        customerName: string;
        customerPhone: string;
        bookingDate: string;
        bookingTime: string;
        status: "confirmed" | "inProgress" | "completed" | "cancelled";
        notes: string;
        completedAt: string;
        cancelledAt: string;
        cancelReason: string;
        createdAt: string;
        updatedAt: string;
    }
    export type PetShopViewServiceBookingDetailsOutput = PetShopViewServiceBookingDetailsOutputItem;
}
declare module "_102049_/l2/petShop/web/contracts/operatorSchedule.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/petManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
            source: string;
            presentation: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "petManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/petManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/petManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/petManagement" {
    export interface PetShopBrowseAdoptablePetsAdminInput {
        statusFilter?: "available" | "unavailable";
    }
    export interface PetShopBrowseAdoptablePetsAdminOutputItem {
        adoptablePetId: string;
        name: string;
        age: number;
        description: string;
        photoUrl: string;
        status: "available" | "unavailable";
        createdAt: string;
        updatedAt: string;
    }
    export interface PetShopBrowseAdoptablePetsAdminOutput {
        items: PetShopBrowseAdoptablePetsAdminOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopCreateAdoptablePetInput {
        name: string;
        age: number;
        description: string;
        photoUrl: string;
    }
    export interface PetShopCreateAdoptablePetOutput {
        adoptablePetId: string;
        name: string;
        age: number;
        description: string;
        photoUrl: string;
        status: "available" | "unavailable";
        createdAt: string;
    }
    export interface PetShopUpdateAdoptablePetInput {
        adoptablePetId: string;
        name: string;
        age: number;
        description: string;
        photoUrl: string;
        status: "available" | "unavailable";
    }
    export interface PetShopUpdateAdoptablePetOutput {
        adoptablePetId: string;
        name: string;
        age: number;
        description: string;
        photoUrl: string;
        status: "available" | "unavailable";
        updatedAt: string;
    }
}
declare module "_102049_/l2/petShop/web/contracts/petManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/productCatalog.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "productCatalog__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/productCatalog.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/productCatalog.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/productCatalog" {
    export interface PetShopBrowseProductCatalogInput {
        searchName?: string;
        productCategoryId?: string;
    }
    export interface PetShopBrowseProductCatalogOutputItem {
        productId: string;
        name: string;
        description: string;
        price: number;
        imageUrl: string;
        productCategoryId: string;
        featured: boolean;
    }
    export interface PetShopBrowseProductCatalogOutput {
        items: PetShopBrowseProductCatalogOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopViewProductDetailsInput {
        productId: string;
    }
    export interface PetShopViewProductDetailsOutputItem {
        productId: string;
        name: string;
        description: string;
        price: number;
        imageUrl: string;
        productCategoryId: string;
        featured: boolean;
        status: "active" | "inactive";
    }
    export type PetShopViewProductDetailsOutput = PetShopViewProductDetailsOutputItem;
    export interface PetShopPlaceStorePickupOrderInput {
        customerName: string;
        customerPhone?: string;
    }
    export interface PetShopPlaceStorePickupOrderOutput {
        orderId: string;
        status: "registered" | "completed" | "cancelled";
        customerName: string;
        customerPhone: string;
        createdAt: string;
    }
}
declare module "_102049_/l2/petShop/web/contracts/productCatalog.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/productManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
            source: string;
            presentation: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "productManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/productManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/productManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/productManagement" {
    export interface PetShopBrowseProductsInput {
        searchName?: string;
        filterStatus?: "active" | "inactive";
        filterProductCategoryId?: string;
        filterFeatured?: boolean;
    }
    export interface PetShopBrowseProductsOutputItem {
        productId: string;
        name: string;
        price: number;
        imageUrl: string;
        productCategoryId: string;
        featured: boolean;
        status: "active" | "inactive";
        createdAt: string;
        updatedAt: string;
    }
    export interface PetShopBrowseProductsOutput {
        items: PetShopBrowseProductsOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopCreateProductInput {
        name: string;
        description?: string;
        price: number;
        imageUrl?: string;
        productCategoryId: string;
        featured: boolean;
    }
    export interface PetShopCreateProductOutput {
        productId: string;
        name: string;
        price: number;
        productCategoryId: string;
        featured: boolean;
        status: "active" | "inactive";
        createdAt: string;
    }
    export interface PetShopUpdateProductInput {
        productId: string;
        name: string;
        description?: string;
        price: number;
        imageUrl?: string;
        productCategoryId: string;
        featured: boolean;
        status: "active" | "inactive";
    }
    export interface PetShopUpdateProductOutput {
        productId: string;
        name: string;
        description: string;
        price: number;
        imageUrl: string;
        productCategoryId: string;
        featured: boolean;
        status: "active" | "inactive";
        updatedAt: string;
    }
}
declare module "_102049_/l2/petShop/web/contracts/productManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/schedulingCapacity.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "schedulingCapacity__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/schedulingCapacity.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/schedulingCapacity.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/schedulingCapacity" {
    export interface PetShopAssignOperatorToShiftInput {
        operatorId: string;
        shiftId: string;
    }
    export interface PetShopAssignOperatorToShiftOutput {
        shiftAssignmentId: string;
        operatorId: string;
        shiftId: string;
        createdAt: string;
    }
    export interface PetShopReviewSchedulingCapacityInput {
        shiftId?: string;
    }
    export interface PetShopReviewSchedulingCapacityOutputItem {
        shiftAssignmentId: string;
        operatorId: string;
        shiftId: string;
        createdAt: string;
        startTime: string;
        endTime: string;
        name: string;
    }
    export interface PetShopReviewSchedulingCapacityOutput {
        items: PetShopReviewSchedulingCapacityOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
}
declare module "_102049_/l2/petShop/web/contracts/schedulingCapacity.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/serviceBooking.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "serviceBooking__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/serviceBooking.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/serviceBooking.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/serviceBooking" {
    export interface PetShopBrowseServiceCatalogInput {
    }
    export interface PetShopBrowseServiceCatalogOutputItem {
        serviceId: string;
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
    }
    export interface PetShopBrowseServiceCatalogOutput {
        items: PetShopBrowseServiceCatalogOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopCreateServiceBookingInput {
        serviceId: string;
        customerName: string;
        customerPhone: string;
        bookingDate: string;
        bookingTime: string;
        notes?: string;
    }
    export interface PetShopCreateServiceBookingOutput {
        serviceBookingId: string;
        serviceId: string;
        operatorId: string;
        shiftId: string;
        bookingDate: string;
        bookingTime: string;
        status: "confirmed" | "inProgress" | "completed" | "cancelled";
        customerName: string;
    }
}
declare module "_102049_/l2/petShop/web/contracts/serviceBooking.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/serviceExecution.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "serviceExecution__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/serviceExecution.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/serviceExecution.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/serviceExecution" {
    export interface PetShopStartServiceExecutionInput {
        serviceBookingId: string;
    }
    export interface PetShopStartServiceExecutionOutput {
        serviceBookingId: string;
        status: "confirmed" | "inProgress" | "completed" | "cancelled";
        updatedAt: string;
    }
    export interface PetShopCompleteServiceExecutionInput {
        serviceBookingId: string;
    }
    export interface PetShopCompleteServiceExecutionOutput {
        serviceBookingId: string;
        status: "confirmed" | "inProgress" | "completed" | "cancelled";
        completedAt: string;
    }
}
declare module "_102049_/l2/petShop/web/contracts/serviceExecution.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/serviceManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
            source: string;
            presentation: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "serviceManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/serviceManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/serviceManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/serviceManagement" {
    export interface PetShopBrowseServicesInput {
        statusFilter?: "active" | "inactive";
    }
    export interface PetShopBrowseServicesOutputItem {
        serviceId: string;
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
        status: "active" | "inactive";
        deactivatedAt: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface PetShopBrowseServicesOutput {
        items: PetShopBrowseServicesOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopCreateServiceInput {
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
    }
    export interface PetShopCreateServiceOutput {
        serviceId: string;
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
        status: "active" | "inactive";
        createdAt: string;
    }
    export interface PetShopUpdateServiceInput {
        serviceId: string;
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
        status: "active" | "inactive";
    }
    export interface PetShopUpdateServiceOutput {
        serviceId: string;
        name: string;
        description: string;
        estimatedDurationMinutes: number;
        price: number;
        status: "active" | "inactive";
        deactivatedAt: string;
        updatedAt: string;
    }
}
declare module "_102049_/l2/petShop/web/contracts/serviceManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/shiftManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: {
            name: string;
            type: string;
            description: string;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "shiftManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/shiftManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/shiftManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/shiftManagement" {
    export interface PetShopBrowseShiftsInput {
        activeFilter?: boolean;
    }
    export interface PetShopBrowseShiftsOutputItem {
        shiftId: string;
        name: string;
        startTime: string;
        endTime: string;
        monday: boolean;
        tuesday: boolean;
        wednesday: boolean;
        thursday: boolean;
        friday: boolean;
        saturday: boolean;
        sunday: boolean;
        active: boolean;
        createdAt: string;
        updatedAt: string;
    }
    export interface PetShopBrowseShiftsOutput {
        items: PetShopBrowseShiftsOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface PetShopCreateShiftInput {
        name: string;
        startTime: string;
        endTime: string;
        monday: boolean;
        tuesday: boolean;
        wednesday: boolean;
        thursday: boolean;
        friday: boolean;
        saturday: boolean;
        sunday: boolean;
        active: boolean;
    }
    export interface PetShopCreateShiftOutput {
        shiftId: string;
        name: string;
        startTime: string;
        endTime: string;
        monday: boolean;
        tuesday: boolean;
        wednesday: boolean;
        thursday: boolean;
        friday: boolean;
        saturday: boolean;
        sunday: boolean;
        active: boolean;
        createdAt: string;
    }
    export interface PetShopUpdateShiftInput {
        shiftId: string;
        name: string;
        startTime: string;
        endTime: string;
        monday: boolean;
        tuesday: boolean;
        wednesday: boolean;
        thursday: boolean;
        friday: boolean;
        saturday: boolean;
        sunday: boolean;
        active: boolean;
    }
    export interface PetShopUpdateShiftOutput {
        shiftId: string;
        name: string;
        startTime: string;
        endTime: string;
        monday: boolean;
        tuesday: boolean;
        wednesday: boolean;
        thursday: boolean;
        friday: boolean;
        saturday: boolean;
        sunday: boolean;
        active: boolean;
    }
}
declare module "_102049_/l2/petShop/web/contracts/shiftManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/desktop/page11/adoptionGallery.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "adoptionGallery__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/adoptionGallery.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/adoptionGallery.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/adoptionGallery.defs.ts", "_102049_/l2/petShop/web/shared/adoptionGallery.ts", "_102049_/l2/petShop/web/contracts/adoptionGallery.defs.ts", "_102049_/l2/petShop/web/contracts/adoptionGallery.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["adoptionGallery__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/adoptionGallery" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseAdoptablePetsOutput, PetShopViewAdoptablePetDetailsOutput, PetShopExpressAdoptionInterestOutput } from "_102049_/l2/petShop/web/contracts/adoptionGallery";
    const message_pt: {
        "adoptionGallery.section.title": string;
        "adoptionGallery.browse.title": string;
        "adoptionGallery.browse.empty": string;
        "adoptionGallery.details.title": string;
        "adoptionGallery.details.empty": string;
        "adoptionGallery.interestForm.title": string;
        "adoptionGallery.interestForm.empty": string;
        "adoptionGallery.summary.title": string;
        "adoptionGallery.summary.empty": string;
        "adoptionGallery.field.photoUrl": string;
        "adoptionGallery.field.name": string;
        "adoptionGallery.field.age": string;
        "adoptionGallery.field.description": string;
        "adoptionGallery.field.status": string;
        "adoptionGallery.field.adoptablePetId": string;
        "adoptionGallery.field.customerName": string;
        "adoptionGallery.field.customerEmail": string;
        "adoptionGallery.field.customerPhone": string;
        "adoptionGallery.field.adoptionInterestId": string;
        "adoptionGallery.field.interestStatus": string;
        "adoptionGallery.field.createdAt": string;
        "adoptionGallery.action.viewDetails": string;
        "adoptionGallery.action.expressInterest": string;
        "adoptionGallery.action.submitInterest": string;
        "action.expressAdoptionInterest.success": string;
        "action.expressAdoptionInterest.error": string;
        "org.browse.adoptable.pets.title": string;
        "org.view.pet.details.title": string;
        "org.express.interest.title": string;
        "org.adoption.summary.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopAdoptionGalleryBase extends CollabLitElement {
        status: string;
        browseAdoptablePetsState: "idle" | "loading" | "success" | "error";
        browseAdoptablePetsData: PetShopBrowseAdoptablePetsOutput;
        viewAdoptablePetDetailsState: "idle" | "loading" | "success" | "error";
        viewAdoptablePetDetailsAdoptablePetId: string;
        viewAdoptablePetDetailsData: PetShopViewAdoptablePetDetailsOutput | null;
        expressAdoptionInterestState: "idle" | "loading" | "success" | "error";
        expressAdoptionInterestAdoptablePetId: string;
        expressAdoptionInterestCustomerName: string;
        expressAdoptionInterestCustomerEmail: string;
        expressAdoptionInterestCustomerPhone: string;
        expressAdoptionInterestOutput: PetShopExpressAdoptionInterestOutput | null;
        expressAdoptionInterestError: string;
        protected get msg(): MessageType;
        private parseRouteParam;
        loadBrowseAdoptablePets(): Promise<void>;
        handleBrowseAdoptablePetsClick(_e: Event): void;
        loadViewAdoptablePetDetails(): Promise<void>;
        handleViewAdoptablePetDetailsClick(_e: Event): void;
        expressAdoptionInterest(): Promise<void>;
        handleExpressAdoptionInterestClick(e: Event): void;
        setViewAdoptablePetDetailsAdoptablePetId(value: string): void;
        handleViewAdoptablePetDetailsAdoptablePetIdChange(e: Event): void;
        setExpressAdoptionInterestAdoptablePetId(value: string): void;
        handleExpressAdoptionInterestAdoptablePetIdChange(e: Event): void;
        setExpressAdoptionInterestCustomerName(value: string): void;
        handleExpressAdoptionInterestCustomerNameChange(e: Event): void;
        setExpressAdoptionInterestCustomerEmail(value: string): void;
        handleExpressAdoptionInterestCustomerEmailChange(e: Event): void;
        setExpressAdoptionInterestCustomerPhone(value: string): void;
        handleExpressAdoptionInterestCustomerPhoneChange(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/adoptionGallery" {
    import { PetShopAdoptionGalleryBase } from "_102049_/l2/petShop/web/shared/adoptionGallery";
    export class PetShopDesktopPage11AdoptionGalleryPage extends PetShopAdoptionGalleryBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/homePage.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            inputType?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                            inputType?: undefined;
                        })[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            source: string;
                            stateKey: string;
                            inputType?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            source: string;
                            stateKey: string;
                            inputType?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    })[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            inputType?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            inputType?: undefined;
                            stateKey?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                            inputType?: undefined;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: any[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "homePage__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/homePage.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/homePage.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/homePage.defs.ts", "_102049_/l2/petShop/web/shared/homePage.ts", "_102049_/l2/petShop/web/contracts/homePage.defs.ts", "_102049_/l2/petShop/web/contracts/homePage.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["homePage__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/homePage" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseHomePageOutput } from "_102049_/l2/petShop/web/contracts/homePage";
    const message_pt: {
        "homePage.title": string;
        "homePage.section.featuredProducts": string;
        "homePage.section.services": string;
        "homePage.section.adoptablePets": string;
        "homePage.productList.title": string;
        "homePage.productList.empty": string;
        "homePage.productDetail.title": string;
        "homePage.productDetail.empty": string;
        "homePage.productDetail.imageUrl": string;
        "homePage.productDetail.name": string;
        "homePage.productDetail.description": string;
        "homePage.productDetail.price": string;
        "homePage.product.productId": string;
        "homePage.product.name": string;
        "homePage.product.description": string;
        "homePage.product.price": string;
        "homePage.product.imageUrl": string;
        "homePage.product.featured": string;
        "homePage.product.status": string;
        "homePage.servicesList.title": string;
        "homePage.servicesList.empty": string;
        "homePage.service.serviceId": string;
        "homePage.service.name": string;
        "homePage.service.description": string;
        "homePage.service.estimatedDurationMinutes": string;
        "homePage.service.price": string;
        "homePage.service.status": string;
        "homePage.petsGallery.title": string;
        "homePage.petsGallery.empty": string;
        "homePage.pet.adoptablePetId": string;
        "homePage.pet.name": string;
        "homePage.pet.age": string;
        "homePage.pet.description": string;
        "homePage.pet.photoUrl": string;
        "homePage.pet.status": string;
        "homePage.action.browseHomePage": string;
        "homePage.action.browseHomePage.success": string;
        "homePage.action.browseHomePage.error": string;
        "org.featured.products.title": string;
        "org.services.title": string;
        "org.adoptable.pets.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopHomePageBase extends CollabLitElement {
        status: string;
        browseHomePageState: "idle" | "loading" | "success" | "error";
        browseHomePageData: PetShopBrowseHomePageOutput;
        protected get msg(): MessageType;
        loadBrowseHomePage(): Promise<void>;
        handleBrowseHomePageClick(_event: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/homePage" {
    import { PetShopHomePageBase } from "_102049_/l2/petShop/web/shared/homePage";
    export class PetShopDesktopPage11HomePagePage extends PetShopHomePageBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/operatorManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "operatorManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/operatorManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/operatorManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/operatorManagement.defs.ts", "_102049_/l2/petShop/web/shared/operatorManagement.ts", "_102049_/l2/petShop/web/contracts/operatorManagement.defs.ts", "_102049_/l2/petShop/web/contracts/operatorManagement.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["operatorManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/operatorManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseOperatorsOutput, PetShopCreateOperatorOutput, PetShopUpdateOperatorOutput } from "_102049_/l2/petShop/web/contracts/operatorManagement";
    const message_pt: {
        "operatorManagement.browse.title": string;
        "operatorManagement.browse.empty": string;
        "operatorManagement.create.title": string;
        "operatorManagement.create.empty": string;
        "operatorManagement.update.title": string;
        "operatorManagement.update.empty": string;
        "operatorManagement.field.name": string;
        "operatorManagement.field.email": string;
        "operatorManagement.field.phone": string;
        "operatorManagement.field.active": string;
        "operatorManagement.field.updatedAt": string;
        "operatorManagement.field.operatorId": string;
        "operatorManagement.filter.active": string;
        "operatorManagement.action.create": string;
        "operatorManagement.action.create.submit": string;
        "operatorManagement.action.update": string;
        "operatorManagement.action.update.submit": string;
        "action.createOperator.success": string;
        "action.createOperator.error": string;
        "action.updateOperator.success": string;
        "action.updateOperator.error": string;
        "sec.operator.management.title": string;
        "org.browse.operators.title": string;
        "org.create.operator.title": string;
        "org.update.operator.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopOperatorManagementBase extends CollabLitElement {
        status: string;
        browseOperatorsState: 'idle' | 'loading' | 'success' | 'error';
        browseOperatorsActiveFilter: string;
        browseOperatorsData: PetShopBrowseOperatorsOutput;
        createOperatorState: 'idle' | 'loading' | 'success' | 'error';
        createOperatorName: string;
        createOperatorEmail: string;
        createOperatorPhone: string;
        createOperatorActive: string;
        createOperatorOutput: PetShopCreateOperatorOutput | null;
        createOperatorError: string;
        updateOperatorState: 'idle' | 'loading' | 'success' | 'error';
        updateOperatorOperatorId: string;
        updateOperatorName: string;
        updateOperatorEmail: string;
        updateOperatorPhone: string;
        updateOperatorActive: string;
        updateOperatorOutput: PetShopUpdateOperatorOutput | null;
        updateOperatorError: string;
        protected get msg(): MessageType;
        private subscribedKeys;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private parseRouteParams;
        loadBrowseOperators(): Promise<void>;
        handleBrowseOperatorsClick(_e: Event): void;
        createOperator(): Promise<void>;
        handleCreateOperatorClick(e: Event): void;
        updateOperator(): Promise<void>;
        handleUpdateOperatorClick(e: Event): void;
        setBrowseOperatorsActiveFilter(value: string): void;
        handleBrowseOperatorsActiveFilterChange(e: Event): void;
        setCreateOperatorName(value: string): void;
        handleCreateOperatorNameChange(e: Event): void;
        setCreateOperatorEmail(value: string): void;
        handleCreateOperatorEmailChange(e: Event): void;
        setCreateOperatorPhone(value: string): void;
        handleCreateOperatorPhoneChange(e: Event): void;
        setCreateOperatorActive(value: string): void;
        handleCreateOperatorActiveChange(e: Event): void;
        setUpdateOperatorOperatorId(value: string): void;
        handleUpdateOperatorOperatorIdChange(e: Event): void;
        setUpdateOperatorName(value: string): void;
        handleUpdateOperatorNameChange(e: Event): void;
        setUpdateOperatorEmail(value: string): void;
        handleUpdateOperatorEmailChange(e: Event): void;
        setUpdateOperatorPhone(value: string): void;
        handleUpdateOperatorPhoneChange(e: Event): void;
        setUpdateOperatorActive(value: string): void;
        handleUpdateOperatorActiveChange(e: Event): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/operatorManagement" {
    import { PetShopOperatorManagementBase } from "_102049_/l2/petShop/web/shared/operatorManagement";
    export class PetShopDesktopPage11OperatorManagementPage extends PetShopOperatorManagementBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/operatorSchedule.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "operatorSchedule__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/operatorSchedule.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/operatorSchedule.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/operatorSchedule.defs.ts", "_102049_/l2/petShop/web/shared/operatorSchedule.ts", "_102049_/l2/petShop/web/contracts/operatorSchedule.defs.ts", "_102049_/l2/petShop/web/contracts/operatorSchedule.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["operatorSchedule__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/operatorSchedule" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopViewOperatorScheduleOutput, PetShopViewServiceBookingDetailsOutput } from "_102049_/l2/petShop/web/contracts/operatorSchedule";
    const message_pt: {
        "page.title": string;
        "section.schedule.title": string;
        "section.payment.title": string;
        "organism.metrics.title": string;
        "organism.metrics.empty": string;
        "metric.confirmed": string;
        "metric.inProgress": string;
        "metric.completed": string;
        "metric.total": string;
        "organism.list.title": string;
        "organism.list.empty": string;
        "organism.details.title": string;
        "organism.details.empty": string;
        "organism.payment.title": string;
        "organism.payment.empty": string;
        "column.customerName": string;
        "column.customerPhone": string;
        "column.bookingDate": string;
        "column.bookingTime": string;
        "column.status": string;
        "column.notes": string;
        "filter.status": string;
        "filter.bookingDate": string;
        "field.serviceBookingId": string;
        "field.serviceId": string;
        "field.customerName": string;
        "field.customerPhone": string;
        "field.bookingDate": string;
        "field.bookingTime": string;
        "field.status": string;
        "field.notes": string;
        "field.completedAt": string;
        "field.cancelledAt": string;
        "field.cancelReason": string;
        "field.createdAt": string;
        "field.updatedAt": string;
        "field.paymentInfo": string;
        "field.paymentMethod": string;
        "action.viewDetails": string;
        "action.viewOperatorSchedule.success": string;
        "action.viewOperatorSchedule.error": string;
        "action.viewServiceBookingDetails.success": string;
        "action.viewServiceBookingDetails.error": string;
        "scheduleMetrics.title": string;
        "scheduleList.title": string;
        "bookingDetails.title": string;
        "paymentContext.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopOperatorScheduleBase extends CollabLitElement {
        status: string;
        viewOperatorScheduleState: "idle" | "loading" | "success" | "error";
        viewOperatorScheduleData: PetShopViewOperatorScheduleOutput;
        viewServiceBookingDetailsState: "idle" | "loading" | "success" | "error";
        viewServiceBookingDetailsServiceBookingId: string;
        viewServiceBookingDetailsData: PetShopViewServiceBookingDetailsOutput | null;
        protected get msg(): MessageType;
        private parseRouteParams;
        loadViewOperatorSchedule(): Promise<void>;
        handleViewOperatorScheduleClick(): void;
        loadViewServiceBookingDetails(): Promise<void>;
        handleViewServiceBookingDetailsClick(): void;
        setViewServiceBookingDetailsServiceBookingId(value: string): void;
        handleViewServiceBookingDetailsServiceBookingIdChange(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/operatorSchedule" {
    import { type TemplateResult } from 'lit';
    import { PetShopOperatorScheduleBase } from "_102049_/l2/petShop/web/shared/operatorSchedule";
    export class PetShopDesktopPage11OperatorSchedulePage extends PetShopOperatorScheduleBase {
        render(): TemplateResult;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/petManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "petManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/petManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/petManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/petManagement.defs.ts", "_102049_/l2/petShop/web/shared/petManagement.ts", "_102049_/l2/petShop/web/contracts/petManagement.defs.ts", "_102049_/l2/petShop/web/contracts/petManagement.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["petManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/petManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseAdoptablePetsAdminOutput, PetShopCreateAdoptablePetOutput, PetShopUpdateAdoptablePetOutput } from "_102049_/l2/petShop/web/contracts/petManagement";
    const message_pt: {
        "petManagement.section.title": string;
        "petManagement.list.title": string;
        "petManagement.list.empty": string;
        "petManagement.create.title": string;
        "petManagement.create.empty": string;
        "petManagement.update.title": string;
        "petManagement.update.empty": string;
        "petManagement.summary.title": string;
        "petManagement.summary.sectionTitle": string;
        "petManagement.summary.empty": string;
        "petManagement.field.name": string;
        "petManagement.field.age": string;
        "petManagement.field.description": string;
        "petManagement.field.photoUrl": string;
        "petManagement.field.status": string;
        "petManagement.field.adoptablePetId": string;
        "petManagement.field.createdAt": string;
        "petManagement.field.updatedAt": string;
        "petManagement.filter.statusFilter": string;
        "petManagement.action.create": string;
        "petManagement.action.create.submit": string;
        "petManagement.action.update": string;
        "petManagement.action.update.submit": string;
        "action.createAdoptablePet.success": string;
        "action.createAdoptablePet.error": string;
        "action.updateAdoptablePet.success": string;
        "action.updateAdoptablePet.error": string;
        "org.browse.pets.title": string;
        "org.create.pet.title": string;
        "org.update.pet.title": string;
        "org.pet.summary.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopPetManagementBase extends CollabLitElement {
        status: string;
        browseAdoptablePetsAdminState: 'idle' | 'loading' | 'success' | 'error';
        browseAdoptablePetsAdminStatusFilter: "available" | "unavailable" | '';
        browseAdoptablePetsAdminData: PetShopBrowseAdoptablePetsAdminOutput;
        createAdoptablePetState: 'idle' | 'loading' | 'success' | 'error';
        createAdoptablePetName: string;
        createAdoptablePetAge: number | '';
        createAdoptablePetDescription: string;
        createAdoptablePetPhotoUrl: string;
        createAdoptablePetOutput: PetShopCreateAdoptablePetOutput | null;
        createAdoptablePetError: string;
        updateAdoptablePetState: 'idle' | 'loading' | 'success' | 'error';
        updateAdoptablePetAdoptablePetId: string;
        updateAdoptablePetName: string;
        updateAdoptablePetAge: number | '';
        updateAdoptablePetDescription: string;
        updateAdoptablePetPhotoUrl: string;
        updateAdoptablePetStatus: "available" | "unavailable" | '';
        updateAdoptablePetOutput: PetShopUpdateAdoptablePetOutput | null;
        updateAdoptablePetError: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(stateKey: string, value: unknown): void;
        setBrowseAdoptablePetsAdminStatusFilter(value: "available" | "unavailable" | ''): void;
        handleBrowseAdoptablePetsAdminStatusFilterChange(event: Event): void;
        setCreateAdoptablePetName(value: string): void;
        handleCreateAdoptablePetNameChange(event: Event): void;
        setCreateAdoptablePetAge(value: number | ''): void;
        handleCreateAdoptablePetAgeChange(event: Event): void;
        setCreateAdoptablePetDescription(value: string): void;
        handleCreateAdoptablePetDescriptionChange(event: Event): void;
        setCreateAdoptablePetPhotoUrl(value: string): void;
        handleCreateAdoptablePetPhotoUrlChange(event: Event): void;
        setUpdateAdoptablePetAdoptablePetId(value: string): void;
        handleUpdateAdoptablePetAdoptablePetIdChange(event: Event): void;
        setUpdateAdoptablePetName(value: string): void;
        handleUpdateAdoptablePetNameChange(event: Event): void;
        setUpdateAdoptablePetAge(value: number | ''): void;
        handleUpdateAdoptablePetAgeChange(event: Event): void;
        setUpdateAdoptablePetDescription(value: string): void;
        handleUpdateAdoptablePetDescriptionChange(event: Event): void;
        setUpdateAdoptablePetPhotoUrl(value: string): void;
        handleUpdateAdoptablePetPhotoUrlChange(event: Event): void;
        setUpdateAdoptablePetStatus(value: "available" | "unavailable" | ''): void;
        handleUpdateAdoptablePetStatusChange(event: Event): void;
        loadBrowseAdoptablePetsAdmin(signal?: AbortSignal): Promise<boolean>;
        handleBrowseAdoptablePetsAdminClick(): void;
        createAdoptablePet(signal?: AbortSignal): Promise<boolean>;
        handleCreateAdoptablePetClick(): void;
        updateAdoptablePet(signal?: AbortSignal): Promise<boolean>;
        handleUpdateAdoptablePetClick(): void;
        private readTextValue;
        private readNumberValue;
        private createBrowseAdoptablePetsAdminDefault;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/petManagement" {
    import { PetShopPetManagementBase } from "_102049_/l2/petShop/web/shared/petManagement";
    export class PetShopDesktopPage11PetManagementPage extends PetShopPetManagementBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/productCatalog.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    order: number;
                    stateKey?: undefined;
                    action?: undefined;
                    submitAction?: undefined;
                } | {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                })[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            })[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        source?: undefined;
                        binding?: undefined;
                        action?: undefined;
                        submitAction?: undefined;
                        stateKey?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    })[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "productCatalog__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/productCatalog.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/productCatalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/productCatalog.defs.ts", "_102049_/l2/petShop/web/shared/productCatalog.ts", "_102049_/l2/petShop/web/contracts/productCatalog.defs.ts", "_102049_/l2/petShop/web/contracts/productCatalog.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["productCatalog__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/productCatalog" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseProductCatalogOutput, PetShopViewProductDetailsOutput, PetShopPlaceStorePickupOrderOutput } from "_102049_/l2/petShop/web/contracts/productCatalog";
    const message_pt: {
        "page.title": string;
        "section.catalog.title": string;
        "section.checkout.title": string;
        "organism.browse.title": string;
        "organism.details.title": string;
        "organism.cart.title": string;
        "organism.checkout.title": string;
        "organism.summary.title": string;
        "field.searchName": string;
        "field.productCategoryId": string;
        "field.productId": string;
        "field.name": string;
        "field.description": string;
        "field.price": string;
        "field.imageUrl": string;
        "field.featured": string;
        "field.status": string;
        "field.quantity": string;
        "field.unitPrice": string;
        "field.customerName": string;
        "field.customerPhone": string;
        "field.orderId": string;
        "field.createdAt": string;
        "column.imageUrl": string;
        "column.name": string;
        "column.price": string;
        "column.productCategoryId": string;
        "column.featured": string;
        "column.productId": string;
        "column.quantity": string;
        "column.unitPrice": string;
        "action.viewProductDetails": string;
        "action.placeStorePickupOrder": string;
        "empty.browse": string;
        "empty.details": string;
        "empty.cart": string;
        "empty.summary": string;
        "action.placeStorePickupOrder.success": string;
        "action.placeStorePickupOrder.error": string;
        "sec.catalog.title": string;
        "org.browse.catalog.title": string;
        "org.product.details.title": string;
        "org.cart.and.checkout.title": string;
        "org.order.result.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopProductCatalogBase extends CollabLitElement {
        status: string;
        browseProductCatalogState: "idle" | "loading" | "success" | "error";
        browseProductCatalogSearchName: string;
        browseProductCatalogProductCategoryId: string;
        browseProductCatalogData: PetShopBrowseProductCatalogOutput;
        viewProductDetailsState: "idle" | "loading" | "success" | "error";
        viewProductDetailsProductId: string;
        viewProductDetailsData: PetShopViewProductDetailsOutput | null;
        placeStorePickupOrderState: "idle" | "loading" | "success" | "error";
        placeStorePickupOrderCustomerName: string;
        placeStorePickupOrderCustomerPhone: string;
        placeStorePickupOrderOutput: PetShopPlaceStorePickupOrderOutput | null;
        placeStorePickupOrderError: string;
        private subscribedKeys;
        protected get msg(): MessageType;
        private parseRouteParams;
        setBrowseProductCatalogSearchName(value: string): void;
        handleBrowseProductCatalogSearchNameChange(e: Event): void;
        setBrowseProductCatalogProductCategoryId(value: string): void;
        handleBrowseProductCatalogProductCategoryIdChange(e: Event): void;
        setViewProductDetailsProductId(value: string): void;
        handleViewProductDetailsProductIdChange(e: Event): void;
        setPlaceStorePickupOrderCustomerName(value: string): void;
        handlePlaceStorePickupOrderCustomerNameChange(e: Event): void;
        setPlaceStorePickupOrderCustomerPhone(value: string): void;
        handlePlaceStorePickupOrderCustomerPhoneChange(e: Event): void;
        loadBrowseProductCatalog(): Promise<void>;
        handleBrowseProductCatalogClick(): void;
        loadViewProductDetails(): Promise<void>;
        handleViewProductDetailsClick(): void;
        placeStorePickupOrder(): Promise<void>;
        handlePlaceStorePickupOrderClick(): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/productCatalog" {
    import { PetShopProductCatalogBase } from "_102049_/l2/petShop/web/shared/productCatalog";
    export class PetShopDesktopPage11ProductCatalogPage extends PetShopProductCatalogBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/productManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                            source?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "productManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/productManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/productManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/productManagement.defs.ts", "_102049_/l2/petShop/web/shared/productManagement.ts", "_102049_/l2/petShop/web/contracts/productManagement.defs.ts", "_102049_/l2/petShop/web/contracts/productManagement.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["productManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/productManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseProductsOutput, PetShopCreateProductOutput, PetShopUpdateProductOutput } from "_102049_/l2/petShop/web/contracts/productManagement";
    const message_pt: {
        "page.title": string;
        "section.productManagement": string;
        "section.review": string;
        "organism.browseProducts.title": string;
        "organism.createProduct.title": string;
        "organism.updateProduct.title": string;
        "organism.review.title": string;
        "empty.browseProducts": string;
        "empty.createProduct": string;
        "empty.updateProduct": string;
        "empty.review": string;
        "column.name": string;
        "column.price": string;
        "column.productCategoryId": string;
        "column.featured": string;
        "column.status": string;
        "filter.searchName": string;
        "filter.filterStatus": string;
        "filter.filterProductCategoryId": string;
        "filter.filterFeatured": string;
        "field.name": string;
        "field.description": string;
        "field.price": string;
        "field.imageUrl": string;
        "field.productCategoryId": string;
        "field.featured": string;
        "field.status": string;
        "field.productId": string;
        "action.createProduct": string;
        "action.createProduct.submit": string;
        "action.updateProduct": string;
        "action.updateProduct.submit": string;
        "action.createProduct.success": string;
        "action.createProduct.error": string;
        "action.updateProduct.success": string;
        "action.updateProduct.error": string;
        "org.browseProducts.title": string;
        "org.createProduct.title": string;
        "org.updateProduct.title": string;
        "org.review.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopProductManagementBase extends CollabLitElement {
        status: string;
        browseProductsState: "idle" | "loading" | "success" | "error";
        browseProductsSearchName: string;
        browseProductsFilterStatus: string;
        browseProductsFilterProductCategoryId: string;
        browseProductsFilterFeatured: string;
        browseProductsData: PetShopBrowseProductsOutput;
        createProductState: "idle" | "loading" | "success" | "error";
        createProductName: string;
        createProductDescription: string;
        createProductPrice: string;
        createProductImageUrl: string;
        createProductProductCategoryId: string;
        createProductFeatured: string;
        createProductOutput: PetShopCreateProductOutput | null;
        createProductError: string;
        updateProductState: "idle" | "loading" | "success" | "error";
        updateProductProductId: string;
        updateProductName: string;
        updateProductDescription: string;
        updateProductPrice: string;
        updateProductImageUrl: string;
        updateProductProductCategoryId: string;
        updateProductFeatured: string;
        updateProductStatus: string;
        updateProductOutput: PetShopUpdateProductOutput | null;
        updateProductError: string;
        protected get msg(): MessageType;
        setBrowseProductsSearchName(value: string): void;
        handleBrowseProductsSearchNameChange(e: Event): void;
        setBrowseProductsFilterStatus(value: string): void;
        handleBrowseProductsFilterStatusChange(e: Event): void;
        setBrowseProductsFilterProductCategoryId(value: string): void;
        handleBrowseProductsFilterProductCategoryIdChange(e: Event): void;
        setBrowseProductsFilterFeatured(value: string): void;
        handleBrowseProductsFilterFeaturedChange(e: Event): void;
        setCreateProductName(value: string): void;
        handleCreateProductNameChange(e: Event): void;
        setCreateProductDescription(value: string): void;
        handleCreateProductDescriptionChange(e: Event): void;
        setCreateProductPrice(value: string): void;
        handleCreateProductPriceChange(e: Event): void;
        setCreateProductImageUrl(value: string): void;
        handleCreateProductImageUrlChange(e: Event): void;
        setCreateProductProductCategoryId(value: string): void;
        handleCreateProductProductCategoryIdChange(e: Event): void;
        setCreateProductFeatured(value: string): void;
        handleCreateProductFeaturedChange(e: Event): void;
        setUpdateProductProductId(value: string): void;
        handleUpdateProductProductIdChange(e: Event): void;
        setUpdateProductName(value: string): void;
        handleUpdateProductNameChange(e: Event): void;
        setUpdateProductDescription(value: string): void;
        handleUpdateProductDescriptionChange(e: Event): void;
        setUpdateProductPrice(value: string): void;
        handleUpdateProductPriceChange(e: Event): void;
        setUpdateProductImageUrl(value: string): void;
        handleUpdateProductImageUrlChange(e: Event): void;
        setUpdateProductProductCategoryId(value: string): void;
        handleUpdateProductProductCategoryIdChange(e: Event): void;
        setUpdateProductFeatured(value: string): void;
        handleUpdateProductFeaturedChange(e: Event): void;
        setUpdateProductStatus(value: string): void;
        handleUpdateProductStatusChange(e: Event): void;
        loadBrowseProducts(): Promise<void>;
        handleBrowseProductsClick(e: Event): void;
        createProduct(): Promise<void>;
        handleCreateProductClick(e: Event): void;
        updateProduct(): Promise<void>;
        handleUpdateProductClick(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/productManagement" {
    import { PetShopProductManagementBase } from "_102049_/l2/petShop/web/shared/productManagement";
    export class PetShopDesktopPage11ProductManagementPage extends PetShopProductManagementBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/schedulingCapacity.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: {
            operationId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "schedulingCapacity__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/schedulingCapacity.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/schedulingCapacity.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/schedulingCapacity.defs.ts", "_102049_/l2/petShop/web/shared/schedulingCapacity.ts", "_102049_/l2/petShop/web/contracts/schedulingCapacity.defs.ts", "_102049_/l2/petShop/web/contracts/schedulingCapacity.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["schedulingCapacity__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/schedulingCapacity" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopAssignOperatorToShiftOutput, PetShopReviewSchedulingCapacityOutput } from "_102049_/l2/petShop/web/contracts/schedulingCapacity";
    const message_pt: {
        "section.schedulingCapacity.title": string;
        "intention.queryList.title": string;
        "intention.queryList.empty": string;
        "intention.commandForm.title": string;
        "intention.commandForm.empty": string;
        "intention.summary.title": string;
        "intention.summary.empty": string;
        "field.operatorId.label": string;
        "field.shiftId.label": string;
        "column.shiftAssignmentId.label": string;
        "column.name.label": string;
        "column.shiftId.label": string;
        "column.startTime.label": string;
        "column.endTime.label": string;
        "column.createdAt.label": string;
        "filter.shiftId.label": string;
        "action.assignOperatorToShift.label": string;
        "action.reviewSchedulingCapacity.label": string;
        "action.assignOperatorToShift.success": string;
        "action.assignOperatorToShift.error": string;
        "action.reviewSchedulingCapacity.success": string;
        "action.reviewSchedulingCapacity.error": string;
        "org.review.scheduling.capacity.title": string;
        "org.assign.operator.to.shift.title": string;
        "org.capacity.summary.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopSchedulingCapacityBase extends CollabLitElement {
        status: string;
        assignOperatorToShiftState: "idle" | "loading" | "success" | "error";
        assignOperatorToShiftOperatorId: string;
        assignOperatorToShiftShiftId: string;
        assignOperatorToShiftOutput: PetShopAssignOperatorToShiftOutput | null;
        assignOperatorToShiftError: string;
        reviewSchedulingCapacityState: "idle" | "loading" | "success" | "error";
        reviewSchedulingCapacityShiftId: string;
        reviewSchedulingCapacityData: PetShopReviewSchedulingCapacityOutput;
        activeCompanyId: string;
        protected get msg(): MessageType;
        setAssignOperatorToShiftOperatorId(value: string): void;
        handleAssignOperatorToShiftOperatorIdChange(e: Event): void;
        setAssignOperatorToShiftShiftId(value: string): void;
        handleAssignOperatorToShiftShiftIdChange(e: Event): void;
        setReviewSchedulingCapacityShiftId(value: string): void;
        handleReviewSchedulingCapacityShiftIdChange(e: Event): void;
        loadReviewSchedulingCapacity(): Promise<void>;
        handleReviewSchedulingCapacityClick(e: Event): void;
        assignOperatorToShift(): Promise<void>;
        handleAssignOperatorToShiftClick(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: unknown): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/schedulingCapacity" {
    import { PetShopSchedulingCapacityBase } from "_102049_/l2/petShop/web/shared/schedulingCapacity";
    export class PetShopDesktopPage11SchedulingCapacityPage extends PetShopSchedulingCapacityBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/serviceBooking.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                            source?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "serviceBooking__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/serviceBooking.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/serviceBooking.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/serviceBooking.defs.ts", "_102049_/l2/petShop/web/shared/serviceBooking.ts", "_102049_/l2/petShop/web/contracts/serviceBooking.defs.ts", "_102049_/l2/petShop/web/contracts/serviceBooking.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["serviceBooking__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/serviceBooking" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseServiceCatalogOutput, PetShopCreateServiceBookingOutput } from "_102049_/l2/petShop/web/contracts/serviceBooking";
    const message_pt: {
        "page.title": string;
        "section.catalog.title": string;
        "section.catalog.empty": string;
        "section.booking.title": string;
        "section.booking.empty": string;
        "section.confirmation.title": string;
        "section.confirmation.empty": string;
        "field.serviceId.label": string;
        "field.customerName.label": string;
        "field.customerPhone.label": string;
        "field.bookingDate.label": string;
        "field.bookingTime.label": string;
        "field.notes.label": string;
        "field.serviceBookingId.label": string;
        "field.status.label": string;
        "column.serviceId.label": string;
        "column.name.label": string;
        "column.description.label": string;
        "column.estimatedDurationMinutes.label": string;
        "column.price.label": string;
        "filter.name.label": string;
        "action.browseServiceCatalog.label": string;
        "action.createServiceBooking.label": string;
        "action.createServiceBooking.success": string;
        "action.createServiceBooking.error": string;
        "summary.paymentNotice": string;
        "sec.catalog.title": string;
        "org.browseCatalog.title": string;
        "sec.booking.title": string;
        "org.createBooking.title": string;
        "sec.confirmation.title": string;
        "org.bookingSummary.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopServiceBookingBase extends CollabLitElement {
        status: string;
        browseServiceCatalogState: "idle" | "loading" | "success" | "error";
        browseServiceCatalogData: PetShopBrowseServiceCatalogOutput;
        createServiceBookingState: "idle" | "loading" | "success" | "error";
        createServiceBookingServiceId: string;
        createServiceBookingCustomerName: string;
        createServiceBookingCustomerPhone: string;
        createServiceBookingBookingDate: string;
        createServiceBookingBookingTime: string;
        createServiceBookingNotes: string;
        createServiceBookingOutput: PetShopCreateServiceBookingOutput | null;
        createServiceBookingError: string;
        protected get msg(): MessageType;
        private readonly stateKeyMap;
        private subscribedKeys;
        loadBrowseServiceCatalog(): Promise<void>;
        handleBrowseServiceCatalogClick(_e: Event): void;
        createServiceBooking(): Promise<void>;
        handleCreateServiceBookingClick(_e: Event): void;
        setCreateServiceBookingServiceId(value: string): void;
        handleCreateServiceBookingServiceIdChange(e: Event): void;
        setCreateServiceBookingCustomerName(value: string): void;
        handleCreateServiceBookingCustomerNameChange(e: Event): void;
        setCreateServiceBookingCustomerPhone(value: string): void;
        handleCreateServiceBookingCustomerPhoneChange(e: Event): void;
        setCreateServiceBookingBookingDate(value: string): void;
        handleCreateServiceBookingBookingDateChange(e: Event): void;
        setCreateServiceBookingBookingTime(value: string): void;
        handleCreateServiceBookingBookingTimeChange(e: Event): void;
        setCreateServiceBookingNotes(value: string): void;
        handleCreateServiceBookingNotesChange(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/serviceBooking" {
    import { PetShopServiceBookingBase } from "_102049_/l2/petShop/web/shared/serviceBooking";
    export class PetShopDesktopPage11ServiceBookingPage extends PetShopServiceBookingBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/serviceExecution.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                        }[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        source?: undefined;
                    })[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: ({
            id: string;
            source: string;
            entity: string;
            description: string;
            command?: undefined;
            stateKey?: undefined;
            inputStateKeys?: undefined;
        } | {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "serviceExecution__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/serviceExecution.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/serviceExecution.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/serviceExecution.defs.ts", "_102049_/l2/petShop/web/shared/serviceExecution.ts", "_102049_/l2/petShop/web/contracts/serviceExecution.defs.ts", "_102049_/l2/petShop/web/contracts/serviceExecution.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["serviceExecution__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/serviceExecution" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopStartServiceExecutionOutput, PetShopCompleteServiceExecutionOutput } from "_102049_/l2/petShop/web/contracts/serviceExecution";
    const message_pt: {
        "page.title": string;
        "section.bookings.title": string;
        "section.bookings.empty": string;
        "section.start.title": string;
        "section.start.empty": string;
        "section.complete.title": string;
        "section.complete.empty": string;
        "section.review.title": string;
        "section.review.empty": string;
        "column.customerName": string;
        "column.bookingDate": string;
        "column.bookingTime": string;
        "column.status": string;
        "column.notes": string;
        "column.updatedAt": string;
        "column.completedAt": string;
        "filter.status": string;
        "field.serviceBookingId": string;
        "action.startServiceExecution": string;
        "action.completeServiceExecution": string;
        "action.startServiceExecution.success": string;
        "action.startServiceExecution.error": string;
        "action.completeServiceExecution.success": string;
        "action.completeServiceExecution.error": string;
        "intention.bookingQuery.title": string;
        "intention.workflowStatus.title": string;
        "intention.startForm.title": string;
        "intention.completeForm.title": string;
        "intention.review.title": string;
        "sec.bookings.title": string;
        "org.booking.list.title": string;
        "sec.start.service.title": string;
        "org.start.service.title": string;
        "sec.complete.service.title": string;
        "org.complete.service.title": string;
        "sec.review.title": string;
        "org.review.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopServiceExecutionBase extends CollabLitElement {
        status: string;
        startServiceExecutionState: "idle" | "loading" | "success" | "error";
        startServiceExecutionServiceBookingId: string;
        startServiceExecutionOutput: PetShopStartServiceExecutionOutput | null;
        startServiceExecutionError: string;
        completeServiceExecutionState: "idle" | "loading" | "success" | "error";
        completeServiceExecutionServiceBookingId: string;
        completeServiceExecutionOutput: PetShopCompleteServiceExecutionOutput | null;
        completeServiceExecutionError: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setStartServiceExecutionServiceBookingId(value: string): void;
        handleStartServiceExecutionServiceBookingIdChange(e: Event): void;
        setCompleteServiceExecutionServiceBookingId(value: string): void;
        handleCompleteServiceExecutionServiceBookingIdChange(e: Event): void;
        startServiceExecution(): Promise<void>;
        handleStartServiceExecutionClick(): void;
        completeServiceExecution(): Promise<void>;
        handleCompleteServiceExecutionClick(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/serviceExecution" {
    import { PetShopServiceExecutionBase } from "_102049_/l2/petShop/web/shared/serviceExecution";
    export class PetShopDesktopPage11ServiceExecutionPage extends PetShopServiceExecutionBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/serviceManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "serviceManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/serviceManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/serviceManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/serviceManagement.defs.ts", "_102049_/l2/petShop/web/shared/serviceManagement.ts", "_102049_/l2/petShop/web/contracts/serviceManagement.defs.ts", "_102049_/l2/petShop/web/contracts/serviceManagement.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["serviceManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/serviceManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseServicesOutput, PetShopCreateServiceOutput, PetShopUpdateServiceOutput } from "_102049_/l2/petShop/web/contracts/serviceManagement";
    const message_pt: {
        "section.serviceManagement.title": string;
        "browseServices.title": string;
        "browseServices.empty": string;
        "createService.title": string;
        "createService.empty": string;
        "updateService.title": string;
        "updateService.empty": string;
        "field.name": string;
        "field.description": string;
        "field.estimatedDurationMinutes": string;
        "field.price": string;
        "field.status": string;
        "field.serviceId": string;
        "filter.statusFilter": string;
        "toolbar.createService": string;
        "rowAction.updateService": string;
        "action.createService.submit": string;
        "action.updateService.submit": string;
        "status.active": string;
        "status.inactive": string;
        "action.createService.success": string;
        "action.createService.error": string;
        "action.updateService.success": string;
        "action.updateService.error": string;
        "org.browse.services.title": string;
        "org.create.service.title": string;
        "org.update.service.title": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopServiceManagementBase extends CollabLitElement {
        status: string;
        browseServicesState: "idle" | "loading" | "success" | "error";
        browseServicesStatusFilter: string;
        browseServicesData: PetShopBrowseServicesOutput;
        createServiceState: "idle" | "loading" | "success" | "error";
        createServiceName: string;
        createServiceDescription: string;
        createServiceEstimatedDurationMinutes: string;
        createServicePrice: string;
        createServiceOutput: PetShopCreateServiceOutput | null;
        createServiceError: string;
        updateServiceState: "idle" | "loading" | "success" | "error";
        updateServiceServiceId: string;
        updateServiceName: string;
        updateServiceDescription: string;
        updateServiceEstimatedDurationMinutes: string;
        updateServicePrice: string;
        updateServiceStatus: string;
        updateServiceOutput: PetShopUpdateServiceOutput | null;
        updateServiceError: string;
        protected get msg(): MessageType;
        setBrowseServicesStatusFilter(value: string): void;
        handleBrowseServicesStatusFilterChange(e: Event): void;
        setCreateServiceName(value: string): void;
        handleCreateServiceNameChange(e: Event): void;
        setCreateServiceDescription(value: string): void;
        handleCreateServiceDescriptionChange(e: Event): void;
        setCreateServiceEstimatedDurationMinutes(value: string): void;
        handleCreateServiceEstimatedDurationMinutesChange(e: Event): void;
        setCreateServicePrice(value: string): void;
        handleCreateServicePriceChange(e: Event): void;
        setUpdateServiceServiceId(value: string): void;
        handleUpdateServiceServiceIdChange(e: Event): void;
        setUpdateServiceName(value: string): void;
        handleUpdateServiceNameChange(e: Event): void;
        setUpdateServiceDescription(value: string): void;
        handleUpdateServiceDescriptionChange(e: Event): void;
        setUpdateServiceEstimatedDurationMinutes(value: string): void;
        handleUpdateServiceEstimatedDurationMinutesChange(e: Event): void;
        setUpdateServicePrice(value: string): void;
        handleUpdateServicePriceChange(e: Event): void;
        setUpdateServiceStatus(value: string): void;
        handleUpdateServiceStatusChange(e: Event): void;
        loadBrowseServices(): Promise<void>;
        handleBrowseServicesClick(): void;
        createService(): Promise<void>;
        handleCreateServiceClick(): void;
        updateService(): Promise<void>;
        handleUpdateServiceClick(): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/serviceManagement" {
    import { PetShopServiceManagementBase } from "_102049_/l2/petShop/web/shared/serviceManagement";
    export class PetShopDesktopPage11ServiceManagementPage extends PetShopServiceManagementBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/shiftManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            })[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "shiftManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/shiftManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/shiftManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/shiftManagement.defs.ts", "_102049_/l2/petShop/web/shared/shiftManagement.ts", "_102049_/l2/petShop/web/contracts/shiftManagement.defs.ts", "_102049_/l2/petShop/web/contracts/shiftManagement.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["shiftManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Site-first, visualmente atraente, com galerias de imagens, catálogos navegáveis, carrinho de compras e agenda orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/shiftManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseShiftsOutput, PetShopCreateShiftOutput, PetShopUpdateShiftOutput } from "_102049_/l2/petShop/web/contracts/shiftManagement";
    const message_pt: {
        "shiftManagement.section.gestaoTurnos.title": string;
        "shiftManagement.organism.browseShifts.title": string;
        "shiftManagement.organism.createShift.title": string;
        "shiftManagement.organism.updateShift.title": string;
        "shiftManagement.intent.browseList.title": string;
        "shiftManagement.intent.browseList.empty": string;
        "shiftManagement.intent.createForm.title": string;
        "shiftManagement.intent.updateForm.title": string;
        "shiftManagement.field.name.label": string;
        "shiftManagement.field.startTime.label": string;
        "shiftManagement.field.endTime.label": string;
        "shiftManagement.field.monday.label": string;
        "shiftManagement.field.tuesday.label": string;
        "shiftManagement.field.wednesday.label": string;
        "shiftManagement.field.thursday.label": string;
        "shiftManagement.field.friday.label": string;
        "shiftManagement.field.saturday.label": string;
        "shiftManagement.field.sunday.label": string;
        "shiftManagement.field.active.label": string;
        "shiftManagement.filter.activeFilter.label": string;
        "shiftManagement.action.createShift.label": string;
        "shiftManagement.action.updateShift.label": string;
        "shiftManagement.action.createShift.submit": string;
        "shiftManagement.action.updateShift.submit": string;
        "action.createShift.success": string;
        "action.createShift.error": string;
        "action.updateShift.success": string;
        "action.updateShift.error": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopShiftManagementBase extends CollabLitElement {
        status: string;
        browseShiftsState: 'idle' | 'loading' | 'success' | 'error';
        browseShiftsActiveFilter: string;
        browseShiftsData: PetShopBrowseShiftsOutput;
        createShiftState: 'idle' | 'loading' | 'success' | 'error';
        createShiftName: string;
        createShiftStartTime: string;
        createShiftEndTime: string;
        createShiftMonday: string;
        createShiftTuesday: string;
        createShiftWednesday: string;
        createShiftThursday: string;
        createShiftFriday: string;
        createShiftSaturday: string;
        createShiftSunday: string;
        createShiftActive: string;
        createShiftOutput: PetShopCreateShiftOutput | null;
        createShiftError: string;
        updateShiftState: 'idle' | 'loading' | 'success' | 'error';
        updateShiftShiftId: string;
        updateShiftName: string;
        updateShiftStartTime: string;
        updateShiftEndTime: string;
        updateShiftMonday: string;
        updateShiftTuesday: string;
        updateShiftWednesday: string;
        updateShiftThursday: string;
        updateShiftFriday: string;
        updateShiftSaturday: string;
        updateShiftSunday: string;
        updateShiftActive: string;
        updateShiftOutput: PetShopUpdateShiftOutput | null;
        updateShiftError: string;
        private readonly subscribedKeys;
        protected get msg(): MessageType;
        private toBool;
        private readInputValue;
        loadBrowseShifts(): Promise<boolean>;
        handleBrowseShiftsClick(): void;
        createShift(signal?: AbortSignal): Promise<void>;
        handleCreateShiftClick(): void;
        updateShift(signal?: AbortSignal): Promise<void>;
        handleUpdateShiftClick(): void;
        setBrowseShiftsActiveFilter(value: string): void;
        handleBrowseShiftsActiveFilterChange(e: Event): void;
        setCreateShiftName(value: string): void;
        handleCreateShiftNameChange(e: Event): void;
        setCreateShiftStartTime(value: string): void;
        handleCreateShiftStartTimeChange(e: Event): void;
        setCreateShiftEndTime(value: string): void;
        handleCreateShiftEndTimeChange(e: Event): void;
        setCreateShiftMonday(value: string): void;
        handleCreateShiftMondayChange(e: Event): void;
        setCreateShiftTuesday(value: string): void;
        handleCreateShiftTuesdayChange(e: Event): void;
        setCreateShiftWednesday(value: string): void;
        handleCreateShiftWednesdayChange(e: Event): void;
        setCreateShiftThursday(value: string): void;
        handleCreateShiftThursdayChange(e: Event): void;
        setCreateShiftFriday(value: string): void;
        handleCreateShiftFridayChange(e: Event): void;
        setCreateShiftSaturday(value: string): void;
        handleCreateShiftSaturdayChange(e: Event): void;
        setCreateShiftSunday(value: string): void;
        handleCreateShiftSundayChange(e: Event): void;
        setCreateShiftActive(value: string): void;
        handleCreateShiftActiveChange(e: Event): void;
        setUpdateShiftShiftId(value: string): void;
        handleUpdateShiftShiftIdChange(e: Event): void;
        setUpdateShiftName(value: string): void;
        handleUpdateShiftNameChange(e: Event): void;
        setUpdateShiftStartTime(value: string): void;
        handleUpdateShiftStartTimeChange(e: Event): void;
        setUpdateShiftEndTime(value: string): void;
        handleUpdateShiftEndTimeChange(e: Event): void;
        setUpdateShiftMonday(value: string): void;
        handleUpdateShiftMondayChange(e: Event): void;
        setUpdateShiftTuesday(value: string): void;
        handleUpdateShiftTuesdayChange(e: Event): void;
        setUpdateShiftWednesday(value: string): void;
        handleUpdateShiftWednesdayChange(e: Event): void;
        setUpdateShiftThursday(value: string): void;
        handleUpdateShiftThursdayChange(e: Event): void;
        setUpdateShiftFriday(value: string): void;
        handleUpdateShiftFridayChange(e: Event): void;
        setUpdateShiftSaturday(value: string): void;
        handleUpdateShiftSaturdayChange(e: Event): void;
        setUpdateShiftSunday(value: string): void;
        handleUpdateShiftSundayChange(e: Event): void;
        setUpdateShiftActive(value: string): void;
        handleUpdateShiftActiveChange(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/shiftManagement" {
    import { PetShopShiftManagementBase } from "_102049_/l2/petShop/web/shared/shiftManagement";
    export class PetShopDesktopPage11ShiftManagementPage extends PetShopShiftManagementBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/shared/adoptionGallery.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "adoptionGallery.section.title": string;
            "adoptionGallery.browse.title": string;
            "adoptionGallery.browse.empty": string;
            "adoptionGallery.details.title": string;
            "adoptionGallery.details.empty": string;
            "adoptionGallery.interestForm.title": string;
            "adoptionGallery.interestForm.empty": string;
            "adoptionGallery.summary.title": string;
            "adoptionGallery.summary.empty": string;
            "adoptionGallery.field.photoUrl": string;
            "adoptionGallery.field.name": string;
            "adoptionGallery.field.age": string;
            "adoptionGallery.field.description": string;
            "adoptionGallery.field.status": string;
            "adoptionGallery.field.adoptablePetId": string;
            "adoptionGallery.field.customerName": string;
            "adoptionGallery.field.customerEmail": string;
            "adoptionGallery.field.customerPhone": string;
            "adoptionGallery.field.adoptionInterestId": string;
            "adoptionGallery.field.interestStatus": string;
            "adoptionGallery.field.createdAt": string;
            "adoptionGallery.action.viewDetails": string;
            "adoptionGallery.action.expressInterest": string;
            "adoptionGallery.action.submitInterest": string;
            "action.expressAdoptionInterest.success": string;
            "action.expressAdoptionInterest.error": string;
            "org.browse.adoptable.pets.title": string;
            "org.view.pet.details.title": string;
            "org.express.interest.title": string;
            "org.adoption.summary.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "adoptionGallery__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/adoptionGallery.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/adoptionGallery.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/adoptionGallery.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["adoptionGallery__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/adoptionGallery.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/homePage.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: any[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
        }[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "homePage.title": string;
            "homePage.section.featuredProducts": string;
            "homePage.section.services": string;
            "homePage.section.adoptablePets": string;
            "homePage.productList.title": string;
            "homePage.productList.empty": string;
            "homePage.productDetail.title": string;
            "homePage.productDetail.empty": string;
            "homePage.productDetail.imageUrl": string;
            "homePage.productDetail.name": string;
            "homePage.productDetail.description": string;
            "homePage.productDetail.price": string;
            "homePage.product.productId": string;
            "homePage.product.name": string;
            "homePage.product.description": string;
            "homePage.product.price": string;
            "homePage.product.imageUrl": string;
            "homePage.product.featured": string;
            "homePage.product.status": string;
            "homePage.servicesList.title": string;
            "homePage.servicesList.empty": string;
            "homePage.service.serviceId": string;
            "homePage.service.name": string;
            "homePage.service.description": string;
            "homePage.service.estimatedDurationMinutes": string;
            "homePage.service.price": string;
            "homePage.service.status": string;
            "homePage.petsGallery.title": string;
            "homePage.petsGallery.empty": string;
            "homePage.pet.adoptablePetId": string;
            "homePage.pet.name": string;
            "homePage.pet.age": string;
            "homePage.pet.description": string;
            "homePage.pet.photoUrl": string;
            "homePage.pet.status": string;
            "homePage.action.browseHomePage": string;
            "homePage.action.browseHomePage.success": string;
            "homePage.action.browseHomePage.error": string;
            "org.featured.products.title": string;
            "org.services.title": string;
            "org.adoptable.pets.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "homePage__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/homePage.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/homePage.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/homePage.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["homePage__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/homePage.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/operatorManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "operatorManagement.browse.title": string;
            "operatorManagement.browse.empty": string;
            "operatorManagement.create.title": string;
            "operatorManagement.create.empty": string;
            "operatorManagement.update.title": string;
            "operatorManagement.update.empty": string;
            "operatorManagement.field.name": string;
            "operatorManagement.field.email": string;
            "operatorManagement.field.phone": string;
            "operatorManagement.field.active": string;
            "operatorManagement.field.updatedAt": string;
            "operatorManagement.field.operatorId": string;
            "operatorManagement.filter.active": string;
            "operatorManagement.action.create": string;
            "operatorManagement.action.create.submit": string;
            "operatorManagement.action.update": string;
            "operatorManagement.action.update.submit": string;
            "action.createOperator.success": string;
            "action.createOperator.error": string;
            "action.updateOperator.success": string;
            "action.updateOperator.error": string;
            "sec.operator.management.title": string;
            "org.browse.operators.title": string;
            "org.create.operator.title": string;
            "org.update.operator.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "operatorManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/operatorManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/operatorManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/operatorManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["operatorManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/operatorManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/operatorSchedule.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.title": string;
            "section.schedule.title": string;
            "section.payment.title": string;
            "organism.metrics.title": string;
            "organism.metrics.empty": string;
            "metric.confirmed": string;
            "metric.inProgress": string;
            "metric.completed": string;
            "metric.total": string;
            "organism.list.title": string;
            "organism.list.empty": string;
            "organism.details.title": string;
            "organism.details.empty": string;
            "organism.payment.title": string;
            "organism.payment.empty": string;
            "column.customerName": string;
            "column.customerPhone": string;
            "column.bookingDate": string;
            "column.bookingTime": string;
            "column.status": string;
            "column.notes": string;
            "filter.status": string;
            "filter.bookingDate": string;
            "field.serviceBookingId": string;
            "field.serviceId": string;
            "field.customerName": string;
            "field.customerPhone": string;
            "field.bookingDate": string;
            "field.bookingTime": string;
            "field.status": string;
            "field.notes": string;
            "field.completedAt": string;
            "field.cancelledAt": string;
            "field.cancelReason": string;
            "field.createdAt": string;
            "field.updatedAt": string;
            "field.paymentInfo": string;
            "field.paymentMethod": string;
            "action.viewDetails": string;
            "action.viewOperatorSchedule.success": string;
            "action.viewOperatorSchedule.error": string;
            "action.viewServiceBookingDetails.success": string;
            "action.viewServiceBookingDetails.error": string;
            "scheduleMetrics.title": string;
            "scheduleList.title": string;
            "bookingDetails.title": string;
            "paymentContext.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "operatorSchedule__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/operatorSchedule.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/operatorSchedule.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/operatorSchedule.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["operatorSchedule__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/operatorSchedule.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/petManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "petManagement.section.title": string;
            "petManagement.list.title": string;
            "petManagement.list.empty": string;
            "petManagement.create.title": string;
            "petManagement.create.empty": string;
            "petManagement.update.title": string;
            "petManagement.update.empty": string;
            "petManagement.summary.title": string;
            "petManagement.summary.sectionTitle": string;
            "petManagement.summary.empty": string;
            "petManagement.field.name": string;
            "petManagement.field.age": string;
            "petManagement.field.description": string;
            "petManagement.field.photoUrl": string;
            "petManagement.field.status": string;
            "petManagement.field.adoptablePetId": string;
            "petManagement.field.createdAt": string;
            "petManagement.field.updatedAt": string;
            "petManagement.filter.statusFilter": string;
            "petManagement.action.create": string;
            "petManagement.action.create.submit": string;
            "petManagement.action.update": string;
            "petManagement.action.update.submit": string;
            "action.createAdoptablePet.success": string;
            "action.createAdoptablePet.error": string;
            "action.updateAdoptablePet.success": string;
            "action.updateAdoptablePet.error": string;
            "org.browse.pets.title": string;
            "org.create.pet.title": string;
            "org.update.pet.title": string;
            "org.pet.summary.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "petManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/petManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/petManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/petManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["petManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/petManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/productCatalog.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.title": string;
            "section.catalog.title": string;
            "section.checkout.title": string;
            "organism.browse.title": string;
            "organism.details.title": string;
            "organism.cart.title": string;
            "organism.checkout.title": string;
            "organism.summary.title": string;
            "field.searchName": string;
            "field.productCategoryId": string;
            "field.productId": string;
            "field.name": string;
            "field.description": string;
            "field.price": string;
            "field.imageUrl": string;
            "field.featured": string;
            "field.status": string;
            "field.quantity": string;
            "field.unitPrice": string;
            "field.customerName": string;
            "field.customerPhone": string;
            "field.orderId": string;
            "field.createdAt": string;
            "column.imageUrl": string;
            "column.name": string;
            "column.price": string;
            "column.productCategoryId": string;
            "column.featured": string;
            "column.productId": string;
            "column.quantity": string;
            "column.unitPrice": string;
            "action.viewProductDetails": string;
            "action.placeStorePickupOrder": string;
            "empty.browse": string;
            "empty.details": string;
            "empty.cart": string;
            "empty.summary": string;
            "action.placeStorePickupOrder.success": string;
            "action.placeStorePickupOrder.error": string;
            "sec.catalog.title": string;
            "org.browse.catalog.title": string;
            "org.product.details.title": string;
            "org.cart.and.checkout.title": string;
            "org.order.result.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "productCatalog__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/productCatalog.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/productCatalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/productCatalog.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["productCatalog__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/productCatalog.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/productManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.title": string;
            "section.productManagement": string;
            "section.review": string;
            "organism.browseProducts.title": string;
            "organism.createProduct.title": string;
            "organism.updateProduct.title": string;
            "organism.review.title": string;
            "empty.browseProducts": string;
            "empty.createProduct": string;
            "empty.updateProduct": string;
            "empty.review": string;
            "column.name": string;
            "column.price": string;
            "column.productCategoryId": string;
            "column.featured": string;
            "column.status": string;
            "filter.searchName": string;
            "filter.filterStatus": string;
            "filter.filterProductCategoryId": string;
            "filter.filterFeatured": string;
            "field.name": string;
            "field.description": string;
            "field.price": string;
            "field.imageUrl": string;
            "field.productCategoryId": string;
            "field.featured": string;
            "field.status": string;
            "field.productId": string;
            "action.createProduct": string;
            "action.createProduct.submit": string;
            "action.updateProduct": string;
            "action.updateProduct.submit": string;
            "action.createProduct.success": string;
            "action.createProduct.error": string;
            "action.updateProduct.success": string;
            "action.updateProduct.error": string;
            "org.browseProducts.title": string;
            "org.createProduct.title": string;
            "org.updateProduct.title": string;
            "org.review.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "productManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/productManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/productManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/productManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["productManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/productManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/schedulingCapacity.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            targetRef: string;
            required: boolean;
            selector: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: {
            operationId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "section.schedulingCapacity.title": string;
            "intention.queryList.title": string;
            "intention.queryList.empty": string;
            "intention.commandForm.title": string;
            "intention.commandForm.empty": string;
            "intention.summary.title": string;
            "intention.summary.empty": string;
            "field.operatorId.label": string;
            "field.shiftId.label": string;
            "column.shiftAssignmentId.label": string;
            "column.name.label": string;
            "column.shiftId.label": string;
            "column.startTime.label": string;
            "column.endTime.label": string;
            "column.createdAt.label": string;
            "filter.shiftId.label": string;
            "action.assignOperatorToShift.label": string;
            "action.reviewSchedulingCapacity.label": string;
            "action.assignOperatorToShift.success": string;
            "action.assignOperatorToShift.error": string;
            "action.reviewSchedulingCapacity.success": string;
            "action.reviewSchedulingCapacity.error": string;
            "org.review.scheduling.capacity.title": string;
            "org.assign.operator.to.shift.title": string;
            "org.capacity.summary.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "schedulingCapacity__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/schedulingCapacity.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/schedulingCapacity.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/schedulingCapacity.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["schedulingCapacity__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/schedulingCapacity.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/serviceBooking.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: any[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.title": string;
            "section.catalog.title": string;
            "section.catalog.empty": string;
            "section.booking.title": string;
            "section.booking.empty": string;
            "section.confirmation.title": string;
            "section.confirmation.empty": string;
            "field.serviceId.label": string;
            "field.customerName.label": string;
            "field.customerPhone.label": string;
            "field.bookingDate.label": string;
            "field.bookingTime.label": string;
            "field.notes.label": string;
            "field.serviceBookingId.label": string;
            "field.status.label": string;
            "column.serviceId.label": string;
            "column.name.label": string;
            "column.description.label": string;
            "column.estimatedDurationMinutes.label": string;
            "column.price.label": string;
            "filter.name.label": string;
            "action.browseServiceCatalog.label": string;
            "action.createServiceBooking.label": string;
            "action.createServiceBooking.success": string;
            "action.createServiceBooking.error": string;
            "summary.paymentNotice": string;
            "sec.catalog.title": string;
            "org.browseCatalog.title": string;
            "sec.booking.title": string;
            "org.createBooking.title": string;
            "sec.confirmation.title": string;
            "org.bookingSummary.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "serviceBooking__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/serviceBooking.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/serviceBooking.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/serviceBooking.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["serviceBooking__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/serviceBooking.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/serviceExecution.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
        })[];
        initialLoads: any[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.title": string;
            "section.bookings.title": string;
            "section.bookings.empty": string;
            "section.start.title": string;
            "section.start.empty": string;
            "section.complete.title": string;
            "section.complete.empty": string;
            "section.review.title": string;
            "section.review.empty": string;
            "column.customerName": string;
            "column.bookingDate": string;
            "column.bookingTime": string;
            "column.status": string;
            "column.notes": string;
            "column.updatedAt": string;
            "column.completedAt": string;
            "filter.status": string;
            "field.serviceBookingId": string;
            "action.startServiceExecution": string;
            "action.completeServiceExecution": string;
            "action.startServiceExecution.success": string;
            "action.startServiceExecution.error": string;
            "action.completeServiceExecution.success": string;
            "action.completeServiceExecution.error": string;
            "intention.bookingQuery.title": string;
            "intention.workflowStatus.title": string;
            "intention.startForm.title": string;
            "intention.completeForm.title": string;
            "intention.review.title": string;
            "sec.bookings.title": string;
            "org.booking.list.title": string;
            "sec.start.service.title": string;
            "org.start.service.title": string;
            "sec.complete.service.title": string;
            "org.complete.service.title": string;
            "sec.review.title": string;
            "org.review.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "serviceExecution__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/serviceExecution.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/serviceExecution.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/serviceExecution.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["serviceExecution__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/serviceExecution.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/serviceManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "section.serviceManagement.title": string;
            "browseServices.title": string;
            "browseServices.empty": string;
            "createService.title": string;
            "createService.empty": string;
            "updateService.title": string;
            "updateService.empty": string;
            "field.name": string;
            "field.description": string;
            "field.estimatedDurationMinutes": string;
            "field.price": string;
            "field.status": string;
            "field.serviceId": string;
            "filter.statusFilter": string;
            "toolbar.createService": string;
            "rowAction.updateService": string;
            "action.createService.submit": string;
            "action.updateService.submit": string;
            "status.active": string;
            "status.inactive": string;
            "action.createService.success": string;
            "action.createService.error": string;
            "action.updateService.success": string;
            "action.updateService.error": string;
            "org.browse.services.title": string;
            "org.create.service.title": string;
            "org.update.service.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "serviceManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/serviceManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/serviceManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/serviceManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["serviceManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/serviceManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/shiftManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "shiftManagement.section.gestaoTurnos.title": string;
            "shiftManagement.organism.browseShifts.title": string;
            "shiftManagement.organism.createShift.title": string;
            "shiftManagement.organism.updateShift.title": string;
            "shiftManagement.intent.browseList.title": string;
            "shiftManagement.intent.browseList.empty": string;
            "shiftManagement.intent.createForm.title": string;
            "shiftManagement.intent.updateForm.title": string;
            "shiftManagement.field.name.label": string;
            "shiftManagement.field.startTime.label": string;
            "shiftManagement.field.endTime.label": string;
            "shiftManagement.field.monday.label": string;
            "shiftManagement.field.tuesday.label": string;
            "shiftManagement.field.wednesday.label": string;
            "shiftManagement.field.thursday.label": string;
            "shiftManagement.field.friday.label": string;
            "shiftManagement.field.saturday.label": string;
            "shiftManagement.field.sunday.label": string;
            "shiftManagement.field.active.label": string;
            "shiftManagement.filter.activeFilter.label": string;
            "shiftManagement.action.createShift.label": string;
            "shiftManagement.action.updateShift.label": string;
            "shiftManagement.action.createShift.submit": string;
            "shiftManagement.action.updateShift.submit": string;
            "action.createShift.success": string;
            "action.createShift.error": string;
            "action.updateShift.success": string;
            "action.updateShift.error": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "shiftManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/shiftManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/shiftManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/shiftManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["shiftManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/shiftManagement.test" {
    export {};
}

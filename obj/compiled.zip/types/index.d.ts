declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseCatalog.defs" {
    export const browseCatalogController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseCatalog";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseCatalog";
            readonly controllerName: "BrowseCatalogController";
            readonly ownerKind: "operation";
            readonly outputSource: "dto";
            readonly dtoTypeName: "BrowseCatalogResponseDto";
            readonly dtoModulePath: "_102049_/l1/petShop/layer_1_external/adapters/http/dto/browseCatalog.js";
            readonly usecaseOutputTypeName: "BrowseCatalogOutput";
            readonly responseShape: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "products";
                    readonly type: "array";
                    readonly required: true;
                }, {
                    readonly name: "total";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: true;
                }];
            };
            readonly handlers: readonly [{
                readonly handlerName: "petShopBrowseCatalogHandler";
                readonly command: "browseCatalog";
                readonly usecaseRef: "browseCatalog";
                readonly inputTypeName: "BrowseCatalogInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "searchTerm";
                    readonly fieldRef: "Product.name";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Termo de busca para filtrar produtos por nome, insensível a maiúsculas e minúsculas com correspondência parcial";
                }, {
                    readonly inputId: "petTypeId";
                    readonly fieldRef: "Product.petTypeId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Identificador do tipo de pet para filtrar produtos indicados para esse tipo";
                }, {
                    readonly inputId: "categoryId";
                    readonly fieldRef: "Product.categoryId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Identificador da categoria para filtrar produtos pertencentes a essa categoria";
                }, {
                    readonly inputId: "minPrice";
                    readonly fieldRef: "Product.price";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Preço mínimo da faixa de valor para filtragem por faixa de preço";
                }, {
                    readonly inputId: "maxPrice";
                    readonly fieldRef: "Product.price";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Preço máximo da faixa de valor para filtragem por faixa de preço";
                }];
                readonly contextResolution: readonly [];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Product";
                    readonly keyField: "Product.productId";
                    readonly filters: readonly ["Product.status", "Product.name", "Product.petTypeId", "Product.categoryId", "Product.price", "Product.highlighted"];
                    readonly sort: readonly ["Product.createdAt"];
                    readonly pagination: "required";
                    readonly selection: "multiple";
                    readonly output: readonly ["Product.productId", "Product.name", "Product.description", "Product.price", "Product.petTypeId", "Product.categoryId", "Product.highlighted", "Product.status"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.browseCatalog.browseCatalog";
                readonly handlerName: "petShopBrowseCatalogHandler";
            }];
        };
    };
    export default browseCatalogController;
    export const pipeline: readonly [{
        readonly id: "browseCatalog__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseCatalog.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseCatalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/browseCatalog.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/http/dto/browseCatalog.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/product" {
    export type ProductStatus = 'available' | 'unavailable';
    export interface Product {
        productId: string;
        name: string;
        description: string | null;
        price: number;
        petTypeId: string;
        categoryId: string;
        highlighted: boolean;
        status: ProductStatus;
        createdAt: string;
        updatedAt: string;
    }
    export function productHighlightedRequiresAvailable(product: Pick<Product, 'highlighted' | 'status'>): boolean;
}
declare module "_102049_/l1/petShop/layer_2_application/ports/productRepository" {
    import type { Product, ProductStatus } from "_102049_/l1/petShop/layer_3_domain/entities/product";
    export interface ProductFilter {
        status?: ProductStatus;
        categoryId?: string;
        petTypeId?: string;
        highlighted?: boolean;
    }
    export interface IProductRepository {
        getById(id: string): Promise<Product>;
        list(filter?: ProductFilter): Promise<Product[]>;
        save(product: Product): Promise<void>;
        findByName(name: string): Promise<Product[]>;
        findByCategory(category: string): Promise<Product[]>;
    }
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseCatalog" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseCatalogInput {
        searchTerm?: string;
        petTypeId?: string;
        categoryId?: string;
        minPrice?: number;
        maxPrice?: number;
        page: number;
        pageSize: number;
    }
    export interface BrowseCatalogProduct {
        productId: string;
        name: string;
        description?: string | null;
        price: number;
        petTypeId: string;
        petTypeName?: string;
        categoryId: string;
        categoryName?: string;
        highlighted: boolean;
        status: string;
    }
    export interface BrowseCatalogOutput {
        products: BrowseCatalogProduct[];
        total: number;
        page: number;
        pageSize: number;
    }
    export function browseCatalog(ctx: RequestContext, input: BrowseCatalogInput): Promise<BrowseCatalogOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/dto/browseCatalog" {
    import type { BrowseCatalogOutput } from "_102049_/l1/petShop/layer_2_application/usecases/browseCatalog";
    export type BrowseCatalogResponseDto = BrowseCatalogOutput;
    export function toDto(result: BrowseCatalogOutput): BrowseCatalogResponseDto;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseCatalog" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopBrowseCatalogHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseProducts.defs" {
    export const browseProductsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseProducts";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseProducts";
            readonly controllerName: "BrowseProductsController";
            readonly ownerKind: "operation";
            readonly outputSource: "dto";
            readonly dtoTypeName: "BrowseProductsResponseDto";
            readonly dtoModulePath: "_102049_/l1/petShop/layer_1_external/adapters/http/dto/browseProducts.js";
            readonly usecaseOutputTypeName: "BrowseProductsOutput";
            readonly responseShape: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "petTypeName";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "categoryName";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "highlighted";
                    readonly type: "boolean";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly handlers: readonly [{
                readonly handlerName: "petShopBrowseProductsHandler";
                readonly command: "browseProducts";
                readonly usecaseRef: "browseProducts";
                readonly inputTypeName: "BrowseProductsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "searchTerm";
                    readonly fieldRef: "Product.name";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Termo de busca para filtrar produtos por nome com correspondência parcial e insensível a maiúsculas e minúsculas.";
                }, {
                    readonly inputId: "petTypeId";
                    readonly fieldRef: "Product.petTypeId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro por tipo de pet indicado para o produto.";
                }, {
                    readonly inputId: "categoryId";
                    readonly fieldRef: "Product.categoryId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro por categoria do catálogo.";
                }, {
                    readonly inputId: "priceMin";
                    readonly fieldRef: "Product.price";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro de faixa de preço — valor mínimo (inclusive).";
                }, {
                    readonly inputId: "priceMax";
                    readonly fieldRef: "Product.price";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro de faixa de preço — valor máximo (inclusive).";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Product.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro por status de disponibilidade do produto (available ou unavailable).";
                }, {
                    readonly inputId: "highlighted";
                    readonly fieldRef: "Product.highlighted";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro para exibir apenas produtos marcados como destaque.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "actorSession.actorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "Identifica o usuário loja autenticado na sessão para autorizar o acesso ao catálogo de produtos.";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Product";
                    readonly keyField: "Product.productId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["Product.productId", "Product.name", "Product.description", "Product.price", "Product.petTypeId", "Product.categoryId", "Product.highlighted", "Product.status", "Product.createdAt", "Product.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.browseProducts.browseProducts";
                readonly handlerName: "petShopBrowseProductsHandler";
            }];
        };
    };
    export default browseProductsController;
    export const pipeline: readonly [{
        readonly id: "browseProducts__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseProducts.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseProducts.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/browseProducts.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/http/dto/browseProducts.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseProducts" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseProductsInput {
        searchTerm?: string;
        petTypeId?: string;
        categoryId?: string;
        priceMin?: number;
        priceMax?: number;
        status?: string;
        highlighted?: boolean;
        page?: number;
        pageSize?: number;
    }
    export interface BrowseProductsItem {
        productId: string;
        name: string;
        description?: string;
        price: number;
        petTypeId: string;
        petTypeName: string;
        categoryId: string;
        categoryName: string;
        highlighted: boolean;
        status: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface BrowseProductsOutput {
        products: BrowseProductsItem[];
    }
    export function browseProducts(ctx: RequestContext, input: BrowseProductsInput): Promise<BrowseProductsOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/dto/browseProducts" {
    import type { BrowseProductsOutput } from "_102049_/l1/petShop/layer_2_application/usecases/browseProducts";
    export type BrowseProductsResponseDto = BrowseProductsOutput;
    export function toDto(result: BrowseProductsOutput): BrowseProductsResponseDto;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/browseProducts" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopBrowseProductsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/cancelReservation.defs" {
    export const cancelReservationController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "cancelReservation";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "reservationLifecycle";
            readonly controllerName: "CancelReservationController";
            readonly ownerKind: "operation";
            readonly outputSource: "dto";
            readonly dtoTypeName: "CancelReservationResponseDto";
            readonly dtoModulePath: "_102049_/l1/petShop/layer_1_external/adapters/http/dto/cancelReservation.js";
            readonly usecaseOutputTypeName: "CancelReservationOutput";
            readonly responseShape: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "cancelledAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "cancelReason";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "restoredProducts";
                    readonly type: "array";
                    readonly required: true;
                }];
            };
            readonly handlers: readonly [{
                readonly handlerName: "petShopCancelReservationHandler";
                readonly command: "cancelReservation";
                readonly usecaseRef: "cancelReservation";
                readonly inputTypeName: "CancelReservationInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "reservationId";
                    readonly fieldRef: "Reservation.reservationId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador da reserva selecionada para cancelamento";
                }, {
                    readonly inputId: "cancelReason";
                    readonly fieldRef: "Reservation.cancelReason";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Motivo opcional informado pelo cliente ao cancelar a reserva";
                }];
                readonly contextResolution: readonly [{
                    readonly inputId: "reservationId";
                    readonly targetRef: "Reservation.reservationId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Reservation.reservationId";
                    readonly description: "A reserva atualmente selecionada pelo cliente na tela de detalhes da reserva";
                }, {
                    readonly targetRef: "Reservation.customerId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O ID do cliente autenticado obtido da sessão, usado para verificar que o cliente é o dono da reserva";
                }, {
                    readonly targetRef: "Reservation.cancelledAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O timestamp atual do sistema registrado como momento do cancelamento";
                }, {
                    readonly targetRef: "Reservation.status";
                    readonly source: "workflowState";
                    readonly originRef: "Reservation.status";
                    readonly description: "O status atual da reserva é lido para validar que apenas reservas ativas ou prontas podem ser canceladas";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Reservation";
                    readonly keyField: "Reservation.reservationId";
                    readonly filters: readonly ["Reservation.status"];
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Reservation.reservationId", "Reservation.status", "Reservation.cancelledAt", "Reservation.cancelReason", "Reservation.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.reservationLifecycle.cancelReservation";
                readonly handlerName: "petShopCancelReservationHandler";
            }];
        };
    };
    export default cancelReservationController;
    export const pipeline: readonly [{
        readonly id: "cancelReservation__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/cancelReservation.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/cancelReservation.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/cancelReservation.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/http/dto/cancelReservation.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/reservation" {
    export type ReservationStatus = 'draft' | 'active' | 'ready' | 'delivered' | 'expired' | 'cancelled';
    export interface ReservationItem {
        reservationItemId: string;
        reservationId: string;
        productId: string;
        quantity: number;
        createdAt: string;
        updatedAt: string;
    }
    export interface Reservation {
        reservationId: string;
        customerId: string;
        status: ReservationStatus;
        confirmedAt: string | null;
        expiresAt: string;
        readyAt: string | null;
        deliveredAt: string | null;
        expiredAt: string | null;
        cancelledAt: string | null;
        cancelReason: string | null;
        paymentId: string | null;
        reservationItems: ReservationItem[];
        createdAt: string;
        updatedAt: string;
    }
    export function reservationRequiresConfirmedAt(input: Pick<Reservation, 'status' | 'confirmedAt'>): boolean;
    export function reservationRequiresReadyAt(input: Pick<Reservation, 'status' | 'readyAt'>): boolean;
    export function reservationRequiresDeliveredAt(input: Pick<Reservation, 'status' | 'deliveredAt'>): boolean;
    export function reservationRequiresExpiredAt(input: Pick<Reservation, 'status' | 'expiredAt'>): boolean;
    export function reservationRequiresCancelledAt(input: Pick<Reservation, 'status' | 'cancelledAt'>): boolean;
    export function reservationPaymentRequiresDelivered(input: Pick<Reservation, 'status' | 'paymentId'>): boolean;
    export function reservationExpiresAfterConfirmedAt(input: Pick<Reservation, 'confirmedAt' | 'expiresAt'>): boolean;
}
declare module "_102049_/l1/petShop/layer_2_application/ports/reservationRepository" {
    import type { Reservation, ReservationStatus } from "_102049_/l1/petShop/layer_3_domain/entities/reservation";
    export interface ReservationFilter {
        customerId?: string;
        status?: ReservationStatus;
    }
    export interface IReservationRepository {
        getById(id: string): Promise<Reservation>;
        list(filter: ReservationFilter): Promise<Reservation[]>;
        save(reservation: Reservation): Promise<void>;
        findByCustomerId(customerId: string): Promise<Reservation[]>;
        findByStatus(status: ReservationStatus): Promise<Reservation[]>;
    }
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/cancelReservation" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CancelReservationInput {
        reservationId: string;
        cancelReason?: string;
    }
    export interface RestoredProduct {
        productId: string;
        available: boolean;
    }
    export interface CancelReservationOutput {
        reservationId: string;
        status: string;
        cancelledAt: string;
        cancelReason?: string;
        updatedAt: string;
        restoredProducts: RestoredProduct[];
    }
    export function cancelReservation(ctx: RequestContext, input: CancelReservationInput): Promise<CancelReservationOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/dto/cancelReservation" {
    import type { CancelReservationOutput } from "_102049_/l1/petShop/layer_2_application/usecases/cancelReservation";
    export type CancelReservationResponseDto = CancelReservationOutput;
    export function toDto(result: CancelReservationOutput): CancelReservationResponseDto;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/cancelReservation" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopCancelReservationHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createProduct.defs" {
    export const createProductController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createProduct";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createProduct";
            readonly controllerName: "CreateProductController";
            readonly ownerKind: "operation";
            readonly outputSource: "dto";
            readonly dtoTypeName: "CreateProductResponseDto";
            readonly dtoModulePath: "_102049_/l1/petShop/layer_1_external/adapters/http/dto/createProduct.js";
            readonly usecaseOutputTypeName: "CreateProductOutput";
            readonly responseShape: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "highlighted";
                    readonly type: "boolean";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly handlers: readonly [{
                readonly handlerName: "petShopCreateProductHandler";
                readonly command: "createProduct";
                readonly usecaseRef: "createProduct";
                readonly inputTypeName: "CreateProductInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "name";
                    readonly fieldRef: "Product.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do produto informado pela loja.";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "Product.description";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Descrição detalhada do produto (opcional).";
                }, {
                    readonly inputId: "price";
                    readonly fieldRef: "Product.price";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Preço do produto informado pela loja.";
                }, {
                    readonly inputId: "petTypeId";
                    readonly fieldRef: "Product.petTypeId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Referência ao tipo de pet indicado para o produto.";
                }, {
                    readonly inputId: "categoryId";
                    readonly fieldRef: "Product.categoryId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Referência à categoria do catálogo à qual o produto pertence.";
                }, {
                    readonly inputId: "highlighted";
                    readonly fieldRef: "Product.highlighted";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indica se o produto deve ser marcado como destaque pela loja.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Product.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Disponibilidade do produto: available ou unavailable.";
                }, {
                    readonly inputId: "productId";
                    readonly fieldRef: "Product.productId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Identificador único gerado automaticamente para o novo produto.";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "Product.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora de criação definidas automaticamente.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Product.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização, igual à de criação no cadastro.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Product.productId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "O backend gera um UUID para o novo produto antes de persistir.";
                }, {
                    readonly targetRef: "Product.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define a data e hora atuais no momento da criação.";
                }, {
                    readonly targetRef: "Product.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define a data e hora atuais, iguais ao createdAt no cadastro.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Product";
                    readonly keyField: "Product.productId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Product.productId", "Product.name", "Product.description", "Product.price", "Product.petTypeId", "Product.categoryId", "Product.highlighted", "Product.status", "Product.createdAt", "Product.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.createProduct.createProduct";
                readonly handlerName: "petShopCreateProductHandler";
            }];
        };
    };
    export default createProductController;
    export const pipeline: readonly [{
        readonly id: "createProduct__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createProduct.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createProduct.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/createProduct.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/http/dto/createProduct.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/createProduct" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateProductInput {
        name: string;
        description?: string;
        price: number;
        petTypeId: string;
        categoryId: string;
        highlighted: boolean;
        status: string;
    }
    export interface CreateProductOutput {
        productId: string;
        name: string;
        description?: string;
        price: number;
        petTypeId: string;
        categoryId: string;
        highlighted: boolean;
        status: string;
        createdAt: string;
        updatedAt: string;
    }
    export function createProduct(ctx: RequestContext, input: CreateProductInput): Promise<CreateProductOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/dto/createProduct" {
    import type { CreateProductOutput } from "_102049_/l1/petShop/layer_2_application/usecases/createProduct";
    export type CreateProductResponseDto = CreateProductOutput;
    export function toDto(result: CreateProductOutput): CreateProductResponseDto;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createProduct" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopCreateProductHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createReservation.defs" {
    export const createReservationController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createReservation";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "reservationLifecycle";
            readonly controllerName: "CreateReservationController";
            readonly ownerKind: "operation";
            readonly outputSource: "dto";
            readonly dtoTypeName: "CreateReservationResponseDto";
            readonly dtoModulePath: "_102049_/l1/petShop/layer_1_external/adapters/http/dto/createReservation.js";
            readonly usecaseOutputTypeName: "CreateReservationOutput";
            readonly responseShape: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "customerId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "confirmedAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "expiresAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "items";
                    readonly type: "array";
                    readonly required: true;
                }];
            };
            readonly handlers: readonly [{
                readonly handlerName: "petShopCreateReservationHandler";
                readonly command: "createReservation";
                readonly usecaseRef: "createReservation";
                readonly inputTypeName: "CreateReservationInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "items";
                    readonly fieldRef: "ReservationItem.productId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Lista de produtos e quantidades que o cliente deseja reservar para retirada na loja";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Reservation.customerId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O identificador do cliente autenticado é obtido da sessão ativa do actor";
                }, {
                    readonly targetRef: "Reservation.reservationId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "Um novo UUID é gerado pelo sistema para o identificador da reserva";
                }, {
                    readonly targetRef: "Reservation.status";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O status é definido como 'active' pois a reserva é confirmada no momento da criação";
                }, {
                    readonly targetRef: "Reservation.confirmedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O momento de confirmação é definido como o timestamp atual do sistema";
                }, {
                    readonly targetRef: "Reservation.expiresAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O prazo de expiração é calculado como o timestamp atual mais 24 horas, conforme a regra de expiração";
                }, {
                    readonly targetRef: "Reservation.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O momento de criação é definido como o timestamp atual do sistema";
                }, {
                    readonly targetRef: "Reservation.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O momento da última atualização é definido como o timestamp atual do sistema";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Reservation";
                    readonly keyField: "Reservation.reservationId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["Reservation.reservationId", "Reservation.customerId", "Reservation.status", "Reservation.expiresAt", "Reservation.createdAt", "Reservation.updatedAt", "ReservationItem.productId", "ReservationItem.quantity"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.reservationLifecycle.createReservation";
                readonly handlerName: "petShopCreateReservationHandler";
            }];
        };
    };
    export default createReservationController;
    export const pipeline: readonly [{
        readonly id: "createReservation__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createReservation.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createReservation.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/createReservation.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/http/dto/createReservation.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/createReservation" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateReservationItemInput {
        productId: string;
        quantity: number;
    }
    export interface CreateReservationInput {
        items: CreateReservationItemInput[];
    }
    export interface CreateReservationOutputItem {
        reservationItemId: string;
        productId: string;
        quantity: number;
    }
    export interface CreateReservationOutput {
        reservationId: string;
        customerId: string;
        status: string;
        confirmedAt: string;
        expiresAt: string;
        createdAt: string;
        updatedAt: string;
        items: CreateReservationOutputItem[];
    }
    export function createReservation(ctx: RequestContext, input: CreateReservationInput): Promise<CreateReservationOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/dto/createReservation" {
    import type { CreateReservationOutput } from "_102049_/l1/petShop/layer_2_application/usecases/createReservation";
    export type CreateReservationResponseDto = CreateReservationOutput;
    export function toDto(result: CreateReservationOutput): CreateReservationResponseDto;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/createReservation" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopCreateReservationHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/expireReservations.defs" {
    export const expireReservationsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "expireReservations";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "reservationLifecycle";
            readonly controllerName: "ExpireReservationsController";
            readonly ownerKind: "operation";
            readonly outputSource: "dto";
            readonly dtoTypeName: "ExpireReservationsResponseDto";
            readonly dtoModulePath: "_102049_/l1/petShop/layer_1_external/adapters/http/dto/expireReservations.js";
            readonly usecaseOutputTypeName: "ExpireReservationsOutput";
            readonly responseShape: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "expiredCount";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "expiredReservations";
                    readonly type: "array";
                    readonly required: true;
                }, {
                    readonly name: "productsReleased";
                    readonly type: "number";
                    readonly required: true;
                }];
            };
            readonly handlers: readonly [{
                readonly handlerName: "petShopExpireReservationsHandler";
                readonly command: "expireReservations";
                readonly usecaseRef: "expireReservations";
                readonly inputTypeName: "ExpireReservationsInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "currentTimestamp";
                    readonly fieldRef: "Reservation.expiresAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora atual do sistema usada para comparar com expiresAt e identificar reservas vencidas";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "Reservation.reservationId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identidade da loja autenticada que dispara a expiração em lote das reservas vencidas";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Reservation.expiresAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Obtém o timestamp atual do sistema para comparar com o campo expiresAt de cada reserva ativa ou pronta e determinar quais estão vencidas";
                }, {
                    readonly targetRef: "Reservation.reservationId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "Identifica a loja autenticada na sessão para autorizar a operação de expiração em lote sobre as reservas";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Reservation";
                    readonly keyField: "Reservation.reservationId";
                    readonly pagination: "none";
                    readonly selection: "multiple";
                    readonly output: readonly ["Reservation.reservationId", "Reservation.status", "Reservation.expiredAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.reservationLifecycle.expireReservations";
                readonly handlerName: "petShopExpireReservationsHandler";
            }];
        };
    };
    export default expireReservationsController;
    export const pipeline: readonly [{
        readonly id: "expireReservations__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/expireReservations.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/expireReservations.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/expireReservations.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/http/dto/expireReservations.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/payment" {
    export type PaymentMethod = 'cash' | 'creditCard' | 'debitCard' | 'pix';
    export type PaymentStatus = 'posted' | 'voided';
    export interface Payment {
        paymentId: string;
        reservationId: string;
        amount: number;
        paymentMethod: PaymentMethod;
        status: PaymentStatus;
        voidedAt: string | null;
        voidReason: string | null;
        createdAt: string;
    }
    export const PAYMENT_STATUS_TRANSITIONS: Record<PaymentStatus, PaymentStatus[]>;
    export function canTransitionPayment(from: PaymentStatus, to: PaymentStatus): boolean;
    export function isPaymentActive(payment: Pick<Payment, 'status'>): boolean;
    export function isPaymentVoided(payment: Pick<Payment, 'status'>): boolean;
}
declare module "_102049_/l1/petShop/layer_2_application/ports/paymentRepository" {
    import type { Payment } from "_102049_/l1/petShop/layer_3_domain/entities/payment";
    export type PaymentEvent = Payment;
    export interface IPaymentRepository {
        append(record: PaymentEvent): Promise<void>;
        listByOwnerId(ownerId: string): Promise<PaymentEvent[]>;
        listByPeriod(from: Date, to: Date): Promise<PaymentEvent[]>;
    }
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/expireReservations" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ExpireReservationsInput {
    }
    export interface ExpiredReservationSummary {
        reservationId: string;
        status: string;
        expiredAt: string;
    }
    export interface ExpireReservationsOutput {
        expiredCount: number;
        expiredReservations: ExpiredReservationSummary[];
        productsReleased: number;
    }
    export function expireReservations(ctx: RequestContext, input: ExpireReservationsInput): Promise<ExpireReservationsOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/dto/expireReservations" {
    import type { ExpireReservationsOutput } from "_102049_/l1/petShop/layer_2_application/usecases/expireReservations";
    export type ExpireReservationsResponseDto = ExpireReservationsOutput;
    export function toDto(result: ExpireReservationsOutput): ExpireReservationsResponseDto;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/expireReservations" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopExpireReservationsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/filterProducts.defs" {
    export const filterProductsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "filterProducts";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "filterProducts";
            readonly controllerName: "FilterProductsController";
            readonly ownerKind: "operation";
            readonly outputSource: "dto";
            readonly dtoTypeName: "FilterProductsResponseDto";
            readonly dtoModulePath: "_102049_/l1/petShop/layer_1_external/adapters/http/dto/filterProducts.js";
            readonly usecaseOutputTypeName: "FilterProductsOutput";
            readonly responseShape: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "highlighted";
                    readonly type: "boolean";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly handlers: readonly [{
                readonly handlerName: "petShopFilterProductsHandler";
                readonly command: "filterProducts";
                readonly usecaseRef: "filterProducts";
                readonly inputTypeName: "FilterProductsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "petTypeId";
                    readonly fieldRef: "Product.petTypeId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Tipo de pet selecionado para filtrar o catálogo (ex.: cão, gato).";
                }, {
                    readonly inputId: "categoryId";
                    readonly fieldRef: "Product.categoryId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Categoria selecionada para filtrar o catálogo (ex.: ração, brinquedo).";
                }, {
                    readonly inputId: "minPrice";
                    readonly fieldRef: "Product.price";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Preço mínimo da faixa de valor informada pelo cliente.";
                }, {
                    readonly inputId: "maxPrice";
                    readonly fieldRef: "Product.price";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Preço máximo da faixa de valor informada pelo cliente.";
                }];
                readonly contextResolution: readonly [];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Product";
                    readonly keyField: "Product.productId";
                    readonly pagination: "optional";
                    readonly selection: "multiple";
                    readonly output: readonly ["Product.productId", "Product.name", "Product.description", "Product.price", "Product.petTypeId", "Product.categoryId", "Product.highlighted", "Product.status"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.filterProducts.filterProducts";
                readonly handlerName: "petShopFilterProductsHandler";
            }];
        };
    };
    export default filterProductsController;
    export const pipeline: readonly [{
        readonly id: "filterProducts__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/filterProducts.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/filterProducts.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/filterProducts.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/http/dto/filterProducts.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/filterProducts" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface FilterProductsInput {
        petTypeId?: string;
        categoryId?: string;
        minPrice?: number;
        maxPrice?: number;
    }
    export interface FilterProductsItem {
        productId: string;
        name: string;
        description: string | null;
        price: number;
        petTypeId: string;
        categoryId: string;
        highlighted: boolean;
        status: string;
    }
    export interface FilterProductsOutput {
        products: FilterProductsItem[];
    }
    export function filterProducts(ctx: RequestContext, input: FilterProductsInput): Promise<FilterProductsOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/dto/filterProducts" {
    import type { FilterProductsOutput } from "_102049_/l1/petShop/layer_2_application/usecases/filterProducts";
    export type FilterProductsResponseDto = FilterProductsOutput;
    export function toDto(result: FilterProductsOutput): FilterProductsResponseDto;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/filterProducts" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopFilterProductsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/listReservations.defs" {
    export const listReservationsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "listReservations";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "listReservations";
            readonly controllerName: "ListReservationsController";
            readonly ownerKind: "operation";
            readonly outputSource: "dto";
            readonly dtoTypeName: "ListReservationsResponseDto";
            readonly dtoModulePath: "_102049_/l1/petShop/layer_1_external/adapters/http/dto/listReservations.js";
            readonly usecaseOutputTypeName: "ListReservationsOutput";
            readonly responseShape: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "customerId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "confirmedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "expiresAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "readyAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "deliveredAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "items";
                    readonly type: "array";
                    readonly required: true;
                }];
            };
            readonly handlers: readonly [{
                readonly handlerName: "petShopListReservationsHandler";
                readonly command: "listReservations";
                readonly usecaseRef: "listReservations";
                readonly inputTypeName: "ListReservationsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "status";
                    readonly fieldRef: "Reservation.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional por status da reserva (draft, active, ready, delivered, expired, cancelled)";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "actorSession.actorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "Identidade da loja autenticada obtida da sessão para autorizar o acesso à lista de reservas recebidas";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Reservation";
                    readonly keyField: "Reservation.reservationId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["Reservation.reservationId", "Reservation.customerId", "Reservation.status", "Reservation.confirmedAt", "Reservation.expiresAt", "Reservation.readyAt", "Reservation.deliveredAt", "Reservation.createdAt", "Reservation.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.listReservations.listReservations";
                readonly handlerName: "petShopListReservationsHandler";
            }];
        };
    };
    export default listReservationsController;
    export const pipeline: readonly [{
        readonly id: "listReservations__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/listReservations.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/listReservations.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/listReservations.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/http/dto/listReservations.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/listReservations" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ListReservationsInput {
        status?: string;
    }
    export interface ListReservationsItemItem {
        reservationItemId: string;
        productId: string;
        quantity: number;
    }
    export interface ListReservationsItem {
        reservationId: string;
        customerId: string;
        status: string;
        confirmedAt?: string;
        expiresAt: string;
        readyAt?: string;
        deliveredAt?: string;
        createdAt: string;
        updatedAt: string;
        items: ListReservationsItemItem[];
    }
    export interface ListReservationsOutput extends Array<ListReservationsItem> {
    }
    export function listReservations(ctx: RequestContext, input: ListReservationsInput): Promise<ListReservationsOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/dto/listReservations" {
    import type { ListReservationsOutput } from "_102049_/l1/petShop/layer_2_application/usecases/listReservations";
    export type ListReservationsResponseDto = ListReservationsOutput;
    export function toDto(result: ListReservationsOutput): ListReservationsResponseDto;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/listReservations" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopListReservationsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/payInStore.defs" {
    export const payInStoreController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "payInStore";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "reservationLifecycle";
            readonly controllerName: "PayInStoreController";
            readonly ownerKind: "operation";
            readonly outputSource: "dto";
            readonly dtoTypeName: "PayInStoreResponseDto";
            readonly dtoModulePath: "_102049_/l1/petShop/layer_1_external/adapters/http/dto/payInStore.js";
            readonly usecaseOutputTypeName: "PayInStoreOutput";
            readonly responseShape: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "deliveredAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "paymentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly handlers: readonly [{
                readonly handlerName: "petShopPayInStoreHandler";
                readonly command: "payInStore";
                readonly usecaseRef: "payInStore";
                readonly inputTypeName: "PayInStoreInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "reservationId";
                    readonly fieldRef: "Reservation.reservationId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador da reserva selecionada para pagamento e retirada";
                }, {
                    readonly inputId: "paymentMethod";
                    readonly fieldRef: "Payment.method";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Método de pagamento utilizado no balcão (dinheiro, cartão, pix, etc.)";
                }, {
                    readonly inputId: "paymentAmount";
                    readonly fieldRef: "Payment.amount";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Valor do pagamento realizado presencialmente";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Reservation.reservationId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Reservation.reservationId";
                    readonly description: "A reserva atualmente selecionada pela loja no painel de retirada";
                }, {
                    readonly targetRef: "Reservation.deliveredAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Timestamp atual do sistema registrado como momento da entrega";
                }, {
                    readonly targetRef: "Reservation.paymentId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "UUID gerado pelo sistema para o novo registro de pagamento";
                }, {
                    readonly targetRef: "Reservation.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Timestamp atual do sistema registrado como momento da última atualização da reserva";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Reservation";
                    readonly keyField: "Reservation.reservationId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Reservation.reservationId", "Reservation.status", "Reservation.deliveredAt", "Reservation.paymentId", "Reservation.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.reservationLifecycle.payInStore";
                readonly handlerName: "petShopPayInStoreHandler";
            }];
        };
    };
    export default payInStoreController;
    export const pipeline: readonly [{
        readonly id: "payInStore__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/payInStore.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/payInStore.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/payInStore.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/http/dto/payInStore.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/payInStore" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface PayInStoreInput {
        reservationId: string;
        paymentMethod: string;
        paymentAmount: number;
    }
    export interface PayInStoreOutput {
        reservationId: string;
        status: string;
        deliveredAt: string;
        paymentId: string;
        updatedAt: string;
    }
    export function payInStore(ctx: RequestContext, input: PayInStoreInput): Promise<PayInStoreOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/dto/payInStore" {
    import type { PayInStoreOutput } from "_102049_/l1/petShop/layer_2_application/usecases/payInStore";
    export type PayInStoreResponseDto = PayInStoreOutput;
    export function toDto(result: PayInStoreOutput): PayInStoreResponseDto;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/payInStore" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopPayInStoreHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/searchProducts.defs" {
    export const searchProductsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "searchProducts";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "searchProducts";
            readonly controllerName: "SearchProductsController";
            readonly ownerKind: "operation";
            readonly outputSource: "dto";
            readonly dtoTypeName: "SearchProductsResponseDto";
            readonly dtoModulePath: "_102049_/l1/petShop/layer_1_external/adapters/http/dto/searchProducts.js";
            readonly usecaseOutputTypeName: "SearchProductsOutput";
            readonly responseShape: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "petTypeName";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "categoryName";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "highlighted";
                    readonly type: "boolean";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly handlers: readonly [{
                readonly handlerName: "petShopSearchProductsHandler";
                readonly command: "searchProducts";
                readonly usecaseRef: "searchProducts";
                readonly inputTypeName: "SearchProductsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "searchTerm";
                    readonly fieldRef: "Product.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Termo de busca digitado pelo cliente para encontrar produtos por nome (correspondência parcial e insensível a caixa)";
                }, {
                    readonly inputId: "petTypeId";
                    readonly fieldRef: "Product.petTypeId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional por tipo de pet indicado para o produto";
                }, {
                    readonly inputId: "categoryId";
                    readonly fieldRef: "Product.categoryId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional por categoria do catálogo";
                }, {
                    readonly inputId: "minPrice";
                    readonly fieldRef: "Product.price";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional de preço mínimo para faixa de valor";
                }, {
                    readonly inputId: "maxPrice";
                    readonly fieldRef: "Product.price";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional de preço máximo para faixa de valor";
                }];
                readonly contextResolution: readonly [];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Product";
                    readonly keyField: "Product.productId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["Product.productId", "Product.name", "Product.description", "Product.price", "Product.petTypeId", "Product.categoryId", "Product.highlighted", "Product.status"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.searchProducts.searchProducts";
                readonly handlerName: "petShopSearchProductsHandler";
            }];
        };
    };
    export default searchProductsController;
    export const pipeline: readonly [{
        readonly id: "searchProducts__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/searchProducts.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/searchProducts.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/searchProducts.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/http/dto/searchProducts.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/searchProducts" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface SearchProductsInput {
        searchTerm: string;
        petTypeId?: string;
        categoryId?: string;
        minPrice?: number;
        maxPrice?: number;
    }
    export interface SearchProductItem {
        productId: string;
        name: string;
        description?: string;
        price: number;
        petTypeId: string;
        petTypeName: string;
        categoryId: string;
        categoryName: string;
        highlighted: boolean;
        status: string;
    }
    export interface SearchProductsOutput {
        products: SearchProductItem[];
    }
    export function searchProducts(ctx: RequestContext, input: SearchProductsInput): Promise<SearchProductsOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/dto/searchProducts" {
    import type { SearchProductsOutput } from "_102049_/l1/petShop/layer_2_application/usecases/searchProducts";
    export type SearchProductsResponseDto = SearchProductsOutput;
    export function toDto(result: SearchProductsOutput): SearchProductsResponseDto;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/searchProducts" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopSearchProductsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/setProductHighlights.defs" {
    export const setProductHighlightsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "setProductHighlights";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "setProductHighlights";
            readonly controllerName: "SetProductHighlightsController";
            readonly ownerKind: "operation";
            readonly outputSource: "dto";
            readonly dtoTypeName: "SetProductHighlightsResponseDto";
            readonly dtoModulePath: "_102049_/l1/petShop/layer_1_external/adapters/http/dto/setProductHighlights.js";
            readonly usecaseOutputTypeName: "SetProductHighlightsOutput";
            readonly responseShape: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "updatedCount";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "products";
                    readonly type: "array";
                    readonly required: true;
                }];
            };
            readonly handlers: readonly [{
                readonly handlerName: "petShopSetProductHighlightsHandler";
                readonly command: "setProductHighlights";
                readonly usecaseRef: "setProductHighlights";
                readonly inputTypeName: "SetProductHighlightsInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "productIds";
                    readonly fieldRef: "Product.productId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Lista de IDs dos produtos que terão o destaque alterado.";
                }, {
                    readonly inputId: "highlighted";
                    readonly fieldRef: "Product.highlighted";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Valor do destaque a ser aplicado: true para marcar como destaque, false para remover o destaque.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "actorSession.actorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "Identidade da loja autenticada obtida da sessão para autorizar a alteração manual de destaques de produtos.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Product";
                    readonly keyField: "Product.productId";
                    readonly pagination: "none";
                    readonly selection: "multiple";
                    readonly output: readonly ["Product.productId", "Product.name", "Product.highlighted", "Product.status"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.setProductHighlights.setProductHighlights";
                readonly handlerName: "petShopSetProductHighlightsHandler";
            }];
        };
    };
    export default setProductHighlightsController;
    export const pipeline: readonly [{
        readonly id: "setProductHighlights__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/setProductHighlights.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/setProductHighlights.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/setProductHighlights.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/http/dto/setProductHighlights.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/setProductHighlights" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface SetProductHighlightsInput {
        productIds: string[];
        highlighted: boolean;
    }
    export interface SetProductHighlightsProduct {
        productId: string;
        name: string;
        highlighted: boolean;
        status: string;
    }
    export interface SetProductHighlightsOutput {
        updatedCount: number;
        products: SetProductHighlightsProduct[];
    }
    export function setProductHighlights(ctx: RequestContext, input: SetProductHighlightsInput): Promise<SetProductHighlightsOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/dto/setProductHighlights" {
    import type { SetProductHighlightsOutput } from "_102049_/l1/petShop/layer_2_application/usecases/setProductHighlights";
    export type SetProductHighlightsResponseDto = SetProductHighlightsOutput;
    export function toDto(result: SetProductHighlightsOutput): SetProductHighlightsResponseDto;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/setProductHighlights" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopSetProductHighlightsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateProduct.defs" {
    export const updateProductController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateProduct";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateProduct";
            readonly controllerName: "UpdateProductController";
            readonly ownerKind: "operation";
            readonly outputSource: "dto";
            readonly dtoTypeName: "UpdateProductResponseDto";
            readonly dtoModulePath: "_102049_/l1/petShop/layer_1_external/adapters/http/dto/updateProduct.js";
            readonly usecaseOutputTypeName: "UpdateProductOutput";
            readonly responseShape: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "highlighted";
                    readonly type: "boolean";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly handlers: readonly [{
                readonly handlerName: "petShopUpdateProductHandler";
                readonly command: "updateProduct";
                readonly usecaseRef: "updateProduct";
                readonly inputTypeName: "UpdateProductInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "productId";
                    readonly fieldRef: "Product.productId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador do produto que está sendo editado";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "Product.name";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Novo nome do produto, se alterado";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "Product.description";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Nova descrição do produto, se alterada";
                }, {
                    readonly inputId: "price";
                    readonly fieldRef: "Product.price";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Novo preço do produto, se alterado";
                }, {
                    readonly inputId: "petTypeId";
                    readonly fieldRef: "Product.petTypeId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Novo tipo de pet indicado para o produto, se alterado";
                }, {
                    readonly inputId: "categoryId";
                    readonly fieldRef: "Product.categoryId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Nova categoria do produto, se alterada";
                }, {
                    readonly inputId: "highlighted";
                    readonly fieldRef: "Product.highlighted";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Nova flag de destaque do produto, se alterada";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Product.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Nova disponibilidade do produto (available ou unavailable), se alterada";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Product.productId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Product.productId";
                    readonly description: "O productId é obtido do produto atualmente selecionado pela loja na tela de edição do catálogo";
                }, {
                    readonly targetRef: "Product.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O campo updatedAt é preenchido automaticamente com a data e hora atuais no momento da persistência da alteração";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Product";
                    readonly keyField: "Product.productId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Product.productId", "Product.name", "Product.description", "Product.price", "Product.petTypeId", "Product.categoryId", "Product.highlighted", "Product.status", "Product.createdAt", "Product.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.updateProduct.updateProduct";
                readonly handlerName: "petShopUpdateProductHandler";
            }];
        };
    };
    export default updateProductController;
    export const pipeline: readonly [{
        readonly id: "updateProduct__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateProduct.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateProduct.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/updateProduct.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/http/dto/updateProduct.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/updateProduct" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateProductInput {
        productId: string;
        name?: string;
        description?: string;
        price?: number;
        petTypeId?: string;
        categoryId?: string;
        highlighted?: boolean;
        status?: string;
    }
    export interface UpdateProductOutput {
        productId: string;
        name: string;
        description: string | null;
        price: number;
        petTypeId: string;
        categoryId: string;
        highlighted: boolean;
        status: string;
        createdAt: string;
        updatedAt: string;
    }
    export function updateProduct(ctx: RequestContext, input: UpdateProductInput): Promise<UpdateProductOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/dto/updateProduct" {
    import type { UpdateProductOutput } from "_102049_/l1/petShop/layer_2_application/usecases/updateProduct";
    export type UpdateProductResponseDto = UpdateProductOutput;
    export function toDto(result: UpdateProductOutput): UpdateProductResponseDto;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateProduct" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopUpdateProductHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateReservationStatus.defs" {
    export const updateReservationStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateReservationStatus";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "reservationLifecycle";
            readonly controllerName: "UpdateReservationStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "dto";
            readonly dtoTypeName: "UpdateReservationStatusResponseDto";
            readonly dtoModulePath: "_102049_/l1/petShop/layer_1_external/adapters/http/dto/updateReservationStatus.js";
            readonly usecaseOutputTypeName: "UpdateReservationStatusOutput";
            readonly responseShape: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "readyAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "deliveredAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "cancelledAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "cancelReason";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "paymentId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly handlers: readonly [{
                readonly handlerName: "petShopUpdateReservationStatusHandler";
                readonly command: "updateReservationStatus";
                readonly usecaseRef: "updateReservationStatus";
                readonly inputTypeName: "UpdateReservationStatusInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "reservationId";
                    readonly fieldRef: "Reservation.reservationId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador da reserva cujo status será atualizado";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Reservation.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Novo status da reserva: ready, delivered ou cancelled";
                }, {
                    readonly inputId: "cancelReason";
                    readonly fieldRef: "Reservation.cancelReason";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Motivo do cancelamento, obrigatório apenas quando o status for cancelled";
                }, {
                    readonly inputId: "paymentId";
                    readonly fieldRef: "Reservation.paymentId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Referência ao pagamento presencial, informado apenas quando o status for delivered";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Reservation.reservationId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Reservation.reservationId";
                    readonly description: "A reserva atualmente selecionada pela loja na tela de gestão de reservas";
                }, {
                    readonly targetRef: "Reservation.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O timestamp atual do sistema é gravado no campo updatedAt ao persistir a alteração de status";
                }, {
                    readonly targetRef: "Reservation.readyAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Quando o status muda para ready, o sistema registra o timestamp atual no campo readyAt";
                }, {
                    readonly targetRef: "Reservation.deliveredAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Quando o status muda para delivered, o sistema registra o timestamp atual no campo deliveredAt";
                }, {
                    readonly targetRef: "Reservation.cancelledAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Quando o status muda para cancelled, o sistema registra o timestamp atual no campo cancelledAt";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Reservation";
                    readonly keyField: "Reservation.reservationId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Reservation.reservationId", "Reservation.status", "Reservation.readyAt", "Reservation.deliveredAt", "Reservation.cancelledAt", "Reservation.cancelReason", "Reservation.paymentId", "Reservation.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.reservationLifecycle.updateReservationStatus";
                readonly handlerName: "petShopUpdateReservationStatusHandler";
            }];
        };
    };
    export default updateReservationStatusController;
    export const pipeline: readonly [{
        readonly id: "updateReservationStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateReservationStatus.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateReservationStatus.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/updateReservationStatus.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/http/dto/updateReservationStatus.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/updateReservationStatus" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateReservationStatusInput {
        reservationId: string;
        status: string;
        cancelReason?: string;
        paymentId?: string;
    }
    export interface UpdateReservationStatusOutput {
        reservationId: string;
        status: string;
        readyAt: string | null;
        deliveredAt: string | null;
        cancelledAt: string | null;
        cancelReason: string | null;
        paymentId: string | null;
        updatedAt: string;
    }
    export function updateReservationStatus(ctx: RequestContext, input: UpdateReservationStatusInput): Promise<UpdateReservationStatusOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/dto/updateReservationStatus" {
    import type { UpdateReservationStatusOutput } from "_102049_/l1/petShop/layer_2_application/usecases/updateReservationStatus";
    export type UpdateReservationStatusResponseDto = UpdateReservationStatusOutput;
    export function toDto(result: UpdateReservationStatusOutput): UpdateReservationStatusResponseDto;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/updateReservationStatus" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopUpdateReservationStatusHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewHighlights.defs" {
    export const viewHighlightsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewHighlights";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewHighlights";
            readonly controllerName: "ViewHighlightsController";
            readonly ownerKind: "operation";
            readonly outputSource: "dto";
            readonly dtoTypeName: "ViewHighlightsResponseDto";
            readonly dtoModulePath: "_102049_/l1/petShop/layer_1_external/adapters/http/dto/viewHighlights.js";
            readonly usecaseOutputTypeName: "ViewHighlightsOutput";
            readonly responseShape: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "highlighted";
                    readonly type: "boolean";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly handlers: readonly [{
                readonly handlerName: "petShopViewHighlightsHandler";
                readonly command: "viewHighlights";
                readonly usecaseRef: "viewHighlights";
                readonly inputTypeName: "ViewHighlightsInput";
                readonly kind: "view";
                readonly inputContract: readonly [];
                readonly contextResolution: readonly [];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Product";
                    readonly keyField: "Product.productId";
                    readonly pagination: "optional";
                    readonly selection: "multiple";
                    readonly output: readonly ["Product.productId", "Product.name", "Product.description", "Product.price", "Product.petTypeId", "Product.categoryId", "Product.highlighted", "Product.status"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.viewHighlights.viewHighlights";
                readonly handlerName: "petShopViewHighlightsHandler";
            }];
        };
    };
    export default viewHighlightsController;
    export const pipeline: readonly [{
        readonly id: "viewHighlights__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewHighlights.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewHighlights.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/viewHighlights.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/http/dto/viewHighlights.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/viewHighlights" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewHighlightsInput {
    }
    export interface ViewHighlightsOutput {
        productId: string;
        name: string;
        description: string | null;
        price: number;
        petTypeId: string;
        categoryId: string;
        highlighted: boolean;
        status: string;
    }
    export function viewHighlights(ctx: RequestContext, _input: ViewHighlightsInput): Promise<ViewHighlightsOutput[]>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/dto/viewHighlights" {
    import type { ViewHighlightsOutput } from "_102049_/l1/petShop/layer_2_application/usecases/viewHighlights";
    export type ViewHighlightsResponseDto = ViewHighlightsOutput;
    export function toDto(result: ViewHighlightsOutput): ViewHighlightsResponseDto;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewHighlights" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopViewHighlightsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewMyReservations.defs" {
    export const viewMyReservationsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewMyReservations";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewMyReservations";
            readonly controllerName: "ViewMyReservationsController";
            readonly ownerKind: "operation";
            readonly outputSource: "dto";
            readonly dtoTypeName: "ViewMyReservationsResponseDto";
            readonly dtoModulePath: "_102049_/l1/petShop/layer_1_external/adapters/http/dto/viewMyReservations.js";
            readonly usecaseOutputTypeName: "ViewMyReservationsOutput";
            readonly responseShape: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "expiresAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "confirmedAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "readyAt";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "items";
                    readonly type: "array";
                    readonly required: true;
                }];
            };
            readonly handlers: readonly [{
                readonly handlerName: "petShopViewMyReservationsHandler";
                readonly command: "viewMyReservations";
                readonly usecaseRef: "viewMyReservations";
                readonly inputTypeName: "ViewMyReservationsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "customerId";
                    readonly fieldRef: "Reservation.customerId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do cliente autenticado obtido da sessão para filtrar apenas suas reservas";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Reservation.customerId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O customerId é resolvido a partir do identificador do ator autenticado na sessão, garantindo que o cliente só veja suas próprias reservas";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Reservation";
                    readonly keyField: "Reservation.reservationId";
                    readonly filters: readonly ["Reservation.customerId"];
                    readonly sort: readonly ["Reservation.createdAt"];
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["Reservation.reservationId", "Reservation.status", "Reservation.expiresAt", "Reservation.createdAt", "Reservation.confirmedAt", "Reservation.readyAt", "ReservationItem.productId", "ReservationItem.quantity"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.viewMyReservations.viewMyReservations";
                readonly handlerName: "petShopViewMyReservationsHandler";
            }];
        };
    };
    export default viewMyReservationsController;
    export const pipeline: readonly [{
        readonly id: "viewMyReservations__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewMyReservations.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewMyReservations.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/viewMyReservations.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/http/dto/viewMyReservations.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/viewMyReservations" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewMyReservationsInput {
    }
    export interface ViewMyReservationsItem {
        productId: string;
        quantity: number;
    }
    export interface ViewMyReservationsEntry {
        reservationId: string;
        status: string;
        expiresAt: string;
        createdAt: string;
        confirmedAt?: string;
        readyAt?: string;
        items: ViewMyReservationsItem[];
    }
    export type ViewMyReservationsOutput = ViewMyReservationsEntry[];
    export function viewMyReservations(ctx: RequestContext, _input: ViewMyReservationsInput): Promise<ViewMyReservationsOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/dto/viewMyReservations" {
    import type { ViewMyReservationsOutput } from "_102049_/l1/petShop/layer_2_application/usecases/viewMyReservations";
    export type ViewMyReservationsResponseDto = ViewMyReservationsOutput;
    export function toDto(result: ViewMyReservationsOutput): ViewMyReservationsResponseDto;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewMyReservations" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopViewMyReservationsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewProductDetails.defs" {
    export const viewProductDetailsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewProductDetails";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewProductDetails";
            readonly controllerName: "ViewProductDetailsController";
            readonly ownerKind: "operation";
            readonly outputSource: "dto";
            readonly dtoTypeName: "ViewProductDetailsResponseDto";
            readonly dtoModulePath: "_102049_/l1/petShop/layer_1_external/adapters/http/dto/viewProductDetails.js";
            readonly usecaseOutputTypeName: "ViewProductDetailsOutput";
            readonly responseShape: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "petTypeName";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "categoryName";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "highlighted";
                    readonly type: "boolean";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly handlers: readonly [{
                readonly handlerName: "petShopViewProductDetailsHandler";
                readonly command: "viewProductDetails";
                readonly usecaseRef: "viewProductDetails";
                readonly inputTypeName: "ViewProductDetailsInput";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "productId";
                    readonly fieldRef: "Product.productId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identificador do produto selecionado pelo cliente na vitrine ou nos resultados de busca";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Product.productId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.productId";
                    readonly description: "O identificador do produto é extraído do parâmetro de rota da página de detalhes do produto";
                }, {
                    readonly targetRef: "PetType.name";
                    readonly source: "selectedEntity";
                    readonly originRef: "Product.petTypeId";
                    readonly description: "O nome do tipo de pet é resolvido consultando a entidade PetType pelo petTypeId do produto";
                }, {
                    readonly targetRef: "Category.name";
                    readonly source: "selectedEntity";
                    readonly originRef: "Product.categoryId";
                    readonly description: "O nome da categoria é resolvido consultando a entidade Category pelo categoryId do produto";
                }];
                readonly accessPattern: {
                    readonly kind: "getById";
                    readonly description: "";
                    readonly entity: "Product";
                    readonly keyField: "Product.productId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Product.productId", "Product.name", "Product.description", "Product.price", "Product.petTypeId", "Product.categoryId", "Product.highlighted", "Product.status", "Product.createdAt", "Product.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "petShop.viewProductDetails.viewProductDetails";
                readonly handlerName: "petShopViewProductDetailsHandler";
            }];
        };
    };
    export default viewProductDetailsController;
    export const pipeline: readonly [{
        readonly id: "viewProductDetails__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewProductDetails.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewProductDetails.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/viewProductDetails.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/http/dto/viewProductDetails.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/viewProductDetails" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewProductDetailsInput {
        productId: string;
    }
    export interface ViewProductDetailsOutput {
        productId: string;
        name: string;
        description?: string;
        price: number;
        petTypeId: string;
        petTypeName: string;
        categoryId: string;
        categoryName: string;
        highlighted: boolean;
        status: string;
        createdAt: string;
        updatedAt: string;
    }
    export function viewProductDetails(ctx: RequestContext, input: ViewProductDetailsInput): Promise<ViewProductDetailsOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/dto/viewProductDetails" {
    import type { ViewProductDetailsOutput } from "_102049_/l1/petShop/layer_2_application/usecases/viewProductDetails";
    export type ViewProductDetailsResponseDto = ViewProductDetailsOutput;
    export function toDto(result: ViewProductDetailsOutput): ViewProductDetailsResponseDto;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/viewProductDetails" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const petShopViewProductDetailsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/payment.defs" {
    export const paymentTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Payment";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Payment";
            readonly tableName: "payment";
            readonly columns: readonly [{
                readonly name: "payment_id";
                readonly type: "uuid";
                readonly nullable: false;
            }, {
                readonly name: "reservation_id";
                readonly type: "uuid";
                readonly nullable: false;
            }, {
                readonly name: "payment_method";
                readonly type: "text";
                readonly nullable: false;
            }, {
                readonly name: "status";
                readonly type: "text";
                readonly nullable: false;
            }, {
                readonly name: "created_at";
                readonly type: "timestamptz";
                readonly nullable: false;
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
            }];
            readonly primaryKey: readonly ["payment_id"];
            readonly indexes: readonly [{
                readonly indexName: "ix_payment_reservation_id";
                readonly columns: readonly ["reservation_id"];
            }, {
                readonly indexName: "ix_payment_payment_method";
                readonly columns: readonly ["payment_method"];
            }, {
                readonly indexName: "ix_payment_status";
                readonly columns: readonly ["status"];
            }, {
                readonly indexName: "ix_payment_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
            readonly appendOnly: true;
            readonly purpose: "controle";
            readonly retentionDays: 365;
        };
    };
    export default paymentTableDefinition;
    export const pipeline: readonly [{
        readonly id: "payment__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/payment.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/payment.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/payment" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const paymentTableDef: TableDefinition;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/paymentRepositoryAdapter.defs" {
    export const paymentRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "PaymentRepositoryAdapter";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "PaymentRepositoryAdapter";
            readonly entityId: "Payment";
            readonly portRef: "IPaymentRepository";
            readonly tableRef: "payments";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Append-only event adapter: insert one row only, no update/delete", "Real columns: payment_id, reservation_id, payment_method, status, created_at", "Details JSONB: amount, voidedAt, voidReason", "Implements append() + read finders (e.g., findByReservationId)", "Uses ctx.data.moduleData for local payments table reads/writes"];
        };
    };
    export default paymentRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "paymentRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/paymentRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/paymentRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/paymentRepository.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/persistence/payment.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/paymentRepositoryAdapter" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IPaymentRepository } from "_102049_/l1/petShop/layer_2_application/ports/paymentRepository";
    export function createPaymentRepositoryAdapter(ctx: RequestContext): IPaymentRepository;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/product.defs" {
    export const productTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Product";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Product";
            readonly tableName: "product";
            readonly columns: readonly [{
                readonly name: "product_id";
                readonly type: "uuid";
                readonly nullable: false;
            }, {
                readonly name: "pet_type_id";
                readonly type: "uuid";
                readonly nullable: false;
            }, {
                readonly name: "category_id";
                readonly type: "uuid";
                readonly nullable: false;
            }, {
                readonly name: "status";
                readonly type: "text";
                readonly nullable: false;
            }, {
                readonly name: "created_at";
                readonly type: "timestamptz";
                readonly nullable: false;
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
            }];
            readonly primaryKey: readonly ["product_id"];
            readonly indexes: readonly [{
                readonly indexName: "ix_product_pet_type_id";
                readonly columns: readonly ["pet_type_id"];
            }, {
                readonly indexName: "ix_product_category_id";
                readonly columns: readonly ["category_id"];
            }, {
                readonly indexName: "ix_product_status";
                readonly columns: readonly ["status"];
            }, {
                readonly indexName: "ix_product_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default productTableDefinition;
    export const pipeline: readonly [{
        readonly id: "product__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/product.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/product.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/product" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const productTableDef: TableDefinition;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/productRepositoryAdapter.defs" {
    export const productRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ProductRepositoryAdapter";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ProductRepositoryAdapter";
            readonly entityId: "Product";
            readonly portRef: "IProductRepository";
            readonly tableRef: "products";
            readonly mdmReads: readonly ["PetType", "Category"];
            readonly notes: readonly ["Real columns: product_id, pet_type_id, category_id, status, created_at", "Details JSONB: name, description, price, highlighted, updatedAt", "Resolves pet_type_id -> PetType and category_id -> Category via ctx.mdm.collection.getMany/hydrateMany (bulk load, never entity.get in loop)", "Uses ctx.data.moduleData for local products table reads/writes", "No raw MDM runtime primitives (mdmDocument, mdmEntityIndex, mdmRelationship)"];
        };
    };
    export default productRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "productRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/productRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/productRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/persistence/product.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/productRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IProductRepository } from "_102049_/l1/petShop/layer_2_application/ports/productRepository";
    export function createProductRepositoryAdapter(ctx: RequestContext): IProductRepository;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservationRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IReservationRepository } from "_102049_/l1/petShop/layer_2_application/ports/reservationRepository";
    export function createReservationRepositoryAdapter(ctx: RequestContext): IReservationRepository;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/registerRepositories" { }
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservation.defs" {
    export const reservationTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Reservation";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Reservation";
            readonly tableName: "reservation";
            readonly columns: readonly [{
                readonly name: "reservation_id";
                readonly type: "uuid";
                readonly nullable: false;
            }, {
                readonly name: "customer_id";
                readonly type: "uuid";
                readonly nullable: false;
            }, {
                readonly name: "status";
                readonly type: "text";
                readonly nullable: false;
            }, {
                readonly name: "payment_id";
                readonly type: "uuid";
                readonly nullable: false;
            }, {
                readonly name: "created_at";
                readonly type: "timestamptz";
                readonly nullable: false;
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
            }];
            readonly primaryKey: readonly ["reservation_id"];
            readonly indexes: readonly [{
                readonly indexName: "ix_reservation_customer_id";
                readonly columns: readonly ["customer_id"];
            }, {
                readonly indexName: "ix_reservation_payment_id";
                readonly columns: readonly ["payment_id"];
            }, {
                readonly indexName: "ix_reservation_status";
                readonly columns: readonly ["status"];
            }, {
                readonly indexName: "ix_reservation_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["ReservationItem"];
            };
        };
    };
    export default reservationTableDefinition;
    export const pipeline: readonly [{
        readonly id: "reservation__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservation.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservation.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservation" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const reservationTableDef: TableDefinition;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservationRepositoryAdapter.defs" {
    export const reservationRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ReservationRepositoryAdapter";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ReservationRepositoryAdapter";
            readonly entityId: "Reservation";
            readonly portRef: "IReservationRepository";
            readonly tableRef: "reservations";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns: reservation_id, customer_id, status, payment_id, created_at", "Details JSONB: confirmedAt, expiresAt, readyAt, deliveredAt, expiredAt, cancelledAt, cancelReason, updatedAt, plus embedded ReservationItem[]", "Uses ctx.data.moduleData for local reservations table reads/writes"];
        };
    };
    export default reservationRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "reservationRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservationRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservationRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/reservationRepository.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservation.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/seeds" {
    import type { TableSeedRows } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const paymentSeeds: TableSeedRows;
    export const productSeeds: TableSeedRows;
    export const reservationSeeds: TableSeedRows;
    export const mdmEntityIndexSeeds: TableSeedRows;
    export const mdmDocumentSeeds: TableSeedRows;
}
declare module "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.defs" {
    export const paymentRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "PaymentRepository";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Payment";
            readonly interfaceName: "IPaymentRepository";
            readonly methods: readonly [{
                readonly name: "append";
                readonly params: readonly ["record: PaymentEvent"];
                readonly returns: "void";
                readonly description: "Append-only event storage";
            }, {
                readonly name: "listByOwnerId";
                readonly params: readonly ["ownerId: string"];
                readonly returns: "PaymentEvent[]";
                readonly description: "Read finder by owner reservation id";
            }, {
                readonly name: "listByPeriod";
                readonly params: readonly ["from: Date", "to: Date"];
                readonly returns: "PaymentEvent[]";
                readonly description: "Read finder by date period";
            }];
        };
    };
    export default paymentRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "paymentRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/ports/productRepository.defs" {
    export const productRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ProductRepository";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Product";
            readonly interfaceName: "IProductRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: string"];
                readonly returns: "Product";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: ProductFilter"];
                readonly returns: "Product[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["product: Product"];
                readonly returns: "void";
            }, {
                readonly name: "findByName";
                readonly params: readonly ["name: string"];
                readonly returns: "Product[]";
                readonly description: "Domain finder by product name";
            }, {
                readonly name: "findByCategory";
                readonly params: readonly ["category: string"];
                readonly returns: "Product[]";
                readonly description: "Domain finder by product category";
            }];
        };
    };
    export default productRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "productRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/ports/productRepository.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/ports/productRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/ports/reservationRepository.defs" {
    export const reservationRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ReservationRepository";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Reservation";
            readonly interfaceName: "IReservationRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: string"];
                readonly returns: "Reservation";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: ReservationFilter"];
                readonly returns: "Reservation[]";
            }, {
                readonly name: "save";
                readonly params: readonly ["reservation: Reservation"];
                readonly returns: "void";
            }, {
                readonly name: "findByCustomerId";
                readonly params: readonly ["customerId: string"];
                readonly returns: "Reservation[]";
                readonly description: "Domain finder by customer identifier";
            }, {
                readonly name: "findByStatus";
                readonly params: readonly ["status: ReservationStatus"];
                readonly returns: "Reservation[]";
                readonly description: "Domain finder by reservation status";
            }];
        };
    };
    export default reservationRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "reservationRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/ports/reservationRepository.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/ports/reservationRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseCatalog.defs" {
    export const browseCatalogUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseCatalog";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseCatalog";
            readonly ports: readonly ["Product"];
            readonly rulesApplied: readonly ["onlyAvailableProductsVisibleAndReservable", "searchIsCaseInsensitiveAndPartial", "filtersCanBeCombined", "highlightRequiresAvailableProduct"];
            readonly functions: readonly [{
                readonly functionName: "browseCatalog";
                readonly inputTypeName: "BrowseCatalogInput";
                readonly outputTypeName: "BrowseCatalogOutput";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "minPrice";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "maxPrice";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "products";
                    readonly type: "array";
                    readonly required: true;
                }, {
                    readonly name: "total";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: true;
                }];
                readonly ports: readonly ["Product"];
                readonly rulesApplied: readonly ["onlyAvailableProductsVisibleAndReservable", "searchIsCaseInsensitiveAndPartial", "filtersCanBeCombined", "highlightRequiresAvailableProduct"];
                readonly transactional: false;
                readonly steps: readonly ["Build filters with status='available' (onlyAvailableProductsVisibleAndReservable, highlightRequiresAvailableProduct).", "If searchTerm provided, apply case-insensitive partial match on Product.name (searchIsCaseInsensitiveAndPartial).", "Apply optional filters petTypeId, categoryId, minPrice, maxPrice together (filtersCanBeCombined).", "Query Product port list with filters, sort by createdAt, and required pagination (page,pageSize) to get items and total.", "Collect distinct petTypeId and categoryId from products; load MDM names via ctx.mdm.collection.getMany for PetType and Category (plural-first).", "Map products to output shape with petTypeName/categoryName, and return paginated structure {products,total,page,pageSize}."];
                readonly outputShape: {
                    readonly kind: "paginated";
                    readonly fields: readonly [{
                        readonly name: "products";
                        readonly type: "array";
                        readonly required: true;
                        readonly item: {
                            readonly fields: readonly [{
                                readonly name: "productId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.productId";
                            }, {
                                readonly name: "name";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.name";
                            }, {
                                readonly name: "description";
                                readonly type: "string";
                                readonly required: false;
                                readonly fieldRef: "Product.description";
                            }, {
                                readonly name: "price";
                                readonly type: "number";
                                readonly required: true;
                                readonly fieldRef: "Product.price";
                            }, {
                                readonly name: "petTypeId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.petTypeId";
                            }, {
                                readonly name: "petTypeName";
                                readonly type: "string";
                                readonly required: false;
                            }, {
                                readonly name: "categoryId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.categoryId";
                            }, {
                                readonly name: "categoryName";
                                readonly type: "string";
                                readonly required: false;
                            }, {
                                readonly name: "highlighted";
                                readonly type: "boolean";
                                readonly required: true;
                                readonly fieldRef: "Product.highlighted";
                            }, {
                                readonly name: "status";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.status";
                            }];
                        };
                    }, {
                        readonly name: "total";
                        readonly type: "number";
                        readonly required: true;
                    }, {
                        readonly name: "page";
                        readonly type: "number";
                        readonly required: true;
                    }, {
                        readonly name: "pageSize";
                        readonly type: "number";
                        readonly required: true;
                    }];
                };
            }];
            readonly mdmRefs: readonly ["PetType", "Category"];
        };
    };
    export default browseCatalogUsecase;
    export const pipeline: readonly [{
        readonly id: "browseCatalog__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/browseCatalog.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/browseCatalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["onlyAvailableProductsVisibleAndReservable", "searchIsCaseInsensitiveAndPartial", "filtersCanBeCombined", "highlightRequiresAvailableProduct"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseProducts.defs" {
    export const browseProductsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseProducts";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseProducts";
            readonly ports: readonly ["Product"];
            readonly functions: readonly [{
                readonly functionName: "browseProducts";
                readonly inputTypeName: "BrowseProductsInput";
                readonly outputTypeName: "BrowseProductsOutput";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Termo de busca para filtrar produtos por nome com correspondência parcial e insensível a maiúsculas e minúsculas.";
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Filtro por tipo de pet indicado para o produto.";
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Filtro por categoria do catálogo.";
                }, {
                    readonly name: "priceMin";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Filtro de faixa de preço — valor mínimo (inclusive).";
                }, {
                    readonly name: "priceMax";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Filtro de faixa de preço — valor máximo (inclusive).";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Filtro por status de disponibilidade do produto (available ou unavailable).";
                }, {
                    readonly name: "highlighted";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Filtro para exibir apenas produtos marcados como destaque.";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Número da página solicitada (base 1).";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Quantidade de itens por página.";
                }];
                readonly output: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "petTypeName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "PetType";
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "categoryName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Category";
                }, {
                    readonly name: "highlighted";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }];
                readonly ports: readonly ["Product"];
                readonly rulesApplied: readonly ["searchIsCaseInsensitiveAndPartial", "filtersCanBeCombined", "highlightRequiresAvailableProduct"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolve actorId from ctx.sessionContext for catalog access authorization (contextResolution: actorSession.actorId).", "2. Build a filter object from user inputs: searchTerm, petTypeId, categoryId, priceMin, priceMax, status, highlighted — all optional.", "3. Apply rule searchIsCaseInsensitiveAndPartial: if searchTerm is provided, query the Product port filtering by name using case-insensitive partial match (name ILIKE '%searchTerm%' or equivalent). If no searchTerm, skip name filter.", "4. Apply rule filtersCanBeCombined: combine all provided filters with AND logic — petTypeId (exact), categoryId (exact), priceMin (>=), priceMax (<=), status (exact), highlighted (exact). No filter excludes another; all are AND-joined.", "5. Query the Product port (list/find) with the combined filter criteria. If page and pageSize are provided, apply pagination (offset = (page-1)*pageSize, limit = pageSize); otherwise return all matching products.", "6. Apply rule highlightRequiresAvailableProduct: iterate over results — for each product where highlighted=true AND status='unavailable', set the output highlighted field to false (the product stays in the list but is not presented as a valid highlight). If the user explicitly filtered highlighted=true, additionally exclude any product whose status='unavailable' from the result set entirely.", "7. Collect unique petTypeId values and unique categoryId values from the filtered product list.", "8. Bulk-fetch PetType MDM records via ctx.mdm.collection.getMany({ mdmIds: petTypeIds }) and Category MDM records via ctx.mdm.collection.getMany({ mdmIds: categoryIds }). Build lookup maps: petTypeId -> name and categoryId -> name.", "9. For each product in the result list, enrich with petTypeName (from PetType lookup) and categoryName (from Category lookup). If a lookup misses (e.g. inactive MDM record), set the name to null or empty string.", "10. Return the enriched list as the products array with all fields: productId, name, description, price, petTypeId, petTypeName, categoryId, categoryName, highlighted (effective), status, createdAt, updatedAt."];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "productId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.productId";
                    }, {
                        readonly name: "name";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.name";
                    }, {
                        readonly name: "description";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Product.description";
                    }, {
                        readonly name: "price";
                        readonly type: "number";
                        readonly required: true;
                        readonly fieldRef: "Product.price";
                    }, {
                        readonly name: "petTypeId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.petTypeId";
                    }, {
                        readonly name: "petTypeName";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "PetType.name";
                    }, {
                        readonly name: "categoryId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.categoryId";
                    }, {
                        readonly name: "categoryName";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Category.name";
                    }, {
                        readonly name: "highlighted";
                        readonly type: "boolean";
                        readonly required: true;
                        readonly fieldRef: "Product.highlighted";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.status";
                    }, {
                        readonly name: "createdAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.createdAt";
                    }, {
                        readonly name: "updatedAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.updatedAt";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["PetType", "Category"];
        };
    };
    export default browseProductsUsecase;
    export const pipeline: readonly [{
        readonly id: "browseProducts__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/browseProducts.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/browseProducts.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/cancelReservation.defs" {
    export const cancelReservationUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "cancelReservation";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "cancelReservation";
            readonly ports: readonly ["Reservation", "Product", "Payment"];
            readonly rulesApplied: readonly ["reservationRequiresAuthentication", "onlyActiveReservationsCanBeCancelled", "cancellationRestoresAvailability", "reservationStatusReflectsStage"];
            readonly functions: readonly [{
                readonly functionName: "cancelReservation";
                readonly inputTypeName: "CancelReservationInput";
                readonly outputTypeName: "CancelReservationOutput";
                readonly input: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                    readonly fieldRef: "Reservation.reservationId";
                }, {
                    readonly name: "cancelReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                    readonly fieldRef: "Reservation.cancelReason";
                }];
                readonly output: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "cancelledAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "cancelReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "restoredProducts";
                    readonly type: "array";
                    readonly required: true;
                }];
                readonly ports: readonly ["Reservation", "Product"];
                readonly rulesApplied: readonly ["reservationRequiresAuthentication", "onlyActiveReservationsCanBeCancelled", "cancellationRestoresAvailability", "reservationStatusReflectsStage"];
                readonly transactional: true;
                readonly steps: readonly ["Load Reservation by reservationId via Reservation port.", "Validate reservationRequiresAuthentication: ctx.sessionContext.actorId must equal Reservation.customerId; on failure return validation error with rule id.", "Validate onlyActiveReservationsCanBeCancelled: Reservation.status must be 'active' or 'ready'; otherwise reject with rule id.", "Set Reservation.status='cancelled', Reservation.cancelledAt=ctx.clock.now(), Reservation.cancelReason=input.cancelReason (if provided), Reservation.updatedAt=ctx.clock.now().", "Determine reserved productIds to restore availability (modeling gap if Reservation does not embed ReservationItems).", "Load Products by productIds via Product port; set Product.status='available' (or mapped availability) and updatedAt=ctx.clock.now().", "Persist Reservation and Products in a single transaction wrapper (ctx.data).", "Build restoredProducts array from updated Products (productId + availability flag).", "Return outputShape fields."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "reservationId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.reservationId";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.status";
                    }, {
                        readonly name: "cancelledAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.cancelledAt";
                    }, {
                        readonly name: "cancelReason";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.cancelReason";
                    }, {
                        readonly name: "updatedAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.updatedAt";
                    }, {
                        readonly name: "restoredProducts";
                        readonly type: "array";
                        readonly required: true;
                        readonly item: {
                            readonly fields: readonly [{
                                readonly name: "productId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.productId";
                            }, {
                                readonly name: "available";
                                readonly type: "boolean";
                                readonly required: true;
                                readonly fieldRef: "Product.available";
                            }];
                        };
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default cancelReservationUsecase;
    export const pipeline: readonly [{
        readonly id: "cancelReservation__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/cancelReservation.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/cancelReservation.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/reservationRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["reservationRequiresAuthentication", "onlyActiveReservationsCanBeCancelled", "cancellationRestoresAvailability", "reservationStatusReflectsStage"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/createProduct.defs" {
    export const createProductUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createProduct";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createProduct";
            readonly ports: readonly ["Product"];
            readonly functions: readonly [{
                readonly functionName: "createProduct";
                readonly inputTypeName: "CreateProductInput";
                readonly outputTypeName: "CreateProductOutput";
                readonly input: readonly [{
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Nome do produto informado pela loja.";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Descrição detalhada do produto (opcional).";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Preço do produto informado pela loja.";
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Referência ao tipo de pet indicado para o produto.";
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Referência à categoria do catálogo à qual o produto pertence.";
                }, {
                    readonly name: "highlighted";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Indica se o produto deve ser marcado como destaque pela loja.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Disponibilidade do produto: available ou unavailable.";
                }];
                readonly output: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "highlighted";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }];
                readonly ports: readonly ["Product"];
                readonly rulesApplied: readonly ["productRequiresMinimumFields", "highlightRequiresAvailableProduct", "highlightsAreManualOnly"];
                readonly transactional: true;
                readonly steps: readonly ["1. Validate required fields (name, price, petTypeId, categoryId) are present and non-empty — rule productRequiresMinimumFields. If any is missing, throw validation error with rule id.", "2. Validate status is one of 'available' or 'unavailable'.", "3. If highlighted === true and status !== 'available', throw validation error — rule highlightRequiresAvailableProduct. A product must be available to be highlighted.", "4. Rule highlightsAreManualOnly: highlighted is set solely from user input; no automatic highlight logic is applied. Accept the value as-is.", "5. Resolve MDM references: call ctx.mdm.collection.getMany({ mdmIds: [petTypeId, categoryId] }) to verify both PetType and Category exist. If either is not found, throw validation error referencing the missing id.", "6. Generate productId via ctx.idGenerator.uuid().", "7. Resolve createdAt and updatedAt via ctx.clock.now() (both equal at creation).", "8. Build the Product aggregate with all fields: productId, name, description, price, petTypeId, categoryId, highlighted, status, createdAt, updatedAt.", "9. Persist via ProductPort.save(product) inside ctx.data transaction.", "10. Return the created Product projection with all output fields."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "productId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.productId";
                    }, {
                        readonly name: "name";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.name";
                    }, {
                        readonly name: "description";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Product.description";
                    }, {
                        readonly name: "price";
                        readonly type: "number";
                        readonly required: true;
                        readonly fieldRef: "Product.price";
                    }, {
                        readonly name: "petTypeId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.petTypeId";
                    }, {
                        readonly name: "categoryId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.categoryId";
                    }, {
                        readonly name: "highlighted";
                        readonly type: "boolean";
                        readonly required: true;
                        readonly fieldRef: "Product.highlighted";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.status";
                    }, {
                        readonly name: "createdAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.createdAt";
                    }, {
                        readonly name: "updatedAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.updatedAt";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["PetType", "Category"];
        };
    };
    export default createProductUsecase;
    export const pipeline: readonly [{
        readonly id: "createProduct__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/createProduct.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/createProduct.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/createReservation.defs" {
    export const createReservationUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createReservation";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createReservation";
            readonly ports: readonly ["Reservation", "Product", "Payment"];
            readonly rulesApplied: readonly ["reservationRequiresAuthentication", "reservationExpiresIn24Hours", "reservationStatusReflectsStage"];
            readonly functions: readonly [{
                readonly functionName: "createReservation";
                readonly inputTypeName: "CreateReservationInput";
                readonly outputTypeName: "CreateReservationOutput";
                readonly input: readonly [{
                    readonly name: "items";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "Lista de produtos e quantidades que o cliente deseja reservar para retirada na loja";
                    readonly item: {
                        readonly fields: readonly [{
                            readonly name: "productId";
                            readonly type: "string";
                            readonly required: true;
                            readonly fieldRef: "ReservationItem.productId";
                        }, {
                            readonly name: "quantity";
                            readonly type: "number";
                            readonly required: true;
                            readonly fieldRef: "ReservationItem.quantity";
                        }];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "customerId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "confirmedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "expiresAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "items";
                    readonly type: "array";
                    readonly required: true;
                }];
                readonly ports: readonly ["Reservation", "Product"];
                readonly rulesApplied: readonly ["reservationRequiresAuthentication", "reservationExpiresIn24Hours", "reservationStatusReflectsStage"];
                readonly transactional: true;
                readonly steps: readonly ["Validate rule reservationRequiresAuthentication: require ctx.sessionContext.actorId; if missing, throw validation error with rule id.", "Collect unique productIds from items; load products via Product port bulk-get; if any missing or status != 'available', throw validation error.", "Generate reservationId and reservationItemId values with ctx.idGenerator.", "Set now = ctx.clock.now(); set status='active' and confirmedAt=now per reservationStatusReflectsStage.", "Set expiresAt = now + 24h per reservationExpiresIn24Hours.", "Assemble Reservation aggregate with customerId from ctx.sessionContext.actorId, timestamps createdAt/updatedAt=now, items with createdAt/updatedAt=now.", "Within a transaction via ctx.data, save Reservation aggregate via Reservation port.", "Append Payment audit event within same transaction via Payment port (modeling gap: port not provided in ports list).", "Return output shape from saved aggregate."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "reservationId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.reservationId";
                    }, {
                        readonly name: "customerId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.customerId";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.status";
                    }, {
                        readonly name: "confirmedAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.confirmedAt";
                    }, {
                        readonly name: "expiresAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.expiresAt";
                    }, {
                        readonly name: "createdAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.createdAt";
                    }, {
                        readonly name: "updatedAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.updatedAt";
                    }, {
                        readonly name: "items";
                        readonly type: "array";
                        readonly required: true;
                        readonly item: {
                            readonly fields: readonly [{
                                readonly name: "reservationItemId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "ReservationItem.reservationItemId";
                            }, {
                                readonly name: "productId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "ReservationItem.productId";
                            }, {
                                readonly name: "quantity";
                                readonly type: "number";
                                readonly required: true;
                                readonly fieldRef: "ReservationItem.quantity";
                            }];
                        };
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default createReservationUsecase;
    export const pipeline: readonly [{
        readonly id: "createReservation__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/createReservation.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/createReservation.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/reservationRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["reservationRequiresAuthentication", "reservationExpiresIn24Hours", "reservationStatusReflectsStage"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/expireReservations.defs" {
    export const expireReservationsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "expireReservations";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "expireReservations";
            readonly ports: readonly ["Reservation", "Product", "Payment"];
            readonly functions: readonly [{
                readonly functionName: "expireReservations";
                readonly inputTypeName: "ExpireReservationsInput";
                readonly outputTypeName: "ExpireReservationsOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "expiredCount";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "expiredReservations";
                    readonly type: "array";
                    readonly required: true;
                }, {
                    readonly name: "productsReleased";
                    readonly type: "number";
                    readonly required: true;
                }];
                readonly ports: readonly ["Reservation", "Product", "Payment"];
                readonly rulesApplied: readonly ["reservationExpiresIn24Hours", "expiredReservationRestoresAvailability", "reservationStatusReflectsStage"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolve currentTimestamp from ctx.clock.now() and actorId from ctx.sessionContext.actorId — neither is public input (systemDefault / actorSession sources)", "2. Load all reservations with status 'active' or 'ready' via Reservation port (listByStatus or equivalent query); reservations with status draft, delivered, expired or cancelled are excluded", "3. Filter the loaded reservations where expiresAt < currentTimestamp — this applies rule reservationExpiresIn24Hours: any active/ready reservation whose expiresAt is in the past is eligible for expiration", "4. If no reservations match, return { expiredCount: 0, expiredReservations: [], productsReleased: 0 }", "5. For each eligible reservation: set status to 'expired', set expiredAt to currentTimestamp, set updatedAt to currentTimestamp — this applies rule reservationStatusReflectsStage: the status must directly reflect the expired stage with no intermediate states", "6. Collect all reservationIds of the expired reservations", "7. Load ReservationItems for all expired reservations via the Reservation port (ReservationItem is a child collection embedded in the Reservation aggregate); collect productId and quantity from each item", "8. Deduplicate productIds across all expired reservation items; load affected Products via Product port (getMany by productIds)", "9. For each affected product: check whether any OTHER reservation with status 'active' or 'ready' (not among the ones being expired) still references that product via its ReservationItems; if no other active/ready reservation holds it, set product status to 'available' and update updatedAt to currentTimestamp — this applies rule expiredReservationRestoresAvailability", "10. Count products whose status was actually changed to 'available' as productsReleased", "11. Save all updated reservations (with their embedded ReservationItems unchanged) via Reservation port inside a single transaction (ctx.data transaction wrapper)", "12. Save all updated products via Product port inside the same transaction", "13. For each expired reservation that has a paymentId, build a Payment audit event record capturing { reservationId, paymentId, previousStatus, newStatus: 'expired', expiredAt, actorId, timestamp } and append it via the Payment port inside the same transaction — event is append-only, never updated or deleted", "14. Assemble the result: expiredCount = count of expired reservations, expiredReservations = array of { reservationId, status: 'expired', expiredAt } for each, productsReleased = count of products restored to available", "15. Return the assembled result object"];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "expiredCount";
                        readonly type: "number";
                        readonly required: true;
                    }, {
                        readonly name: "expiredReservations";
                        readonly type: "array";
                        readonly required: true;
                        readonly item: {
                            readonly fields: readonly [{
                                readonly name: "reservationId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Reservation.reservationId";
                            }, {
                                readonly name: "status";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Reservation.status";
                            }, {
                                readonly name: "expiredAt";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Reservation.expiredAt";
                            }];
                        };
                    }, {
                        readonly name: "productsReleased";
                        readonly type: "number";
                        readonly required: true;
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default expireReservationsUsecase;
    export const pipeline: readonly [{
        readonly id: "expireReservations__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/expireReservations.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/expireReservations.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/reservationRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/filterProducts.defs" {
    export const filterProductsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "filterProducts";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "filterProducts";
            readonly ports: readonly ["Product"];
            readonly functions: readonly [{
                readonly functionName: "filterProducts";
                readonly inputTypeName: "FilterProductsInput";
                readonly outputTypeName: "FilterProductsOutput";
                readonly input: readonly [{
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Tipo de pet selecionado para filtrar o catálogo (ex.: cão, gato).";
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Categoria selecionada para filtrar o catálogo (ex.: ração, brinquedo).";
                }, {
                    readonly name: "minPrice";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Preço mínimo da faixa de valor informada pelo cliente.";
                }, {
                    readonly name: "maxPrice";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Preço máximo da faixa de valor informada pelo cliente.";
                }];
                readonly output: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "highlighted";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }];
                readonly ports: readonly ["Product"];
                readonly rulesApplied: readonly ["onlyAvailableProductsVisibleAndReservable", "filtersCanBeCombined"];
                readonly transactional: false;
                readonly steps: readonly ["1. Load all products from the Product port (productPort.findAll or equivalent list query).", "2. Apply rule 'onlyAvailableProductsVisibleAndReservable': filter the collection to keep only products where status === 'available'; products with status 'unavailable' are excluded from results unconditionally.", "3. Apply rule 'filtersCanBeCombined': combine all provided filter criteria using AND logic — they are never mutually exclusive.", "4. If petTypeId is provided, keep only products whose petTypeId equals the supplied value.", "5. If categoryId is provided, keep only products whose categoryId equals the supplied value.", "6. If minPrice is provided, keep only products whose price >= minPrice (inclusive).", "7. If maxPrice is provided, keep only products whose price <= maxPrice (inclusive).", "8. If no filters are provided, return all available products (the status filter from step 2 still applies).", "9. Project each remaining product to the output shape: productId, name, description, price, petTypeId, categoryId, highlighted, status.", "10. Return the projected list as 'products'."];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "productId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.productId";
                    }, {
                        readonly name: "name";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.name";
                    }, {
                        readonly name: "description";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Product.description";
                    }, {
                        readonly name: "price";
                        readonly type: "number";
                        readonly required: true;
                        readonly fieldRef: "Product.price";
                    }, {
                        readonly name: "petTypeId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.petTypeId";
                    }, {
                        readonly name: "categoryId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.categoryId";
                    }, {
                        readonly name: "highlighted";
                        readonly type: "boolean";
                        readonly required: true;
                        readonly fieldRef: "Product.highlighted";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default filterProductsUsecase;
    export const pipeline: readonly [{
        readonly id: "filterProducts__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/filterProducts.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/filterProducts.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/listReservations.defs" {
    export const listReservationsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "listReservations";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "listReservations";
            readonly ports: readonly ["Reservation", "Payment"];
            readonly functions: readonly [{
                readonly functionName: "listReservations";
                readonly inputTypeName: "ListReservationsInput";
                readonly outputTypeName: "ListReservationsOutput";
                readonly input: readonly [{
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Filtro opcional por status da reserva (draft, active, ready, delivered, expired, cancelled)";
                }];
                readonly output: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "customerId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "confirmedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "expiresAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "readyAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "deliveredAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "items";
                    readonly type: "array";
                    readonly required: true;
                }];
                readonly ports: readonly ["Reservation"];
                readonly rulesApplied: readonly ["reservationStatusReflectsStage"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolve actorSession.actorId from ctx.sessionContext for authorization of the store viewing received reservations.", "2. Query all reservations via the Reservation port (reservationPort.list). If the optional `status` input is provided, pass it as a filter criterion; otherwise return all statuses including draft.", "3. For each loaded Reservation aggregate, extract its embedded ReservationItem collection (items are children of the Reservation aggregate root).", "4. Apply rule reservationStatusReflectsStage inline: for each reservation, evaluate whether the persisted status still matches the lifecycle stage implied by its timestamps — if status is 'active' but expiresAt < ctx.clock.now() and readyAt is null, the effective status is 'expired'; if deliveredAt is set, the effective status is 'delivered'; if readyAt is set and deliveredAt is null, the effective status is 'ready'. Use the corrected effective status in the output so the store sees the true current stage.", "5. Sort the resulting list by createdAt descending (most recent first).", "6. Map each reservation to the output projection: reservationId, customerId, effectiveStatus, confirmedAt, expiresAt, readyAt, deliveredAt, createdAt, updatedAt, and the embedded items array (reservationItemId, productId, quantity).", "7. Return the assembled list. No events are emitted — this is a read-only query with no aggregate mutations."];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "reservationId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.reservationId";
                    }, {
                        readonly name: "customerId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.customerId";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.status";
                    }, {
                        readonly name: "confirmedAt";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.confirmedAt";
                    }, {
                        readonly name: "expiresAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.expiresAt";
                    }, {
                        readonly name: "readyAt";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.readyAt";
                    }, {
                        readonly name: "deliveredAt";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.deliveredAt";
                    }, {
                        readonly name: "createdAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.createdAt";
                    }, {
                        readonly name: "updatedAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.updatedAt";
                    }, {
                        readonly name: "items";
                        readonly type: "array";
                        readonly required: true;
                        readonly item: {
                            readonly fields: readonly [{
                                readonly name: "reservationItemId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "ReservationItem.reservationItemId";
                            }, {
                                readonly name: "productId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "ReservationItem.productId";
                            }, {
                                readonly name: "quantity";
                                readonly type: "number";
                                readonly required: true;
                                readonly fieldRef: "ReservationItem.quantity";
                            }];
                        };
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default listReservationsUsecase;
    export const pipeline: readonly [{
        readonly id: "listReservations__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/listReservations.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/listReservations.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/reservationRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/payInStore.defs" {
    export const payInStoreUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "payInStore";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "payInStore";
            readonly ports: readonly ["Reservation", "Payment"];
            readonly rulesApplied: readonly ["pickupRequiresValidReservation", "reservationStatusReflectsStage", "reservationExpiresIn24Hours"];
            readonly functions: readonly [{
                readonly functionName: "payInStore";
                readonly inputTypeName: "PayInStoreInput";
                readonly outputTypeName: "PayInStoreOutput";
                readonly input: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                    readonly fieldRef: "Reservation.reservationId";
                }, {
                    readonly name: "paymentMethod";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                    readonly fieldRef: "Payment.paymentMethod";
                }, {
                    readonly name: "paymentAmount";
                    readonly type: "number";
                    readonly required: true;
                    readonly fieldRef: "Payment.amount";
                }];
                readonly output: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "deliveredAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "paymentId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }];
                readonly ports: readonly ["Reservation"];
                readonly rulesApplied: readonly ["pickupRequiresValidReservation", "reservationStatusReflectsStage", "reservationExpiresIn24Hours"];
                readonly transactional: true;
                readonly steps: readonly ["load Reservation by reservationId via Reservation port", "validate pickupRequiresValidReservation: reservation exists and status in ['ready'] and not cancelled/expired/delivered; if invalid return error with rule id", "validate reservationExpiresIn24Hours: now <= expiresAt and within 24h window; otherwise error with rule id", "create Payment record with paymentId from ctx.idGenerator, reservationId, amount, paymentMethod, status 'posted', createdAt now; persist via Payment eventWrites port (audit) in same transaction", "set Reservation.paymentId, deliveredAt=now, status='delivered', updatedAt=now", "apply reservationStatusReflectsStage invariant and save Reservation via Reservation port", "return outputShape fields"];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "reservationId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.reservationId";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.status";
                    }, {
                        readonly name: "deliveredAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.deliveredAt";
                    }, {
                        readonly name: "paymentId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.paymentId";
                    }, {
                        readonly name: "updatedAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.updatedAt";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default payInStoreUsecase;
    export const pipeline: readonly [{
        readonly id: "payInStore__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/payInStore.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/payInStore.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/reservationRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["pickupRequiresValidReservation", "reservationStatusReflectsStage", "reservationExpiresIn24Hours"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/searchProducts.defs" {
    export const searchProductsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "searchProducts";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "searchProducts";
            readonly ports: readonly ["Product"];
            readonly functions: readonly [{
                readonly functionName: "searchProducts";
                readonly inputTypeName: "SearchProductsInput";
                readonly outputTypeName: "SearchProductsOutput";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Termo de busca digitado pelo cliente para encontrar produtos por nome (correspondência parcial e insensível a caixa)";
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Filtro opcional por tipo de pet indicado para o produto";
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Filtro opcional por categoria do catálogo";
                }, {
                    readonly name: "minPrice";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Filtro opcional de preço mínimo para faixa de valor";
                }, {
                    readonly name: "maxPrice";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Filtro opcional de preço máximo para faixa de valor";
                }];
                readonly output: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "petTypeName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "PetType";
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "categoryName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Category";
                }, {
                    readonly name: "highlighted";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }];
                readonly ports: readonly ["Product"];
                readonly rulesApplied: readonly ["searchIsCaseInsensitiveAndPartial", "onlyAvailableProductsVisibleAndReservable", "filtersCanBeCombined"];
                readonly transactional: false;
                readonly steps: readonly ["1. Validate searchTerm is non-empty; throw validation error with rule 'searchIsCaseInsensitiveAndPartial' if blank.", "2. Load all products from the Product port (productPort.list).", "3. Apply rule 'onlyAvailableProductsVisibleAndReservable': filter to products where status === 'available'.", "4. Apply rule 'searchIsCaseInsensitiveAndPartial': keep products whose name, lowercased, includes searchTerm lowercased (partial, case-insensitive match).", "5. Apply rule 'filtersCanBeCombined': if petTypeId provided, filter products where petTypeId === input.petTypeId; if categoryId provided, filter where categoryId === input.categoryId; if minPrice provided, filter where price >= minPrice; if maxPrice provided, filter where price <= maxPrice. All filters AND together without mutual exclusion.", "6. Collect unique petTypeId values and unique categoryId values from the filtered products.", "7. Bulk-fetch PetType MDM records via ctx.mdm.collection.getMany({ mdmIds: petTypeIds }) and Category MDM records via ctx.mdm.collection.getMany({ mdmIds: categoryIds }). Build lookup maps petTypeId->name and categoryId->name.", "8. Map each filtered product to the output shape, enriching with petTypeName from the PetType lookup and categoryName from the Category lookup.", "9. Return { products: enrichedList }."];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "productId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.productId";
                    }, {
                        readonly name: "name";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.name";
                    }, {
                        readonly name: "description";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Product.description";
                    }, {
                        readonly name: "price";
                        readonly type: "number";
                        readonly required: true;
                        readonly fieldRef: "Product.price";
                    }, {
                        readonly name: "petTypeId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.petTypeId";
                    }, {
                        readonly name: "petTypeName";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "PetType.name";
                    }, {
                        readonly name: "categoryId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.categoryId";
                    }, {
                        readonly name: "categoryName";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Category.name";
                    }, {
                        readonly name: "highlighted";
                        readonly type: "boolean";
                        readonly required: true;
                        readonly fieldRef: "Product.highlighted";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["PetType", "Category"];
        };
    };
    export default searchProductsUsecase;
    export const pipeline: readonly [{
        readonly id: "searchProducts__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/searchProducts.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/searchProducts.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/setProductHighlights.defs" {
    export const setProductHighlightsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "setProductHighlights";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "setProductHighlights";
            readonly ports: readonly ["Product"];
            readonly rulesApplied: readonly ["highlightRequiresAvailableProduct", "highlightsAreManualOnly"];
            readonly functions: readonly [{
                readonly functionName: "setProductHighlights";
                readonly inputTypeName: "SetProductHighlightsInput";
                readonly outputTypeName: "SetProductHighlightsOutput";
                readonly input: readonly [{
                    readonly name: "productIds";
                    readonly type: "array";
                    readonly required: true;
                    readonly fieldRef: "Product.productId";
                    readonly item: {
                        readonly type: "string";
                    };
                }, {
                    readonly name: "highlighted";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly fieldRef: "Product.highlighted";
                }];
                readonly output: readonly [{
                    readonly name: "updatedCount";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "products";
                    readonly type: "array";
                    readonly required: true;
                }];
                readonly ports: readonly ["Product"];
                readonly rulesApplied: readonly ["highlightRequiresAvailableProduct", "highlightsAreManualOnly"];
                readonly transactional: true;
                readonly steps: readonly ["Resolve actorId from ctx.sessionContext.actorId; if missing, reject as manual operation only (rule highlightsAreManualOnly).", "Load Products by ids via Product port.", "If highlighted=true, validate all loaded products have status != 'unavailable'; if any unavailable, reject with rule highlightRequiresAvailableProduct.", "Apply highlighted value to each loaded product; set updatedAt=ctx.clock.now();", "Persist updated products via Product port inside ctx.data transaction.", "Return updatedCount and products projection (productId,name,highlighted,status)."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "updatedCount";
                        readonly type: "number";
                        readonly required: true;
                    }, {
                        readonly name: "products";
                        readonly type: "array";
                        readonly required: true;
                        readonly item: {
                            readonly fields: readonly [{
                                readonly name: "productId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.productId";
                            }, {
                                readonly name: "name";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.name";
                            }, {
                                readonly name: "highlighted";
                                readonly type: "boolean";
                                readonly required: true;
                                readonly fieldRef: "Product.highlighted";
                            }, {
                                readonly name: "status";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.status";
                            }];
                        };
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default setProductHighlightsUsecase;
    export const pipeline: readonly [{
        readonly id: "setProductHighlights__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/setProductHighlights.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/setProductHighlights.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["highlightRequiresAvailableProduct", "highlightsAreManualOnly"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/updateProduct.defs" {
    export const updateProductUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateProduct";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateProduct";
            readonly ports: readonly ["Product"];
            readonly functions: readonly [{
                readonly functionName: "updateProduct";
                readonly inputTypeName: "UpdateProductInput";
                readonly outputTypeName: "UpdateProductOutput";
                readonly input: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly description: "Identificador do produto que está sendo editado";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Novo nome do produto, se alterado";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Nova descrição do produto, se alterada";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Novo preço do produto, se alterado";
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Novo tipo de pet indicado para o produto, se alterado";
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Nova categoria do produto, se alterada";
                }, {
                    readonly name: "highlighted";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Nova flag de destaque do produto, se alterada";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly description: "Nova disponibilidade do produto (available ou unavailable), se alterada";
                }];
                readonly output: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "highlighted";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }];
                readonly ports: readonly ["Product"];
                readonly rulesApplied: readonly ["highlightRequiresAvailableProduct", "productRequiresMinimumFields", "highlightsAreManualOnly"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the existing Product aggregate from the Product port by productId (ProductPort.getById). If not found, throw a not-found validation error.", "2. Merge user-supplied fields onto the loaded product: for each of name, description, price, petTypeId, categoryId, highlighted, status — if the field is present in the input (not undefined), overwrite the existing value; otherwise keep the existing value. productId and createdAt are never overwritten.", "3. Rule productRequiresMinimumFields: after merge, verify that name is non-empty, price is a positive number, petTypeId is non-empty, and categoryId is non-empty. If any provided required field is empty/blank, throw a validation error including the rule id 'productRequiresMinimumFields' and the offending field name.", "4. Rule highlightRequiresAvailableProduct: after merge, if highlighted === true AND status === 'unavailable', throw a validation error including the rule id 'highlightRequiresAvailableProduct'.", "5. Rule highlightsAreManualOnly: ensure highlighted is only set from the explicit user input — never auto-computed. If highlighted was not provided in the input, keep the existing value unchanged (no automatic highlight logic).", "6. If petTypeId changed from the existing value, validate the MDM PetType exists and is active via ctx.mdm.entity.get({ mdmId: petTypeId }). If not found or inactive, throw a validation error.", "7. If categoryId changed from the existing value, validate the MDM Category exists via ctx.mdm.entity.get({ mdmId: categoryId }). If not found, throw a validation error.", "8. Set updatedAt to ctx.clock.now() (systemDefault). Leave createdAt unchanged.", "9. Persist the updated Product aggregate through the Product port (ProductPort.save) inside a single transaction (ctx.data transaction wrapper).", "10. Return the full updated Product projection: productId, name, description, price, petTypeId, categoryId, highlighted, status, createdAt, updatedAt."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "productId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.productId";
                    }, {
                        readonly name: "name";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.name";
                    }, {
                        readonly name: "description";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Product.description";
                    }, {
                        readonly name: "price";
                        readonly type: "number";
                        readonly required: true;
                        readonly fieldRef: "Product.price";
                    }, {
                        readonly name: "petTypeId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.petTypeId";
                    }, {
                        readonly name: "categoryId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.categoryId";
                    }, {
                        readonly name: "highlighted";
                        readonly type: "boolean";
                        readonly required: true;
                        readonly fieldRef: "Product.highlighted";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.status";
                    }, {
                        readonly name: "createdAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.createdAt";
                    }, {
                        readonly name: "updatedAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.updatedAt";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["PetType", "Category"];
        };
    };
    export default updateProductUsecase;
    export const pipeline: readonly [{
        readonly id: "updateProduct__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/updateProduct.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/updateProduct.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/updateReservationStatus.defs" {
    export const updateReservationStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateReservationStatus";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateReservationStatus";
            readonly ports: readonly ["Reservation", "Product", "Payment"];
            readonly rulesApplied: readonly ["storeCanMarkReservationReady", "reservationStatusReflectsStage", "onlyActiveReservationsCanBeCancelled", "pickupRequiresValidReservation", "cancellationRestoresAvailability"];
            readonly functions: readonly [{
                readonly functionName: "updateReservationStatus";
                readonly inputTypeName: "UpdateReservationStatusInput";
                readonly outputTypeName: "UpdateReservationStatusOutput";
                readonly input: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                    readonly fieldRef: "Reservation.reservationId";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                    readonly fieldRef: "Reservation.status";
                }, {
                    readonly name: "cancelReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                    readonly fieldRef: "Reservation.cancelReason";
                }, {
                    readonly name: "paymentId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                    readonly fieldRef: "Reservation.paymentId";
                }];
                readonly output: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "readyAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "deliveredAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "cancelledAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "cancelReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "paymentId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }];
                readonly ports: readonly ["Reservation", "Product"];
                readonly rulesApplied: readonly ["storeCanMarkReservationReady", "reservationStatusReflectsStage", "onlyActiveReservationsCanBeCancelled", "pickupRequiresValidReservation", "cancellationRestoresAvailability"];
                readonly transactional: true;
                readonly steps: readonly ["Load Reservation by reservationId via Reservation port.", "Validate status is one of ready/delivered/cancelled (rule reservationStatusReflectsStage).", "If status=ready: ensure store can mark reservation ready (rule storeCanMarkReservationReady) and current reservation.status is active; set readyAt=ctx.clock.now().", "If status=delivered: ensure reservation.status is ready and ctx.clock.now() <= reservation.expiresAt (rule pickupRequiresValidReservation); require paymentId input; set deliveredAt=ctx.clock.now() and paymentId.", "If status=cancelled: ensure reservation.status is active (rule onlyActiveReservationsCanBeCancelled); require cancelReason input; set cancelledAt=ctx.clock.now() and cancelReason.", "Always set updatedAt=ctx.clock.now().", "If status=cancelled: collect productIds from reservation items (embedded on Reservation); load Products via Product port; set each Product.status to available (rule cancellationRestoresAvailability); persist Product updates.", "Persist Reservation changes via Reservation port inside a single transaction with Product updates.", "Return fields per outputShape from the updated Reservation."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "reservationId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.reservationId";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.status";
                    }, {
                        readonly name: "readyAt";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.readyAt";
                    }, {
                        readonly name: "deliveredAt";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.deliveredAt";
                    }, {
                        readonly name: "cancelledAt";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.cancelledAt";
                    }, {
                        readonly name: "cancelReason";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.cancelReason";
                    }, {
                        readonly name: "paymentId";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.paymentId";
                    }, {
                        readonly name: "updatedAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.updatedAt";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateReservationStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateReservationStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/updateReservationStatus.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/updateReservationStatus.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/reservationRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["storeCanMarkReservationReady", "reservationStatusReflectsStage", "onlyActiveReservationsCanBeCancelled", "pickupRequiresValidReservation", "cancellationRestoresAvailability"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/viewHighlights.defs" {
    export const viewHighlightsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewHighlights";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewHighlights";
            readonly ports: readonly ["Product"];
            readonly functions: readonly [{
                readonly functionName: "viewHighlights";
                readonly inputTypeName: "ViewHighlightsInput";
                readonly outputTypeName: "ViewHighlightsOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "highlighted";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }];
                readonly ports: readonly ["Product"];
                readonly rulesApplied: readonly ["highlightRequiresAvailableProduct", "onlyAvailableProductsVisibleAndReservable", "highlightsAreManualOnly"];
                readonly transactional: false;
                readonly steps: readonly ["1. Load all products from the Product port (list query).", "2. Apply rule 'highlightsAreManualOnly': do NOT auto-select or compute highlights — only products already flagged highlighted=true by the store are candidates.", "3. Apply rule 'highlightRequiresAvailableProduct' and 'onlyAvailableProductsVisibleAndReservable': filter the candidate set to products where status === 'available'. Products with status 'unavailable' are excluded even if highlighted=true.", "4. Project each surviving product onto the output shape: productId, name, description, price, petTypeId, categoryId, highlighted, status.", "5. Return the resulting list (may be empty if no highlighted+available products exist)."];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "productId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.productId";
                    }, {
                        readonly name: "name";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.name";
                    }, {
                        readonly name: "description";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Product.description";
                    }, {
                        readonly name: "price";
                        readonly type: "number";
                        readonly required: true;
                        readonly fieldRef: "Product.price";
                    }, {
                        readonly name: "petTypeId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.petTypeId";
                    }, {
                        readonly name: "categoryId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.categoryId";
                    }, {
                        readonly name: "highlighted";
                        readonly type: "boolean";
                        readonly required: true;
                        readonly fieldRef: "Product.highlighted";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["PetType", "Category"];
        };
    };
    export default viewHighlightsUsecase;
    export const pipeline: readonly [{
        readonly id: "viewHighlights__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/viewHighlights.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/viewHighlights.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/viewMyReservations.defs" {
    export const viewMyReservationsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewMyReservations";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewMyReservations";
            readonly ports: readonly ["Reservation", "Payment"];
            readonly functions: readonly [{
                readonly functionName: "viewMyReservations";
                readonly inputTypeName: "ViewMyReservationsInput";
                readonly outputTypeName: "ViewMyReservationsOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "expiresAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "confirmedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "readyAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "items";
                    readonly type: "array";
                    readonly required: true;
                }];
                readonly ports: readonly ["Reservation"];
                readonly rulesApplied: readonly ["reservationRequiresAuthentication", "reservationStatusReflectsStage"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolve the authenticated actor id from ctx.sessionContext.actorId — this becomes the customerId filter (rule reservationRequiresAuthentication: if no actorId is present in session context, throw a 401 authentication error with detail 'reservationRequiresAuthentication').", "2. Load all Reservation aggregates owned by this customer via the Reservation port: reservationPort.list({ filter: { customerId: actorId }, sort: { createdAt: 'desc' } }). The customerId filter is applied on the Reservation.customerId field which exists in the entity model.", "3. For each loaded Reservation, validate that status is one of the allowed enum values [draft, active, ready, delivered, expired, cancelled] (rule reservationStatusReflectsStage: if any reservation has an unknown status, skip it and log a warning — the invariant guarantees only valid stages are persisted).", "4. For each Reservation, extract its embedded ReservationItem collection (items are children of the Reservation aggregate root, loaded together via the port). Map each item to { productId, quantity }.", "5. Assemble the output list: for each reservation produce { reservationId, status, expiresAt, createdAt, confirmedAt?, readyAt?, items[] } sorted by createdAt descending (already sorted by the port query).", "6. Return the assembled list. No mutations occur, so no event writes are emitted."];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "reservationId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.reservationId";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.status";
                    }, {
                        readonly name: "expiresAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.expiresAt";
                    }, {
                        readonly name: "createdAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.createdAt";
                    }, {
                        readonly name: "confirmedAt";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.confirmedAt";
                    }, {
                        readonly name: "readyAt";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.readyAt";
                    }, {
                        readonly name: "items";
                        readonly type: "array";
                        readonly required: true;
                        readonly item: {
                            readonly fields: readonly [{
                                readonly name: "productId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "ReservationItem.productId";
                            }, {
                                readonly name: "quantity";
                                readonly type: "number";
                                readonly required: true;
                                readonly fieldRef: "ReservationItem.quantity";
                            }];
                        };
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewMyReservationsUsecase;
    export const pipeline: readonly [{
        readonly id: "viewMyReservations__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/viewMyReservations.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/viewMyReservations.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/reservationRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/viewProductDetails.defs" {
    export const viewProductDetailsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewProductDetails";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewProductDetails";
            readonly ports: readonly ["Product"];
            readonly rulesApplied: readonly ["onlyAvailableProductsVisibleAndReservable"];
            readonly functions: readonly [{
                readonly functionName: "viewProductDetails";
                readonly inputTypeName: "ViewProductDetailsInput";
                readonly outputTypeName: "ViewProductDetailsOutput";
                readonly input: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly fieldRef: "Product.productId";
                }];
                readonly output: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "petTypeName";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "categoryName";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "highlighted";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }];
                readonly ports: readonly ["Product"];
                readonly rulesApplied: readonly ["onlyAvailableProductsVisibleAndReservable"];
                readonly transactional: false;
                readonly steps: readonly ["Load Product by productId via Product port.", "Apply rule onlyAvailableProductsVisibleAndReservable: if product.status !== 'available', return not found/validation error with rule id; if product.highlighted is true while status != 'available', return validation error with rule id (defensive).", "Resolve petTypeName via ctx.mdm.entity.get({ mdmId: product.petTypeId }) for PetType; resolve categoryName via ctx.mdm.entity.get({ mdmId: product.categoryId }) for Category.", "Return output shape with product fields plus petTypeName and categoryName."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "productId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.productId";
                    }, {
                        readonly name: "name";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.name";
                    }, {
                        readonly name: "description";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Product.description";
                    }, {
                        readonly name: "price";
                        readonly type: "number";
                        readonly required: true;
                        readonly fieldRef: "Product.price";
                    }, {
                        readonly name: "petTypeId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.petTypeId";
                    }, {
                        readonly name: "petTypeName";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "categoryId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.categoryId";
                    }, {
                        readonly name: "categoryName";
                        readonly type: "string";
                        readonly required: true;
                    }, {
                        readonly name: "highlighted";
                        readonly type: "boolean";
                        readonly required: true;
                        readonly fieldRef: "Product.highlighted";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.status";
                    }, {
                        readonly name: "createdAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.createdAt";
                    }, {
                        readonly name: "updatedAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.updatedAt";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["PetType", "Category"];
        };
    };
    export default viewProductDetailsUsecase;
    export const pipeline: readonly [{
        readonly id: "viewProductDetails__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/viewProductDetails.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/viewProductDetails.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/productRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/product.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["onlyAvailableProductsVisibleAndReservable"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/payment.defs" {
    export const paymentDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Payment";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Payment";
            readonly title: "Payment";
            readonly fields: readonly [{
                readonly fieldId: "paymentId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do registro de pagamento.";
            }, {
                readonly fieldId: "reservationId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência à reserva cuja retirada gerou este pagamento.";
            }, {
                readonly fieldId: "amount";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor total pago presencialmente na retirada da reserva.";
            }, {
                readonly fieldId: "paymentMethod";
                readonly type: "string";
                readonly required: true;
                readonly description: "Meio utilizado para o pagamento na loja física.";
                readonly enum: readonly ["cash", "creditCard", "debitCard", "pix"];
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação atual do pagamento: registrado ou anulado.";
                readonly enum: readonly ["posted", "voided"];
            }, {
                readonly fieldId: "voidedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que o pagamento foi anulado por evento compensatório.";
            }, {
                readonly fieldId: "voidReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo da anulação do pagamento, registrado quando há estorno ou cancelamento.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora em que o pagamento foi registrado na loja.";
            }];
            readonly valueObjects: readonly [];
            readonly invariants: readonly [];
            readonly statusEnum: readonly ["posted", "voided"];
        };
    };
    export default paymentDomainEntity;
    export const pipeline: readonly [{
        readonly id: "payment__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/petShop/layer_3_domain/entities/payment.ts";
        readonly defPath: "_102049_/l1/petShop/layer_3_domain/entities/payment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/product.defs" {
    export const productDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Product";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Product";
            readonly title: "Product";
            readonly fields: readonly [{
                readonly fieldId: "productId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do produto no catálogo.";
            }, {
                readonly fieldId: "name";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do produto usado na busca insensível a maiúsculas e minúsculas com correspondência parcial.";
            }, {
                readonly fieldId: "description";
                readonly type: "text";
                readonly required: false;
                readonly description: "Descrição detalhada do produto exibida na página de detalhes.";
            }, {
                readonly fieldId: "price";
                readonly type: "money";
                readonly required: true;
                readonly description: "Preço do produto utilizado na filtragem por faixa de valor.";
            }, {
                readonly fieldId: "petTypeId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao tipo de pet indicado para o produto, usado como filtro de catálogo.";
            }, {
                readonly fieldId: "categoryId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência à categoria do catálogo à qual o produto pertence, usada como filtro.";
            }, {
                readonly fieldId: "highlighted";
                readonly type: "boolean";
                readonly required: true;
                readonly description: "Indica se o produto foi manualmente marcado como destaque pela loja; só pode ser verdadeiro quando o produto está disponível.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Disponibilidade do produto na vitrine; produtos indisponíveis não aparecem na vitrine nem podem ser reservados.";
                readonly enum: readonly ["available", "unavailable"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do produto no catálogo.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização dos dados do produto.";
            }];
            readonly valueObjects: readonly [];
            readonly invariants: readonly ["highlighted = true requires status = 'available'"];
            readonly statusEnum: readonly ["available", "unavailable"];
        };
    };
    export default productDomainEntity;
    export const pipeline: readonly [{
        readonly id: "product__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/petShop/layer_3_domain/entities/product.ts";
        readonly defPath: "_102049_/l1/petShop/layer_3_domain/entities/product.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/reservation.defs" {
    export const reservationDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Reservation";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Reservation";
            readonly title: "Reservation";
            readonly fields: readonly [{
                readonly fieldId: "reservationId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único da reserva";
            }, {
                readonly fieldId: "customerId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Cliente autenticado que criou a reserva";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Estágio atual da reserva no ciclo de vida";
                readonly enum: readonly ["draft", "active", "ready", "delivered", "expired", "cancelled"];
            }, {
                readonly fieldId: "confirmedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Momento em que a reserva saiu de rascunho e foi confirmada como ativa";
            }, {
                readonly fieldId: "expiresAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora limite para retirada, 24 horas após a confirmação";
            }, {
                readonly fieldId: "readyAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Momento em que a loja marcou a reserva como pronta para retirada após separar os produtos";
            }, {
                readonly fieldId: "deliveredAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Momento em que o cliente retirou os produtos na loja física";
            }, {
                readonly fieldId: "expiredAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Momento em que a reserva expirou automaticamente por não retirada em 24 horas";
            }, {
                readonly fieldId: "cancelledAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Momento em que a reserva foi cancelada pelo cliente ou pela loja";
            }, {
                readonly fieldId: "cancelReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo informado no cancelamento da reserva";
            }, {
                readonly fieldId: "paymentId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência ao pagamento presencial associado quando a reserva é entregue";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Momento de criação da reserva";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Momento da última atualização da reserva";
            }];
            readonly valueObjects: readonly [{
                readonly name: "ReservationItem";
                readonly collection: true;
                readonly fields: readonly [{
                    readonly fieldId: "reservationItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do item da reserva.";
                }, {
                    readonly fieldId: "reservationId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência à reserva à qual este item pertence.";
                }, {
                    readonly fieldId: "productId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao produto do catálogo que está sendo reservado.";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade do produto reservada pelo cliente neste item.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora em que o item da reserva foi criado.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do item da reserva.";
                }];
            }];
            readonly invariants: readonly ["status != 'draft' requires confirmedAt set", "status = 'ready' or 'delivered' requires readyAt set", "status = 'delivered' requires deliveredAt set", "status = 'expired' requires expiredAt set", "status = 'cancelled' requires cancelledAt set", "paymentId set requires status = 'delivered'", "expiresAt is 24 hours after confirmedAt"];
            readonly statusEnum: readonly ["draft", "active", "ready", "delivered", "expired", "cancelled"];
        };
    };
    export default reservationDomainEntity;
    export const pipeline: readonly [{
        readonly id: "reservation__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/petShop/layer_3_domain/entities/reservation.ts";
        readonly defPath: "_102049_/l1/petShop/layer_3_domain/entities/reservation.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l2/designSystem" {
    import { IDesignSystemTokens } from '_102029_/l2/designSystemBase';
    /**
     * Design system do projeto — vocabulário de tokens POR PAPEL (role-based).
     * Este vocabulário é o padrão para novos projetos; só os VALORES mudam por marca.
     *
     * Regras de nomenclatura (color):
     *  - O nome diz onde o token é usado; nunca deduza pelo valor.
     *  - Pares bg/text andam juntos: quem usa button-primary-bg escreve o rótulo
     *    com button-primary-text; quem usa status-error-bg usa status-error-text;
     *    nav-bg com nav-text; tooltip-bg com tooltip-text. Vale para todo par
     *    <papel>-bg / <papel>-text.
     *  - Superfícies: page-bg (fundo da página) > surface-bg (cards, painéis,
     *    modais) > surface-alt-bg (linhas zebradas, hover de linha, skeleton,
     *    cabeçalhos de seção). Texto sobre superfícies: text-strong (títulos),
     *    text-default (corpo), text-muted (secundário/placeholder).
     *  - Navegação (sidebar/topbar): nav-bg + nav-text; item ativo usa
     *    nav-active-bg + nav-active-text.
     *  - Overlay de modal: overlay-backdrop-bg atrás, surface-bg no modal.
     *  - Gráficos: séries usam chart-series-1..6 SEMPRE nesta ordem fixa (a ordem
     *    é o mecanismo de segurança para daltonismo — nunca embaralhar nem gerar
     *    cores novas); textos e eixos usam os tokens text-*, nunca a cor da série;
     *    status-* são reservados a estado e nunca viram série de gráfico.
     *  - Todo token base de cor tem as variantes -hover, -focus e -disabled
     *    (em chart-series, -disabled é a série apagada pela legenda).
     *  - Modo noite: cada chave tem par com prefixo _dark- (mesmo nome). O
     *    compilador gera o bloco dark automaticamente; paginas usam so o nome base.
     */
    export const tokens: IDesignSystemTokens[];
}
declare module "_102049_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102049_/l2/petShop/web/contracts/myReservations.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        canonicalOutputShape: {
            kind: string;
            fields: ({
                name: string;
                type: string;
                required: boolean;
                fieldRef: string;
                item?: undefined;
            } | {
                name: string;
                type: string;
                required: boolean;
                item: {
                    fields: {
                        name: string;
                        type: string;
                        required: boolean;
                        fieldRef: string;
                    }[];
                };
                fieldRef?: undefined;
            })[];
        };
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: {
            name: string;
            type: string;
            required: boolean;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "myReservations__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/myReservations.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/myReservations.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/myReservations" {
    export interface PetShopCreateReservationInput {
        items: string;
    }
    export interface PetShopCreateReservationItem {
        reservationItemId: string;
        productId: string;
        quantity: number;
    }
    export interface PetShopCreateReservationOutput {
        reservationId: string;
        customerId: string;
        status: string;
        confirmedAt: string;
        expiresAt: string;
        createdAt: string;
        updatedAt: string;
        items: PetShopCreateReservationItem[];
    }
    export interface PetShopCancelReservationInput {
        reservationId: string;
        cancelReason?: string;
    }
    export interface PetShopCancelReservationRestoredProduct {
        productId: string;
        available: boolean;
    }
    export interface PetShopCancelReservationOutput {
        reservationId: string;
        status: string;
        cancelledAt: string;
        cancelReason?: string;
        updatedAt: string;
        restoredProducts: PetShopCancelReservationRestoredProduct[];
    }
    export interface PetShopViewMyReservationsInput {
    }
    export interface PetShopViewMyReservationsItem {
        productId: string;
        quantity: number;
    }
    export interface PetShopViewMyReservationsOutputItem {
        reservationId: string;
        status: string;
        expiresAt: string;
        createdAt: string;
        confirmedAt?: string;
        readyAt?: string;
        items: PetShopViewMyReservationsItem[];
    }
    export type PetShopViewMyReservationsOutput = PetShopViewMyReservationsOutputItem[];
}
declare module "_102049_/l2/petShop/web/contracts/myReservations.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/productCatalog.defs" {
    export const definition: ({
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        canonicalOutputShape: {
            kind: string;
            fields: ({
                name: string;
                type: string;
                required: boolean;
                item: {
                    fields: ({
                        name: string;
                        type: string;
                        required: boolean;
                        fieldRef: string;
                    } | {
                        name: string;
                        type: string;
                        required: boolean;
                        fieldRef?: undefined;
                    })[];
                };
            } | {
                name: string;
                type: string;
                required: boolean;
                item?: undefined;
            })[];
        };
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: {
            name: string;
            type: string;
            required: boolean;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    } | {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        canonicalOutputShape: {
            kind: string;
            fields: ({
                name: string;
                type: string;
                required: boolean;
                fieldRef: string;
            } | {
                name: string;
                type: string;
                required: boolean;
                fieldRef?: undefined;
            })[];
        };
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: {
            name: string;
            type: string;
            required: boolean;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    })[];
    export const pipeline: readonly [{
        readonly id: "productCatalog__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/productCatalog.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/productCatalog.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/productCatalog" {
    export interface PetShopViewHighlightsInput {
    }
    export interface PetShopViewHighlightsOutputItem {
        productId: string;
        name: string;
        description?: string;
        price: number;
        petTypeId: string;
        categoryId: string;
        highlighted: boolean;
        status: string;
    }
    export type PetShopViewHighlightsOutput = PetShopViewHighlightsOutputItem[];
    export interface PetShopBrowseCatalogInput {
        searchTerm?: string;
        petTypeId?: string;
        categoryId?: string;
        minPrice?: number;
        maxPrice?: number;
    }
    export interface PetShopBrowseCatalogProduct {
        productId: string;
        name: string;
        description?: string;
        price: number;
        petTypeId: string;
        petTypeName?: string;
        categoryId: string;
        categoryName?: string;
        highlighted: boolean;
        status: string;
    }
    export interface PetShopBrowseCatalogOutput {
        products: PetShopBrowseCatalogProduct[];
        total: number;
        page: number;
        pageSize: number;
    }
    export interface PetShopSearchProductsInput {
        searchTerm: string;
        petTypeId?: string;
        categoryId?: string;
        minPrice?: number;
        maxPrice?: number;
    }
    export interface PetShopSearchProductsOutputItem {
        productId: string;
        name: string;
        description?: string;
        price: number;
        petTypeId: string;
        petTypeName: string;
        categoryId: string;
        categoryName: string;
        highlighted: boolean;
        status: string;
    }
    export type PetShopSearchProductsOutput = PetShopSearchProductsOutputItem[];
    export interface PetShopFilterProductsInput {
        petTypeId?: string;
        categoryId?: string;
        minPrice?: number;
        maxPrice?: number;
    }
    export interface PetShopFilterProductsOutputItem {
        productId: string;
        name: string;
        description?: string;
        price: number;
        petTypeId: string;
        categoryId: string;
        highlighted: boolean;
        status: string;
    }
    export type PetShopFilterProductsOutput = PetShopFilterProductsOutputItem[];
    export interface PetShopViewProductDetailsInput {
        productId: string;
    }
    export interface PetShopViewProductDetailsOutput {
        productId: string;
        name: string;
        description?: string;
        price: number;
        petTypeId: string;
        petTypeName: string;
        categoryId: string;
        categoryName: string;
        highlighted: boolean;
        status: string;
        createdAt: string;
        updatedAt: string;
    }
}
declare module "_102049_/l2/petShop/web/contracts/productCatalog.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/productManagement.defs" {
    export const definition: ({
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        canonicalOutputShape: {
            kind: string;
            fields: {
                name: string;
                type: string;
                required: boolean;
                fieldRef: string;
            }[];
        };
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
            source: string;
            presentation: string;
        })[];
        output: {
            name: string;
            type: string;
            required: boolean;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    } | {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        canonicalOutputShape: {
            kind: string;
            fields: ({
                name: string;
                type: string;
                required: boolean;
                item?: undefined;
            } | {
                name: string;
                type: string;
                required: boolean;
                item: {
                    fields: {
                        name: string;
                        type: string;
                        required: boolean;
                        fieldRef: string;
                    }[];
                };
            })[];
        };
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: {
            name: string;
            type: string;
            required: boolean;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    })[];
    export const pipeline: readonly [{
        readonly id: "productManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/productManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/productManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/productManagement" {
    export interface PetShopBrowseProductsInput {
        searchTerm?: string;
        petTypeId?: string;
        categoryId?: string;
        priceMin?: number;
        priceMax?: number;
        status?: "available" | "unavailable";
        highlighted?: boolean;
    }
    export interface PetShopBrowseProductsOutputItem {
        productId: string;
        name: string;
        description?: string;
        price: number;
        petTypeId: string;
        petTypeName: string;
        categoryId: string;
        categoryName: string;
        highlighted: boolean;
        status: string;
        createdAt: string;
        updatedAt: string;
    }
    export type PetShopBrowseProductsOutput = PetShopBrowseProductsOutputItem[];
    export interface PetShopCreateProductInput {
        name: string;
        description?: string;
        price: number;
        petTypeId: string;
        categoryId: string;
        highlighted: boolean;
        status: "available" | "unavailable";
    }
    export interface PetShopCreateProductOutput {
        productId: string;
        name: string;
        description?: string;
        price: number;
        petTypeId: string;
        categoryId: string;
        highlighted: boolean;
        status: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface PetShopUpdateProductInput {
        productId: string;
        name?: string;
        description?: string;
        price?: number;
        petTypeId?: string;
        categoryId?: string;
        highlighted?: boolean;
        status?: "available" | "unavailable";
    }
    export interface PetShopUpdateProductOutput {
        productId: string;
        name: string;
        description?: string;
        price: number;
        petTypeId: string;
        categoryId: string;
        highlighted: boolean;
        status: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface PetShopSetProductHighlightsInput {
        productIds: string[];
        highlighted: boolean;
    }
    export interface PetShopSetProductHighlightsProduct {
        productId: string;
        name: string;
        highlighted: boolean;
        status: string;
    }
    export interface PetShopSetProductHighlightsOutput {
        updatedCount: number;
        products: PetShopSetProductHighlightsProduct[];
    }
}
declare module "_102049_/l2/petShop/web/contracts/productManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/contracts/reservationManagement.defs" {
    export const definition: ({
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        canonicalOutputShape: {
            kind: string;
            fields: ({
                name: string;
                type: string;
                required: boolean;
                fieldRef: string;
                item?: undefined;
            } | {
                name: string;
                type: string;
                required: boolean;
                item: {
                    fields: {
                        name: string;
                        type: string;
                        required: boolean;
                        fieldRef: string;
                    }[];
                };
                fieldRef?: undefined;
            })[];
        };
        input: {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
            source: string;
            presentation: string;
        }[];
        output: {
            name: string;
            type: string;
            required: boolean;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    } | {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        canonicalOutputShape: {
            kind: string;
            fields: {
                name: string;
                type: string;
                required: boolean;
                fieldRef: string;
            }[];
        };
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
            source: string;
            presentation: string;
        })[];
        output: {
            name: string;
            type: string;
            required: boolean;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    } | {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        canonicalOutputShape: {
            kind: string;
            fields: ({
                name: string;
                type: string;
                required: boolean;
                item?: undefined;
            } | {
                name: string;
                type: string;
                required: boolean;
                item: {
                    fields: {
                        name: string;
                        type: string;
                        required: boolean;
                        fieldRef: string;
                    }[];
                };
            })[];
        };
        input: any[];
        output: {
            name: string;
            type: string;
            required: boolean;
        }[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    })[];
    export const pipeline: readonly [{
        readonly id: "reservationManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102049_/l2/petShop/web/contracts/reservationManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/contracts/reservationManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/contracts/reservationManagement" {
    export interface PetShopListReservationsInput {
        status?: "draft" | "active" | "ready" | "delivered" | "expired" | "cancelled";
    }
    export interface PetShopListReservationsItem {
        reservationItemId: string;
        productId: string;
        quantity: number;
    }
    export interface PetShopListReservationsOutputItem {
        reservationId: string;
        customerId: string;
        status: string;
        confirmedAt?: string;
        expiresAt: string;
        readyAt?: string;
        deliveredAt?: string;
        createdAt: string;
        updatedAt: string;
        items: PetShopListReservationsItem[];
    }
    export type PetShopListReservationsOutput = PetShopListReservationsOutputItem[];
    export interface PetShopUpdateReservationStatusInput {
        reservationId: string;
        status: "draft" | "active" | "ready" | "delivered" | "expired" | "cancelled";
        cancelReason?: string;
        paymentId?: string;
    }
    export interface PetShopUpdateReservationStatusOutput {
        reservationId: string;
        status: string;
        readyAt?: string;
        deliveredAt?: string;
        cancelledAt?: string;
        cancelReason?: string;
        paymentId?: string;
        updatedAt: string;
    }
    export interface PetShopPayInStoreInput {
        reservationId: string;
        paymentMethod: unknown;
        paymentAmount: number;
    }
    export interface PetShopPayInStoreOutput {
        reservationId: string;
        status: string;
        deliveredAt: string;
        paymentId: string;
        updatedAt: string;
    }
    export interface PetShopExpireReservationsInput {
    }
    export interface PetShopExpireReservation {
        reservationId: string;
        status: string;
        expiredAt: string;
    }
    export interface PetShopExpireReservationsOutput {
        expiredCount: number;
        expiredReservations: PetShopExpireReservation[];
        productsReleased: number;
    }
}
declare module "_102049_/l2/petShop/web/contracts/reservationManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/desktop/page11/myReservations.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        submitAction: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            source?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "myReservations__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/myReservations.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/myReservations.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/myReservations.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["myReservations__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Catálogo-first, cards de produto com foto e preço, seção de destaques na home, checkout simplificado focado em reserva e retirada na loja";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/desktop/page11/myReservations.test" {
    export const pageTests: {
        readonly moduleName: "petShop";
        readonly page: "myReservations";
        readonly variant: "page11";
        readonly cases: readonly [{
            readonly id: "createReservation.ok";
            readonly routine: "petShop.reservationLifecycle.createReservation";
            readonly params: {
                readonly items: "<seedRef>";
            };
            readonly expect: {
                readonly ok: true;
                readonly shape: "object";
            };
            readonly mutating: true;
        }, {
            readonly id: "createReservation.items.required";
            readonly routine: "petShop.reservationLifecycle.createReservation";
            readonly params: {};
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }, {
            readonly id: "cancelReservation.ok";
            readonly routine: "petShop.reservationLifecycle.cancelReservation";
            readonly params: {
                readonly reservationId: "<seedRef>";
            };
            readonly expect: {
                readonly ok: true;
                readonly shape: "object";
            };
            readonly mutating: true;
        }, {
            readonly id: "viewMyReservations.ok";
            readonly routine: "petShop.viewMyReservations.viewMyReservations";
            readonly params: {};
            readonly expect: {
                readonly ok: true;
                readonly shape: "array";
                readonly minItems: 1;
            };
        }];
    };
}
declare module "_102049_/l2/petShop/web/shared/myReservations" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopCreateReservationOutput, PetShopCancelReservationOutput, PetShopViewMyReservationsOutput } from "_102049_/l2/petShop/web/contracts/myReservations";
    export type { PetShopCreateReservationInput, PetShopCreateReservationItem, PetShopCreateReservationOutput, PetShopCancelReservationInput, PetShopCancelReservationRestoredProduct, PetShopCancelReservationOutput, PetShopViewMyReservationsInput, PetShopViewMyReservationsItem, PetShopViewMyReservationsOutputItem, PetShopViewMyReservationsOutput, } from "_102049_/l2/petShop/web/contracts/myReservations";
    const message_pt: {
        "section.board.title": string;
        "section.create.title": string;
        "section.cancel.title": string;
        "column.reservationId.label": string;
        "column.status.label": string;
        "column.expiresAt.label": string;
        "column.createdAt.label": string;
        "column.confirmedAt.label": string;
        "column.readyAt.label": string;
        "column.items.label": string;
        "empty.board": string;
        "empty.create": string;
        "empty.cancel": string;
        "field.items.label": string;
        "field.reservationId.label": string;
        "field.cancelReason.label": string;
        "action.createReservation.label": string;
        "action.cancelReservation.label": string;
        "action.createReservation.success": string;
        "action.createReservation.error": string;
        "action.cancelReservation.success": string;
        "action.cancelReservation.error": string;
        "rowAction.cancelReservation.label": string;
        "toolbar.refresh.label": string;
        "lane.active": string;
        "lane.ready": string;
        "lane.delivered": string;
        "lane.expired": string;
        "lane.cancelled": string;
        "page.myReservations.title": string;
        "section.reservations.title": string;
        "section.createReservation.title": string;
        "organism.reservationList.title": string;
        "organism.createForm.title": string;
        "intention.queryReservations.title": string;
        "intention.cancelReservation.title": string;
        "intention.createReservation.title": string;
        "filter.status.label": string;
        "action.viewMyReservations.label": string;
        "action.selectForCancel.label": string;
        "empty.reservations": string;
        "empty.cancelContext": string;
        "empty.createForm": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopMyReservationsBase extends CollabLitElement {
        /** state ui.myReservations.status — pageStatus */
        status: string;
        /** state ui.myReservations.action.createReservation.status — actionStatus, values: idle|loading|success|error */
        createReservationState: 'idle' | 'loading' | 'success' | 'error';
        /** state ui.myReservations.input.createReservation.items — input */
        createReservationItems: string;
        /** state ui.myReservations.output.createReservation — commandOutput */
        createReservationOutput: PetShopCreateReservationOutput | null;
        /** state ui.myReservations.action.createReservation.error — actionError */
        createReservationError: string;
        /** state ui.myReservations.action.cancelReservation.status — actionStatus, values: idle|loading|success|error */
        cancelReservationState: 'idle' | 'loading' | 'success' | 'error';
        /** state ui.myReservations.input.cancelReservation.reservationId — input (selection) */
        cancelReservationReservationId: string;
        /** state ui.myReservations.input.cancelReservation.cancelReason — input */
        cancelReservationCancelReason: string;
        /** state ui.myReservations.output.cancelReservation — commandOutput */
        cancelReservationOutput: PetShopCancelReservationOutput | null;
        /** state ui.myReservations.action.cancelReservation.error — actionError */
        cancelReservationError: string;
        /** state ui.myReservations.action.viewMyReservations.status — actionStatus, values: idle|loading|success|error */
        viewMyReservationsState: 'idle' | 'loading' | 'success' | 'error';
        /** state ui.myReservations.data.viewMyReservations — queryResult, outputShape: array */
        viewMyReservationsData: PetShopViewMyReservationsOutput;
        /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
        protected get msg(): MessageType;
        /** action createReservation (command) — route petShop.reservationLifecycle.createReservation; inputs: items; writes ui.myReservations.output.createReservation; status ui.myReservations.action.createReservation.status; feedback keys action.createReservation.success / action.createReservation.error */
        createReservation(): Promise<void>;
        /** handler for action createReservation — bind UI events here */
        handleCreateReservationClick(e: Event): Promise<void>;
        /** action cancelReservation (command) — route petShop.reservationLifecycle.cancelReservation; inputs: reservationId, cancelReason; writes ui.myReservations.output.cancelReservation; status ui.myReservations.action.cancelReservation.status; feedback keys action.cancelReservation.success / action.cancelReservation.error */
        cancelReservation(): Promise<void>;
        /** handler for action cancelReservation — bind UI events here */
        handleCancelReservationClick(e: Event): Promise<void>;
        /** action viewMyReservations (query) — route petShop.viewMyReservations.viewMyReservations; inputs: none; writes ui.myReservations.data.viewMyReservations; status ui.myReservations.action.viewMyReservations.status */
        loadViewMyReservations(): Promise<void>;
        /** handler for action viewMyReservations — bind UI events here */
        handleViewMyReservationsClick(e: Event): Promise<void>;
        /** setter for state ui.myReservations.input.createReservation.items */
        setCreateReservationItems(value: string): void;
        /** handler for action set.createReservationItems — bind UI events here */
        handleCreateReservationItemsChange(e: Event): void;
        /** setter for state ui.myReservations.input.cancelReservation.reservationId */
        setCancelReservationReservationId(value: string): void;
        /** handler for action set.cancelReservationReservationId — bind UI events here */
        handleCancelReservationReservationIdChange(e: Event): void;
        /** setter for state ui.myReservations.input.cancelReservation.cancelReason */
        setCancelReservationCancelReason(value: string): void;
        /** handler for action set.cancelReservationCancelReason — bind UI events here */
        handleCancelReservationCancelReasonChange(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/myReservations" {
    import { PetShopMyReservationsBase } from "_102049_/l2/petShop/web/shared/myReservations";
    export class PetShopDesktopPage11MyReservationsPage extends PetShopMyReservationsBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/productCatalog.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    stateKey: string;
                    submitAction: string;
                    order: number;
                    action?: undefined;
                } | {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                    submitAction?: undefined;
                })[];
            }[];
        }[];
        templateId: string;
        visualStyle: string;
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        submitAction: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        source?: undefined;
                        action?: undefined;
                        emptyKey?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                        submitAction?: undefined;
                    })[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "productCatalog__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/productCatalog.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/productCatalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/productCatalog.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["productCatalog__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Catálogo-first, cards de produto com foto e preço, seção de destaques na home, checkout simplificado focado em reserva e retirada na loja";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/desktop/page11/productCatalog.test" {
    export const pageTests: {
        readonly moduleName: "petShop";
        readonly page: "productCatalog";
        readonly variant: "page11";
        readonly cases: readonly [{
            readonly id: "viewHighlights.ok";
            readonly routine: "petShop.viewHighlights.viewHighlights";
            readonly params: {};
            readonly expect: {
                readonly ok: true;
                readonly shape: "array";
                readonly minItems: 1;
            };
        }, {
            readonly id: "browseCatalog.ok";
            readonly routine: "petShop.browseCatalog.browseCatalog";
            readonly params: {};
            readonly expect: {
                readonly ok: true;
                readonly shape: "paginated";
                readonly minItems: 1;
            };
        }, {
            readonly id: "searchProducts.ok";
            readonly routine: "petShop.searchProducts.searchProducts";
            readonly params: {
                readonly searchTerm: "<seedRef>";
            };
            readonly expect: {
                readonly ok: true;
                readonly shape: "array";
                readonly minItems: 1;
            };
        }, {
            readonly id: "filterProducts.ok";
            readonly routine: "petShop.filterProducts.filterProducts";
            readonly params: {};
            readonly expect: {
                readonly ok: true;
                readonly shape: "array";
                readonly minItems: 1;
            };
        }, {
            readonly id: "viewProductDetails.ok";
            readonly routine: "petShop.viewProductDetails.viewProductDetails";
            readonly params: {
                readonly productId: "<seedRef>";
            };
            readonly expect: {
                readonly ok: true;
                readonly shape: "object";
            };
        }];
    };
}
declare module "_102049_/l2/petShop/web/shared/productCatalog" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopViewHighlightsOutput, PetShopBrowseCatalogOutput, PetShopSearchProductsOutput, PetShopFilterProductsOutput, PetShopViewProductDetailsOutput } from "_102049_/l2/petShop/web/contracts/productCatalog";
    export type { PetShopViewHighlightsInput, PetShopViewHighlightsOutputItem, PetShopViewHighlightsOutput, PetShopBrowseCatalogInput, PetShopBrowseCatalogProduct, PetShopBrowseCatalogOutput, PetShopSearchProductsInput, PetShopSearchProductsOutputItem, PetShopSearchProductsOutput, PetShopFilterProductsInput, PetShopFilterProductsOutputItem, PetShopFilterProductsOutput, PetShopViewProductDetailsInput, PetShopViewProductDetailsOutput } from "_102049_/l2/petShop/web/contracts/productCatalog";
    const message_pt: {
        "page.productCatalog.title": string;
        "section.overview.title": string;
        "section.catalog.title": string;
        "section.details.title": string;
        "organism.highlightsCards.title": string;
        "organism.catalogSummary.title": string;
        "organism.catalogBrowser.title": string;
        "organism.productDetails.title": string;
        "intention.viewHighlights.title": string;
        "intention.browseCatalogSummary.title": string;
        "intention.browseCatalogFilter.title": string;
        "intention.searchProductsFilter.title": string;
        "intention.filterProductsFilter.title": string;
        "intention.searchProductsList.title": string;
        "intention.filterProductsList.title": string;
        "intention.viewProductDetails.title": string;
        "intention.viewHighlights.empty": string;
        "intention.browseCatalogSummary.empty": string;
        "intention.searchProductsList.empty": string;
        "intention.filterProductsList.empty": string;
        "intention.viewProductDetails.empty": string;
        "field.searchTerm.label": string;
        "field.petTypeId.label": string;
        "field.categoryId.label": string;
        "field.minPrice.label": string;
        "field.maxPrice.label": string;
        "field.productId.label": string;
        "field.name.label": string;
        "field.description.label": string;
        "field.price.label": string;
        "field.petTypeName.label": string;
        "field.categoryName.label": string;
        "field.highlighted.label": string;
        "field.status.label": string;
        "field.products.label": string;
        "field.total.label": string;
        "field.page.label": string;
        "field.pageSize.label": string;
        "field.createdAt.label": string;
        "field.updatedAt.label": string;
        "action.browseCatalog.label": string;
        "action.searchProducts.label": string;
        "action.filterProducts.label": string;
        "action.viewProductDetails.label": string;
        "action.viewHighlights.label": string;
        "sec.overview.title": string;
        "org.highlights.title": string;
        "org.catalog.summary.title": string;
        "sec.catalog.title": string;
        "org.catalog.browser.title": string;
        "sec.details.title": string;
        "org.product.details.title": string;
        "page.title": string;
        "section.highlights.title": string;
        "section.detail.title": string;
        "empty.highlights": string;
        "empty.catalog": string;
        "empty.detail": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopProductCatalogBase extends CollabLitElement {
        private readonly subscribedKeys;
        /** state ui.productCatalog.status — pageStatus */
        status: string;
        /** state ui.productCatalog.action.viewHighlights.status — actionStatus, values: idle | loading | success | error */
        viewHighlightsState: 'idle' | 'loading' | 'success' | 'error';
        /** state ui.productCatalog.data.viewHighlights — queryResult, outputShape: array */
        viewHighlightsData: PetShopViewHighlightsOutput;
        /** state ui.productCatalog.action.browseCatalog.status — actionStatus, values: idle | loading | success | error */
        browseCatalogState: 'idle' | 'loading' | 'success' | 'error';
        /** state ui.productCatalog.input.browseCatalog.searchTerm — input */
        browseCatalogSearchTerm: string;
        /** state ui.productCatalog.input.browseCatalog.petTypeId — input */
        browseCatalogPetTypeId: string;
        /** state ui.productCatalog.input.browseCatalog.categoryId — input */
        browseCatalogCategoryId: string;
        /** state ui.productCatalog.input.browseCatalog.minPrice — input */
        browseCatalogMinPrice: number | '';
        /** state ui.productCatalog.input.browseCatalog.maxPrice — input */
        browseCatalogMaxPrice: number | '';
        /** state ui.productCatalog.data.browseCatalog — queryResult, outputShape: paginated */
        browseCatalogData: PetShopBrowseCatalogOutput;
        /** state ui.productCatalog.action.searchProducts.status — actionStatus, values: idle | loading | success | error */
        searchProductsState: 'idle' | 'loading' | 'success' | 'error';
        /** state ui.productCatalog.input.searchProducts.searchTerm — input */
        searchProductsSearchTerm: string;
        /** state ui.productCatalog.input.searchProducts.petTypeId — input */
        searchProductsPetTypeId: string;
        /** state ui.productCatalog.input.searchProducts.categoryId — input */
        searchProductsCategoryId: string;
        /** state ui.productCatalog.input.searchProducts.minPrice — input */
        searchProductsMinPrice: number | '';
        /** state ui.productCatalog.input.searchProducts.maxPrice — input */
        searchProductsMaxPrice: number | '';
        /** state ui.productCatalog.data.searchProducts — queryResult, outputShape: array */
        searchProductsData: PetShopSearchProductsOutput;
        /** state ui.productCatalog.action.filterProducts.status — actionStatus, values: idle | loading | success | error */
        filterProductsState: 'idle' | 'loading' | 'success' | 'error';
        /** state ui.productCatalog.input.filterProducts.petTypeId — input */
        filterProductsPetTypeId: string;
        /** state ui.productCatalog.input.filterProducts.categoryId — input */
        filterProductsCategoryId: string;
        /** state ui.productCatalog.input.filterProducts.minPrice — input */
        filterProductsMinPrice: number | '';
        /** state ui.productCatalog.input.filterProducts.maxPrice — input */
        filterProductsMaxPrice: number | '';
        /** state ui.productCatalog.data.filterProducts — queryResult, outputShape: array */
        filterProductsData: PetShopFilterProductsOutput;
        /** state ui.productCatalog.action.viewProductDetails.status — actionStatus, values: idle | loading | success | error */
        viewProductDetailsState: 'idle' | 'loading' | 'success' | 'error';
        /** state ui.productCatalog.input.viewProductDetails.productId — input */
        viewProductDetailsProductId: string;
        /** state ui.productCatalog.data.viewProductDetails — queryResult, outputShape: object */
        viewProductDetailsData: PetShopViewProductDetailsOutput | null;
        /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
        protected get msg(): MessageType;
        /** lifecycle connectedCallback — init state, subscribe and load data */
        connectedCallback(): void;
        /** lifecycle disconnectedCallback — cleanup subscriptions */
        disconnectedCallback(): void;
        /** action viewHighlights (query) — route petShop.viewHighlights.viewHighlights; inputs: none; writes ui.productCatalog.data.viewHighlights; status ui.productCatalog.action.viewHighlights.status */
        loadViewHighlights(): Promise<void>;
        /** handler for action viewHighlights — bind UI events here */
        handleViewHighlightsClick(event: Event): void;
        /** action browseCatalog (query) — route petShop.browseCatalog.browseCatalog; inputs: ui.productCatalog.input.browseCatalog.searchTerm, ui.productCatalog.input.browseCatalog.petTypeId, ui.productCatalog.input.browseCatalog.categoryId, ui.productCatalog.input.browseCatalog.minPrice, ui.productCatalog.input.browseCatalog.maxPrice; writes ui.productCatalog.data.browseCatalog; status ui.productCatalog.action.browseCatalog.status */
        loadBrowseCatalog(): Promise<void>;
        /** handler for action browseCatalog — bind UI events here */
        handleBrowseCatalogClick(event: Event): void;
        /** action searchProducts (query) — route petShop.searchProducts.searchProducts; inputs: ui.productCatalog.input.searchProducts.searchTerm, ui.productCatalog.input.searchProducts.petTypeId, ui.productCatalog.input.searchProducts.categoryId, ui.productCatalog.input.searchProducts.minPrice, ui.productCatalog.input.searchProducts.maxPrice; writes ui.productCatalog.data.searchProducts; status ui.productCatalog.action.searchProducts.status */
        loadSearchProducts(): Promise<void>;
        /** handler for action searchProducts — bind UI events here */
        handleSearchProductsClick(event: Event): void;
        /** action filterProducts (query) — route petShop.filterProducts.filterProducts; inputs: ui.productCatalog.input.filterProducts.petTypeId, ui.productCatalog.input.filterProducts.categoryId, ui.productCatalog.input.filterProducts.minPrice, ui.productCatalog.input.filterProducts.maxPrice; writes ui.productCatalog.data.filterProducts; status ui.productCatalog.action.filterProducts.status */
        loadFilterProducts(): Promise<void>;
        /** handler for action filterProducts — bind UI events here */
        handleFilterProductsClick(event: Event): void;
        /** action viewProductDetails (query) — route petShop.viewProductDetails.viewProductDetails; inputs: ui.productCatalog.input.viewProductDetails.productId; writes ui.productCatalog.data.viewProductDetails; status ui.productCatalog.action.viewProductDetails.status */
        loadViewProductDetails(): Promise<void>;
        /** handler for action viewProductDetails — bind UI events here */
        handleViewProductDetailsClick(event: Event): void;
        /** setter for state ui.productCatalog.input.browseCatalog.searchTerm */
        setBrowseCatalogSearchTerm(value: string): void;
        /** handler for action set.browseCatalogSearchTerm — bind UI events here */
        handleBrowseCatalogSearchTermChange(event: Event): void;
        /** setter for state ui.productCatalog.input.browseCatalog.petTypeId */
        setBrowseCatalogPetTypeId(value: string): void;
        /** handler for action set.browseCatalogPetTypeId — bind UI events here */
        handleBrowseCatalogPetTypeIdChange(event: Event): void;
        /** setter for state ui.productCatalog.input.browseCatalog.categoryId */
        setBrowseCatalogCategoryId(value: string): void;
        /** handler for action set.browseCatalogCategoryId — bind UI events here */
        handleBrowseCatalogCategoryIdChange(event: Event): void;
        /** setter for state ui.productCatalog.input.browseCatalog.minPrice */
        setBrowseCatalogMinPrice(value: number | ''): void;
        /** handler for action set.browseCatalogMinPrice — bind UI events here */
        handleBrowseCatalogMinPriceChange(event: Event): void;
        /** setter for state ui.productCatalog.input.browseCatalog.maxPrice */
        setBrowseCatalogMaxPrice(value: number | ''): void;
        /** handler for action set.browseCatalogMaxPrice — bind UI events here */
        handleBrowseCatalogMaxPriceChange(event: Event): void;
        /** setter for state ui.productCatalog.input.searchProducts.searchTerm */
        setSearchProductsSearchTerm(value: string): void;
        /** handler for action set.searchProductsSearchTerm — bind UI events here */
        handleSearchProductsSearchTermChange(event: Event): void;
        /** setter for state ui.productCatalog.input.searchProducts.petTypeId */
        setSearchProductsPetTypeId(value: string): void;
        /** handler for action set.searchProductsPetTypeId — bind UI events here */
        handleSearchProductsPetTypeIdChange(event: Event): void;
        /** setter for state ui.productCatalog.input.searchProducts.categoryId */
        setSearchProductsCategoryId(value: string): void;
        /** handler for action set.searchProductsCategoryId — bind UI events here */
        handleSearchProductsCategoryIdChange(event: Event): void;
        /** setter for state ui.productCatalog.input.searchProducts.minPrice */
        setSearchProductsMinPrice(value: number | ''): void;
        /** handler for action set.searchProductsMinPrice — bind UI events here */
        handleSearchProductsMinPriceChange(event: Event): void;
        /** setter for state ui.productCatalog.input.searchProducts.maxPrice */
        setSearchProductsMaxPrice(value: number | ''): void;
        /** handler for action set.searchProductsMaxPrice — bind UI events here */
        handleSearchProductsMaxPriceChange(event: Event): void;
        /** setter for state ui.productCatalog.input.filterProducts.petTypeId */
        setFilterProductsPetTypeId(value: string): void;
        /** handler for action set.filterProductsPetTypeId — bind UI events here */
        handleFilterProductsPetTypeIdChange(event: Event): void;
        /** setter for state ui.productCatalog.input.filterProducts.categoryId */
        setFilterProductsCategoryId(value: string): void;
        /** handler for action set.filterProductsCategoryId — bind UI events here */
        handleFilterProductsCategoryIdChange(event: Event): void;
        /** setter for state ui.productCatalog.input.filterProducts.minPrice */
        setFilterProductsMinPrice(value: number | ''): void;
        /** handler for action set.filterProductsMinPrice — bind UI events here */
        handleFilterProductsMinPriceChange(event: Event): void;
        /** setter for state ui.productCatalog.input.filterProducts.maxPrice */
        setFilterProductsMaxPrice(value: number | ''): void;
        /** handler for action set.filterProductsMaxPrice — bind UI events here */
        handleFilterProductsMaxPriceChange(event: Event): void;
        /** setter for state ui.productCatalog.input.viewProductDetails.productId */
        setViewProductDetailsProductId(value: string): void;
        /** handler for action set.viewProductDetailsProductId — bind UI events here */
        handleViewProductDetailsProductIdChange(event: Event): void;
        private initStateValue;
        private normalizeOptionalString;
        private normalizeOptionalNumber;
        private getRouteParams;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/productCatalog" {
    import { PetShopProductCatalogBase } from "_102049_/l2/petShop/web/shared/productCatalog";
    export class PetShopDesktopPage11ProductCatalogPage extends PetShopProductCatalogBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/productManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        submitAction: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "productManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/productManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/productManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/productManagement.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["productManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Catálogo-first, cards de produto com foto e preço, seção de destaques na home, checkout simplificado focado em reserva e retirada na loja";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/desktop/page11/productManagement.test" {
    export const pageTests: {
        readonly moduleName: "petShop";
        readonly page: "productManagement";
        readonly variant: "page11";
        readonly cases: readonly [{
            readonly id: "browseProducts.ok";
            readonly routine: "petShop.browseProducts.browseProducts";
            readonly params: {};
            readonly expect: {
                readonly ok: true;
                readonly shape: "array";
                readonly minItems: 1;
            };
        }, {
            readonly id: "createProduct.ok";
            readonly routine: "petShop.createProduct.createProduct";
            readonly params: {
                readonly name: "<seedRef>";
                readonly price: "<seedRef>";
                readonly petTypeId: "<seedRef>";
                readonly categoryId: "<seedRef>";
                readonly highlighted: "<seedRef>";
                readonly status: "<seedRef>";
            };
            readonly expect: {
                readonly ok: true;
                readonly shape: "object";
            };
            readonly mutating: true;
        }, {
            readonly id: "createProduct.name.required";
            readonly routine: "petShop.createProduct.createProduct";
            readonly params: {
                readonly price: "<seedRef>";
                readonly petTypeId: "<seedRef>";
                readonly categoryId: "<seedRef>";
                readonly highlighted: "<seedRef>";
                readonly status: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }, {
            readonly id: "createProduct.price.required";
            readonly routine: "petShop.createProduct.createProduct";
            readonly params: {
                readonly name: "<seedRef>";
                readonly petTypeId: "<seedRef>";
                readonly categoryId: "<seedRef>";
                readonly highlighted: "<seedRef>";
                readonly status: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }, {
            readonly id: "createProduct.petTypeId.required";
            readonly routine: "petShop.createProduct.createProduct";
            readonly params: {
                readonly name: "<seedRef>";
                readonly price: "<seedRef>";
                readonly categoryId: "<seedRef>";
                readonly highlighted: "<seedRef>";
                readonly status: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }, {
            readonly id: "createProduct.categoryId.required";
            readonly routine: "petShop.createProduct.createProduct";
            readonly params: {
                readonly name: "<seedRef>";
                readonly price: "<seedRef>";
                readonly petTypeId: "<seedRef>";
                readonly highlighted: "<seedRef>";
                readonly status: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }, {
            readonly id: "createProduct.highlighted.required";
            readonly routine: "petShop.createProduct.createProduct";
            readonly params: {
                readonly name: "<seedRef>";
                readonly price: "<seedRef>";
                readonly petTypeId: "<seedRef>";
                readonly categoryId: "<seedRef>";
                readonly status: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }, {
            readonly id: "createProduct.status.required";
            readonly routine: "petShop.createProduct.createProduct";
            readonly params: {
                readonly name: "<seedRef>";
                readonly price: "<seedRef>";
                readonly petTypeId: "<seedRef>";
                readonly categoryId: "<seedRef>";
                readonly highlighted: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }, {
            readonly id: "updateProduct.ok";
            readonly routine: "petShop.updateProduct.updateProduct";
            readonly params: {
                readonly productId: "<seedRef>";
            };
            readonly expect: {
                readonly ok: true;
                readonly shape: "object";
            };
            readonly mutating: true;
        }, {
            readonly id: "setProductHighlights.ok";
            readonly routine: "petShop.setProductHighlights.setProductHighlights";
            readonly params: {
                readonly productIds: "<seedRef>";
                readonly highlighted: "<seedRef>";
            };
            readonly expect: {
                readonly ok: true;
                readonly shape: "object";
            };
            readonly mutating: true;
        }, {
            readonly id: "setProductHighlights.productIds.required";
            readonly routine: "petShop.setProductHighlights.setProductHighlights";
            readonly params: {
                readonly highlighted: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }, {
            readonly id: "setProductHighlights.highlighted.required";
            readonly routine: "petShop.setProductHighlights.setProductHighlights";
            readonly params: {
                readonly productIds: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }];
    };
}
declare module "_102049_/l2/petShop/web/shared/productManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopBrowseProductsOutput, PetShopCreateProductOutput, PetShopUpdateProductOutput, PetShopSetProductHighlightsOutput } from "_102049_/l2/petShop/web/contracts/productManagement";
    export type { PetShopBrowseProductsInput, PetShopBrowseProductsOutputItem, PetShopBrowseProductsOutput, PetShopCreateProductInput, PetShopCreateProductOutput, PetShopUpdateProductInput, PetShopUpdateProductOutput, PetShopSetProductHighlightsInput, PetShopSetProductHighlightsProduct, PetShopSetProductHighlightsOutput } from "_102049_/l2/petShop/web/contracts/productManagement";
    const message_pt: {
        "page.productManagement.title": string;
        "section.productList.title": string;
        "section.createProduct.title": string;
        "section.updateProduct.title": string;
        "section.setHighlights.title": string;
        "field.searchTerm.label": string;
        "field.petTypeId.label": string;
        "field.categoryId.label": string;
        "field.priceMin.label": string;
        "field.priceMax.label": string;
        "field.status.label": string;
        "field.highlighted.label": string;
        "field.name.label": string;
        "field.description.label": string;
        "field.price.label": string;
        "field.productId.label": string;
        "field.productIds.label": string;
        "column.name.label": string;
        "column.price.label": string;
        "column.petTypeName.label": string;
        "column.categoryName.label": string;
        "column.highlighted.label": string;
        "column.status.label": string;
        "action.browseProducts.label": string;
        "action.createProduct.label": string;
        "action.updateProduct.label": string;
        "action.setProductHighlights.label": string;
        "empty.productList": string;
        "action.createProduct.success": string;
        "action.createProduct.error": string;
        "action.updateProduct.success": string;
        "action.updateProduct.error": string;
        "action.setProductHighlights.success": string;
        "action.setProductHighlights.error": string;
        "section.product.list.title": string;
        "org.product.table.title": string;
        "section.create.product.title": string;
        "org.create.form.title": string;
        "section.update.product.title": string;
        "org.update.form.title": string;
        "section.set.highlights.title": string;
        "org.highlights.form.title": string;
        "section.catalog.title": string;
        "section.detail.title": string;
        "organism.productList.title": string;
        "organism.updateProductForm.title": string;
        "organism.createProductForm.title": string;
        "organism.setHighlightsForm.title": string;
        "intent.productList.title": string;
        "intent.updateProduct.title": string;
        "intent.createProduct.title": string;
        "intent.setHighlights.title": string;
        "field.product.name": string;
        "field.product.description": string;
        "field.product.price": string;
        "field.product.petTypeId": string;
        "field.product.petTypeName": string;
        "field.product.categoryId": string;
        "field.product.categoryName": string;
        "field.product.highlighted": string;
        "field.product.status": string;
        "field.product.searchTerm": string;
        "field.product.priceMin": string;
        "field.product.priceMax": string;
        "field.product.productIds": string;
        "action.browseProducts": string;
        "action.selectForEdit": string;
        "action.updateProduct": string;
        "action.createProduct": string;
        "action.setProductHighlights": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopProductManagementBase extends CollabLitElement {
        private readonly stateDefaults;
        private readonly subscribedKeys;
        /** state ui.productManagement.status — pageStatus */
        status: string;
        /** state ui.productManagement.action.browseProducts.status — actionStatus, values: idle | loading | success | error */
        browseProductsState: 'idle' | 'loading' | 'success' | 'error';
        /** state ui.productManagement.input.browseProducts.searchTerm — input */
        browseProductsSearchTerm: string;
        /** state ui.productManagement.input.browseProducts.petTypeId — input */
        browseProductsPetTypeId: string;
        /** state ui.productManagement.input.browseProducts.categoryId — input */
        browseProductsCategoryId: string;
        /** state ui.productManagement.input.browseProducts.priceMin — input */
        browseProductsPriceMin: number | '';
        /** state ui.productManagement.input.browseProducts.priceMax — input */
        browseProductsPriceMax: number | '';
        /** state ui.productManagement.input.browseProducts.status — input, values: available | unavailable */
        browseProductsStatus: 'available' | 'unavailable' | '';
        /** state ui.productManagement.input.browseProducts.highlighted — input */
        browseProductsHighlighted: boolean | '';
        /** state ui.productManagement.data.browseProducts — queryResult, outputShape: array */
        browseProductsData: PetShopBrowseProductsOutput;
        /** state ui.productManagement.action.createProduct.status — actionStatus, values: idle | loading | success | error */
        createProductState: 'idle' | 'loading' | 'success' | 'error';
        /** state ui.productManagement.input.createProduct.name — input */
        createProductName: string;
        /** state ui.productManagement.input.createProduct.description — input */
        createProductDescription: string;
        /** state ui.productManagement.input.createProduct.price — input */
        createProductPrice: number | '';
        /** state ui.productManagement.input.createProduct.petTypeId — input */
        createProductPetTypeId: string;
        /** state ui.productManagement.input.createProduct.categoryId — input */
        createProductCategoryId: string;
        /** state ui.productManagement.input.createProduct.highlighted — input */
        createProductHighlighted: boolean | '';
        /** state ui.productManagement.input.createProduct.status — input, values: available | unavailable */
        createProductStatus: 'available' | 'unavailable' | '';
        /** state ui.productManagement.output.createProduct — commandOutput */
        createProductOutput: PetShopCreateProductOutput | null;
        /** state ui.productManagement.action.createProduct.error — actionError */
        createProductError: string;
        /** state ui.productManagement.action.updateProduct.status — actionStatus, values: idle | loading | success | error */
        updateProductState: 'idle' | 'loading' | 'success' | 'error';
        /** state ui.productManagement.input.updateProduct.productId — input */
        updateProductProductId: string;
        /** state ui.productManagement.input.updateProduct.name — input */
        updateProductName: string;
        /** state ui.productManagement.input.updateProduct.description — input */
        updateProductDescription: string;
        /** state ui.productManagement.input.updateProduct.price — input */
        updateProductPrice: number | '';
        /** state ui.productManagement.input.updateProduct.petTypeId — input */
        updateProductPetTypeId: string;
        /** state ui.productManagement.input.updateProduct.categoryId — input */
        updateProductCategoryId: string;
        /** state ui.productManagement.input.updateProduct.highlighted — input */
        updateProductHighlighted: boolean | '';
        /** state ui.productManagement.input.updateProduct.status — input, values: available | unavailable */
        updateProductStatus: 'available' | 'unavailable' | '';
        /** state ui.productManagement.output.updateProduct — commandOutput */
        updateProductOutput: PetShopUpdateProductOutput | null;
        /** state ui.productManagement.action.updateProduct.error — actionError */
        updateProductError: string;
        /** state ui.productManagement.action.setProductHighlights.status — actionStatus, values: idle | loading | success | error */
        setProductHighlightsState: 'idle' | 'loading' | 'success' | 'error';
        /** state ui.productManagement.input.setProductHighlights.productIds — input */
        setProductHighlightsProductIds: string[] | '';
        /** state ui.productManagement.input.setProductHighlights.highlighted — input */
        setProductHighlightsHighlighted: boolean | '';
        /** state ui.productManagement.output.setProductHighlights — commandOutput */
        setProductHighlightsOutput: PetShopSetProductHighlightsOutput | null;
        /** state ui.productManagement.action.setProductHighlights.error — actionError */
        setProductHighlightsError: string;
        /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        /** action browseProducts (query) — route petShop.browseProducts.browseProducts; inputs: searchTerm, petTypeId, categoryId, priceMin, priceMax, status, highlighted; writes ui.productManagement.data.browseProducts; status ui.productManagement.action.browseProducts.status */
        loadBrowseProducts(): Promise<void>;
        /** handler for action browseProducts — bind UI events here */
        handleBrowseProductsClick(_event: Event): void;
        /** action createProduct (command) — route petShop.createProduct.createProduct; inputs: name, description, price, petTypeId, categoryId, highlighted, status; writes ui.productManagement.output.createProduct; status ui.productManagement.action.createProduct.status; feedback keys action.createProduct.success / action.createProduct.error */
        createProduct(signal?: AbortSignal): Promise<void>;
        /** handler for action createProduct — bind UI events here */
        handleCreateProductClick(_event: Event): void;
        /** action updateProduct (command) — route petShop.updateProduct.updateProduct; inputs: productId, name, description, price, petTypeId, categoryId, highlighted, status; writes ui.productManagement.output.updateProduct; status ui.productManagement.action.updateProduct.status; feedback keys action.updateProduct.success / action.updateProduct.error */
        updateProduct(signal?: AbortSignal): Promise<void>;
        /** handler for action updateProduct — bind UI events here */
        handleUpdateProductClick(_event: Event): void;
        /** action setProductHighlights (command) — route petShop.setProductHighlights.setProductHighlights; inputs: productIds, highlighted; writes ui.productManagement.output.setProductHighlights; status ui.productManagement.action.setProductHighlights.status; feedback keys action.setProductHighlights.success / action.setProductHighlights.error */
        setProductHighlights(signal?: AbortSignal): Promise<void>;
        /** handler for action setProductHighlights — bind UI events here */
        handleSetProductHighlightsClick(_event: Event): void;
        /** setter for state ui.productManagement.input.browseProducts.searchTerm */
        setBrowseProductsSearchTerm(value: string): void;
        /** handler for action set.browseProductsSearchTerm — bind UI events here */
        handleBrowseProductsSearchTermChange(event: Event): void;
        /** setter for state ui.productManagement.input.browseProducts.petTypeId */
        setBrowseProductsPetTypeId(value: string): void;
        /** handler for action set.browseProductsPetTypeId — bind UI events here */
        handleBrowseProductsPetTypeIdChange(event: Event): void;
        /** setter for state ui.productManagement.input.browseProducts.categoryId */
        setBrowseProductsCategoryId(value: string): void;
        /** handler for action set.browseProductsCategoryId — bind UI events here */
        handleBrowseProductsCategoryIdChange(event: Event): void;
        /** setter for state ui.productManagement.input.browseProducts.priceMin */
        setBrowseProductsPriceMin(value: number | ''): void;
        /** handler for action set.browseProductsPriceMin — bind UI events here */
        handleBrowseProductsPriceMinChange(event: Event): void;
        /** setter for state ui.productManagement.input.browseProducts.priceMax */
        setBrowseProductsPriceMax(value: number | ''): void;
        /** handler for action set.browseProductsPriceMax — bind UI events here */
        handleBrowseProductsPriceMaxChange(event: Event): void;
        /** setter for state ui.productManagement.input.browseProducts.status */
        setBrowseProductsStatus(value: 'available' | 'unavailable' | ''): void;
        /** handler for action set.browseProductsStatus — bind UI events here */
        handleBrowseProductsStatusChange(event: Event): void;
        /** setter for state ui.productManagement.input.browseProducts.highlighted */
        setBrowseProductsHighlighted(value: boolean | ''): void;
        /** handler for action set.browseProductsHighlighted — bind UI events here */
        handleBrowseProductsHighlightedChange(event: Event): void;
        /** setter for state ui.productManagement.input.createProduct.name */
        setCreateProductName(value: string): void;
        /** handler for action set.createProductName — bind UI events here */
        handleCreateProductNameChange(event: Event): void;
        /** setter for state ui.productManagement.input.createProduct.description */
        setCreateProductDescription(value: string): void;
        /** handler for action set.createProductDescription — bind UI events here */
        handleCreateProductDescriptionChange(event: Event): void;
        /** setter for state ui.productManagement.input.createProduct.price */
        setCreateProductPrice(value: number | ''): void;
        /** handler for action set.createProductPrice — bind UI events here */
        handleCreateProductPriceChange(event: Event): void;
        /** setter for state ui.productManagement.input.createProduct.petTypeId */
        setCreateProductPetTypeId(value: string): void;
        /** handler for action set.createProductPetTypeId — bind UI events here */
        handleCreateProductPetTypeIdChange(event: Event): void;
        /** setter for state ui.productManagement.input.createProduct.categoryId */
        setCreateProductCategoryId(value: string): void;
        /** handler for action set.createProductCategoryId — bind UI events here */
        handleCreateProductCategoryIdChange(event: Event): void;
        /** setter for state ui.productManagement.input.createProduct.highlighted */
        setCreateProductHighlighted(value: boolean | ''): void;
        /** handler for action set.createProductHighlighted — bind UI events here */
        handleCreateProductHighlightedChange(event: Event): void;
        /** setter for state ui.productManagement.input.createProduct.status */
        setCreateProductStatus(value: 'available' | 'unavailable' | ''): void;
        /** handler for action set.createProductStatus — bind UI events here */
        handleCreateProductStatusChange(event: Event): void;
        /** setter for state ui.productManagement.input.updateProduct.productId */
        setUpdateProductProductId(value: string): void;
        /** handler for action set.updateProductProductId — bind UI events here */
        handleUpdateProductProductIdChange(event: Event): void;
        /** setter for state ui.productManagement.input.updateProduct.name */
        setUpdateProductName(value: string): void;
        /** handler for action set.updateProductName — bind UI events here */
        handleUpdateProductNameChange(event: Event): void;
        /** setter for state ui.productManagement.input.updateProduct.description */
        setUpdateProductDescription(value: string): void;
        /** handler for action set.updateProductDescription — bind UI events here */
        handleUpdateProductDescriptionChange(event: Event): void;
        /** setter for state ui.productManagement.input.updateProduct.price */
        setUpdateProductPrice(value: number | ''): void;
        /** handler for action set.updateProductPrice — bind UI events here */
        handleUpdateProductPriceChange(event: Event): void;
        /** setter for state ui.productManagement.input.updateProduct.petTypeId */
        setUpdateProductPetTypeId(value: string): void;
        /** handler for action set.updateProductPetTypeId — bind UI events here */
        handleUpdateProductPetTypeIdChange(event: Event): void;
        /** setter for state ui.productManagement.input.updateProduct.categoryId */
        setUpdateProductCategoryId(value: string): void;
        /** handler for action set.updateProductCategoryId — bind UI events here */
        handleUpdateProductCategoryIdChange(event: Event): void;
        /** setter for state ui.productManagement.input.updateProduct.highlighted */
        setUpdateProductHighlighted(value: boolean | ''): void;
        /** handler for action set.updateProductHighlighted — bind UI events here */
        handleUpdateProductHighlightedChange(event: Event): void;
        /** setter for state ui.productManagement.input.updateProduct.status */
        setUpdateProductStatus(value: 'available' | 'unavailable' | ''): void;
        /** handler for action set.updateProductStatus — bind UI events here */
        handleUpdateProductStatusChange(event: Event): void;
        /** setter for state ui.productManagement.input.setProductHighlights.productIds */
        setSetProductHighlightsProductIds(value: string[] | ''): void;
        /** handler for action set.setProductHighlightsProductIds — bind UI events here */
        handleSetProductHighlightsProductIdsChange(event: Event): void;
        /** setter for state ui.productManagement.input.setProductHighlights.highlighted */
        setSetProductHighlightsHighlighted(value: boolean | ''): void;
        /** handler for action set.setProductHighlightsHighlighted — bind UI events here */
        handleSetProductHighlightsHighlightedChange(event: Event): void;
        private getStateValue;
        private getInputValue;
        private getNumberInputValue;
        private getBooleanInputValue;
        private normalizeStringArray;
        private clearInputStates;
        private refreshBrowseProducts;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/productManagement" {
    import { PetShopProductManagementBase } from "_102049_/l2/petShop/web/shared/productManagement";
    export class PetShopDesktopPage11ProductManagementPage extends PetShopProductManagementBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/reservationManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        submitAction: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        submitAction: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "reservationManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/reservationManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/reservationManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/reservationManagement.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["reservationManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Catálogo-first, cards de produto com foto e preço, seção de destaques na home, checkout simplificado focado em reserva e retirada na loja";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/desktop/page11/reservationManagement.test" {
    export const pageTests: {
        readonly moduleName: "petShop";
        readonly page: "reservationManagement";
        readonly variant: "page11";
        readonly cases: readonly [{
            readonly id: "listReservations.ok";
            readonly routine: "petShop.listReservations.listReservations";
            readonly params: {};
            readonly expect: {
                readonly ok: true;
                readonly shape: "array";
                readonly minItems: 1;
            };
        }, {
            readonly id: "updateReservationStatus.ok";
            readonly routine: "petShop.reservationLifecycle.updateReservationStatus";
            readonly params: {
                readonly reservationId: "<seedRef>";
                readonly status: "<seedRef>";
            };
            readonly expect: {
                readonly ok: true;
                readonly shape: "object";
            };
            readonly mutating: true;
        }, {
            readonly id: "updateReservationStatus.status.required";
            readonly routine: "petShop.reservationLifecycle.updateReservationStatus";
            readonly params: {
                readonly reservationId: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }, {
            readonly id: "payInStore.ok";
            readonly routine: "petShop.reservationLifecycle.payInStore";
            readonly params: {
                readonly reservationId: "<seedRef>";
                readonly paymentMethod: "<seedRef>";
                readonly paymentAmount: "<seedRef>";
            };
            readonly expect: {
                readonly ok: true;
                readonly shape: "object";
            };
            readonly mutating: true;
        }, {
            readonly id: "payInStore.paymentMethod.required";
            readonly routine: "petShop.reservationLifecycle.payInStore";
            readonly params: {
                readonly reservationId: "<seedRef>";
                readonly paymentAmount: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }, {
            readonly id: "payInStore.paymentAmount.required";
            readonly routine: "petShop.reservationLifecycle.payInStore";
            readonly params: {
                readonly reservationId: "<seedRef>";
                readonly paymentMethod: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }, {
            readonly id: "expireReservations.ok";
            readonly routine: "petShop.reservationLifecycle.expireReservations";
            readonly params: {};
            readonly expect: {
                readonly ok: true;
                readonly shape: "object";
            };
            readonly mutating: true;
        }];
    };
}
declare module "_102049_/l2/petShop/web/shared/reservationManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { PetShopExpireReservationsOutput, PetShopListReservationsInput, PetShopListReservationsOutput, PetShopPayInStoreOutput, PetShopUpdateReservationStatusInput, PetShopUpdateReservationStatusOutput } from "_102049_/l2/petShop/web/contracts/reservationManagement";
    export type { PetShopExpireReservation, PetShopExpireReservationsInput, PetShopExpireReservationsOutput, PetShopListReservationsInput, PetShopListReservationsItem, PetShopListReservationsOutput, PetShopListReservationsOutputItem, PetShopPayInStoreInput, PetShopPayInStoreOutput, PetShopUpdateReservationStatusInput, PetShopUpdateReservationStatusOutput, } from "_102049_/l2/petShop/web/contracts/reservationManagement";
    const message_pt: {
        "page.reservationManagement.title": string;
        "section.queue.title": string;
        "section.queue.empty": string;
        "section.execute.title": string;
        "section.batch.title": string;
        "section.review.title": string;
        "intention.queryReservations.title": string;
        "intention.updateStatus.title": string;
        "intention.payInStore.title": string;
        "intention.expireReservations.title": string;
        "intention.expireReservations.empty": string;
        "intention.summary.title": string;
        "column.reservationId": string;
        "column.customerId": string;
        "column.status": string;
        "column.expiresAt": string;
        "column.readyAt": string;
        "column.items": string;
        "filter.status": string;
        "field.reservationId": string;
        "field.status": string;
        "field.cancelReason": string;
        "field.paymentId": string;
        "field.paymentMethod": string;
        "field.paymentAmount": string;
        "action.refresh": string;
        "action.selectForUpdate": string;
        "action.selectForPayment": string;
        "action.updateReservationStatus.submit": string;
        "action.payInStore.submit": string;
        "action.expireReservations.submit": string;
        "action.updateReservationStatus.success": string;
        "action.updateReservationStatus.error": string;
        "action.payInStore.success": string;
        "action.payInStore.error": string;
        "action.expireReservations.success": string;
        "action.expireReservations.error": string;
        "org.reservationQueue.title": string;
        "org.reservationTransitions.title": string;
        "org.batchOperations.title": string;
        "org.reviewSummary.title": string;
        "section.detail.title": string;
        "organism.reservationBoard.title": string;
        "organism.reservationTransitions.title": string;
        "organism.payInStore.title": string;
        "intent.listReservations.title": string;
        "intent.updateReservationStatus.title": string;
        "intent.payInStore.title": string;
        "field.customerId": string;
        "field.expiresAt": string;
        "field.readyAt": string;
        "field.deliveredAt": string;
        "field.items": string;
        "action.listReservations": string;
        "action.expireReservations": string;
        "action.selectReservation": string;
        "action.updateReservationStatus.ready": string;
        "action.updateReservationStatus.delivered": string;
        "action.updateReservationStatus.cancelled": string;
        "action.payInStore": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopReservationManagementBase extends CollabLitElement {
        private readonly _stateKeys;
        /** state ui.reservationManagement.status — pageStatus */
        status: string;
        /** state ui.reservationManagement.action.listReservations.status — actionStatus, values: idle | loading | success | error */
        listReservationsState: 'idle' | 'loading' | 'success' | 'error';
        /** state ui.reservationManagement.input.listReservations.status — input, values: draft | active | ready | delivered | expired | cancelled */
        listReservationsStatus: PetShopListReservationsInput['status'] | '';
        /** state ui.reservationManagement.data.listReservations — queryResult, outputShape: array */
        listReservationsData: PetShopListReservationsOutput;
        /** state ui.reservationManagement.action.updateReservationStatus.status — actionStatus, values: idle | loading | success | error */
        updateReservationStatusState: 'idle' | 'loading' | 'success' | 'error';
        /** state ui.reservationManagement.input.updateReservationStatus.reservationId — input */
        updateReservationStatusReservationId: string;
        /** state ui.reservationManagement.input.updateReservationStatus.status — input, values: draft | active | ready | delivered | expired | cancelled */
        updateReservationStatusStatus: PetShopUpdateReservationStatusInput['status'] | '';
        /** state ui.reservationManagement.input.updateReservationStatus.cancelReason — input */
        updateReservationStatusCancelReason: string;
        /** state ui.reservationManagement.input.updateReservationStatus.paymentId — input */
        updateReservationStatusPaymentId: string;
        /** state ui.reservationManagement.output.updateReservationStatus — commandOutput */
        updateReservationStatusOutput: PetShopUpdateReservationStatusOutput | null;
        /** state ui.reservationManagement.action.updateReservationStatus.error — actionError */
        updateReservationStatusError: string;
        /** state ui.reservationManagement.action.payInStore.status — actionStatus, values: idle | loading | success | error */
        payInStoreState: 'idle' | 'loading' | 'success' | 'error';
        /** state ui.reservationManagement.input.payInStore.reservationId — input */
        payInStoreReservationId: string;
        /** state ui.reservationManagement.input.payInStore.paymentMethod — input */
        payInStorePaymentMethod: unknown;
        /** state ui.reservationManagement.input.payInStore.paymentAmount — input */
        payInStorePaymentAmount: number | '';
        /** state ui.reservationManagement.output.payInStore — commandOutput */
        payInStoreOutput: PetShopPayInStoreOutput | null;
        /** state ui.reservationManagement.action.payInStore.error — actionError */
        payInStoreError: string;
        /** state ui.reservationManagement.action.expireReservations.status — actionStatus, values: idle | loading | success | error */
        expireReservationsState: 'idle' | 'loading' | 'success' | 'error';
        /** state ui.reservationManagement.output.expireReservations — commandOutput */
        expireReservationsOutput: PetShopExpireReservationsOutput | null;
        /** state ui.reservationManagement.action.expireReservations.error — actionError */
        expireReservationsError: string;
        /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        /** action listReservations (query) — route petShop.listReservations.listReservations; inputs: status; writes ui.reservationManagement.data.listReservations; status ui.reservationManagement.action.listReservations.status */
        loadListReservations(): Promise<boolean>;
        /** handler for action listReservations — bind UI events here */
        handleListReservationsClick(): void;
        /** action updateReservationStatus (command) — route petShop.reservationLifecycle.updateReservationStatus; inputs: reservationId, status, cancelReason, paymentId; writes ui.reservationManagement.output.updateReservationStatus; status ui.reservationManagement.action.updateReservationStatus.status; feedback keys action.updateReservationStatus.success / action.updateReservationStatus.error */
        updateReservationStatus(signal?: AbortSignal): Promise<boolean>;
        /** handler for action updateReservationStatus — bind UI events here */
        handleUpdateReservationStatusClick(): void;
        /** action payInStore (command) — route petShop.reservationLifecycle.payInStore; inputs: reservationId, paymentMethod, paymentAmount; writes ui.reservationManagement.output.payInStore; status ui.reservationManagement.action.payInStore.status; feedback keys action.payInStore.success / action.payInStore.error */
        payInStore(signal?: AbortSignal): Promise<boolean>;
        /** handler for action payInStore — bind UI events here */
        handlePayInStoreClick(): void;
        /** action expireReservations (command) — route petShop.reservationLifecycle.expireReservations; inputs: none; writes ui.reservationManagement.output.expireReservations; status ui.reservationManagement.action.expireReservations.status; feedback keys action.expireReservations.success / action.expireReservations.error */
        expireReservations(signal?: AbortSignal): Promise<boolean>;
        /** handler for action expireReservations — bind UI events here */
        handleExpireReservationsClick(): void;
        /** setter for state ui.reservationManagement.input.listReservations.status */
        setListReservationsStatus(value: PetShopListReservationsInput['status'] | ''): void;
        /** handler for action set.listReservationsStatus — bind UI events here */
        handleListReservationsStatusChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.updateReservationStatus.reservationId */
        setUpdateReservationStatusReservationId(value: string): void;
        /** handler for action set.updateReservationStatusReservationId — bind UI events here */
        handleUpdateReservationStatusReservationIdChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.updateReservationStatus.status */
        setUpdateReservationStatusStatus(value: PetShopUpdateReservationStatusInput['status'] | ''): void;
        /** handler for action set.updateReservationStatusStatus — bind UI events here */
        handleUpdateReservationStatusStatusChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.updateReservationStatus.cancelReason */
        setUpdateReservationStatusCancelReason(value: string): void;
        /** handler for action set.updateReservationStatusCancelReason — bind UI events here */
        handleUpdateReservationStatusCancelReasonChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.updateReservationStatus.paymentId */
        setUpdateReservationStatusPaymentId(value: string): void;
        /** handler for action set.updateReservationStatusPaymentId — bind UI events here */
        handleUpdateReservationStatusPaymentIdChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.payInStore.reservationId */
        setPayInStoreReservationId(value: string): void;
        /** handler for action set.payInStoreReservationId — bind UI events here */
        handlePayInStoreReservationIdChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.payInStore.paymentMethod */
        setPayInStorePaymentMethod(value: unknown): void;
        /** handler for action set.payInStorePaymentMethod — bind UI events here */
        handlePayInStorePaymentMethodChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.payInStore.paymentAmount */
        setPayInStorePaymentAmount(value: number | ''): void;
        /** handler for action set.payInStorePaymentAmount — bind UI events here */
        handlePayInStorePaymentAmountChange(event: Event): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/reservationManagement" {
    import { PetShopReservationManagementBase } from "_102049_/l2/petShop/web/shared/reservationManagement";
    export class PetShopDesktopPage11ReservationManagementPage extends PetShopReservationManagementBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page21/myReservations.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                    action?: undefined;
                    submitAction?: undefined;
                } | {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                })[];
            }[];
        }[];
        templateId: string;
        visualStyle: string;
        pageObjective: {
            actor: string;
            jobToBeDone: string;
            primaryDecision: string;
            decisiveInfo: string[];
            usageFrequency: string;
            criticalActions: {
                action: string;
                presentation: string;
            }[];
            informationHierarchy: string[];
            successCriteria: string;
            antiPatterns: string[];
        };
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        action?: undefined;
                        submitAction?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    })[];
                }[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "myReservations__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page21/myReservations.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page21/myReservations.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/myReservations.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["myReservations__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Catálogo-first, cards de produto com foto e preço, seção de destaques na home, checkout simplificado focado em reserva e retirada na loja";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/desktop/page21/myReservations" {
    import { PetShopMyReservationsBase } from "_102049_/l2/petShop/web/shared/myReservations";
    export class PetShopDesktopPage21MyReservationsPage extends PetShopMyReservationsBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page21/productCatalog.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    submitAction: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            })[];
        })[];
        templateId: string;
        visualStyle: string;
        pageObjective: {
            actor: string;
            jobToBeDone: string;
            primaryDecision: string;
            decisiveInfo: string[];
            usageFrequency: string;
            criticalActions: {
                action: string;
                presentation: string;
            }[];
            informationHierarchy: string[];
            successCriteria: string;
            antiPatterns: string[];
        };
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    })[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        submitAction: string;
                        stateKey: string;
                        fields: any[];
                        columns: any[];
                        filters: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        submitAction: string;
                        stateKey: string;
                        fields: any[];
                        columns: any[];
                        filters: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    })[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                })[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "productCatalog__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page21/productCatalog.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page21/productCatalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/productCatalog.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["productCatalog__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Catálogo-first, cards de produto com foto e preço, seção de destaques na home, checkout simplificado focado em reserva e retirada na loja";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/desktop/page21/productCatalog" {
    import { PetShopProductCatalogBase } from "_102049_/l2/petShop/web/shared/productCatalog";
    export class PetShopDesktopPage21ProductCatalogPage extends PetShopProductCatalogBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page21/productManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        pageObjective: {
            actor: string;
            jobToBeDone: string;
            primaryDecision: string;
            decisiveInfo: string[];
            usageFrequency: string;
            criticalActions: {
                action: string;
                presentation: string;
            }[];
            informationHierarchy: string[];
            successCriteria: string[];
            antiPatterns: string[];
        };
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        displayHint: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            description: string;
            stateKey: string;
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "productManagement__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page21/productManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page21/productManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/productManagement.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["productManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Catálogo-first, cards de produto com foto e preço, seção de destaques na home, checkout simplificado focado em reserva e retirada na loja";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/desktop/page21/productManagement" {
    import { PetShopProductManagementBase } from "_102049_/l2/petShop/web/shared/productManagement";
    export class PetShopDesktopPage21ProductManagementPage extends PetShopProductManagementBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page21/reservationManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        pageObjective: {
            actor: string;
            jobToBeDone: string;
            primaryDecision: string;
            decisiveInfo: string[];
            usageFrequency: string;
            criticalActions: {
                action: string;
                presentation: string;
            }[];
            informationHierarchy: string[];
            successCriteria: string[];
            antiPatterns: string[];
        };
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        displayHint: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            })[];
        };
        dataBindings: ({
            id: string;
            source: string;
            entity: string;
            description: string;
            stateKey: string;
        } | {
            id: string;
            source: string;
            stateKey: string;
            entity?: undefined;
            description?: undefined;
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "reservationManagement__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page21/reservationManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page21/reservationManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/reservationManagement.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["reservationManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Catálogo-first, cards de produto com foto e preço, seção de destaques na home, checkout simplificado focado em reserva e retirada na loja";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/desktop/page21/reservationManagement" {
    import { PetShopReservationManagementBase } from "_102049_/l2/petShop/web/shared/reservationManagement";
    export class PetShopDesktopPage21ReservationManagementPage extends PetShopReservationManagementBase {
        render(): any;
    }
}
declare module "_102049_/l2/petShop/web/shared/myReservations.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: any[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "section.board.title": string;
            "section.create.title": string;
            "section.cancel.title": string;
            "column.reservationId.label": string;
            "column.status.label": string;
            "column.expiresAt.label": string;
            "column.createdAt.label": string;
            "column.confirmedAt.label": string;
            "column.readyAt.label": string;
            "column.items.label": string;
            "empty.board": string;
            "empty.create": string;
            "empty.cancel": string;
            "field.items.label": string;
            "field.reservationId.label": string;
            "field.cancelReason.label": string;
            "action.createReservation.label": string;
            "action.cancelReservation.label": string;
            "action.createReservation.success": string;
            "action.createReservation.error": string;
            "action.cancelReservation.success": string;
            "action.cancelReservation.error": string;
            "rowAction.cancelReservation.label": string;
            "toolbar.refresh.label": string;
            "lane.active": string;
            "lane.ready": string;
            "lane.delivered": string;
            "lane.expired": string;
            "lane.cancelled": string;
            "page.myReservations.title": string;
            "section.reservations.title": string;
            "section.createReservation.title": string;
            "organism.reservationList.title": string;
            "organism.createForm.title": string;
            "intention.queryReservations.title": string;
            "intention.cancelReservation.title": string;
            "intention.createReservation.title": string;
            "filter.status.label": string;
            "action.viewMyReservations.label": string;
            "action.selectForCancel.label": string;
            "empty.reservations": string;
            "empty.cancelContext": string;
            "empty.createForm": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "myReservations__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/myReservations.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/myReservations.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/myReservations.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["myReservations__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/myReservations.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/productCatalog.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.productCatalog.title": string;
            "section.overview.title": string;
            "section.catalog.title": string;
            "section.details.title": string;
            "organism.highlightsCards.title": string;
            "organism.catalogSummary.title": string;
            "organism.catalogBrowser.title": string;
            "organism.productDetails.title": string;
            "intention.viewHighlights.title": string;
            "intention.browseCatalogSummary.title": string;
            "intention.browseCatalogFilter.title": string;
            "intention.searchProductsFilter.title": string;
            "intention.filterProductsFilter.title": string;
            "intention.searchProductsList.title": string;
            "intention.filterProductsList.title": string;
            "intention.viewProductDetails.title": string;
            "intention.viewHighlights.empty": string;
            "intention.browseCatalogSummary.empty": string;
            "intention.searchProductsList.empty": string;
            "intention.filterProductsList.empty": string;
            "intention.viewProductDetails.empty": string;
            "field.searchTerm.label": string;
            "field.petTypeId.label": string;
            "field.categoryId.label": string;
            "field.minPrice.label": string;
            "field.maxPrice.label": string;
            "field.productId.label": string;
            "field.name.label": string;
            "field.description.label": string;
            "field.price.label": string;
            "field.petTypeName.label": string;
            "field.categoryName.label": string;
            "field.highlighted.label": string;
            "field.status.label": string;
            "field.products.label": string;
            "field.total.label": string;
            "field.page.label": string;
            "field.pageSize.label": string;
            "field.createdAt.label": string;
            "field.updatedAt.label": string;
            "action.browseCatalog.label": string;
            "action.searchProducts.label": string;
            "action.filterProducts.label": string;
            "action.viewProductDetails.label": string;
            "action.viewHighlights.label": string;
            "sec.overview.title": string;
            "org.highlights.title": string;
            "org.catalog.summary.title": string;
            "sec.catalog.title": string;
            "org.catalog.browser.title": string;
            "sec.details.title": string;
            "org.product.details.title": string;
            "page.title": string;
            "section.highlights.title": string;
            "section.detail.title": string;
            "empty.highlights": string;
            "empty.catalog": string;
            "empty.detail": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "productCatalog__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/productCatalog.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/productCatalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/productCatalog.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["productCatalog__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/productCatalog.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/productManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
            prefill?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
            prefill?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            prefill?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            prefill: {
                command: string;
                sourceStateKey: string;
                sourceOutputShape: string;
                matchField: string;
                fields: {
                    itemField: string;
                    targetStateKey: string;
                }[];
            };
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.productManagement.title": string;
            "section.productList.title": string;
            "section.createProduct.title": string;
            "section.updateProduct.title": string;
            "section.setHighlights.title": string;
            "field.searchTerm.label": string;
            "field.petTypeId.label": string;
            "field.categoryId.label": string;
            "field.priceMin.label": string;
            "field.priceMax.label": string;
            "field.status.label": string;
            "field.highlighted.label": string;
            "field.name.label": string;
            "field.description.label": string;
            "field.price.label": string;
            "field.productId.label": string;
            "field.productIds.label": string;
            "column.name.label": string;
            "column.price.label": string;
            "column.petTypeName.label": string;
            "column.categoryName.label": string;
            "column.highlighted.label": string;
            "column.status.label": string;
            "action.browseProducts.label": string;
            "action.createProduct.label": string;
            "action.updateProduct.label": string;
            "action.setProductHighlights.label": string;
            "empty.productList": string;
            "action.createProduct.success": string;
            "action.createProduct.error": string;
            "action.updateProduct.success": string;
            "action.updateProduct.error": string;
            "action.setProductHighlights.success": string;
            "action.setProductHighlights.error": string;
            "section.product.list.title": string;
            "org.product.table.title": string;
            "section.create.product.title": string;
            "org.create.form.title": string;
            "section.update.product.title": string;
            "org.update.form.title": string;
            "section.set.highlights.title": string;
            "org.highlights.form.title": string;
            "section.catalog.title": string;
            "section.detail.title": string;
            "organism.productList.title": string;
            "organism.updateProductForm.title": string;
            "organism.createProductForm.title": string;
            "organism.setHighlightsForm.title": string;
            "intent.productList.title": string;
            "intent.updateProduct.title": string;
            "intent.createProduct.title": string;
            "intent.setHighlights.title": string;
            "field.product.name": string;
            "field.product.description": string;
            "field.product.price": string;
            "field.product.petTypeId": string;
            "field.product.petTypeName": string;
            "field.product.categoryId": string;
            "field.product.categoryName": string;
            "field.product.highlighted": string;
            "field.product.status": string;
            "field.product.searchTerm": string;
            "field.product.priceMin": string;
            "field.product.priceMax": string;
            "field.product.productIds": string;
            "action.browseProducts": string;
            "action.selectForEdit": string;
            "action.updateProduct": string;
            "action.createProduct": string;
            "action.setProductHighlights": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "productManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/productManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/productManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/productManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["productManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/productManagement.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/reservationManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
            prefill?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
            prefill?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            prefill?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            prefill: {
                command: string;
                sourceStateKey: string;
                sourceOutputShape: string;
                matchField: string;
                fields: {
                    itemField: string;
                    targetStateKey: string;
                }[];
            };
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.reservationManagement.title": string;
            "section.queue.title": string;
            "section.queue.empty": string;
            "section.execute.title": string;
            "section.batch.title": string;
            "section.review.title": string;
            "intention.queryReservations.title": string;
            "intention.updateStatus.title": string;
            "intention.payInStore.title": string;
            "intention.expireReservations.title": string;
            "intention.expireReservations.empty": string;
            "intention.summary.title": string;
            "column.reservationId": string;
            "column.customerId": string;
            "column.status": string;
            "column.expiresAt": string;
            "column.readyAt": string;
            "column.items": string;
            "filter.status": string;
            "field.reservationId": string;
            "field.status": string;
            "field.cancelReason": string;
            "field.paymentId": string;
            "field.paymentMethod": string;
            "field.paymentAmount": string;
            "action.refresh": string;
            "action.selectForUpdate": string;
            "action.selectForPayment": string;
            "action.updateReservationStatus.submit": string;
            "action.payInStore.submit": string;
            "action.expireReservations.submit": string;
            "action.updateReservationStatus.success": string;
            "action.updateReservationStatus.error": string;
            "action.payInStore.success": string;
            "action.payInStore.error": string;
            "action.expireReservations.success": string;
            "action.expireReservations.error": string;
            "org.reservationQueue.title": string;
            "org.reservationTransitions.title": string;
            "org.batchOperations.title": string;
            "org.reviewSummary.title": string;
            "section.detail.title": string;
            "organism.reservationBoard.title": string;
            "organism.reservationTransitions.title": string;
            "organism.payInStore.title": string;
            "intent.listReservations.title": string;
            "intent.updateReservationStatus.title": string;
            "intent.payInStore.title": string;
            "field.customerId": string;
            "field.expiresAt": string;
            "field.readyAt": string;
            "field.deliveredAt": string;
            "field.items": string;
            "action.listReservations": string;
            "action.expireReservations": string;
            "action.selectReservation": string;
            "action.updateReservationStatus.ready": string;
            "action.updateReservationStatus.delivered": string;
            "action.updateReservationStatus.cancelled": string;
            "action.payInStore": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "reservationManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/reservationManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/reservationManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/reservationManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["reservationManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/reservationManagement.test" {
    export {};
}

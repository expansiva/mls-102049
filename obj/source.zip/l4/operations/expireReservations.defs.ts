/// <mls fileReference="_102049_/l4/operations/expireReservations.defs.ts" enhancement="_blank"/>

export const operationExpireReservations = {
  "operationId": "expireReservations",
  "title": "Expirar reservas vencidas",
  "actor": "loja",
  "entity": "Reservation",
  "kind": "update",
  "reads": [
    "Reservation",
    "ReservationItem",
    "Product"
  ],
  "writes": [
    "Reservation",
    "Product"
  ],
  "rulesApplied": [
    "reservationExpiresIn24Hours",
    "expiredReservationRestoresAvailability",
    "reservationStatusReflectsStage"
  ],
  "story": {
    "actor": "loja",
    "goal": "Expirar automaticamente as reservas que ultrapassaram o prazo de 24 horas e liberar os produtos comprometidos de volta ao catálogo",
    "steps": [
      "O sistema identifica todas as reservas com status active ou ready cujo expiresAt é anterior ao timestamp atual",
      "Cada reserva identificada tem seu status atualizado para expired e o campo expiredAt é definido com o timestamp atual",
      "Os produtos associados a cada reserva expirada (via ReservationItem) têm sua disponibilidade restaurada no catálogo",
      "O sistema retorna o resumo com a quantidade de reservas expiradas e produtos liberados"
    ],
    "outcome": "Reservas vencidas são marcadas como expired e os produtos retornam ao catálogo para outros clientes"
  },
  "accessPattern": {
    "kind": "commandInput",
    "entity": "Reservation",
    "keyField": "Reservation.reservationId",
    "pagination": "none",
    "selection": "multiple",
    "output": [
      "Reservation.reservationId",
      "Reservation.status",
      "Reservation.expiredAt"
    ]
  },
  "outputShape": {
    "kind": "object",
    "fields": [
      {
        "name": "expiredCount",
        "type": "number",
        "required": true
      },
      {
        "name": "expiredReservations",
        "type": "array",
        "required": true,
        "item": {
          "fields": [
            {
              "name": "reservationId",
              "type": "string",
              "required": true,
              "fieldRef": "Reservation.reservationId"
            },
            {
              "name": "status",
              "type": "string",
              "required": true,
              "fieldRef": "Reservation.status"
            },
            {
              "name": "expiredAt",
              "type": "string",
              "required": true,
              "fieldRef": "Reservation.expiredAt"
            }
          ]
        }
      },
      {
        "name": "productsReleased",
        "type": "number",
        "required": true
      }
    ]
  },
  "inputs": [
    {
      "inputId": "currentTimestamp",
      "fieldRef": "Reservation.expiresAt",
      "required": true,
      "source": "systemDefault",
      "description": "Data e hora atual do sistema usada para comparar com expiresAt e identificar reservas vencidas"
    },
    {
      "inputId": "actorId",
      "fieldRef": "Reservation.reservationId",
      "required": true,
      "source": "actorSession",
      "description": "Identidade da loja autenticada que dispara a expiração em lote das reservas vencidas"
    }
  ],
  "contextResolution": [
    {
      "targetRef": "Reservation.expiresAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "Obtém o timestamp atual do sistema para comparar com o campo expiresAt de cada reserva ativa ou pronta e determinar quais estão vencidas"
    },
    {
      "targetRef": "Reservation.reservationId",
      "source": "actorSession",
      "originRef": "actorSession.actorId",
      "description": "Identifica a loja autenticada na sessão para autorizar a operação de expiração em lote sobre as reservas"
    }
  ],
  "acceptanceAssertions": [
    "Todas as reservas com status active ou ready e expiresAt anterior ao timestamp atual são atualizadas para status expired",
    "Cada reserva expirada tem o campo expiredAt preenchido com o timestamp atual da operação",
    "Os produtos associados às reservas expiradas (via ReservationItem) têm sua disponibilidade restaurada no catálogo",
    "Reservas com status draft, delivered, expired ou cancelled não são afetadas pela operação",
    "O campo expiredCount do resultado corresponde exatamente à quantidade de reservas que tiveram o status alterado para expired",
    "O campo productsReleased do resultado corresponde à quantidade total de produtos cuja disponibilidade foi restaurada",
    "O status de cada reserva expirada reflete o estágio expired sem estados intermediários não previstos"
  ],
  "pageId": "reservationLifecycle",
  "commandName": "expireReservations",
  "bffName": "petShop.reservationLifecycle.expireReservations",
  "capability": {
    "capabilityId": "reservationLifecycle",
    "title": "Ciclo de vida da reserva",
    "actor": "loja",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationExpireReservations;

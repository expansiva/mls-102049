/// <mls fileReference="_102049_/l2/petShop/web/contracts/reservationManagement.browseReservationsQuery.ts" enhancement="_blank"/>
export const browseReservationsQueryRoute = 'petShop.reservationManagement.browseReservationsQuery';

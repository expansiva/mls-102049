/// <mls fileReference="_102049_/l4/operations/startServiceExecution.defs.ts" enhancement="_blank"/>

export const operationStartServiceExecution = {
  "operationId": "startServiceExecution",
  "title": "Iniciar atendimento do serviço",
  "actor": "operador",
  "entity": "ServiceBooking",
  "kind": "update",
  "reads": [
    "ServiceBooking",
    "Operator"
  ],
  "writes": [
    "ServiceBooking"
  ],
  "rulesApplied": [
    "operatorSeesOnlyAssignedShiftBookings",
    "onlyAssignedOperatorCanComplete"
  ],
  "story": {
    "actor": "operador",
    "goal": "Iniciar o atendimento de um serviço agendado quando o cliente chega à loja no horário marcado.",
    "steps": [
      "O operador seleciona um agendamento confirmado em sua agenda.",
      "O operador confirma o início do atendimento.",
      "O sistema verifica que o operador é o atribuído ao agendamento e que o agendamento está no turno do operador.",
      "O sistema altera o status do agendamento de 'confirmed' para 'inProgress' e registra a data/hora da atualização."
    ],
    "outcome": "O agendamento de serviço passa a status 'inProgress', indicando que o atendimento foi iniciado pelo operador atribuído."
  },
  "accessPattern": {
    "kind": "commandInput",
    "entity": "ServiceBooking",
    "keyField": "ServiceBooking.serviceBookingId",
    "pagination": "none",
    "selection": "single",
    "output": [
      "ServiceBooking.serviceBookingId",
      "ServiceBooking.status",
      "ServiceBooking.updatedAt"
    ]
  },
  "inputs": [
    {
      "inputId": "serviceBookingId",
      "fieldRef": "ServiceBooking.serviceBookingId",
      "required": true,
      "source": "selectedEntity",
      "description": "Identificador do agendamento de serviço selecionado pelo operador para iniciar o atendimento."
    },
    {
      "inputId": "operatorId",
      "fieldRef": "ServiceBooking.operatorId",
      "required": true,
      "source": "actorSession",
      "description": "Identificador do operador autenticado que está iniciando o atendimento, usado para validar que ele é o operador atribuído ao agendamento."
    },
    {
      "inputId": "updatedAt",
      "fieldRef": "ServiceBooking.updatedAt",
      "required": true,
      "source": "systemDefault",
      "description": "Data e hora da atualização do agendamento, registrada automaticamente pelo sistema no momento da transição de status."
    }
  ],
  "contextResolution": [
    {
      "targetRef": "ServiceBooking.serviceBookingId",
      "source": "selectedEntity",
      "originRef": "ServiceBooking.serviceBookingId",
      "description": "O agendamento atualmente selecionado pelo operador na tela de agenda, identificado pelo seu serviceBookingId."
    },
    {
      "targetRef": "ServiceBooking.operatorId",
      "source": "actorSession",
      "originRef": "actorSession.actorId",
      "description": "O identificador do operador autenticado na sessão atual, usado para verificar se ele é o operador atribuído ao agendamento antes de permitir a transição."
    },
    {
      "targetRef": "ServiceBooking.updatedAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "O timestamp atual do sistema, gravado automaticamente como updatedAt no momento em que o status é alterado para inProgress."
    }
  ],
  "acceptanceAssertions": [
    "Após a confirmação, o ServiceBooking existe com status igual a 'inProgress'.",
    "Antes da operação, o ServiceBooking deve estar com status 'confirmed'; agendamentos em outros status não podem ser iniciados.",
    "Apenas o operador atribuído ao agendamento (ServiceBooking.operatorId igual ao actorSession.actorId) pode iniciar o atendimento.",
    "O operador só pode iniciar agendamentos atribuídos ao turno ao qual está alocado; agendamentos de outros turnos não são acessíveis.",
    "Após a operação, o campo ServiceBooking.updatedAt é atualizado com a data e hora atuais do sistema."
  ],
  "pageId": "serviceBookingLifecycle",
  "commandName": "startServiceExecution",
  "bffName": "petShop.serviceBookingLifecycle.startServiceExecution",
  "capability": {
    "capabilityId": "serviceBookingLifecycle",
    "title": "Ciclo de vida do agendamento de serviço",
    "actor": "operador",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationStartServiceExecution;

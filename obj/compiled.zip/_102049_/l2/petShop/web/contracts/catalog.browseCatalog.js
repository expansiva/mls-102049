/// <mls fileReference="_102049_/l2/petShop/web/contracts/catalog.browseCatalog.ts" enhancement="_blank"/>
export const browseCatalogRoute = 'petShop.catalog.browseCatalog';

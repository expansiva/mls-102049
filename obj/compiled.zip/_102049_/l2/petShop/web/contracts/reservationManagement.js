/// <mls fileReference="_102049_/l2/petShop/web/contracts/reservationManagement.ts" enhancement="_blank"/>
export {};

/// <mls fileReference="_102049_/l2/petShop/web/contracts/catalog.reserveProduct.ts" enhancement="_blank"/>
export const reserveProductRoute = 'petShop.catalog.reserveProduct';

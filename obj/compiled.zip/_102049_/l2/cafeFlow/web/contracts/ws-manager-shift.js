/// <mls fileReference="_102049_/l2/cafeFlow/web/contracts/ws-manager-shift.ts" enhancement="_blank"/>
export {};

/// <mls fileReference="_102049_/l2/petShop/web/contracts/shiftManagement.ts" enhancement="_blank"/>
export {};

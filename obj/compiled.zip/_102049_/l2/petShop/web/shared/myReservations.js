/// <mls fileReference="_102049_/l2/petShop/web/shared/myReservations.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "section.board.title": "Minhas Reservas",
    "section.create.title": "Criar Reserva",
    "section.cancel.title": "Cancelar Reserva",
    "column.reservationId.label": "Reserva",
    "column.status.label": "Status",
    "column.expiresAt.label": "Expira em",
    "column.createdAt.label": "Criada em",
    "column.confirmedAt.label": "Confirmada em",
    "column.readyAt.label": "Pronta em",
    "column.items.label": "Itens",
    "empty.board": "Nenhuma reserva encontrada",
    "empty.create": "Selecione produtos para criar uma reserva",
    "empty.cancel": "Selecione uma reserva no quadro para cancelar",
    "field.items.label": "Produtos e quantidades",
    "field.reservationId.label": "Reserva selecionada",
    "field.cancelReason.label": "Motivo do cancelamento (opcional)",
    "action.createReservation.label": "Criar Reserva",
    "action.cancelReservation.label": "Cancelar Reserva",
    "action.createReservation.success": "Reserva criada com sucesso! Você tem 24 horas para retirar na loja.",
    "action.createReservation.error": "Não foi possível criar a reserva. Verifique a disponibilidade dos produtos.",
    "action.cancelReservation.success": "Reserva cancelada com sucesso. Os produtos foram devolvidos ao estoque.",
    "action.cancelReservation.error": "Não foi possível cancelar a reserva. Tente novamente.",
    "rowAction.cancelReservation.label": "Cancelar",
    "toolbar.refresh.label": "Atualizar",
    "lane.active": "Ativas",
    "lane.ready": "Prontas para retirada",
    "lane.delivered": "Entregues",
    "lane.expired": "Expiradas",
    "lane.cancelled": "Canceladas",
    "page.myReservations.title": "Minhas Reservas",
    "section.reservations.title": "Minhas Reservas",
    "section.createReservation.title": "Nova Reserva",
    "organism.reservationList.title": "Lista de Reservas",
    "organism.createForm.title": "Criar Reserva",
    "intention.queryReservations.title": "Reservas",
    "intention.cancelReservation.title": "Cancelar Reserva",
    "intention.createReservation.title": "Criar Nova Reserva",
    "filter.status.label": "Filtrar por status",
    "action.viewMyReservations.label": "Atualizar",
    "action.selectForCancel.label": "Selecionar",
    "empty.reservations": "Você ainda não possui reservas.",
    "empty.cancelContext": "Selecione uma reserva ativa ou pronta para cancelar.",
    "empty.createForm": "Selecione produtos do catálogo para criar sua reserva."
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class PetShopMyReservationsBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state ui.myReservations.status — pageStatus */
        this.status = '';
        /** state ui.myReservations.action.createReservation.status — actionStatus, values: idle|loading|success|error */
        this.createReservationState = 'idle';
        /** state ui.myReservations.input.createReservation.items — input */
        this.createReservationItems = '';
        /** state ui.myReservations.output.createReservation — commandOutput */
        this.createReservationOutput = null;
        /** state ui.myReservations.action.createReservation.error — actionError */
        this.createReservationError = '';
        /** state ui.myReservations.action.cancelReservation.status — actionStatus, values: idle|loading|success|error */
        this.cancelReservationState = 'idle';
        /** state ui.myReservations.input.cancelReservation.reservationId — input (selection) */
        this.cancelReservationReservationId = '';
        /** state ui.myReservations.input.cancelReservation.cancelReason — input */
        this.cancelReservationCancelReason = '';
        /** state ui.myReservations.output.cancelReservation — commandOutput */
        this.cancelReservationOutput = null;
        /** state ui.myReservations.action.cancelReservation.error — actionError */
        this.cancelReservationError = '';
        /** state ui.myReservations.action.viewMyReservations.status — actionStatus, values: idle|loading|success|error */
        this.viewMyReservationsState = 'idle';
        /** state ui.myReservations.data.viewMyReservations — queryResult, outputShape: array */
        this.viewMyReservationsData = [];
    }
    /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    /** action createReservation (command) — route petShop.reservationLifecycle.createReservation; inputs: items; writes ui.myReservations.output.createReservation; status ui.myReservations.action.createReservation.status; feedback keys action.createReservation.success / action.createReservation.error */
    async createReservation() {
        this.createReservationState = 'loading';
        setState('ui.myReservations.action.createReservation.status', 'loading');
        const params = {
            items: this.createReservationItems,
        };
        const options = { mode: 'blocking' };
        const response = await execBff('petShop.reservationLifecycle.createReservation', params, options);
        if (response.ok) {
            this.createReservationOutput = response.data ?? null;
            setState('ui.myReservations.output.createReservation', this.createReservationOutput);
            // Refresh query actions
            let refreshFailed = false;
            try {
                await this.loadViewMyReservations();
            }
            catch {
                refreshFailed = true;
            }
            if (refreshFailed) {
                this.createReservationState = 'error';
                setState('ui.myReservations.action.createReservation.status', 'error');
                return;
            }
            // Clear input state keys
            this.createReservationItems = '';
            setState('ui.myReservations.input.createReservation.items', '');
            this.createReservationState = 'success';
            setState('ui.myReservations.action.createReservation.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? this.msg['action.createReservation.error'];
            this.createReservationError = errorMsg;
            setState('ui.myReservations.action.createReservation.error', errorMsg);
            this.createReservationState = 'error';
            setState('ui.myReservations.action.createReservation.status', 'error');
        }
    }
    /** handler for action createReservation — bind UI events here */
    async handleCreateReservationClick(e) {
        e.preventDefault();
        await runBlockingUiAction(async (_signal) => {
            await this.createReservation();
        });
    }
    /** action cancelReservation (command) — route petShop.reservationLifecycle.cancelReservation; inputs: reservationId, cancelReason; writes ui.myReservations.output.cancelReservation; status ui.myReservations.action.cancelReservation.status; feedback keys action.cancelReservation.success / action.cancelReservation.error */
    async cancelReservation() {
        this.cancelReservationState = 'loading';
        setState('ui.myReservations.action.cancelReservation.status', 'loading');
        const params = {
            reservationId: this.cancelReservationReservationId,
            cancelReason: this.cancelReservationCancelReason,
        };
        const options = { mode: 'blocking' };
        const response = await execBff('petShop.reservationLifecycle.cancelReservation', params, options);
        if (response.ok) {
            this.cancelReservationOutput = response.data ?? null;
            setState('ui.myReservations.output.cancelReservation', this.cancelReservationOutput);
            // Refresh query actions
            let refreshFailed = false;
            try {
                await this.loadViewMyReservations();
            }
            catch {
                refreshFailed = true;
            }
            if (refreshFailed) {
                this.cancelReservationState = 'error';
                setState('ui.myReservations.action.cancelReservation.status', 'error');
                return;
            }
            // Clear input state keys
            this.cancelReservationReservationId = '';
            setState('ui.myReservations.input.cancelReservation.reservationId', '');
            this.cancelReservationCancelReason = '';
            setState('ui.myReservations.input.cancelReservation.cancelReason', '');
            this.cancelReservationState = 'success';
            setState('ui.myReservations.action.cancelReservation.status', 'success');
        }
        else {
            const errorMsg = response.error?.message ?? this.msg['action.cancelReservation.error'];
            this.cancelReservationError = errorMsg;
            setState('ui.myReservations.action.cancelReservation.error', errorMsg);
            this.cancelReservationState = 'error';
            setState('ui.myReservations.action.cancelReservation.status', 'error');
        }
    }
    /** handler for action cancelReservation — bind UI events here */
    async handleCancelReservationClick(e) {
        e.preventDefault();
        await runBlockingUiAction(async (_signal) => {
            await this.cancelReservation();
        });
    }
    /** action viewMyReservations (query) — route petShop.viewMyReservations.viewMyReservations; inputs: none; writes ui.myReservations.data.viewMyReservations; status ui.myReservations.action.viewMyReservations.status */
    async loadViewMyReservations() {
        this.viewMyReservationsState = 'loading';
        setState('ui.myReservations.action.viewMyReservations.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff('petShop.viewMyReservations.viewMyReservations', params, options);
        if (response.ok) {
            this.viewMyReservationsData = response.data ?? [];
            setState('ui.myReservations.data.viewMyReservations', this.viewMyReservationsData);
            this.viewMyReservationsState = 'success';
            setState('ui.myReservations.action.viewMyReservations.status', 'success');
        }
        else {
            this.viewMyReservationsData = [];
            setState('ui.myReservations.data.viewMyReservations', []);
            this.viewMyReservationsState = 'error';
            setState('ui.myReservations.action.viewMyReservations.status', 'error');
        }
    }
    /** handler for action viewMyReservations — bind UI events here */
    async handleViewMyReservationsClick(e) {
        e.preventDefault();
        await this.loadViewMyReservations();
    }
    /** setter for state ui.myReservations.input.createReservation.items */
    setCreateReservationItems(value) {
        this.createReservationItems = value;
        setState('ui.myReservations.input.createReservation.items', value);
        this.requestUpdate();
    }
    /** handler for action set.createReservationItems — bind UI events here */
    handleCreateReservationItemsChange(e) {
        const target = e.target;
        this.setCreateReservationItems(target.value);
    }
    /** setter for state ui.myReservations.input.cancelReservation.reservationId */
    setCancelReservationReservationId(value) {
        this.cancelReservationReservationId = value;
        setState('ui.myReservations.input.cancelReservation.reservationId', value);
        this.requestUpdate();
    }
    /** handler for action set.cancelReservationReservationId — bind UI events here */
    handleCancelReservationReservationIdChange(e) {
        const target = e.target;
        this.setCancelReservationReservationId(target.value);
    }
    /** setter for state ui.myReservations.input.cancelReservation.cancelReason */
    setCancelReservationCancelReason(value) {
        this.cancelReservationCancelReason = value;
        setState('ui.myReservations.input.cancelReservation.cancelReason', value);
        this.requestUpdate();
    }
    /** handler for action set.cancelReservationCancelReason — bind UI events here */
    handleCancelReservationCancelReasonChange(e) {
        const target = e.target;
        this.setCancelReservationCancelReason(target.value);
    }
    connectedCallback() {
        super.connectedCallback();
        // Initialize state from global store where useful
        const storedStatus = getState('ui.myReservations.status');
        if (storedStatus !== undefined) {
            this.status = storedStatus;
        }
        const storedCreateItems = getState('ui.myReservations.input.createReservation.items');
        if (storedCreateItems !== undefined) {
            this.createReservationItems = storedCreateItems;
        }
        const storedCancelReservationId = getState('ui.myReservations.input.cancelReservation.reservationId');
        if (storedCancelReservationId !== undefined) {
            this.cancelReservationReservationId = storedCancelReservationId;
        }
        const storedCancelReason = getState('ui.myReservations.input.cancelReservation.cancelReason');
        if (storedCancelReason !== undefined) {
            this.cancelReservationCancelReason = storedCancelReason;
        }
        const storedViewData = getState('ui.myReservations.data.viewMyReservations');
        if (storedViewData !== undefined) {
            this.viewMyReservationsData = storedViewData;
        }
        // Subscribe to shared states
        subscribe([
            'ui.myReservations.status',
            'ui.myReservations.input.createReservation.items',
            'ui.myReservations.input.cancelReservation.reservationId',
            'ui.myReservations.input.cancelReservation.cancelReason',
            'ui.myReservations.data.viewMyReservations',
        ], this);
        // Run initial loads
        this.loadViewMyReservations();
    }
    disconnectedCallback() {
        unsubscribe([
            'ui.myReservations.status',
            'ui.myReservations.input.createReservation.items',
            'ui.myReservations.input.cancelReservation.reservationId',
            'ui.myReservations.input.cancelReservation.cancelReason',
            'ui.myReservations.data.viewMyReservations',
        ], this);
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], PetShopMyReservationsBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], PetShopMyReservationsBase.prototype, "createReservationState", void 0);
__decorate([
    property({ type: String })
], PetShopMyReservationsBase.prototype, "createReservationItems", void 0);
__decorate([
    property({ type: Object })
], PetShopMyReservationsBase.prototype, "createReservationOutput", void 0);
__decorate([
    property({ type: String })
], PetShopMyReservationsBase.prototype, "createReservationError", void 0);
__decorate([
    property({ type: String })
], PetShopMyReservationsBase.prototype, "cancelReservationState", void 0);
__decorate([
    property({ type: String })
], PetShopMyReservationsBase.prototype, "cancelReservationReservationId", void 0);
__decorate([
    property({ type: String })
], PetShopMyReservationsBase.prototype, "cancelReservationCancelReason", void 0);
__decorate([
    property({ type: Object })
], PetShopMyReservationsBase.prototype, "cancelReservationOutput", void 0);
__decorate([
    property({ type: String })
], PetShopMyReservationsBase.prototype, "cancelReservationError", void 0);
__decorate([
    property({ type: String })
], PetShopMyReservationsBase.prototype, "viewMyReservationsState", void 0);
__decorate([
    property({ type: Array })
], PetShopMyReservationsBase.prototype, "viewMyReservationsData", void 0);

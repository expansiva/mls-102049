/// <mls fileReference="_102049_/l2/cafeFlow/posRapido.defs.ts" enhancement="_blank"/>
export const posRapidoPagePlan = {
    "schemaVersion": "2026-06-06",
    "artifactType": "page",
    "artifactId": "posRapido",
    "moduleName": "cafeFlow",
    "status": "incomplete",
    "source": {
        "agentName": "agentPlanPageDefinition",
        "stepId": 62,
        "planId": ""
    },
    "data": {
        "pageDefinition": {
            "pageId": "posRapido",
            "pageName": "POS rápido",
            "actor": "attendantCashier",
            "purpose": "Lançar, revisar e acompanhar pedidos rápidos no balcão ou mesa.",
            "capabilities": [
                "manageOrders"
            ],
            "flowRefs": {
                "experienceFlows": [],
                "entityLifecycles": [
                    "orderLifecycle"
                ],
                "taskWorkflows": [],
                "automations": []
            },
            "pluginRefs": [],
            "mdmRefs": [
                "menuItem",
                "menuCategory",
                "orderStatus"
            ],
            "pageInputs": [
                {
                    "name": "orderId",
                    "type": "Order",
                    "required": true,
                    "sources": [
                        "routeParam",
                        "previousStepResult"
                    ],
                    "description": "Identificador do pedido para abrir e cancelar.",
                    "entityRef": "Order",
                    "fieldRef": "orderId"
                },
                {
                    "name": "tableSeatId",
                    "type": "TableSeat",
                    "required": false,
                    "sources": [
                        "routeParam",
                        "previousStepResult"
                    ],
                    "description": "Mesa/comanda pré-selecionada, quando aplicável.",
                    "entityRef": "TableSeat",
                    "fieldRef": "tableSeatId"
                }
            ],
            "navigationRefs": [
                {
                    "direction": "outbound",
                    "pageId": "painelCozinha",
                    "trigger": "pedido confirmado para cozinha",
                    "description": "Ao confirmar pedido, acompanhar fila na cozinha."
                }
            ],
            "sections": [
                {
                    "sectionName": "pedidosAtivos",
                    "mode": "view",
                    "organisms": [
                        {
                            "organismName": "listaPedidosAtivos",
                            "purpose": "Exibir pedidos ativos para seleção e acompanhamento.",
                            "userActions": [
                                "selecionarPedido",
                                "filtrarPorStatus",
                                "visualizarMesaComanda"
                            ],
                            "requiredEntities": [
                                "Order",
                                "TableSeat"
                            ],
                            "readsFields": [
                                "Order.orderId",
                                "Order.orderStatusId",
                                "Order.tableSeatId",
                                "Order.originType",
                                "Order.createdAt",
                                "TableSeat.label"
                            ],
                            "writesFields": [],
                            "rulesApplied": [
                                "orderStatusLifecycle"
                            ]
                        }
                    ]
                },
                {
                    "sectionName": "selecaoMesaComanda",
                    "mode": "edit",
                    "organisms": [
                        {
                            "organismName": "seletorMesaComanda",
                            "purpose": "Selecionar mesa/comanda ativa para o novo pedido.",
                            "userActions": [
                                "listarMesasAtivas",
                                "selecionarMesaComanda"
                            ],
                            "requiredEntities": [
                                "TableSeat"
                            ],
                            "readsFields": [
                                "TableSeat.tableSeatId",
                                "TableSeat.label",
                                "TableSeat.seatType",
                                "TableSeat.isActive"
                            ],
                            "writesFields": [
                                "Order.tableSeatId",
                                "Order.originType"
                            ],
                            "rulesApplied": []
                        }
                    ]
                },
                {
                    "sectionName": "itensDoPedido",
                    "mode": "edit",
                    "organisms": [
                        {
                            "organismName": "seletorItensCardapio",
                            "purpose": "Selecionar itens do cardápio e quantidades para o pedido.",
                            "userActions": [
                                "listarItensCardapio",
                                "adicionarItem",
                                "ajustarQuantidade",
                                "removerItem"
                            ],
                            "requiredEntities": [
                                "OrderItem",
                                "MenuItem",
                                "MenuCategory"
                            ],
                            "readsFields": [
                                "MenuItem.menuItemId",
                                "MenuItem.name",
                                "MenuItem.price",
                                "MenuCategory.menuCategoryId",
                                "MenuCategory.name"
                            ],
                            "writesFields": [
                                "OrderItem.menuItemId",
                                "OrderItem.quantity"
                            ],
                            "rulesApplied": [
                                "inventoryDecrementRule"
                            ]
                        }
                    ]
                },
                {
                    "sectionName": "resumoEConfirmacao",
                    "mode": "confirm",
                    "organisms": [
                        {
                            "organismName": "resumoPedido",
                            "purpose": "Revisar dados do pedido antes da confirmação.",
                            "userActions": [
                                "revisarPedido"
                            ],
                            "requiredEntities": [
                                "Order",
                                "OrderItem",
                                "TableSeat"
                            ],
                            "readsFields": [
                                "Order.originType",
                                "Order.tableSeatId",
                                "OrderItem.menuItemId",
                                "OrderItem.quantity",
                                "TableSeat.label"
                            ],
                            "writesFields": [],
                            "rulesApplied": [
                                "orderStatusLifecycle"
                            ]
                        },
                        {
                            "organismName": "acoesPedido",
                            "purpose": "Confirmar criação ou cancelar pedido selecionado.",
                            "userActions": [
                                "confirmarCriacao",
                                "cancelarPedido"
                            ],
                            "requiredEntities": [
                                "Order"
                            ],
                            "readsFields": [
                                "Order.orderId",
                                "Order.orderStatusId"
                            ],
                            "writesFields": [
                                "Order.orderStatusId"
                            ],
                            "rulesApplied": [
                                "orderStatusLifecycle",
                                "inventoryDecrementRule"
                            ]
                        }
                    ]
                }
            ]
        },
        "bffCommands": [
            {
                "commandName": "listarPedidos",
                "purpose": "Listar pedidos ativos para seleção e acompanhamento.",
                "kind": "query",
                "input": [
                    {
                        "name": "orderStatusId",
                        "type": "OrderStatus",
                        "required": false
                    },
                    {
                        "name": "originType",
                        "type": "string",
                        "required": false
                    }
                ],
                "output": [
                    {
                        "name": "orderId",
                        "type": "Order"
                    },
                    {
                        "name": "orderStatusId",
                        "type": "OrderStatus"
                    },
                    {
                        "name": "tableSeatId",
                        "type": "TableSeat"
                    },
                    {
                        "name": "originType",
                        "type": "string"
                    },
                    {
                        "name": "createdAt",
                        "type": "datetime"
                    },
                    {
                        "name": "tableSeatLabel",
                        "type": "string"
                    }
                ],
                "readsEntities": [
                    "Order",
                    "OrderItem",
                    "TableSeat"
                ],
                "writesEntities": [],
                "readsTables": [
                    "orders",
                    "order_items",
                    "table_seats"
                ],
                "writesTables": [],
                "usecaseRefs": [
                    "listarPedidos"
                ],
                "layerContract": {
                    "controllerLayer": "layer_2_controllers",
                    "mustCallLayer": "layer_3_usecases",
                    "directTableAccessForbidden": true
                },
                "rulesApplied": []
            },
            {
                "commandName": "buscarPedidoPorId",
                "purpose": "Buscar detalhes completos do pedido selecionado.",
                "kind": "query",
                "input": [
                    {
                        "name": "orderId",
                        "type": "Order",
                        "required": true
                    }
                ],
                "output": [
                    {
                        "name": "orderId",
                        "type": "Order"
                    },
                    {
                        "name": "originType",
                        "type": "string"
                    },
                    {
                        "name": "tableSeatId",
                        "type": "TableSeat"
                    },
                    {
                        "name": "orderStatusId",
                        "type": "OrderStatus"
                    },
                    {
                        "name": "createdAt",
                        "type": "datetime"
                    },
                    {
                        "name": "orderItemId",
                        "type": "OrderItem"
                    },
                    {
                        "name": "menuItemId",
                        "type": "MenuItem"
                    },
                    {
                        "name": "quantity",
                        "type": "number"
                    }
                ],
                "readsEntities": [
                    "Order",
                    "OrderItem",
                    "TableSeat"
                ],
                "writesEntities": [],
                "readsTables": [
                    "orders",
                    "order_items",
                    "table_seats"
                ],
                "writesTables": [],
                "usecaseRefs": [
                    "buscarPedidoPorId"
                ],
                "layerContract": {
                    "controllerLayer": "layer_2_controllers",
                    "mustCallLayer": "layer_3_usecases",
                    "directTableAccessForbidden": true
                },
                "rulesApplied": []
            },
            {
                "commandName": "listarMesas",
                "purpose": "Listar mesas e comandas disponíveis para seleção.",
                "kind": "query",
                "input": [],
                "output": [
                    {
                        "name": "tableSeatId",
                        "type": "TableSeat"
                    },
                    {
                        "name": "label",
                        "type": "string"
                    },
                    {
                        "name": "seatType",
                        "type": "string"
                    },
                    {
                        "name": "isActive",
                        "type": "boolean"
                    }
                ],
                "readsEntities": [
                    "TableSeat"
                ],
                "writesEntities": [],
                "readsTables": [
                    "table_seats"
                ],
                "writesTables": [],
                "usecaseRefs": [
                    "listarMesas"
                ],
                "layerContract": {
                    "controllerLayer": "layer_2_controllers",
                    "mustCallLayer": "layer_3_usecases",
                    "directTableAccessForbidden": true
                },
                "rulesApplied": []
            },
            {
                "commandName": "criarPedido",
                "purpose": "Criar pedido com itens selecionados.",
                "kind": "command",
                "input": [
                    {
                        "name": "originType",
                        "type": "string",
                        "required": true
                    },
                    {
                        "name": "tableSeatId",
                        "type": "TableSeat",
                        "required": false
                    },
                    {
                        "name": "orderItems",
                        "type": "OrderItemInput[]",
                        "required": true
                    }
                ],
                "output": [
                    {
                        "name": "orderId",
                        "type": "Order"
                    },
                    {
                        "name": "orderStatusId",
                        "type": "OrderStatus"
                    },
                    {
                        "name": "createdAt",
                        "type": "datetime"
                    }
                ],
                "readsEntities": [
                    "Order",
                    "OrderItem",
                    "TableSeat"
                ],
                "writesEntities": [
                    "Order",
                    "OrderItem"
                ],
                "readsTables": [],
                "writesTables": [
                    "orders",
                    "order_items",
                    "daily_sales_metrics",
                    "top_selling_items_metrics",
                    "weekly_sales_metrics",
                    "operational_metrics"
                ],
                "usecaseRefs": [
                    "criarPedido"
                ],
                "layerContract": {
                    "controllerLayer": "layer_2_controllers",
                    "mustCallLayer": "layer_3_usecases",
                    "directTableAccessForbidden": true
                },
                "rulesApplied": [
                    "orderStatusLifecycle",
                    "inventoryDecrementRule"
                ]
            },
            {
                "commandName": "cancelarPedido",
                "purpose": "Cancelar pedido antes da produção.",
                "kind": "command",
                "input": [
                    {
                        "name": "orderId",
                        "type": "Order",
                        "required": true
                    },
                    {
                        "name": "motivo",
                        "type": "string",
                        "required": true
                    }
                ],
                "output": [
                    {
                        "name": "orderId",
                        "type": "Order"
                    },
                    {
                        "name": "orderStatusId",
                        "type": "OrderStatus"
                    },
                    {
                        "name": "updatedAt",
                        "type": "datetime"
                    }
                ],
                "readsEntities": [
                    "Order",
                    "OrderItem"
                ],
                "writesEntities": [
                    "Order"
                ],
                "readsTables": [
                    "orders",
                    "order_items",
                    "inventory_items"
                ],
                "writesTables": [
                    "orders",
                    "inventory_movements",
                    "daily_sales_metrics",
                    "top_selling_items_metrics",
                    "weekly_sales_metrics",
                    "operational_metrics"
                ],
                "usecaseRefs": [
                    "cancelarPedido"
                ],
                "layerContract": {
                    "controllerLayer": "layer_2_controllers",
                    "mustCallLayer": "layer_3_usecases",
                    "directTableAccessForbidden": true
                },
                "rulesApplied": [
                    "orderStatusLifecycle",
                    "inventoryDecrementRule"
                ]
            }
        ],
        "pendingQuestions": [
            "Existe um caso de uso/BFF para listar itens do cardápio e categorias (MenuItem/MenuCategory) para compor o seletor de itens? Se sim, informe o usecaseId e os campos esperados."
        ]
    }
};
export default posRapidoPagePlan;

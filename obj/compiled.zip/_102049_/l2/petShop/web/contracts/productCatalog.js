/// <mls fileReference="_102049_/l2/petShop/web/contracts/productCatalog.ts" enhancement="_blank"/>
export {};

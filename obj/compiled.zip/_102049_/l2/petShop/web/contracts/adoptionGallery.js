/// <mls fileReference="_102049_/l2/petShop/web/contracts/adoptionGallery.ts" enhancement="_blank"/>
export {};

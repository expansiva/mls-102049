/// <mls fileReference="_102049_/l4/petShop/ontology/Operator.defs.ts" enhancement="_blank"/>

export const petShopEntityOperator = {
  "entityId": "Operator",
  "title": "Operador",
  "description": "Funcionário do pet shop responsável por executar serviços agendados, cadastrado pelo administrador e alocável em um ou mais turnos de trabalho.",
  "kind": "core",
  "ownership": "moduleOwned",
  "fields": [
    {
      "fieldId": "operatorId",
      "type": "uuid",
      "required": true,
      "description": "Identificador único do operador."
    },
    {
      "fieldId": "name",
      "type": "string",
      "required": true,
      "description": "Nome completo do operador exibido na agenda e nos agendamentos atribuídos."
    },
    {
      "fieldId": "email",
      "type": "string",
      "required": false,
      "description": "E-mail de contato do operador para notificações de agenda."
    },
    {
      "fieldId": "phone",
      "type": "string",
      "required": false,
      "description": "Telefone de contato do operador."
    },
    {
      "fieldId": "active",
      "type": "boolean",
      "required": true,
      "description": "Indica se o operador está ativo e pode ser alocado em turnos e receber agendamentos."
    },
    {
      "fieldId": "createdAt",
      "type": "datetime",
      "required": true,
      "description": "Data e hora de cadastro do operador pelo administrador."
    },
    {
      "fieldId": "updatedAt",
      "type": "datetime",
      "required": true,
      "description": "Data e hora da última atualização dos dados do operador."
    }
  ]
} as const;

export default petShopEntityOperator;

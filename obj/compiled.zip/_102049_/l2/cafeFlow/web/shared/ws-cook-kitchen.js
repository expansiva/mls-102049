/// <mls fileReference="_102049_/l2/cafeFlow/web/shared/ws-cook-kitchen.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "ws-cook-kitchen.section.kitchenQueue.title": "Cozinha – Fila de Tickets e Baixa de Estoque",
    "ws-cook-kitchen.organism.updateKitchenStatus.title": "Atualizar status de cozinha",
    "ws-cook-kitchen.organism.createStockMovement.title": "Dar baixa no estoque",
    "ws-cook-kitchen.intent.ticketQueue.title": "Fila de tickets da cozinha",
    "ws-cook-kitchen.intent.startPreparation.title": "Iniciar preparo",
    "ws-cook-kitchen.intent.markReady.title": "Marcar como pronto",
    "ws-cook-kitchen.intent.stockMovement.title": "Baixa de estoque",
    "ws-cook-kitchen.field.orderId": "Pedido",
    "ws-cook-kitchen.field.orderType": "Tipo",
    "ws-cook-kitchen.field.tableId": "Mesa",
    "ws-cook-kitchen.field.orderStatus": "Status",
    "ws-cook-kitchen.field.total": "Total",
    "ws-cook-kitchen.field.createdAt": "Criado em",
    "ws-cook-kitchen.field.previousStatus": "Status anterior",
    "ws-cook-kitchen.field.status": "Novo status",
    "ws-cook-kitchen.action.updateKitchenStatus": "Atualizar status",
    "ws-cook-kitchen.action.markReady": "Confirmar pronto",
    "ws-cook-kitchen.field.movementType": "Tipo de movimentação",
    "ws-cook-kitchen.field.quantity": "Quantidade",
    "ws-cook-kitchen.field.reason": "Motivo",
    "ws-cook-kitchen.action.createStockMovement": "Registrar baixa"
};
const messages = { pt: message_pt };
export class CafeFlowWsCookKitchenBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.updateKitchenStatusState = 'idle';
        this.updateKitchenStatusStatus = '';
        this.updateKitchenStatusPreviousStatus = '';
        this.createStockMovementState = 'idle';
        this.createStockMovementMovementType = '';
        this.createStockMovementQuantity = '';
        this.createStockMovementReason = '';
        this.LayoutColOrderId = '';
        this.LayoutColOrderType = '';
        this.LayoutColTableId = '';
        this.LayoutColTotal = '';
        this.LayoutColCreatedAt = '';
        this.stateKeys = [
            'ui.ws-cook-kitchen.status',
            'ui.ws-cook-kitchen.action.updateKitchenStatus.status',
            'ui.ws-cook-kitchen.input.updateKitchenStatus.status',
            'ui.ws-cook-kitchen.input.updateKitchenStatus.previousStatus',
            'ui.ws-cook-kitchen.action.createStockMovement.status',
            'ui.ws-cook-kitchen.input.createStockMovement.movementType',
            'ui.ws-cook-kitchen.input.createStockMovement.quantity',
            'ui.ws-cook-kitchen.input.createStockMovement.reason',
            'ui.ws-cook-kitchen.layout.col-order-id',
            'ui.ws-cook-kitchen.layout.col-order-type',
            'ui.ws-cook-kitchen.layout.col-table-id',
            'ui.ws-cook-kitchen.layout.col-total',
            'ui.ws-cook-kitchen.layout.col-created-at',
        ];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initializeState();
        subscribe(this.stateKeys, this);
    }
    disconnectedCallback() {
        unsubscribe(this.stateKeys, this);
        super.disconnectedCallback();
    }
    initializeState() {
        const statusState = getState('ui.ws-cook-kitchen.status');
        if (statusState !== undefined) {
            this.status = statusState;
        }
        const updateKitchenStatusState = getState('ui.ws-cook-kitchen.action.updateKitchenStatus.status');
        if (updateKitchenStatusState !== undefined) {
            this.updateKitchenStatusState = updateKitchenStatusState;
        }
        const updateKitchenStatusStatus = getState('ui.ws-cook-kitchen.input.updateKitchenStatus.status');
        if (updateKitchenStatusStatus !== undefined) {
            this.updateKitchenStatusStatus = updateKitchenStatusStatus;
        }
        const updateKitchenStatusPreviousStatus = getState('ui.ws-cook-kitchen.input.updateKitchenStatus.previousStatus');
        if (updateKitchenStatusPreviousStatus !== undefined) {
            this.updateKitchenStatusPreviousStatus = updateKitchenStatusPreviousStatus;
        }
        const createStockMovementState = getState('ui.ws-cook-kitchen.action.createStockMovement.status');
        if (createStockMovementState !== undefined) {
            this.createStockMovementState = createStockMovementState;
        }
        const createStockMovementMovementType = getState('ui.ws-cook-kitchen.input.createStockMovement.movementType');
        if (createStockMovementMovementType !== undefined) {
            this.createStockMovementMovementType = createStockMovementMovementType;
        }
        const createStockMovementQuantity = getState('ui.ws-cook-kitchen.input.createStockMovement.quantity');
        if (createStockMovementQuantity !== undefined) {
            this.createStockMovementQuantity = createStockMovementQuantity;
        }
        const createStockMovementReason = getState('ui.ws-cook-kitchen.input.createStockMovement.reason');
        if (createStockMovementReason !== undefined) {
            this.createStockMovementReason = createStockMovementReason;
        }
        const layoutColOrderId = getState('ui.ws-cook-kitchen.layout.col-order-id');
        if (layoutColOrderId !== undefined) {
            this.LayoutColOrderId = layoutColOrderId;
        }
        const layoutColOrderType = getState('ui.ws-cook-kitchen.layout.col-order-type');
        if (layoutColOrderType !== undefined) {
            this.LayoutColOrderType = layoutColOrderType;
        }
        const layoutColTableId = getState('ui.ws-cook-kitchen.layout.col-table-id');
        if (layoutColTableId !== undefined) {
            this.LayoutColTableId = layoutColTableId;
        }
        const layoutColTotal = getState('ui.ws-cook-kitchen.layout.col-total');
        if (layoutColTotal !== undefined) {
            this.LayoutColTotal = layoutColTotal;
        }
        const layoutColCreatedAt = getState('ui.ws-cook-kitchen.layout.col-created-at');
        if (layoutColCreatedAt !== undefined) {
            this.LayoutColCreatedAt = layoutColCreatedAt;
        }
    }
    handleIcaStateChange(key, value) {
        if (value === undefined) {
            return;
        }
        switch (key) {
            case 'ui.ws-cook-kitchen.status':
                this.status = value;
                break;
            case 'ui.ws-cook-kitchen.action.updateKitchenStatus.status':
                this.updateKitchenStatusState = value;
                break;
            case 'ui.ws-cook-kitchen.input.updateKitchenStatus.status':
                this.updateKitchenStatusStatus = value;
                break;
            case 'ui.ws-cook-kitchen.input.updateKitchenStatus.previousStatus':
                this.updateKitchenStatusPreviousStatus = value;
                break;
            case 'ui.ws-cook-kitchen.action.createStockMovement.status':
                this.createStockMovementState = value;
                break;
            case 'ui.ws-cook-kitchen.input.createStockMovement.movementType':
                this.createStockMovementMovementType = value;
                break;
            case 'ui.ws-cook-kitchen.input.createStockMovement.quantity':
                this.createStockMovementQuantity = value;
                break;
            case 'ui.ws-cook-kitchen.input.createStockMovement.reason':
                this.createStockMovementReason = value;
                break;
            case 'ui.ws-cook-kitchen.layout.col-order-id':
                this.LayoutColOrderId = value;
                break;
            case 'ui.ws-cook-kitchen.layout.col-order-type':
                this.LayoutColOrderType = value;
                break;
            case 'ui.ws-cook-kitchen.layout.col-table-id':
                this.LayoutColTableId = value;
                break;
            case 'ui.ws-cook-kitchen.layout.col-total':
                this.LayoutColTotal = value;
                break;
            case 'ui.ws-cook-kitchen.layout.col-created-at':
                this.LayoutColCreatedAt = value;
                break;
            default:
                break;
        }
    }
    setUpdateKitchenStatusStatus(value) {
        this.updateKitchenStatusStatus = value;
        setState('ui.ws-cook-kitchen.input.updateKitchenStatus.status', value);
        this.requestUpdate();
    }
    handleUpdateKitchenStatusStatusChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setUpdateKitchenStatusStatus(target.value);
    }
    setUpdateKitchenStatusPreviousStatus(value) {
        this.updateKitchenStatusPreviousStatus = value;
        setState('ui.ws-cook-kitchen.input.updateKitchenStatus.previousStatus', value);
        this.requestUpdate();
    }
    handleUpdateKitchenStatusPreviousStatusChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setUpdateKitchenStatusPreviousStatus(target.value);
    }
    setCreateStockMovementMovementType(value) {
        this.createStockMovementMovementType = value;
        setState('ui.ws-cook-kitchen.input.createStockMovement.movementType', value);
        this.requestUpdate();
    }
    handleCreateStockMovementMovementTypeChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setCreateStockMovementMovementType(target.value);
    }
    setCreateStockMovementQuantity(value) {
        this.createStockMovementQuantity = value;
        setState('ui.ws-cook-kitchen.input.createStockMovement.quantity', value);
        this.requestUpdate();
    }
    handleCreateStockMovementQuantityChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        if (target.value === '') {
            this.setCreateStockMovementQuantity('');
            return;
        }
        const numericValue = Number(target.value);
        if (Number.isNaN(numericValue)) {
            return;
        }
        this.setCreateStockMovementQuantity(numericValue);
    }
    setCreateStockMovementReason(value) {
        this.createStockMovementReason = value;
        setState('ui.ws-cook-kitchen.input.createStockMovement.reason', value);
        this.requestUpdate();
    }
    handleCreateStockMovementReasonChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setCreateStockMovementReason(target.value);
    }
    async updateKitchenStatus(options = {}) {
        this.updateKitchenStatusState = 'loading';
        setState('ui.ws-cook-kitchen.action.updateKitchenStatus.status', 'loading');
        if (this.updateKitchenStatusStatus === '') {
            this.updateKitchenStatusState = 'error';
            setState('ui.ws-cook-kitchen.action.updateKitchenStatus.status', 'error');
            throw new Error('Status inválido');
        }
        const params = {
            status: this.updateKitchenStatusStatus,
        };
        if (this.updateKitchenStatusPreviousStatus !== '') {
            params.previousStatus = this.updateKitchenStatusPreviousStatus;
        }
        const bffOptions = {
            mode: 'blocking',
            signal: options.signal,
        };
        const response = await execBff('cafeFlow.orderLifecycle.updateKitchenStatus', params, bffOptions);
        if (response.ok) {
            this.updateKitchenStatusState = 'success';
            setState('ui.ws-cook-kitchen.action.updateKitchenStatus.status', 'success');
            return;
        }
        this.updateKitchenStatusState = 'error';
        setState('ui.ws-cook-kitchen.action.updateKitchenStatus.status', 'error');
        throw new Error(response.error?.message ?? 'Erro ao atualizar status');
    }
    handleUpdateKitchenStatusClick() {
        void runBlockingUiAction((signal) => this.updateKitchenStatus({ signal }));
    }
    async createStockMovement(options = {}) {
        this.createStockMovementState = 'loading';
        setState('ui.ws-cook-kitchen.action.createStockMovement.status', 'loading');
        if (this.createStockMovementMovementType === '') {
            this.createStockMovementState = 'error';
            setState('ui.ws-cook-kitchen.action.createStockMovement.status', 'error');
            throw new Error('Tipo de movimentação inválido');
        }
        if (this.createStockMovementReason === '') {
            this.createStockMovementState = 'error';
            setState('ui.ws-cook-kitchen.action.createStockMovement.status', 'error');
            throw new Error('Motivo inválido');
        }
        let quantityValue;
        if (this.createStockMovementQuantity === '') {
            this.createStockMovementState = 'error';
            setState('ui.ws-cook-kitchen.action.createStockMovement.status', 'error');
            throw new Error('Quantidade inválida');
        }
        quantityValue = this.createStockMovementQuantity;
        const params = {
            movementType: this.createStockMovementMovementType,
            quantity: quantityValue,
            reason: this.createStockMovementReason,
        };
        const bffOptions = {
            mode: 'blocking',
            signal: options.signal,
        };
        const response = await execBff('cafeFlow.orderLifecycle.createStockMovement', params, bffOptions);
        if (response.ok) {
            this.createStockMovementState = 'success';
            setState('ui.ws-cook-kitchen.action.createStockMovement.status', 'success');
            return;
        }
        this.createStockMovementState = 'error';
        setState('ui.ws-cook-kitchen.action.createStockMovement.status', 'error');
        throw new Error(response.error?.message ?? 'Erro ao criar movimentação');
    }
    handleCreateStockMovementClick() {
        void runBlockingUiAction((signal) => this.createStockMovement({ signal }));
    }
}
__decorate([
    property()
], CafeFlowWsCookKitchenBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowWsCookKitchenBase.prototype, "updateKitchenStatusState", void 0);
__decorate([
    property()
], CafeFlowWsCookKitchenBase.prototype, "updateKitchenStatusStatus", void 0);
__decorate([
    property()
], CafeFlowWsCookKitchenBase.prototype, "updateKitchenStatusPreviousStatus", void 0);
__decorate([
    property()
], CafeFlowWsCookKitchenBase.prototype, "createStockMovementState", void 0);
__decorate([
    property()
], CafeFlowWsCookKitchenBase.prototype, "createStockMovementMovementType", void 0);
__decorate([
    property()
], CafeFlowWsCookKitchenBase.prototype, "createStockMovementQuantity", void 0);
__decorate([
    property()
], CafeFlowWsCookKitchenBase.prototype, "createStockMovementReason", void 0);
__decorate([
    property()
], CafeFlowWsCookKitchenBase.prototype, "LayoutColOrderId", void 0);
__decorate([
    property()
], CafeFlowWsCookKitchenBase.prototype, "LayoutColOrderType", void 0);
__decorate([
    property()
], CafeFlowWsCookKitchenBase.prototype, "LayoutColTableId", void 0);
__decorate([
    property()
], CafeFlowWsCookKitchenBase.prototype, "LayoutColTotal", void 0);
__decorate([
    property()
], CafeFlowWsCookKitchenBase.prototype, "LayoutColCreatedAt", void 0);

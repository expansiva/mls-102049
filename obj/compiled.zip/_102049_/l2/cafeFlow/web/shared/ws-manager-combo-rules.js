/// <mls fileReference="_102049_/l2/cafeFlow/web/shared/ws-manager-combo-rules.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
/// **collab_i18n_start**
const message_pt = {
    "page.title": "Gestão de Regras de Combo e Substituição",
    "organism.queryComboRules.title": "Consultar Regras de Combo",
    "organism.createComboRule.title": "Criar Regra de Combo",
    "organism.updateComboRule.title": "Editar Regra de Combo",
    "organism.deleteComboRule.title": "Remover Regra de Combo",
    "intention.queryList.title": "Regras de Combo Cadastradas",
    "intention.createForm.title": "Nova Regra de Combo",
    "intention.updateForm.title": "Alterar Regra de Combo",
    "intention.deleteForm.title": "Confirmar Exclusão de Regra",
    "action.queryComboRules.label": "Buscar",
    "action.createComboRule.label": "Salvar",
    "action.updateComboRule.label": "Salvar Alterações",
    "action.deleteComboRule.label": "Confirmar Exclusão",
    "field.comboRuleId.label": "ID da Regra",
    "field.menuItemId.label": "Item do Cardápio",
    "field.name.label": "Nome",
    "field.description.label": "Descrição",
    "field.priceDifference.label": "Diferença de Preço",
    "field.status.label": "Situação",
    "field.createdAt.label": "Criado em",
    "field.updatedAt.label": "Atualizado em",
    "empty.queryComboRules.label": "Nenhuma regra de combo encontrada",
    "sec.main.title": "Gestão de Regras de Combo e Substituição"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowWsManagerComboRulesBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.queryComboRulesState = 'idle';
        this.queryComboRulesComboRuleId = '';
        this.queryComboRulesMenuItemId = '';
        this.queryComboRulesName = '';
        this.queryComboRulesStatus = '';
        this.queryComboRulesCreatedAt = '';
        this.queryComboRulesUpdatedAt = '';
        this.queryComboRulesData = [];
        this.createComboRuleState = 'idle';
        this.createComboRuleName = '';
        this.createComboRuleDescription = '';
        this.createComboRulePriceDifference = '';
        this.createComboRuleStatus = '';
        this.updateComboRuleState = 'idle';
        this.updateComboRuleName = '';
        this.updateComboRuleDescription = '';
        this.updateComboRulePriceDifference = '';
        this.updateComboRuleStatus = '';
        this.deleteComboRuleState = 'idle';
        this.deleteComboRuleComboRuleId = '';
        this.deleteComboRuleMenuItemId = '';
        this.deleteComboRuleName = '';
        this.deleteComboRuleDescription = '';
        this.deleteComboRulePriceDifference = '';
        this.deleteComboRuleStatus = '';
        this.OutputCreateComboRule = null;
        this.OutputUpdateComboRule = null;
        this.OutputDeleteComboRule = null;
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initializeState();
        this.subscribeToState();
        void this.loadQueryComboRules();
    }
    disconnectedCallback() {
        this.unsubscribeFromState();
        super.disconnectedCallback();
    }
    handleIcaStateChange(stateKey, value) {
        switch (stateKey) {
            case 'ui.ws-manager-combo-rules.status':
                this.status = value;
                break;
            case 'ui.ws-manager-combo-rules.action.queryComboRules.status':
                this.queryComboRulesState = value;
                break;
            case 'ui.ws-manager-combo-rules.input.queryComboRules.comboRuleId':
                this.queryComboRulesComboRuleId = value;
                break;
            case 'ui.ws-manager-combo-rules.input.queryComboRules.menuItemId':
                this.queryComboRulesMenuItemId = value;
                break;
            case 'ui.ws-manager-combo-rules.input.queryComboRules.name':
                this.queryComboRulesName = value;
                break;
            case 'ui.ws-manager-combo-rules.input.queryComboRules.status':
                this.queryComboRulesStatus = value;
                break;
            case 'ui.ws-manager-combo-rules.input.queryComboRules.createdAt':
                this.queryComboRulesCreatedAt = value;
                break;
            case 'ui.ws-manager-combo-rules.input.queryComboRules.updatedAt':
                this.queryComboRulesUpdatedAt = value;
                break;
            case 'ui.ws-manager-combo-rules.data.queryComboRules':
                this.queryComboRulesData = value;
                break;
            case 'ui.ws-manager-combo-rules.action.createComboRule.status':
                this.createComboRuleState = value;
                break;
            case 'ui.ws-manager-combo-rules.input.createComboRule.name':
                this.createComboRuleName = value;
                break;
            case 'ui.ws-manager-combo-rules.input.createComboRule.description':
                this.createComboRuleDescription = value;
                break;
            case 'ui.ws-manager-combo-rules.input.createComboRule.priceDifference':
                this.createComboRulePriceDifference = value;
                break;
            case 'ui.ws-manager-combo-rules.input.createComboRule.status':
                this.createComboRuleStatus = value;
                break;
            case 'ui.ws-manager-combo-rules.action.updateComboRule.status':
                this.updateComboRuleState = value;
                break;
            case 'ui.ws-manager-combo-rules.input.updateComboRule.name':
                this.updateComboRuleName = value;
                break;
            case 'ui.ws-manager-combo-rules.input.updateComboRule.description':
                this.updateComboRuleDescription = value;
                break;
            case 'ui.ws-manager-combo-rules.input.updateComboRule.priceDifference':
                this.updateComboRulePriceDifference = value;
                break;
            case 'ui.ws-manager-combo-rules.input.updateComboRule.status':
                this.updateComboRuleStatus = value;
                break;
            case 'ui.ws-manager-combo-rules.action.deleteComboRule.status':
                this.deleteComboRuleState = value;
                break;
            case 'ui.ws-manager-combo-rules.input.deleteComboRule.comboRuleId':
                this.deleteComboRuleComboRuleId = value;
                break;
            case 'ui.ws-manager-combo-rules.input.deleteComboRule.menuItemId':
                this.deleteComboRuleMenuItemId = value;
                break;
            case 'ui.ws-manager-combo-rules.input.deleteComboRule.name':
                this.deleteComboRuleName = value;
                break;
            case 'ui.ws-manager-combo-rules.input.deleteComboRule.description':
                this.deleteComboRuleDescription = value;
                break;
            case 'ui.ws-manager-combo-rules.input.deleteComboRule.priceDifference':
                this.deleteComboRulePriceDifference = value;
                break;
            case 'ui.ws-manager-combo-rules.input.deleteComboRule.status':
                this.deleteComboRuleStatus = value;
                break;
            case 'ui.ws-manager-combo-rules.output.createComboRule':
                this.OutputCreateComboRule = value;
                break;
            case 'ui.ws-manager-combo-rules.output.updateComboRule':
                this.OutputUpdateComboRule = value;
                break;
            case 'ui.ws-manager-combo-rules.output.deleteComboRule':
                this.OutputDeleteComboRule = value;
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initializeState() {
        this.status = this.readState('ui.ws-manager-combo-rules.status', this.status);
        this.queryComboRulesState = this.readState('ui.ws-manager-combo-rules.action.queryComboRules.status', this.queryComboRulesState);
        this.queryComboRulesComboRuleId = this.readState('ui.ws-manager-combo-rules.input.queryComboRules.comboRuleId', this.queryComboRulesComboRuleId);
        this.queryComboRulesMenuItemId = this.readState('ui.ws-manager-combo-rules.input.queryComboRules.menuItemId', this.queryComboRulesMenuItemId);
        this.queryComboRulesName = this.readState('ui.ws-manager-combo-rules.input.queryComboRules.name', this.queryComboRulesName);
        this.queryComboRulesStatus = this.readState('ui.ws-manager-combo-rules.input.queryComboRules.status', this.queryComboRulesStatus);
        this.queryComboRulesCreatedAt = this.readState('ui.ws-manager-combo-rules.input.queryComboRules.createdAt', this.queryComboRulesCreatedAt);
        this.queryComboRulesUpdatedAt = this.readState('ui.ws-manager-combo-rules.input.queryComboRules.updatedAt', this.queryComboRulesUpdatedAt);
        this.queryComboRulesData = this.readState('ui.ws-manager-combo-rules.data.queryComboRules', this.queryComboRulesData);
        this.createComboRuleState = this.readState('ui.ws-manager-combo-rules.action.createComboRule.status', this.createComboRuleState);
        this.createComboRuleName = this.readState('ui.ws-manager-combo-rules.input.createComboRule.name', this.createComboRuleName);
        this.createComboRuleDescription = this.readState('ui.ws-manager-combo-rules.input.createComboRule.description', this.createComboRuleDescription);
        this.createComboRulePriceDifference = this.readState('ui.ws-manager-combo-rules.input.createComboRule.priceDifference', this.createComboRulePriceDifference);
        this.createComboRuleStatus = this.readState('ui.ws-manager-combo-rules.input.createComboRule.status', this.createComboRuleStatus);
        this.updateComboRuleState = this.readState('ui.ws-manager-combo-rules.action.updateComboRule.status', this.updateComboRuleState);
        this.updateComboRuleName = this.readState('ui.ws-manager-combo-rules.input.updateComboRule.name', this.updateComboRuleName);
        this.updateComboRuleDescription = this.readState('ui.ws-manager-combo-rules.input.updateComboRule.description', this.updateComboRuleDescription);
        this.updateComboRulePriceDifference = this.readState('ui.ws-manager-combo-rules.input.updateComboRule.priceDifference', this.updateComboRulePriceDifference);
        this.updateComboRuleStatus = this.readState('ui.ws-manager-combo-rules.input.updateComboRule.status', this.updateComboRuleStatus);
        this.deleteComboRuleState = this.readState('ui.ws-manager-combo-rules.action.deleteComboRule.status', this.deleteComboRuleState);
        this.deleteComboRuleComboRuleId = this.readState('ui.ws-manager-combo-rules.input.deleteComboRule.comboRuleId', this.deleteComboRuleComboRuleId);
        this.deleteComboRuleMenuItemId = this.readState('ui.ws-manager-combo-rules.input.deleteComboRule.menuItemId', this.deleteComboRuleMenuItemId);
        this.deleteComboRuleName = this.readState('ui.ws-manager-combo-rules.input.deleteComboRule.name', this.deleteComboRuleName);
        this.deleteComboRuleDescription = this.readState('ui.ws-manager-combo-rules.input.deleteComboRule.description', this.deleteComboRuleDescription);
        this.deleteComboRulePriceDifference = this.readState('ui.ws-manager-combo-rules.input.deleteComboRule.priceDifference', this.deleteComboRulePriceDifference);
        this.deleteComboRuleStatus = this.readState('ui.ws-manager-combo-rules.input.deleteComboRule.status', this.deleteComboRuleStatus);
        this.OutputCreateComboRule = this.readState('ui.ws-manager-combo-rules.output.createComboRule', this.OutputCreateComboRule);
        this.OutputUpdateComboRule = this.readState('ui.ws-manager-combo-rules.output.updateComboRule', this.OutputUpdateComboRule);
        this.OutputDeleteComboRule = this.readState('ui.ws-manager-combo-rules.output.deleteComboRule', this.OutputDeleteComboRule);
    }
    readState(key, fallback) {
        const stored = getState(key);
        if (stored !== undefined) {
            return stored;
        }
        setState(key, fallback);
        return fallback;
    }
    subscribeToState() {
        subscribe([
            'ui.ws-manager-combo-rules.status',
            'ui.ws-manager-combo-rules.action.queryComboRules.status',
            'ui.ws-manager-combo-rules.input.queryComboRules.comboRuleId',
            'ui.ws-manager-combo-rules.input.queryComboRules.menuItemId',
            'ui.ws-manager-combo-rules.input.queryComboRules.name',
            'ui.ws-manager-combo-rules.input.queryComboRules.status',
            'ui.ws-manager-combo-rules.input.queryComboRules.createdAt',
            'ui.ws-manager-combo-rules.input.queryComboRules.updatedAt',
            'ui.ws-manager-combo-rules.data.queryComboRules',
            'ui.ws-manager-combo-rules.action.createComboRule.status',
            'ui.ws-manager-combo-rules.input.createComboRule.name',
            'ui.ws-manager-combo-rules.input.createComboRule.description',
            'ui.ws-manager-combo-rules.input.createComboRule.priceDifference',
            'ui.ws-manager-combo-rules.input.createComboRule.status',
            'ui.ws-manager-combo-rules.action.updateComboRule.status',
            'ui.ws-manager-combo-rules.input.updateComboRule.name',
            'ui.ws-manager-combo-rules.input.updateComboRule.description',
            'ui.ws-manager-combo-rules.input.updateComboRule.priceDifference',
            'ui.ws-manager-combo-rules.input.updateComboRule.status',
            'ui.ws-manager-combo-rules.action.deleteComboRule.status',
            'ui.ws-manager-combo-rules.input.deleteComboRule.comboRuleId',
            'ui.ws-manager-combo-rules.input.deleteComboRule.menuItemId',
            'ui.ws-manager-combo-rules.input.deleteComboRule.name',
            'ui.ws-manager-combo-rules.input.deleteComboRule.description',
            'ui.ws-manager-combo-rules.input.deleteComboRule.priceDifference',
            'ui.ws-manager-combo-rules.input.deleteComboRule.status',
            'ui.ws-manager-combo-rules.output.createComboRule',
            'ui.ws-manager-combo-rules.output.updateComboRule',
            'ui.ws-manager-combo-rules.output.deleteComboRule'
        ], this);
    }
    unsubscribeFromState() {
        unsubscribe([
            'ui.ws-manager-combo-rules.status',
            'ui.ws-manager-combo-rules.action.queryComboRules.status',
            'ui.ws-manager-combo-rules.input.queryComboRules.comboRuleId',
            'ui.ws-manager-combo-rules.input.queryComboRules.menuItemId',
            'ui.ws-manager-combo-rules.input.queryComboRules.name',
            'ui.ws-manager-combo-rules.input.queryComboRules.status',
            'ui.ws-manager-combo-rules.input.queryComboRules.createdAt',
            'ui.ws-manager-combo-rules.input.queryComboRules.updatedAt',
            'ui.ws-manager-combo-rules.data.queryComboRules',
            'ui.ws-manager-combo-rules.action.createComboRule.status',
            'ui.ws-manager-combo-rules.input.createComboRule.name',
            'ui.ws-manager-combo-rules.input.createComboRule.description',
            'ui.ws-manager-combo-rules.input.createComboRule.priceDifference',
            'ui.ws-manager-combo-rules.input.createComboRule.status',
            'ui.ws-manager-combo-rules.action.updateComboRule.status',
            'ui.ws-manager-combo-rules.input.updateComboRule.name',
            'ui.ws-manager-combo-rules.input.updateComboRule.description',
            'ui.ws-manager-combo-rules.input.updateComboRule.priceDifference',
            'ui.ws-manager-combo-rules.input.updateComboRule.status',
            'ui.ws-manager-combo-rules.action.deleteComboRule.status',
            'ui.ws-manager-combo-rules.input.deleteComboRule.comboRuleId',
            'ui.ws-manager-combo-rules.input.deleteComboRule.menuItemId',
            'ui.ws-manager-combo-rules.input.deleteComboRule.name',
            'ui.ws-manager-combo-rules.input.deleteComboRule.description',
            'ui.ws-manager-combo-rules.input.deleteComboRule.priceDifference',
            'ui.ws-manager-combo-rules.input.deleteComboRule.status',
            'ui.ws-manager-combo-rules.output.createComboRule',
            'ui.ws-manager-combo-rules.output.updateComboRule',
            'ui.ws-manager-combo-rules.output.deleteComboRule'
        ], this);
    }
    async loadQueryComboRules() {
        this.queryComboRulesState = 'loading';
        setState('ui.ws-manager-combo-rules.action.queryComboRules.status', this.queryComboRulesState);
        const params = {
            comboRuleId: this.queryComboRulesComboRuleId || undefined,
            menuItemId: this.queryComboRulesMenuItemId || undefined,
            name: this.queryComboRulesName || undefined,
            status: this.queryComboRulesStatus ? this.queryComboRulesStatus : undefined,
            createdAt: this.queryComboRulesCreatedAt || undefined,
            updatedAt: this.queryComboRulesUpdatedAt || undefined,
        };
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.queryComboRules.queryComboRules', params, options);
        if (!response.ok) {
            this.queryComboRulesState = 'error';
            setState('ui.ws-manager-combo-rules.action.queryComboRules.status', this.queryComboRulesState);
            throw response.error ?? new Error('Falha ao consultar regras de combo.');
        }
        const data = response.data ?? [];
        this.queryComboRulesData = data;
        setState('ui.ws-manager-combo-rules.data.queryComboRules', data);
        this.queryComboRulesState = 'success';
        setState('ui.ws-manager-combo-rules.action.queryComboRules.status', this.queryComboRulesState);
    }
    handleQueryComboRulesClick(_event) {
        void this.loadQueryComboRules();
    }
    async createComboRule(signal) {
        this.createComboRuleState = 'loading';
        setState('ui.ws-manager-combo-rules.action.createComboRule.status', this.createComboRuleState);
        const priceDifference = typeof this.createComboRulePriceDifference === 'string'
            ? Number(this.createComboRulePriceDifference)
            : this.createComboRulePriceDifference;
        const params = {
            name: this.createComboRuleName,
            description: this.createComboRuleDescription || undefined,
            priceDifference,
            status: this.createComboRuleStatus,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('cafeFlow.createComboRule.createComboRule', params, options);
        if (!response.ok) {
            this.createComboRuleState = 'error';
            setState('ui.ws-manager-combo-rules.action.createComboRule.status', this.createComboRuleState);
            throw response.error ?? new Error('Falha ao criar regra de combo.');
        }
        this.OutputCreateComboRule = response.data;
        setState('ui.ws-manager-combo-rules.output.createComboRule', this.OutputCreateComboRule);
        this.createComboRuleState = 'success';
        setState('ui.ws-manager-combo-rules.action.createComboRule.status', this.createComboRuleState);
    }
    handleCreateComboRuleClick(_event) {
        void runBlockingUiAction((signal) => this.createComboRule(signal));
    }
    async updateComboRule(signal) {
        this.updateComboRuleState = 'loading';
        setState('ui.ws-manager-combo-rules.action.updateComboRule.status', this.updateComboRuleState);
        const priceDifference = typeof this.updateComboRulePriceDifference === 'string'
            ? Number(this.updateComboRulePriceDifference)
            : this.updateComboRulePriceDifference;
        const params = {
            name: this.updateComboRuleName,
            description: this.updateComboRuleDescription || undefined,
            priceDifference,
            status: this.updateComboRuleStatus,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('cafeFlow.updateComboRule.updateComboRule', params, options);
        if (!response.ok) {
            this.updateComboRuleState = 'error';
            setState('ui.ws-manager-combo-rules.action.updateComboRule.status', this.updateComboRuleState);
            throw response.error ?? new Error('Falha ao atualizar regra de combo.');
        }
        this.OutputUpdateComboRule = response.data;
        setState('ui.ws-manager-combo-rules.output.updateComboRule', this.OutputUpdateComboRule);
        this.updateComboRuleState = 'success';
        setState('ui.ws-manager-combo-rules.action.updateComboRule.status', this.updateComboRuleState);
    }
    handleUpdateComboRuleClick(_event) {
        void runBlockingUiAction((signal) => this.updateComboRule(signal));
    }
    async deleteComboRule(signal) {
        this.deleteComboRuleState = 'loading';
        setState('ui.ws-manager-combo-rules.action.deleteComboRule.status', this.deleteComboRuleState);
        const priceDifference = typeof this.deleteComboRulePriceDifference === 'string'
            ? Number(this.deleteComboRulePriceDifference)
            : this.deleteComboRulePriceDifference;
        const params = {
            comboRuleId: this.deleteComboRuleComboRuleId || undefined,
            menuItemId: this.deleteComboRuleMenuItemId || undefined,
            name: this.deleteComboRuleName,
            description: this.deleteComboRuleDescription || undefined,
            priceDifference,
            status: this.deleteComboRuleStatus,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('cafeFlow.deleteComboRule.deleteComboRule', params, options);
        if (!response.ok) {
            this.deleteComboRuleState = 'error';
            setState('ui.ws-manager-combo-rules.action.deleteComboRule.status', this.deleteComboRuleState);
            throw response.error ?? new Error('Falha ao remover regra de combo.');
        }
        this.OutputDeleteComboRule = response.data;
        setState('ui.ws-manager-combo-rules.output.deleteComboRule', this.OutputDeleteComboRule);
        this.deleteComboRuleState = 'success';
        setState('ui.ws-manager-combo-rules.action.deleteComboRule.status', this.deleteComboRuleState);
    }
    handleDeleteComboRuleClick(_event) {
        void runBlockingUiAction((signal) => this.deleteComboRule(signal));
    }
    setQueryComboRulesComboRuleId(value) {
        this.queryComboRulesComboRuleId = value;
        setState('ui.ws-manager-combo-rules.input.queryComboRules.comboRuleId', value);
        this.requestUpdate();
    }
    handleQueryComboRulesComboRuleIdChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setQueryComboRulesComboRuleId(target.value);
    }
    setQueryComboRulesMenuItemId(value) {
        this.queryComboRulesMenuItemId = value;
        setState('ui.ws-manager-combo-rules.input.queryComboRules.menuItemId', value);
        this.requestUpdate();
    }
    handleQueryComboRulesMenuItemIdChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setQueryComboRulesMenuItemId(target.value);
    }
    setQueryComboRulesName(value) {
        this.queryComboRulesName = value;
        setState('ui.ws-manager-combo-rules.input.queryComboRules.name', value);
        this.requestUpdate();
    }
    handleQueryComboRulesNameChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setQueryComboRulesName(target.value);
    }
    setQueryComboRulesStatus(value) {
        this.queryComboRulesStatus = value;
        setState('ui.ws-manager-combo-rules.input.queryComboRules.status', value);
        this.requestUpdate();
    }
    handleQueryComboRulesStatusChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setQueryComboRulesStatus(target.value);
    }
    setQueryComboRulesCreatedAt(value) {
        this.queryComboRulesCreatedAt = value;
        setState('ui.ws-manager-combo-rules.input.queryComboRules.createdAt', value);
        this.requestUpdate();
    }
    handleQueryComboRulesCreatedAtChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setQueryComboRulesCreatedAt(target.value);
    }
    setQueryComboRulesUpdatedAt(value) {
        this.queryComboRulesUpdatedAt = value;
        setState('ui.ws-manager-combo-rules.input.queryComboRules.updatedAt', value);
        this.requestUpdate();
    }
    handleQueryComboRulesUpdatedAtChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setQueryComboRulesUpdatedAt(target.value);
    }
    setCreateComboRuleName(value) {
        this.createComboRuleName = value;
        setState('ui.ws-manager-combo-rules.input.createComboRule.name', value);
        this.requestUpdate();
    }
    handleCreateComboRuleNameChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setCreateComboRuleName(target.value);
    }
    setCreateComboRuleDescription(value) {
        this.createComboRuleDescription = value;
        setState('ui.ws-manager-combo-rules.input.createComboRule.description', value);
        this.requestUpdate();
    }
    handleCreateComboRuleDescriptionChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setCreateComboRuleDescription(target.value);
    }
    setCreateComboRulePriceDifference(value) {
        this.createComboRulePriceDifference = value;
        setState('ui.ws-manager-combo-rules.input.createComboRule.priceDifference', value);
        this.requestUpdate();
    }
    handleCreateComboRulePriceDifferenceChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setCreateComboRulePriceDifference(target.value);
    }
    setCreateComboRuleStatus(value) {
        this.createComboRuleStatus = value;
        setState('ui.ws-manager-combo-rules.input.createComboRule.status', value);
        this.requestUpdate();
    }
    handleCreateComboRuleStatusChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setCreateComboRuleStatus(target.value);
    }
    setUpdateComboRuleName(value) {
        this.updateComboRuleName = value;
        setState('ui.ws-manager-combo-rules.input.updateComboRule.name', value);
        this.requestUpdate();
    }
    handleUpdateComboRuleNameChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setUpdateComboRuleName(target.value);
    }
    setUpdateComboRuleDescription(value) {
        this.updateComboRuleDescription = value;
        setState('ui.ws-manager-combo-rules.input.updateComboRule.description', value);
        this.requestUpdate();
    }
    handleUpdateComboRuleDescriptionChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setUpdateComboRuleDescription(target.value);
    }
    setUpdateComboRulePriceDifference(value) {
        this.updateComboRulePriceDifference = value;
        setState('ui.ws-manager-combo-rules.input.updateComboRule.priceDifference', value);
        this.requestUpdate();
    }
    handleUpdateComboRulePriceDifferenceChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setUpdateComboRulePriceDifference(target.value);
    }
    setUpdateComboRuleStatus(value) {
        this.updateComboRuleStatus = value;
        setState('ui.ws-manager-combo-rules.input.updateComboRule.status', value);
        this.requestUpdate();
    }
    handleUpdateComboRuleStatusChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setUpdateComboRuleStatus(target.value);
    }
    setDeleteComboRuleComboRuleId(value) {
        this.deleteComboRuleComboRuleId = value;
        setState('ui.ws-manager-combo-rules.input.deleteComboRule.comboRuleId', value);
        this.requestUpdate();
    }
    handleDeleteComboRuleComboRuleIdChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setDeleteComboRuleComboRuleId(target.value);
    }
    setDeleteComboRuleMenuItemId(value) {
        this.deleteComboRuleMenuItemId = value;
        setState('ui.ws-manager-combo-rules.input.deleteComboRule.menuItemId', value);
        this.requestUpdate();
    }
    handleDeleteComboRuleMenuItemIdChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setDeleteComboRuleMenuItemId(target.value);
    }
    setDeleteComboRuleName(value) {
        this.deleteComboRuleName = value;
        setState('ui.ws-manager-combo-rules.input.deleteComboRule.name', value);
        this.requestUpdate();
    }
    handleDeleteComboRuleNameChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setDeleteComboRuleName(target.value);
    }
    setDeleteComboRuleDescription(value) {
        this.deleteComboRuleDescription = value;
        setState('ui.ws-manager-combo-rules.input.deleteComboRule.description', value);
        this.requestUpdate();
    }
    handleDeleteComboRuleDescriptionChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setDeleteComboRuleDescription(target.value);
    }
    setDeleteComboRulePriceDifference(value) {
        this.deleteComboRulePriceDifference = value;
        setState('ui.ws-manager-combo-rules.input.deleteComboRule.priceDifference', value);
        this.requestUpdate();
    }
    handleDeleteComboRulePriceDifferenceChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setDeleteComboRulePriceDifference(target.value);
    }
    setDeleteComboRuleStatus(value) {
        this.deleteComboRuleStatus = value;
        setState('ui.ws-manager-combo-rules.input.deleteComboRule.status', value);
        this.requestUpdate();
    }
    handleDeleteComboRuleStatusChange(event) {
        const target = event.target;
        if (!target)
            return;
        this.setDeleteComboRuleStatus(target.value);
    }
}
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "queryComboRulesState", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "queryComboRulesComboRuleId", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "queryComboRulesMenuItemId", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "queryComboRulesName", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "queryComboRulesStatus", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "queryComboRulesCreatedAt", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "queryComboRulesUpdatedAt", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "queryComboRulesData", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "createComboRuleState", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "createComboRuleName", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "createComboRuleDescription", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "createComboRulePriceDifference", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "createComboRuleStatus", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "updateComboRuleState", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "updateComboRuleName", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "updateComboRuleDescription", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "updateComboRulePriceDifference", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "updateComboRuleStatus", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "deleteComboRuleState", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "deleteComboRuleComboRuleId", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "deleteComboRuleMenuItemId", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "deleteComboRuleName", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "deleteComboRuleDescription", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "deleteComboRulePriceDifference", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "deleteComboRuleStatus", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "OutputCreateComboRule", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "OutputUpdateComboRule", void 0);
__decorate([
    property()
], CafeFlowWsManagerComboRulesBase.prototype, "OutputDeleteComboRule", void 0);

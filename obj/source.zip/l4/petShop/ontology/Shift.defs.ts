/// <mls fileReference="_102049_/l4/petShop/ontology/Shift.defs.ts" enhancement="_blank"/>

export const petShopEntityShift = {
  "entityId": "Shift",
  "title": "Turno de Trabalho",
  "description": "Turno de trabalho recorrente definido pelo administrador com horário de início, fim e dias da semana, base para o cálculo de capacidade de agendamento.",
  "kind": "mdm",
  "ownership": "moduleOwned",
  "fields": [
    {
      "fieldId": "shiftId",
      "type": "uuid",
      "required": true,
      "description": "Identificador único do turno de trabalho."
    },
    {
      "fieldId": "name",
      "type": "string",
      "required": true,
      "description": "Nome do turno para identificação pelo administrador (ex.: Manhã, Tarde, Dia Inteiro)."
    },
    {
      "fieldId": "startTime",
      "type": "string",
      "required": true,
      "description": "Horário de início do turno no formato HH:mm (ex.: 09:00)."
    },
    {
      "fieldId": "endTime",
      "type": "string",
      "required": true,
      "description": "Horário de fim do turno no formato HH:mm (ex.: 18:00)."
    },
    {
      "fieldId": "monday",
      "type": "boolean",
      "required": true,
      "description": "Indica se o turno ocorre às segundas-feiras."
    },
    {
      "fieldId": "tuesday",
      "type": "boolean",
      "required": true,
      "description": "Indica se o turno ocorre às terças-feiras."
    },
    {
      "fieldId": "wednesday",
      "type": "boolean",
      "required": true,
      "description": "Indica se o turno ocorre às quartas-feiras."
    },
    {
      "fieldId": "thursday",
      "type": "boolean",
      "required": true,
      "description": "Indica se o turno ocorre às quintas-feiras."
    },
    {
      "fieldId": "friday",
      "type": "boolean",
      "required": true,
      "description": "Indica se o turno ocorre às sextas-feiras."
    },
    {
      "fieldId": "saturday",
      "type": "boolean",
      "required": true,
      "description": "Indica se o turno ocorre aos sábados."
    },
    {
      "fieldId": "sunday",
      "type": "boolean",
      "required": true,
      "description": "Indica se o turno ocorre aos domingos."
    },
    {
      "fieldId": "active",
      "type": "boolean",
      "required": true,
      "description": "Indica se o turno está ativo e disponível para alocação de operadores e agendamentos."
    },
    {
      "fieldId": "createdAt",
      "type": "datetime",
      "required": true,
      "description": "Data e hora de criação do turno."
    },
    {
      "fieldId": "updatedAt",
      "type": "datetime",
      "required": true,
      "description": "Data e hora da última atualização do turno."
    }
  ]
} as const;

export default petShopEntityShift;

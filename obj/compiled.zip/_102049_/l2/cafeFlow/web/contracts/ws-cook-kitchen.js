/// <mls fileReference="_102049_/l2/cafeFlow/web/contracts/ws-cook-kitchen.ts" enhancement="_blank"/>
export {};

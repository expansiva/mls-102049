/// <mls fileReference="_102049_/l4/operations/viewMyReservations.defs.ts" enhancement="_blank"/>

export const operationViewMyReservations = {
  "operationId": "viewMyReservations",
  "title": "Visualizar minhas reservas",
  "actor": "cliente",
  "entity": "Reservation",
  "kind": "query",
  "reads": [
    "Reservation",
    "ReservationItem"
  ],
  "writes": [],
  "rulesApplied": [
    "reservationRequiresAuthentication",
    "reservationStatusReflectsStage"
  ],
  "story": {
    "actor": "cliente",
    "goal": "Consultar a lista de suas reservas para verificar o status e o prazo de validade antes de se deslocar à loja ou encontrar uma reserva para cancelar",
    "steps": [
      "O cliente autenticado abre a tela de minhas reservas",
      "O sistema filtra as reservas pelo customerId da sessão ativa",
      "O sistema retorna a lista de reservas ordenadas pela data de criação mais recente",
      "O cliente visualiza o status, o prazo de expiração e os itens de cada reserva"
    ],
    "outcome": "O cliente vê todas as suas reservas com status atual e prazo de validade, podendo decidir se deve ir à loja ou cancelar uma reserva ativa"
  },
  "accessPattern": {
    "kind": "list",
    "entity": "Reservation",
    "keyField": "Reservation.reservationId",
    "filters": [
      "Reservation.customerId"
    ],
    "sort": [
      "Reservation.createdAt"
    ],
    "pagination": "optional",
    "selection": "none",
    "output": [
      "Reservation.reservationId",
      "Reservation.status",
      "Reservation.expiresAt",
      "Reservation.createdAt",
      "Reservation.confirmedAt",
      "Reservation.readyAt",
      "ReservationItem.productId",
      "ReservationItem.quantity"
    ]
  },
  "outputShape": {
    "kind": "list",
    "fields": [
      {
        "name": "reservationId",
        "type": "string",
        "required": true,
        "fieldRef": "Reservation.reservationId"
      },
      {
        "name": "status",
        "type": "string",
        "required": true,
        "fieldRef": "Reservation.status"
      },
      {
        "name": "expiresAt",
        "type": "string",
        "required": true,
        "fieldRef": "Reservation.expiresAt"
      },
      {
        "name": "createdAt",
        "type": "string",
        "required": true,
        "fieldRef": "Reservation.createdAt"
      },
      {
        "name": "confirmedAt",
        "type": "string",
        "required": false,
        "fieldRef": "Reservation.confirmedAt"
      },
      {
        "name": "readyAt",
        "type": "string",
        "required": false,
        "fieldRef": "Reservation.readyAt"
      },
      {
        "name": "items",
        "type": "array",
        "required": true,
        "item": {
          "fields": [
            {
              "name": "productId",
              "type": "string",
              "required": true,
              "fieldRef": "ReservationItem.productId"
            },
            {
              "name": "quantity",
              "type": "number",
              "required": true,
              "fieldRef": "ReservationItem.quantity"
            }
          ]
        }
      }
    ]
  },
  "inputs": [
    {
      "inputId": "customerId",
      "fieldRef": "Reservation.customerId",
      "required": true,
      "source": "actorSession",
      "description": "Identificador do cliente autenticado obtido da sessão para filtrar apenas suas reservas"
    }
  ],
  "contextResolution": [
    {
      "targetRef": "Reservation.customerId",
      "source": "actorSession",
      "originRef": "actorSession.actorId",
      "description": "O customerId é resolvido a partir do identificador do ator autenticado na sessão, garantindo que o cliente só veja suas próprias reservas"
    }
  ],
  "acceptanceAssertions": [
    "A lista retornada contém apenas reservas cujo customerId corresponde ao cliente autenticado na sessão",
    "Cada reserva na lista possui um status válido entre draft, active, ready, delivered, expired ou cancelled",
    "Cada reserva na lista inclui o campo expiresAt indicando o prazo de validade de 24 horas para retirada",
    "As reservas são ordenadas pela data de criação mais recente primeiro",
    "Cada reserva na lista inclui os itens associados com productId e quantity",
    "O cliente não autenticado não consegue acessar a lista de reservas"
  ],
  "pageId": "viewMyReservations",
  "commandName": "viewMyReservations",
  "bffName": "petShop.viewMyReservations.viewMyReservations",
  "capability": {
    "capabilityId": "viewMyReservations",
    "title": "Visualizar minhas reservas",
    "actor": "cliente",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationViewMyReservations;

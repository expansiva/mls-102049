declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/catalog.defs" {
    export const catalogController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "catalog";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "catalog";
            readonly controllerName: "CatalogController";
            readonly ownerKind: "workspace";
            readonly workspaceId: "catalog";
            readonly actors: readonly ["cliente"];
            readonly allowedScopes: readonly ["petShop:cliente"];
            readonly handlers: readonly [{
                readonly handlerName: "catalogFeaturedProductsHandler";
                readonly command: "featuredProducts";
                readonly bffId: "featuredProducts";
                readonly route: "petShop.catalog.featuredProducts";
                readonly kind: "query";
                readonly usecaseRef: "browseFeaturedProducts";
                readonly usecaseRefs: readonly ["browseFeaturedProducts"];
                readonly inputTypeName: "BrowseFeaturedProductsInput";
                readonly inputContract: readonly [{
                    readonly inputId: "categoryId";
                    readonly fieldRef: "Product.categoryId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional por categoria do produto";
                }, {
                    readonly inputId: "petTypeId";
                    readonly fieldRef: "Product.petTypeId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional por tipo de pet associado ao produto";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "Product.name";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Termo de pesquisa opcional para filtrar produtos por nome (insensível a caixa)";
                }, {
                    readonly inputId: "priceMin";
                    readonly fieldRef: "Product.price";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Valor mínimo opcional para filtrar produtos por faixa de preço";
                }, {
                    readonly inputId: "priceMax";
                    readonly fieldRef: "Product.price";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Valor máximo opcional para filtrar produtos por faixa de preço";
                }, {
                    readonly inputId: "page";
                    readonly fieldRef: "";
                    readonly type: "number";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Número da página para paginação opcional dos resultados";
                }, {
                    readonly inputId: "pageSize";
                    readonly fieldRef: "";
                    readonly type: "number";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Quantidade de itens por página para paginação opcional dos resultados";
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "productId";
                        readonly operationId: "browseFeaturedProducts";
                        readonly path: readonly ["productId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "name";
                        readonly operationId: "browseFeaturedProducts";
                        readonly path: readonly ["name"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "price";
                        readonly operationId: "browseFeaturedProducts";
                        readonly path: readonly ["price"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "isFeatured";
                        readonly operationId: "browseFeaturedProducts";
                        readonly path: readonly ["isFeatured"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "categoryId";
                        readonly operationId: "browseFeaturedProducts";
                        readonly path: readonly ["categoryId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "petTypeId";
                        readonly operationId: "browseFeaturedProducts";
                        readonly path: readonly ["petTypeId"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "catalogBrowseCatalogHandler";
                readonly command: "browseCatalog";
                readonly bffId: "browseCatalog";
                readonly route: "petShop.catalog.browseCatalog";
                readonly kind: "query";
                readonly usecaseRef: "browseProducts";
                readonly usecaseRefs: readonly ["browseProducts"];
                readonly inputTypeName: "BrowseProductsInput";
                readonly inputContract: readonly [{
                    readonly inputId: "searchName";
                    readonly fieldRef: "";
                    readonly type: "string";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Texto parcial do nome do produto para pesquisa insensível a caixa";
                }, {
                    readonly inputId: "petTypeId";
                    readonly fieldRef: "";
                    readonly type: "string";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Identificador do tipo de pet para filtrar produtos adequados";
                }, {
                    readonly inputId: "categoryId";
                    readonly fieldRef: "";
                    readonly type: "string";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Identificador da categoria para filtrar produtos";
                }, {
                    readonly inputId: "minPrice";
                    readonly fieldRef: "";
                    readonly type: "string";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Valor mínimo da faixa de preço para filtrar produtos dentro do orçamento";
                }, {
                    readonly inputId: "maxPrice";
                    readonly fieldRef: "";
                    readonly type: "string";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Valor máximo da faixa de preço para filtrar produtos dentro do orçamento";
                }, {
                    readonly inputId: "page";
                    readonly fieldRef: "";
                    readonly type: "number";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Número da página atual para paginação dos resultados";
                }, {
                    readonly inputId: "pageSize";
                    readonly fieldRef: "";
                    readonly type: "number";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Quantidade de itens por página";
                }];
                readonly projection: {
                    readonly kind: "paginated";
                    readonly arrayFieldName: "items";
                    readonly itemFields: readonly [{
                        readonly name: "productId";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["productId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "name";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["name"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "price";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["price"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "isFeatured";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["isFeatured"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "categoryId";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["categoryId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "categoryName";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["categoryName"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "petTypeId";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["petTypeId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "petTypeName";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["petTypeName"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "createdAt";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["createdAt"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "updatedAt";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["updatedAt"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [{
                        readonly name: "total";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["total"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "page";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["page"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "pageSize";
                        readonly operationId: "browseProducts";
                        readonly path: readonly ["pageSize"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "catalogProductDetailsHandler";
                readonly command: "productDetails";
                readonly bffId: "productDetails";
                readonly route: "petShop.catalog.productDetails";
                readonly kind: "query";
                readonly usecaseRef: "viewProductDetails";
                readonly usecaseRefs: readonly ["viewProductDetails"];
                readonly inputTypeName: "ViewProductDetailsInput";
                readonly inputContract: readonly [{
                    readonly inputId: "productId";
                    readonly fieldRef: "Product.productId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identificador do produto selecionado pelo cliente na vitrine ou na lista do catálogo";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "productId";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["productId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "name";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["name"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "price";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["price"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "isFeatured";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["isFeatured"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "categoryId";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["categoryId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "categoryName";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["categoryName"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "petTypeId";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["petTypeId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "petTypeName";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["petTypeName"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "createdAt";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["createdAt"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "updatedAt";
                        readonly operationId: "viewProductDetails";
                        readonly path: readonly ["updatedAt"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "catalogReserveProductHandler";
                readonly command: "reserveProduct";
                readonly bffId: "reserveProduct";
                readonly route: "petShop.catalog.reserveProduct";
                readonly kind: "command";
                readonly usecaseRef: "createReservation";
                readonly usecaseRefs: readonly ["createReservation"];
                readonly inputTypeName: "CreateReservationInput";
                readonly inputContract: readonly [{
                    readonly inputId: "customerName";
                    readonly fieldRef: "Reservation.customerName";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do cliente que está fazendo a reserva";
                }, {
                    readonly inputId: "customerPhone";
                    readonly fieldRef: "Reservation.customerPhone";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Telefone de contato do cliente para identificação na loja";
                }, {
                    readonly inputId: "productId";
                    readonly fieldRef: "Product.productId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador do produto selecionado na tela de detalhes que o cliente deseja reservar";
                }, {
                    readonly inputId: "quantity";
                    readonly fieldRef: "";
                    readonly type: "number";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Quantidade de unidades do produto que o cliente deseja reservar";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "reservationId";
                        readonly operationId: "createReservation";
                        readonly path: readonly ["reservationId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "customerName";
                        readonly operationId: "createReservation";
                        readonly path: readonly ["customerName"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "customerPhone";
                        readonly operationId: "createReservation";
                        readonly path: readonly ["customerPhone"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "createReservation";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "expiresAt";
                        readonly operationId: "createReservation";
                        readonly path: readonly ["expiresAt"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "createdAt";
                        readonly operationId: "createReservation";
                        readonly path: readonly ["createdAt"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "items";
                        readonly operationId: "createReservation";
                        readonly path: readonly ["items"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }];
            readonly routes: readonly [{
                readonly key: "petShop.catalog.featuredProducts";
                readonly handlerName: "catalogFeaturedProductsHandler";
            }, {
                readonly key: "petShop.catalog.browseCatalog";
                readonly handlerName: "catalogBrowseCatalogHandler";
            }, {
                readonly key: "petShop.catalog.productDetails";
                readonly handlerName: "catalogProductDetailsHandler";
            }, {
                readonly key: "petShop.catalog.reserveProduct";
                readonly handlerName: "catalogReserveProductHandler";
            }];
        };
    };
    export default catalogController;
    export const pipeline: readonly [{
        readonly id: "catalog__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/catalog.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/catalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/browseFeaturedProducts.d.ts", "_102049_/l4/petShop/contracts/catalog.featuredProducts.defs.ts", "_102049_/l1/petShop/layer_2_application/usecases/browseProducts.d.ts", "_102049_/l4/petShop/contracts/catalog.browseCatalog.defs.ts", "_102049_/l1/petShop/layer_2_application/usecases/viewProductDetails.d.ts", "_102049_/l4/petShop/contracts/catalog.productDetails.defs.ts", "_102049_/l1/petShop/layer_2_application/usecases/createReservation.d.ts", "_102049_/l4/petShop/contracts/catalog.reserveProduct.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseFeaturedProducts" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseFeaturedProductsInput {
        categoryId?: string;
        petTypeId?: string;
        name?: string;
        priceMin?: number;
        priceMax?: number;
        page?: number;
        pageSize?: number;
    }
    export interface BrowseFeaturedProductItem {
        productId: string;
        name: string;
        price: number;
        isFeatured: boolean;
        categoryId: string;
        petTypeId: string;
    }
    export interface BrowseFeaturedProductsOutput {
        items: BrowseFeaturedProductItem[];
    }
    export function browseFeaturedProducts(ctx: RequestContext, input: BrowseFeaturedProductsInput): Promise<BrowseFeaturedProductsOutput>;
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseProducts" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseProductsInput {
        searchName?: string;
        petTypeId?: string;
        categoryId?: string;
        minPrice?: string;
        maxPrice?: string;
        page?: number;
        pageSize?: number;
    }
    export interface BrowseProductsItem {
        productId: string;
        name: string;
        price: number;
        isFeatured: boolean;
        categoryId: string;
        categoryName: string;
        petTypeId: string;
        petTypeName: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface BrowseProductsOutput {
        items: BrowseProductsItem[];
        total: number;
        page: number;
        pageSize: number;
    }
    export function browseProducts(ctx: RequestContext, input: BrowseProductsInput): Promise<BrowseProductsOutput>;
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/viewProductDetails" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewProductDetailsInput {
        productId: string;
    }
    export interface ViewProductDetailsOutput {
        productId: string;
        name: string;
        price: number;
        isFeatured: boolean;
        categoryId: string;
        categoryName: string;
        petTypeId: string;
        petTypeName: string;
        createdAt: string;
        updatedAt: string;
    }
    export function viewProductDetails(ctx: RequestContext, input: ViewProductDetailsInput): Promise<ViewProductDetailsOutput>;
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/reservation" {
    export type ReservationStatus = 'pending' | 'confirmed' | 'fulfilled' | 'cancelled';
    export interface ReservationItem {
        reservationItemId: string;
        reservationId: string;
        productId: string;
        quantity: number;
        createdAt: string;
        updatedAt: string;
    }
    export interface Reservation {
        reservationId: string;
        customerName: string;
        customerPhone: string;
        status: ReservationStatus;
        expiresAt: string;
        confirmedAt: string | null;
        fulfilledAt: string | null;
        cancelledAt: string | null;
        cancellationReason: string | null;
        paymentId: string | null;
        items: ReservationItem[];
        createdAt: string;
        updatedAt: string;
    }
    export const RESERVATION_STATUS_TRANSITIONS: Record<ReservationStatus, ReservationStatus[]>;
    export function canTransitionReservation(from: ReservationStatus, to: ReservationStatus): boolean;
    /** expiresAt must be exactly 24 hours after createdAt */
    export function reservationExpiresAtIsValid(reservation: Pick<Reservation, 'createdAt' | 'expiresAt'>): boolean;
    /** status='confirmed' implies confirmedAt is set */
    export function reservationConfirmedImpliesTimestamp(reservation: Pick<Reservation, 'status' | 'confirmedAt'>): boolean;
    /** status='fulfilled' implies fulfilledAt is set and paymentId is set */
    export function reservationFulfilledImpliesTimestampAndPayment(reservation: Pick<Reservation, 'status' | 'fulfilledAt' | 'paymentId'>): boolean;
    /** status='cancelled' implies cancelledAt is set and cancellationReason is set */
    export function reservationCancelledImpliesTimestampAndReason(reservation: Pick<Reservation, 'status' | 'cancelledAt' | 'cancellationReason'>): boolean;
    /** confirmedAt, fulfilledAt, cancelledAt (when present) must be on or after createdAt */
    export function reservationLifecycleTimestampsOnOrAfterCreatedAt(reservation: Pick<Reservation, 'createdAt' | 'confirmedAt' | 'fulfilledAt' | 'cancelledAt'>): boolean;
    /** fulfilledAt and cancelledAt are mutually exclusive */
    export function reservationFulfilledAndCancelledAreMutuallyExclusive(reservation: Pick<Reservation, 'fulfilledAt' | 'cancelledAt'>): boolean;
    export function reservationRequiresItem(reservation: Pick<Reservation, 'items'>): boolean;
}
declare module "_102049_/l1/petShop/layer_2_application/ports/reservationRepository" {
    import type { Reservation, ReservationStatus } from "_102049_/l1/petShop/layer_3_domain/entities/reservation";
    export type ReservationId = string;
    export interface DateRange {
        from: string;
        to: string;
    }
    export interface ReservationFilter {
        status?: ReservationStatus;
    }
    export interface IReservationRepository {
        getById(id: ReservationId): Promise<Reservation>;
        list(filter: ReservationFilter): Promise<Reservation[]>;
        save(reservation: Reservation): Promise<void>;
        listByPeriod(period: DateRange): Promise<Reservation[]>;
        existsById(id: ReservationId): Promise<boolean>;
    }
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/payment" {
    export type PaymentMethod = 'cash' | 'creditCard' | 'debitCard' | 'pix';
    export type PaymentStatus = 'posted' | 'voided';
    export interface Payment {
        paymentId: string;
        reservationId: string;
        amount: number;
        method: PaymentMethod;
        status: PaymentStatus;
        receivedBy: string;
        voidedAt: string | null;
        voidReason: string | null;
        createdAt: string;
    }
    export const PAYMENT_STATUS_TRANSITIONS: Record<PaymentStatus, PaymentStatus[]>;
    export function canTransitionPayment(from: PaymentStatus, to: PaymentStatus): boolean;
}
declare module "_102049_/l1/petShop/layer_2_application/ports/paymentRepository" {
    import type { Payment } from "_102049_/l1/petShop/layer_3_domain/entities/payment";
    /** Domain payment record treated as an immutable payment event in the append-only stream. */
    export type PaymentEvent = Payment;
    export type ReservationId = string;
    export interface DateRange {
        from: string;
        to: string;
    }
    export interface IPaymentRepository {
        /** Append a payment event to the append-only event stream */
        append(record: PaymentEvent): Promise<void>;
        /** Read finder: list payment events for the owning reservation */
        listByOwnerId(ownerId: ReservationId): Promise<PaymentEvent[]>;
        /** Read finder: list payment events that occurred within the given period */
        listByPeriod(period: DateRange): Promise<PaymentEvent[]>;
    }
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/createReservation" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateReservationInput {
        customerName: string;
        customerPhone: string;
        productId: string;
        quantity: number;
    }
    export interface CreateReservationOutputItem {
        productId: string;
        productName: string;
        quantity: number;
    }
    export interface CreateReservationOutput {
        reservationId: string;
        customerName: string;
        customerPhone: string;
        status: string;
        expiresAt: string;
        createdAt: string;
        items: CreateReservationOutputItem[];
    }
    export function createReservation(ctx: RequestContext, input: CreateReservationInput): Promise<CreateReservationOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/catalog" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const catalogFeaturedProductsHandler: BffHandler;
    export const catalogBrowseCatalogHandler: BffHandler;
    export const catalogProductDetailsHandler: BffHandler;
    export const catalogReserveProductHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/reservationManagement.defs" {
    export const reservationManagementController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "reservationManagement";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "reservationManagement";
            readonly controllerName: "ReservationManagementController";
            readonly ownerKind: "workspace";
            readonly workspaceId: "reservationManagement";
            readonly actors: readonly ["atendente"];
            readonly allowedScopes: readonly ["petShop:atendente"];
            readonly handlers: readonly [{
                readonly handlerName: "reservationManagementBrowseReservationsQueryHandler";
                readonly command: "browseReservationsQuery";
                readonly bffId: "browseReservationsQuery";
                readonly route: "petShop.reservationManagement.browseReservationsQuery";
                readonly kind: "query";
                readonly usecaseRef: "browseReservations";
                readonly usecaseRefs: readonly ["browseReservations"];
                readonly inputTypeName: "BrowseReservationsInput";
                readonly inputContract: readonly [{
                    readonly inputId: "searchTerm";
                    readonly fieldRef: "";
                    readonly type: "string";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Termo de busca para localizar reserva por nome do cliente, telefone ou número da reserva";
                }, {
                    readonly inputId: "statusFilter";
                    readonly fieldRef: "Reservation.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro de status da reserva (pendente, confirmada, atendida ou cancelada)";
                }, {
                    readonly inputId: "page";
                    readonly fieldRef: "";
                    readonly type: "number";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Número da página para paginação dos resultados";
                }, {
                    readonly inputId: "pageSize";
                    readonly fieldRef: "";
                    readonly type: "number";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Quantidade de reservas por página";
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "reservationId";
                        readonly operationId: "browseReservations";
                        readonly path: readonly ["reservationId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "customerName";
                        readonly operationId: "browseReservations";
                        readonly path: readonly ["customerName"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "customerPhone";
                        readonly operationId: "browseReservations";
                        readonly path: readonly ["customerPhone"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "status";
                        readonly operationId: "browseReservations";
                        readonly path: readonly ["status"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "expiresAt";
                        readonly operationId: "browseReservations";
                        readonly path: readonly ["expiresAt"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "createdAt";
                        readonly operationId: "browseReservations";
                        readonly path: readonly ["createdAt"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "updatedAt";
                        readonly operationId: "browseReservations";
                        readonly path: readonly ["updatedAt"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "reservationManagementUpdateReservationStatusCommandHandler";
                readonly command: "updateReservationStatusCommand";
                readonly bffId: "updateReservationStatusCommand";
                readonly route: "petShop.reservationManagement.updateReservationStatusCommand";
                readonly kind: "command";
                readonly usecaseRef: "updateReservationStatus";
                readonly usecaseRefs: readonly ["updateReservationStatus"];
                readonly inputTypeName: "UpdateReservationStatusInput";
                readonly inputContract: readonly [{
                    readonly inputId: "reservationId";
                    readonly fieldRef: "Reservation.reservationId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identificador da reserva a ser atualizada";
                }, {
                    readonly inputId: "newStatus";
                    readonly fieldRef: "Reservation.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Novo status da reserva: confirmed, fulfilled ou cancelled";
                }, {
                    readonly inputId: "cancellationReason";
                    readonly fieldRef: "Reservation.cancellationReason";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Motivo do cancelamento, obrigatório apenas quando o novo status for cancelled";
                }, {
                    readonly inputId: "paymentId";
                    readonly fieldRef: "Reservation.paymentId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Referência ao pagamento presencial associado, obrigatório apenas quando o novo status for fulfilled";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "reservationId";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["reservationId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "customerName";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["customerName"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "customerPhone";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["customerPhone"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "expiresAt";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["expiresAt"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "confirmedAt";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["confirmedAt"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "fulfilledAt";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["fulfilledAt"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "cancelledAt";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["cancelledAt"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "cancellationReason";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["cancellationReason"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "paymentId";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["paymentId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "updatedAt";
                        readonly operationId: "updateReservationStatus";
                        readonly path: readonly ["updatedAt"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "reservationManagementProcessPaymentCommandHandler";
                readonly command: "processPaymentCommand";
                readonly bffId: "processPaymentCommand";
                readonly route: "petShop.reservationManagement.processPaymentCommand";
                readonly kind: "command";
                readonly usecaseRef: "processPayment";
                readonly usecaseRefs: readonly ["processPayment"];
                readonly inputTypeName: "ProcessPaymentInput";
                readonly inputContract: readonly [{
                    readonly inputId: "reservationId";
                    readonly fieldRef: "Payment.reservationId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Reserva atualmente selecionada pelo atendente na tela de retirada, associada a este pagamento presencial";
                }, {
                    readonly inputId: "method";
                    readonly fieldRef: "Payment.method";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Método de pagamento escolhido pelo cliente na loja: dinheiro, cartão de crédito, cartão de débito ou pix";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "paymentId";
                        readonly operationId: "processPayment";
                        readonly path: readonly ["paymentId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "reservationId";
                        readonly operationId: "processPayment";
                        readonly path: readonly ["reservationId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "amount";
                        readonly operationId: "processPayment";
                        readonly path: readonly ["amount"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "method";
                        readonly operationId: "processPayment";
                        readonly path: readonly ["method"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "processPayment";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "receivedBy";
                        readonly operationId: "processPayment";
                        readonly path: readonly ["receivedBy"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "createdAt";
                        readonly operationId: "processPayment";
                        readonly path: readonly ["createdAt"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "reservationStatus";
                        readonly operationId: "processPayment";
                        readonly path: readonly ["reservationStatus"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }];
            readonly routes: readonly [{
                readonly key: "petShop.reservationManagement.browseReservationsQuery";
                readonly handlerName: "reservationManagementBrowseReservationsQueryHandler";
            }, {
                readonly key: "petShop.reservationManagement.updateReservationStatusCommand";
                readonly handlerName: "reservationManagementUpdateReservationStatusCommandHandler";
            }, {
                readonly key: "petShop.reservationManagement.processPaymentCommand";
                readonly handlerName: "reservationManagementProcessPaymentCommandHandler";
            }];
        };
    };
    export default reservationManagementController;
    export const pipeline: readonly [{
        readonly id: "reservationManagement__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/reservationManagement.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/reservationManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/usecases/browseReservations.d.ts", "_102049_/l4/petShop/contracts/reservationManagement.browseReservationsQuery.defs.ts", "_102049_/l1/petShop/layer_2_application/usecases/updateReservationStatus.d.ts", "_102049_/l4/petShop/contracts/reservationManagement.updateReservationStatusCommand.defs.ts", "_102049_/l1/petShop/layer_2_application/usecases/processPayment.d.ts", "_102049_/l4/petShop/contracts/reservationManagement.processPaymentCommand.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseReservations" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseReservationsInput {
        searchTerm?: string;
        statusFilter?: string;
        page?: number;
        pageSize?: number;
    }
    export interface BrowseReservationsItem {
        reservationId: string;
        customerName: string;
        customerPhone: string;
        status: string;
        expiresAt: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface BrowseReservationsOutput {
        items: BrowseReservationsItem[];
    }
    export function browseReservations(ctx: RequestContext, input: BrowseReservationsInput): Promise<BrowseReservationsOutput>;
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/updateReservationStatus" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateReservationStatusInput {
        reservationId: string;
        newStatus: string;
        cancellationReason?: string;
        paymentId?: string;
    }
    export interface UpdateReservationStatusOutput {
        reservationId: string;
        customerName: string;
        customerPhone: string;
        status: string;
        expiresAt: string;
        confirmedAt?: string;
        fulfilledAt?: string;
        cancelledAt?: string;
        cancellationReason?: string;
        paymentId?: string;
        updatedAt: string;
    }
    export function updateReservationStatus(ctx: RequestContext, input: UpdateReservationStatusInput): Promise<UpdateReservationStatusOutput>;
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/processPayment" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ProcessPaymentInput {
        reservationId: string;
        method: string;
    }
    export interface ProcessPaymentOutput {
        paymentId: string;
        reservationId: string;
        amount: number;
        method: string;
        status: string;
        receivedBy: string;
        createdAt: string;
        reservationStatus: string;
    }
    export function processPayment(ctx: RequestContext, input: ProcessPaymentInput): Promise<ProcessPaymentOutput>;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/http/controllers/reservationManagement" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const reservationManagementBrowseReservationsQueryHandler: BffHandler;
    export const reservationManagementUpdateReservationStatusCommandHandler: BffHandler;
    export const reservationManagementProcessPaymentCommandHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/payment.defs" {
    export const paymentTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Payment";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Payment";
            readonly tableName: "payment";
            readonly columns: readonly [{
                readonly name: "payment_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK";
            }, {
                readonly name: "reservation_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "owner FK";
            }, {
                readonly name: "method";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "payment method";
            }, {
                readonly name: "status";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamptz";
                readonly nullable: false;
                readonly description: "ordering timestamp";
            }];
            readonly primaryKey: readonly ["payment_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_payment_reservation_id";
                readonly columns: readonly ["reservation_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_method";
                readonly columns: readonly ["method"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_payment_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
            readonly appendOnly: true;
            readonly purpose: "controle";
            readonly retentionDays: 365;
        };
    };
    export default paymentTableDefinition;
    export const pipeline: readonly [{
        readonly id: "payment__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/payment.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/payment.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/payment" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const paymentTableDef: TableDefinition;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/paymentRepositoryAdapter.defs" {
    export const paymentRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "PaymentRepositoryAdapter";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "PaymentRepository";
            readonly entityId: "Payment";
            readonly portRef: "IPaymentRepository";
            readonly tableRef: "payments";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns: payment_id, reservation_id, method, status, created_at", "Details JSONB fields: amount, receivedBy, voidedAt, voidReason", "Append-only event adapter: append (insert one row) plus read finders; no update/delete", "No MDM refs; local table accessed via ctx.data.moduleData"];
        };
    };
    export default paymentRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "paymentRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/paymentRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/paymentRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/paymentRepository.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/persistence/payment.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/paymentRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IPaymentRepository } from "_102049_/l1/petShop/layer_2_application/ports/paymentRepository";
    export function createPaymentRepositoryAdapter(ctx: RequestContext): IPaymentRepository;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservationRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IReservationRepository } from "_102049_/l1/petShop/layer_2_application/ports/reservationRepository";
    export function createReservationRepositoryAdapter(ctx: RequestContext): IReservationRepository;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/registerRepositories" { }
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservation.defs" {
    export const reservationTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Reservation";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Reservation";
            readonly tableName: "reservation";
            readonly columns: readonly [{
                readonly name: "reservation_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "PK";
            }, {
                readonly name: "status";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "payment_id";
                readonly type: "uuid";
                readonly nullable: true;
                readonly description: "FK payment";
            }, {
                readonly name: "created_at";
                readonly type: "timestamptz";
                readonly nullable: false;
                readonly description: "ordering timestamp";
            }];
            readonly primaryKey: readonly ["reservation_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_reservation_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_reservation_payment_id";
                readonly columns: readonly ["payment_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_reservation_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["ReservationItem"];
            };
            readonly purpose: "reservation aggregate";
        };
    };
    export default reservationTableDefinition;
    export const pipeline: readonly [{
        readonly id: "reservation__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservation.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservation.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservation" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const reservationTableDef: TableDefinition;
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservationRepositoryAdapter.defs" {
    export const reservationRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ReservationRepositoryAdapter";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ReservationRepository";
            readonly entityId: "Reservation";
            readonly portRef: "IReservationRepository";
            readonly tableRef: "reservations";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns: reservation_id, status, payment_id, created_at", "Details JSONB fields: customerName, customerPhone, expiresAt, confirmedAt, fulfilledAt, cancelledAt, cancellationReason, updatedAt", "Embedded member ReservationItem stored inside details JSONB as items array", "No MDM refs; local table accessed via ctx.data.moduleData"];
        };
    };
    export default reservationRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "reservationRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservationRepositoryAdapter.ts";
        readonly defPath: "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservationRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/reservationRepository.d.ts", "_102049_/l1/petShop/layer_1_external/adapters/persistence/reservation.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_1_external/adapters/persistence/seeds" {
    import type { TableSeedRows } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const mdmEntityIndexSeeds: TableSeedRows;
    export const mdmDocumentSeeds: TableSeedRows;
}
declare module "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.defs" {
    export const paymentRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "PaymentRepository";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Payment";
            readonly interfaceName: "IPaymentRepository";
            readonly methods: readonly [{
                readonly name: "append";
                readonly params: readonly ["record: PaymentEvent"];
                readonly returns: "void";
                readonly description: "Append a payment event to the append-only event stream";
            }, {
                readonly name: "listByOwnerId";
                readonly params: readonly ["ownerId: ReservationId"];
                readonly returns: "List<PaymentEvent>";
                readonly description: "Read finder: list payment events for the owning reservation";
            }, {
                readonly name: "listByPeriod";
                readonly params: readonly ["period: DateRange"];
                readonly returns: "List<PaymentEvent>";
                readonly description: "Read finder: list payment events that occurred within the given period";
            }];
        };
    };
    export default paymentRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "paymentRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/ports/reservationRepository.defs" {
    export const reservationRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ReservationRepository";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Reservation";
            readonly interfaceName: "IReservationRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: ReservationId"];
                readonly returns: "Reservation";
                readonly description: "Retrieve a reservation by its unique identifier";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: ReservationFilter"];
                readonly returns: "List<Reservation>";
                readonly description: "List reservations matching the given domain filter";
            }, {
                readonly name: "save";
                readonly params: readonly ["reservation: Reservation"];
                readonly returns: "void";
                readonly description: "Persist the reservation aggregate root and its embedded items";
            }, {
                readonly name: "listByPeriod";
                readonly params: readonly ["period: DateRange"];
                readonly returns: "List<Reservation>";
                readonly description: "Domain finder: list reservations that fall within the given period";
            }, {
                readonly name: "existsById";
                readonly params: readonly ["id: ReservationId"];
                readonly returns: "boolean";
                readonly description: "Domain finder: verify whether a reservation exists";
            }];
        };
    };
    export default reservationRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "reservationRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/ports/reservationRepository.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/ports/reservationRepository.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseFeaturedProducts.defs" {
    export const browseFeaturedProductsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseFeaturedProducts";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseFeaturedProducts";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "browseFeaturedProducts";
                readonly inputTypeName: "BrowseFeaturedProductsInput";
                readonly outputTypeName: "BrowseFeaturedProductsOutput";
                readonly input: readonly [{
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly fieldRef: "Product.categoryId";
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly fieldRef: "Product.petTypeId";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Product";
                    readonly fieldRef: "Product.name";
                }, {
                    readonly name: "priceMin";
                    readonly type: "number";
                    readonly required: false;
                    readonly fieldRef: "Product.price";
                }, {
                    readonly name: "priceMax";
                    readonly type: "number";
                    readonly required: false;
                    readonly fieldRef: "Product.price";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "isFeatured";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["featuredProductsOnly", "featuredOrderFlexible", "combinedFilters", "caseInsensitiveSearch"];
                readonly transactional: false;
                readonly steps: readonly ["list Product records via ctx.mdm.collection.listByType({ type: 'Product' })", "apply featuredProductsOnly: keep only products where isFeatured === true", "apply combinedFilters: when categoryId provided, filter by Product.categoryId; when petTypeId provided, filter by Product.petTypeId; when priceMin provided, keep price >= priceMin; when priceMax provided, keep price <= priceMax — all active filters combine with AND", "apply caseInsensitiveSearch: when name provided, keep products whose name includes the term case-insensitively", "apply featuredOrderFlexible: preserve a stable flexible order suitable for a featured showcase (no rigid sort required beyond featured set)", "apply optional pagination with page/pageSize when provided", "project each item to outputShape fields: productId, name, price, isFeatured, categoryId, petTypeId", "return the projected list"];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "productId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.productId";
                    }, {
                        readonly name: "name";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.name";
                    }, {
                        readonly name: "price";
                        readonly type: "number";
                        readonly required: true;
                        readonly fieldRef: "Product.price";
                    }, {
                        readonly name: "isFeatured";
                        readonly type: "boolean";
                        readonly required: true;
                        readonly fieldRef: "Product.isFeatured";
                    }, {
                        readonly name: "categoryId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.categoryId";
                    }, {
                        readonly name: "petTypeId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.petTypeId";
                    }];
                };
            }];
            readonly rulesApplied: readonly ["featuredProductsOnly", "featuredOrderFlexible", "combinedFilters", "caseInsensitiveSearch"];
            readonly mdmRefs: readonly ["Product"];
        };
    };
    export default browseFeaturedProductsUsecase;
    export const pipeline: readonly [{
        readonly id: "browseFeaturedProducts__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/browseFeaturedProducts.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/browseFeaturedProducts.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["featuredProductsOnly", "featuredOrderFlexible", "combinedFilters", "caseInsensitiveSearch"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseProducts.defs" {
    export const browseProductsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseProducts";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseProducts";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "browseProducts";
                readonly inputTypeName: "BrowseProductsInput";
                readonly outputTypeName: "BrowseProductsOutput";
                readonly input: readonly [{
                    readonly name: "searchName";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "minPrice";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "maxPrice";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "items";
                    readonly type: "array";
                    readonly required: true;
                }, {
                    readonly name: "total";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: true;
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["catalogShowsAll", "combinedFilters", "caseInsensitiveSearch"];
                readonly transactional: false;
                readonly steps: readonly ["default page to 1 and pageSize to a sensible page size when omitted", "list all Product records via ctx.mdm.collection.listByType (catalogShowsAll: do not filter by isFeatured)", "apply combinedFilters in memory: optional petTypeId equality, optional categoryId equality, optional minPrice/maxPrice numeric range on price (parse string inputs), optional searchName case-insensitive partial match on name (caseInsensitiveSearch)", "collect distinct categoryId and petTypeId from the filtered set; bulk-load ProductCategory and PetType via ctx.mdm.collection.getMany (plural-first, no per-item get)", "map each product to the output item shape joining categoryName and petTypeName from the hydrated MDM maps", "compute total as filtered length; slice items by page/pageSize; return { items, total, page, pageSize }"];
                readonly outputShape: {
                    readonly kind: "paginated";
                    readonly fields: readonly [{
                        readonly name: "items";
                        readonly type: "array";
                        readonly required: true;
                        readonly item: {
                            readonly fields: readonly [{
                                readonly name: "productId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.productId";
                            }, {
                                readonly name: "name";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.name";
                            }, {
                                readonly name: "price";
                                readonly type: "number";
                                readonly required: true;
                                readonly fieldRef: "Product.price";
                            }, {
                                readonly name: "isFeatured";
                                readonly type: "boolean";
                                readonly required: true;
                                readonly fieldRef: "Product.isFeatured";
                            }, {
                                readonly name: "categoryId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.categoryId";
                            }, {
                                readonly name: "categoryName";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "ProductCategory.name";
                            }, {
                                readonly name: "petTypeId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.petTypeId";
                            }, {
                                readonly name: "petTypeName";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "PetType.name";
                            }, {
                                readonly name: "createdAt";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.createdAt";
                            }, {
                                readonly name: "updatedAt";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.updatedAt";
                            }];
                        };
                    }, {
                        readonly name: "total";
                        readonly type: "number";
                        readonly required: true;
                    }, {
                        readonly name: "page";
                        readonly type: "number";
                        readonly required: true;
                    }, {
                        readonly name: "pageSize";
                        readonly type: "number";
                        readonly required: true;
                    }];
                };
            }];
            readonly rulesApplied: readonly ["catalogShowsAll", "combinedFilters", "caseInsensitiveSearch"];
            readonly mdmRefs: readonly ["Product", "ProductCategory", "PetType"];
        };
    };
    export default browseProductsUsecase;
    export const pipeline: readonly [{
        readonly id: "browseProducts__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/browseProducts.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/browseProducts.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["catalogShowsAll", "combinedFilters", "caseInsensitiveSearch"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/browseReservations.defs" {
    export const browseReservationsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseReservations";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseReservations";
            readonly ports: readonly ["Reservation", "Payment"];
            readonly functions: readonly [{
                readonly functionName: "browseReservations";
                readonly inputTypeName: "BrowseReservationsInput";
                readonly outputTypeName: "BrowseReservationsOutput";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "statusFilter";
                    readonly type: "string";
                    readonly required: false;
                    readonly fieldRef: "Reservation.status";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "customerPhone";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "expiresAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }];
                readonly ports: readonly ["Reservation"];
                readonly rulesApplied: readonly ["reservationStatuses", "reservationValidity24h"];
                readonly transactional: false;
                readonly steps: readonly ["Resolve actorId from ctx.sessionContext (actorSession) for audit context only; do not require it as input", "Load reservations via Reservation port (resolveRepository)", "Inline reservationStatuses: keep only items whose status is one of pending|confirmed|fulfilled|cancelled; if statusFilter is provided, validate it is one of those values (else validation error with rule id reservationStatuses) and retain only matching status", "When searchTerm is provided, filter where customerName, customerPhone or reservationId contains the term (case-insensitive)", "Inline reservationValidity24h: for each pending reservation, ensure expiresAt reflects createdAt + 24h (surface the stored expiresAt; do not invent a different validity window)", "Sort by createdAt descending", "Apply optional page/pageSize pagination", "Project each item to reservationId, customerName, customerPhone, status, expiresAt, createdAt, updatedAt and return the list"];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "reservationId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.reservationId";
                    }, {
                        readonly name: "customerName";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.customerName";
                    }, {
                        readonly name: "customerPhone";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.customerPhone";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.status";
                    }, {
                        readonly name: "expiresAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.expiresAt";
                    }, {
                        readonly name: "createdAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.createdAt";
                    }, {
                        readonly name: "updatedAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.updatedAt";
                    }];
                };
            }];
            readonly rulesApplied: readonly ["reservationStatuses", "reservationValidity24h"];
            readonly mdmRefs: readonly [];
        };
    };
    export default browseReservationsUsecase;
    export const pipeline: readonly [{
        readonly id: "browseReservations__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/browseReservations.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/browseReservations.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/reservationRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["reservationStatuses", "reservationValidity24h"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/createReservation.defs" {
    export const createReservationUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createReservation";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createReservation";
            readonly ports: readonly ["Reservation", "Payment"];
            readonly functions: readonly [{
                readonly functionName: "createReservation";
                readonly inputTypeName: "CreateReservationInput";
                readonly outputTypeName: "CreateReservationOutput";
                readonly input: readonly [{
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                    readonly fieldRef: "Reservation.customerName";
                }, {
                    readonly name: "customerPhone";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                    readonly fieldRef: "Reservation.customerPhone";
                }, {
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly fieldRef: "Product.productId";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "customerPhone";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "expiresAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "items";
                    readonly type: "array";
                    readonly required: true;
                }];
                readonly ports: readonly ["Reservation", "Payment"];
                readonly rulesApplied: readonly ["reservationRequiresContact", "reservationValidity24h", "reservationStatuses"];
                readonly transactional: true;
                readonly steps: readonly ["Validate reservationRequiresContact: customerName and customerPhone are non-empty after trim; reject with rule id if missing", "Validate quantity is a positive number; reject if invalid", "Load Product by productId via ctx.mdm.entity.get({ mdmId: productId }); reject if not found", "Generate reservationId via ctx.idGenerator and now via ctx.clock", "Apply reservationValidity24h: set expiresAt = now + 24 hours; set createdAt and updatedAt = now", "Apply reservationStatuses: set initial status to 'pending'", "Build Reservation aggregate with customerName, customerPhone, status pending, expiresAt, timestamps, and embedded ReservationItem (reservationItemId from ctx.idGenerator, productId, quantity, timestamps)", "Inside ctx.data.transaction: save Reservation via Reservation port; build and append audit Payment event record via Payment port (append-only, same tx)", "Return reservationId, customerName, customerPhone, status, expiresAt, createdAt, and items [{ productId, productName from MDM Product.name, quantity }]"];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "reservationId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.reservationId";
                    }, {
                        readonly name: "customerName";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.customerName";
                    }, {
                        readonly name: "customerPhone";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.customerPhone";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.status";
                    }, {
                        readonly name: "expiresAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.expiresAt";
                    }, {
                        readonly name: "createdAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.createdAt";
                    }, {
                        readonly name: "items";
                        readonly type: "array";
                        readonly required: true;
                        readonly item: {
                            readonly fields: readonly [{
                                readonly name: "productId";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.productId";
                            }, {
                                readonly name: "productName";
                                readonly type: "string";
                                readonly required: true;
                                readonly fieldRef: "Product.name";
                            }, {
                                readonly name: "quantity";
                                readonly type: "number";
                                readonly required: true;
                                readonly fieldRef: "ReservationItem.quantity";
                            }];
                        };
                    }];
                };
            }];
            readonly rulesApplied: readonly ["reservationRequiresContact", "reservationValidity24h", "reservationStatuses"];
            readonly mdmRefs: readonly ["Product"];
        };
    };
    export default createReservationUsecase;
    export const pipeline: readonly [{
        readonly id: "createReservation__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/createReservation.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/createReservation.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/reservationRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["reservationRequiresContact", "reservationValidity24h", "reservationStatuses"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/processPayment.defs" {
    export const processPaymentUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "processPayment";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "processPayment";
            readonly ports: readonly ["Reservation", "Payment"];
            readonly functions: readonly [{
                readonly functionName: "processPayment";
                readonly inputTypeName: "ProcessPaymentInput";
                readonly outputTypeName: "ProcessPaymentOutput";
                readonly input: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                    readonly fieldRef: "Payment.reservationId";
                }, {
                    readonly name: "method";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                    readonly fieldRef: "Payment.method";
                }];
                readonly output: readonly [{
                    readonly name: "paymentId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                }, {
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                }, {
                    readonly name: "amount";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                }, {
                    readonly name: "method";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                }, {
                    readonly name: "receivedBy";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Payment";
                }, {
                    readonly name: "reservationStatus";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly ports: readonly ["Reservation", "Payment"];
                readonly rulesApplied: readonly ["inStorePaymentOnly", "totalFromPricesAndQuantities", "paymentRequiresReceipt"];
                readonly transactional: true;
                readonly steps: readonly ["Validate method is one of cash|creditCard|debitCard|pix (inStorePaymentOnly); reject otherwise with rule id in error details", "Resolve receivedBy from ctx.sessionContext.actorId (actorSession); reject if missing (paymentRequiresReceipt — presencial confirmation by logged attendant)", "Load Reservation by input.reservationId via Reservation port; reject if not found", "Validate reservation.status is confirmed (eligible for in-store payment/fulfillment); reject if already fulfilled/cancelled/pending", "Read embedded ReservationItem collection from the loaded reservation (parent aggregate); collect productIds", "Bulk-load Product MDM records via ctx.mdm.collection.getMany({ mdmIds: productIds })", "Compute amount = sum(item.quantity * product.price) for all items (totalFromPricesAndQuantities); reject if no items or any product missing price", "Generate paymentId via ctx.idGenerator and createdAt via ctx.clock; set status to posted", "Inside ctx.data transaction: append Payment audit event { paymentId, reservationId, amount, method, status: posted, receivedBy, createdAt } via Payment port; mutate reservation status to fulfilled, set paymentId, fulfilledAt=now, updatedAt=now; save Reservation via Reservation port", "Return paymentId, reservationId, amount, method, status, receivedBy, createdAt, reservationStatus (fulfilled)"];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "paymentId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Payment.paymentId";
                    }, {
                        readonly name: "reservationId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Payment.reservationId";
                    }, {
                        readonly name: "amount";
                        readonly type: "number";
                        readonly required: true;
                        readonly fieldRef: "Payment.amount";
                    }, {
                        readonly name: "method";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Payment.method";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Payment.status";
                    }, {
                        readonly name: "receivedBy";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Payment.receivedBy";
                    }, {
                        readonly name: "createdAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Payment.createdAt";
                    }, {
                        readonly name: "reservationStatus";
                        readonly type: "string";
                        readonly required: true;
                    }];
                };
            }];
            readonly rulesApplied: readonly ["inStorePaymentOnly", "totalFromPricesAndQuantities", "paymentRequiresReceipt"];
            readonly mdmRefs: readonly ["Product"];
        };
    };
    export default processPaymentUsecase;
    export const pipeline: readonly [{
        readonly id: "processPayment__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/processPayment.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/processPayment.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/reservationRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["inStorePaymentOnly", "totalFromPricesAndQuantities", "paymentRequiresReceipt"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/updateReservationStatus.defs" {
    export const updateReservationStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateReservationStatus";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateReservationStatus";
            readonly ports: readonly ["Reservation", "Payment"];
            readonly functions: readonly [{
                readonly functionName: "updateReservationStatus";
                readonly inputTypeName: "UpdateReservationStatusInput";
                readonly outputTypeName: "UpdateReservationStatusOutput";
                readonly input: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                    readonly fieldRef: "Reservation.reservationId";
                }, {
                    readonly name: "newStatus";
                    readonly type: "string";
                    readonly required: true;
                    readonly fieldRef: "Reservation.status";
                }, {
                    readonly name: "cancellationReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                    readonly fieldRef: "Reservation.cancellationReason";
                }, {
                    readonly name: "paymentId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                    readonly fieldRef: "Reservation.paymentId";
                }];
                readonly output: readonly [{
                    readonly name: "reservationId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "customerPhone";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "expiresAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "confirmedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "fulfilledAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "cancelledAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "cancellationReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "paymentId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Reservation";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Reservation";
                }];
                readonly ports: readonly ["Reservation", "Payment"];
                readonly rulesApplied: readonly ["reservationStatuses", "reservationValidity24h"];
                readonly transactional: true;
                readonly steps: readonly ["resolve Reservation port and load reservation by input.reservationId; fail if not found", "apply reservationStatuses inline: newStatus must be one of pending|confirmed|fulfilled|cancelled; allow only valid transitions from current status (pending->confirmed|cancelled, confirmed->fulfilled|cancelled); include rule id in validation error details when blocked", "when newStatus is cancelled, require cancellationReason; when newStatus is fulfilled, require paymentId; otherwise reject with rule-aware validation error", "apply reservationValidity24h inline: if reservation.expiresAt is before ctx.clock.now(), only cancellation is allowed (attendant may cancel expired reservations); block confirm/fulfill of expired reservations with rule id in error details", "inside ctx.data transaction: set status to newStatus; set confirmedAt/fulfilledAt/cancelledAt from ctx.clock.now() according to the target status; set cancellationReason when cancelling; set paymentId when fulfilling; always set updatedAt to ctx.clock.now()", "save Reservation aggregate via Reservation port", "when transitioning to fulfilled with paymentId, build append-only Payment audit event record and append via Payment port in the same transaction (never update/delete)", "return outputShape fields from the updated Reservation"];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "reservationId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.reservationId";
                    }, {
                        readonly name: "customerName";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.customerName";
                    }, {
                        readonly name: "customerPhone";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.customerPhone";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.status";
                    }, {
                        readonly name: "expiresAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.expiresAt";
                    }, {
                        readonly name: "confirmedAt";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.confirmedAt";
                    }, {
                        readonly name: "fulfilledAt";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.fulfilledAt";
                    }, {
                        readonly name: "cancelledAt";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.cancelledAt";
                    }, {
                        readonly name: "cancellationReason";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.cancellationReason";
                    }, {
                        readonly name: "paymentId";
                        readonly type: "string";
                        readonly required: false;
                        readonly fieldRef: "Reservation.paymentId";
                    }, {
                        readonly name: "updatedAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Reservation.updatedAt";
                    }];
                };
            }];
            readonly rulesApplied: readonly ["reservationStatuses", "reservationValidity24h"];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateReservationStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateReservationStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/updateReservationStatus.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/updateReservationStatus.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l1/petShop/layer_2_application/ports/reservationRepository.d.ts", "_102049_/l1/petShop/layer_2_application/ports/paymentRepository.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/reservation.d.ts", "_102049_/l1/petShop/layer_3_domain/entities/payment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["reservationStatuses", "reservationValidity24h"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_2_application/usecases/viewProductDetails.defs" {
    export const viewProductDetailsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewProductDetails";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewProductDetails";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "viewProductDetails";
                readonly inputTypeName: "ViewProductDetailsInput";
                readonly outputTypeName: "ViewProductDetailsOutput";
                readonly input: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                    readonly fieldRef: "Product.productId";
                }];
                readonly output: readonly [{
                    readonly name: "productId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "isFeatured";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "categoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "categoryName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ProductCategory";
                }, {
                    readonly name: "petTypeId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "petTypeName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "PetType";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Product";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Load Product by input.productId via ctx.mdm.entity.get({ mdmId: productId })", "If product is not found, return not-found error indicating produto não encontrado", "Collect categoryId and petTypeId from the product; bulk-read ProductCategory and PetType via ctx.mdm.collection.getMany({ mdmIds: [categoryId, petTypeId] })", "Resolve categoryName from the ProductCategory record and petTypeName from the PetType record", "Return productId, name, price, isFeatured, categoryId, categoryName, petTypeId, petTypeName, createdAt, updatedAt"];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "productId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.productId";
                    }, {
                        readonly name: "name";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.name";
                    }, {
                        readonly name: "price";
                        readonly type: "number";
                        readonly required: true;
                        readonly fieldRef: "Product.price";
                    }, {
                        readonly name: "isFeatured";
                        readonly type: "boolean";
                        readonly required: true;
                        readonly fieldRef: "Product.isFeatured";
                    }, {
                        readonly name: "categoryId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.categoryId";
                    }, {
                        readonly name: "categoryName";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "ProductCategory.name";
                    }, {
                        readonly name: "petTypeId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.petTypeId";
                    }, {
                        readonly name: "petTypeName";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "PetType.name";
                    }, {
                        readonly name: "createdAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.createdAt";
                    }, {
                        readonly name: "updatedAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.updatedAt";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Product", "ProductCategory", "PetType"];
        };
    };
    export default viewProductDetailsUsecase;
    export const pipeline: readonly [{
        readonly id: "viewProductDetails__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102049_/l1/petShop/layer_2_application/usecases/viewProductDetails.ts";
        readonly defPath: "_102049_/l1/petShop/layer_2_application/usecases/viewProductDetails.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/payment.defs" {
    export const paymentDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Payment";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Payment";
            readonly title: "Payment";
            readonly fields: readonly [{
                readonly fieldId: "paymentId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do registro de pagamento.";
            }, {
                readonly fieldId: "reservationId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência à reserva associada a este pagamento presencial.";
            }, {
                readonly fieldId: "amount";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor total recebido, calculado a partir dos preços dos produtos e quantidades reservadas.";
            }, {
                readonly fieldId: "method";
                readonly type: "string";
                readonly required: true;
                readonly description: "Método de pagamento utilizado pelo cliente na loja.";
                readonly enum: readonly ["cash", "creditCard", "debitCard", "pix"];
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação atual do registro de pagamento.";
                readonly enum: readonly ["posted", "voided"];
            }, {
                readonly fieldId: "receivedBy";
                readonly type: "string";
                readonly required: true;
                readonly description: "Identificador do atendente que confirmou o recebimento do pagamento.";
            }, {
                readonly fieldId: "voidedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que o pagamento foi cancelado ou estornado.";
            }, {
                readonly fieldId: "voidReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo do cancelamento ou estorno do pagamento.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora em que o pagamento foi registrado no sistema.";
            }];
            readonly invariants: readonly [];
            readonly statusEnum: readonly ["posted", "voided"];
        };
    };
    export default paymentDomainEntity;
    export const pipeline: readonly [{
        readonly id: "payment__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/petShop/layer_3_domain/entities/payment.ts";
        readonly defPath: "_102049_/l1/petShop/layer_3_domain/entities/payment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102049_/l1/petShop/layer_3_domain/entities/reservation.defs" {
    export const reservationDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Reservation";
        readonly moduleName: "petShop";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Reservation";
            readonly title: "Reservation";
            readonly fields: readonly [{
                readonly fieldId: "reservationId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único da reserva";
            }, {
                readonly fieldId: "customerName";
                readonly type: "string";
                readonly required: true;
                readonly description: "Nome do cliente que fez a reserva";
            }, {
                readonly fieldId: "customerPhone";
                readonly type: "string";
                readonly required: true;
                readonly description: "Telefone de contato do cliente";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Status de atendimento da reserva controlado pelo atendente";
                readonly enum: readonly ["pending", "confirmed", "fulfilled", "cancelled"];
            }, {
                readonly fieldId: "expiresAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de validade da reserva, 24 horas após o registro";
            }, {
                readonly fieldId: "confirmedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que a reserva foi confirmada pelo atendente";
            }, {
                readonly fieldId: "fulfilledAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que a reserva foi atendida com retirada e pagamento confirmado";
            }, {
                readonly fieldId: "cancelledAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que a reserva foi cancelada";
            }, {
                readonly fieldId: "cancellationReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo do cancelamento da reserva registrado pelo atendente";
            }, {
                readonly fieldId: "paymentId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Referência ao pagamento presencial associado quando a reserva é atendida";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação da reserva";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização da reserva";
            }];
            readonly valueObjects: readonly [{
                readonly name: "ReservationItem";
                readonly collection: true;
                readonly fields: readonly [{
                    readonly fieldId: "reservationItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único do item de reserva.";
                }, {
                    readonly fieldId: "reservationId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência à reserva à qual este item pertence.";
                }, {
                    readonly fieldId: "productId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao produto do catálogo que foi reservado.";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade do produto reservada pelo cliente.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora de criação do item de reserva.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização do item de reserva.";
                }];
            }];
            readonly invariants: readonly ["expiresAt must be exactly 24 hours after createdAt", "status='confirmed' implies confirmedAt is set", "status='fulfilled' implies fulfilledAt is set and paymentId is set", "status='cancelled' implies cancelledAt is set and cancellationReason is set", "confirmedAt, fulfilledAt, cancelledAt (when present) must be on or after createdAt", "fulfilledAt and cancelledAt are mutually exclusive", "status transitions must be valid: pending -> confirmed|cancelled; confirmed -> fulfilled|cancelled; fulfilled and cancelled are terminal"];
            readonly statusEnum: readonly ["pending", "confirmed", "fulfilled", "cancelled"];
        };
    };
    export default reservationDomainEntity;
    export const pipeline: readonly [{
        readonly id: "reservation__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102049_/l1/petShop/layer_3_domain/entities/reservation.ts";
        readonly defPath: "_102049_/l1/petShop/layer_3_domain/entities/reservation.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 11 color families (base key = `<family>-color`). `grey` has a distinct variant shape. */
    export const MANDATORY_COLOR_FAMILIES: readonly ["text-primary", "text-secondary", "bg-primary", "bg-secondary", "grey", "error", "success", "warning", "info", "active", "link"];
    export type MandatoryColorFamily = typeof MANDATORY_COLOR_FAMILIES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102049_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    /**
     * Design system do projeto — vocabulário de tokens POR PAPEL (role-based).
     * Este vocabulário é o padrão para novos projetos; só os VALORES mudam por marca.
     *
     * Regras de nomenclatura (color):
     *  - O nome diz onde o token é usado; nunca deduza pelo valor.
     *  - Pares bg/text andam juntos: quem usa button-primary-bg escreve o rótulo
     *    com button-primary-text; quem usa status-error-bg usa status-error-text;
     *    nav-bg com nav-text; tooltip-bg com tooltip-text. Vale para todo par
     *    <papel>-bg / <papel>-text.
     *  - Superfícies: page-bg (fundo da página) > surface-bg (cards, painéis,
     *    modais) > surface-alt-bg (linhas zebradas, hover de linha, skeleton,
     *    cabeçalhos de seção). Texto sobre superfícies: text-strong (títulos),
     *    text-default (corpo), text-muted (secundário/placeholder).
     *  - Navegação (sidebar/topbar): nav-bg + nav-text; item ativo usa
     *    nav-active-bg + nav-active-text.
     *  - Overlay de modal: overlay-backdrop-bg atrás, surface-bg no modal.
     *  - Gráficos: séries usam chart-series-1..6 SEMPRE nesta ordem fixa (a ordem
     *    é o mecanismo de segurança para daltonismo — nunca embaralhar nem gerar
     *    cores novas); textos e eixos usam os tokens text-*, nunca a cor da série;
     *    status-* são reservados a estado e nunca viram série de gráfico.
     *  - Todo token base de cor tem as variantes -hover, -focus e -disabled
     *    (em chart-series, -disabled é a série apagada pela legenda).
     *  - Modo noite: cada chave tem par com prefixo _dark- (mesmo nome). O
     *    compilador gera o bloco dark automaticamente; paginas usam so o nome base.
     */
    export const tokens: IDesignSystemTokens[];
}
declare module "_102049_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102049_/l2/petShop/web/contracts/catalog.browseCatalog" {
    export interface BrowseCatalogInput {
        searchName?: string;
        petTypeId?: string;
        categoryId?: string;
        minPrice?: number;
        maxPrice?: number;
        page?: number;
        pageSize?: number;
    }
    export interface BrowseCatalogOutput {
        items: {
            productId: string;
            name: string;
            price: number;
            isFeatured: boolean;
            categoryId: string;
            categoryName: string;
            petTypeId: string;
            petTypeName: string;
            createdAt: string;
            updatedAt: string;
        }[];
        total: number;
        page: number;
        pageSize: number;
    }
    export const browseCatalogRoute: "petShop.catalog.browseCatalog";
}
declare module "_102049_/l2/petShop/web/contracts/catalog.featuredProducts" {
    export interface FeaturedProductsInput {
        categoryId?: string;
        petTypeId?: string;
        name?: string;
        priceMin?: number;
        priceMax?: number;
        page?: number;
        pageSize?: number;
    }
    export interface FeaturedProductsOutput {
        productId: string;
        name: string;
        price: number;
        isFeatured: boolean;
        categoryId: string;
        petTypeId: string;
    }
    export const featuredProductsRoute: "petShop.catalog.featuredProducts";
}
declare module "_102049_/l2/petShop/web/contracts/catalog.productDetails" {
    export interface ProductDetailsInput {
        productId: string;
    }
    export interface ProductDetailsOutput {
        productId: string;
        name: string;
        price: number;
        isFeatured: boolean;
        categoryId: string;
        categoryName: string;
        petTypeId: string;
        petTypeName: string;
        createdAt: string;
        updatedAt: string;
    }
    export const productDetailsRoute: "petShop.catalog.productDetails";
}
declare module "_102049_/l2/petShop/web/contracts/catalog.reserveProduct" {
    export interface ReserveProductInput {
        customerName: string;
        customerPhone: string;
        productId: string;
        quantity: number;
    }
    export interface ReserveProductOutput {
        reservationId: string;
        customerName: string;
        customerPhone: string;
        status: string;
        expiresAt: string;
        createdAt: string;
        items: {
            productId: string;
            productName: string;
            quantity: number;
        }[];
    }
    export const reserveProductRoute: "petShop.catalog.reserveProduct";
}
declare module "_102049_/l2/petShop/web/contracts/reservationManagement.browseReservationsQuery" {
    export interface BrowseReservationsQueryInput {
        searchTerm?: string;
        statusFilter?: string;
        page?: number;
        pageSize?: number;
    }
    export interface BrowseReservationsQueryOutput {
        reservationId: string;
        customerName: string;
        customerPhone: string;
        status: string;
        expiresAt: string;
        createdAt: string;
        updatedAt: string;
    }
    export const browseReservationsQueryRoute: "petShop.reservationManagement.browseReservationsQuery";
}
declare module "_102049_/l2/petShop/web/contracts/reservationManagement.processPaymentCommand" {
    export interface ProcessPaymentCommandInput {
        reservationId: string;
        method: string;
    }
    export interface ProcessPaymentCommandOutput {
        paymentId: string;
        reservationId: string;
        amount: number;
        method: string;
        status: string;
        receivedBy: string;
        createdAt: string;
        reservationStatus: string;
    }
    export const processPaymentCommandRoute: "petShop.reservationManagement.processPaymentCommand";
}
declare module "_102049_/l2/petShop/web/contracts/reservationManagement.updateReservationStatusCommand" {
    export interface UpdateReservationStatusCommandInput {
        reservationId: string;
        newStatus: string;
        cancellationReason?: string;
        paymentId?: string;
    }
    export interface UpdateReservationStatusCommandOutput {
        reservationId: string;
        customerName: string;
        customerPhone: string;
        status: string;
        expiresAt: string;
        confirmedAt: string;
        fulfilledAt: string;
        cancelledAt: string;
        cancellationReason: string;
        paymentId: string;
        updatedAt: string;
    }
    export const updateReservationStatusCommandRoute: "petShop.reservationManagement.updateReservationStatusCommand";
}
declare module "_102049_/l2/petShop/web/desktop/page11/catalog.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        emptyKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        emptyKey: string;
                        fields: any[];
                        columns: any[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                })[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        emptyKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        emptyKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            })[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "catalog__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/catalog.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/catalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/catalog.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["catalog__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Storefront-first, catálogo limpo com busca e filtros, fluxo de reserva simples, UI de gestão do atendente orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/desktop/page11/catalog.test" {
    export const pageTests: {
        readonly moduleName: "petShop";
        readonly page: "catalog";
        readonly variant: "page11";
        readonly cases: readonly [{
            readonly id: "featuredProducts.ok";
            readonly routine: "petShop.catalog.featuredProducts";
            readonly params: {};
            readonly expect: {
                readonly ok: true;
                readonly shape: "array";
                readonly minItems: 1;
            };
        }, {
            readonly id: "browseCatalog.ok";
            readonly routine: "petShop.catalog.browseCatalog";
            readonly params: {};
            readonly expect: {
                readonly ok: true;
                readonly shape: "paginated";
                readonly minItems: 1;
            };
        }, {
            readonly id: "productDetails.ok";
            readonly routine: "petShop.catalog.productDetails";
            readonly params: {
                readonly productId: "<seedRef>";
            };
            readonly expect: {
                readonly ok: true;
                readonly shape: "object";
            };
        }, {
            readonly id: "reserveProduct.ok";
            readonly routine: "petShop.catalog.reserveProduct";
            readonly params: {
                readonly customerName: "<seedRef>";
                readonly customerPhone: "<seedRef>";
                readonly productId: "<seedRef>";
                readonly quantity: "<seedRef>";
            };
            readonly expect: {
                readonly ok: true;
                readonly shape: "object";
            };
            readonly mutating: true;
        }, {
            readonly id: "reserveProduct.customerName.required";
            readonly routine: "petShop.catalog.reserveProduct";
            readonly params: {
                readonly customerPhone: "<seedRef>";
                readonly productId: "<seedRef>";
                readonly quantity: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }, {
            readonly id: "reserveProduct.customerPhone.required";
            readonly routine: "petShop.catalog.reserveProduct";
            readonly params: {
                readonly customerName: "<seedRef>";
                readonly productId: "<seedRef>";
                readonly quantity: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }, {
            readonly id: "reserveProduct.quantity.required";
            readonly routine: "petShop.catalog.reserveProduct";
            readonly params: {
                readonly customerName: "<seedRef>";
                readonly customerPhone: "<seedRef>";
                readonly productId: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }];
    };
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/runtimeConfigTypes" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectFrontendPageConfig {
        pageId: string;
        route: string;
        source: string;
        definition?: string;
        componentTag: string;
        title?: string;
    }
    export interface ProjectModuleFrontendConfig {
        layer?: 'l2' | string;
        moduleEntrypoint?: string;
        moduleSource?: string;
        pages?: ProjectFrontendPageConfig[];
        pageTests?: string[];
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint?: string;
        tableDefsDir?: string;
    }
    export interface ProjectRegionRendererConfig {
        entrypoint: string;
        tag: string;
        source?: string;
    }
    export interface ProjectDynamicRegionConfig {
        renderer: ProjectRegionRendererConfig;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface ProjectShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, ProjectDynamicRegionConfig>;
    }
    export interface ProjectClientShellConfig {
        mode: 'spa' | 'pwa';
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: ProjectShellRegionProfiles;
            aside?: ProjectShellRegionProfiles;
        };
    }
    export interface ProjectNavigationEntry {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        navigation?: ProjectNavigationEntry[];
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        frontend?: ProjectModuleFrontendConfig;
        backendRouter?: string;
        backendControllers?: string;
        backend?: Record<string, unknown>;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        runtime?: ProjectRuntimeMetadata;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface ProjectRuntimeMetadata {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    export interface PublicationTargetConfig {
        assetBaseUrl?: string;
        serveStaticFromServer?: boolean;
        minify?: boolean;
        sourcemap?: boolean;
    }
    export interface PublicationConfig {
        defaultTarget: string;
        targets: Record<string, PublicationTargetConfig>;
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        publication: PublicationConfig;
        clientShell?: ProjectClientShellConfig;
        projects: Record<string, ProjectConfigRecord>;
    }
    /** System modules a production master ships with (e.g. 102034: mdm, monitor, audit).
     *  The publish composer merges this into projects[<runtimeProject>] of the composed
     *  config.json — the master stays self-describing and agnostic to clients. */
    export interface MasterRuntimeManifest {
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    /** Signature written by a change agent: who generated this side of the project. */
    export interface L5MasterSignature {
        /** Studio (dev) project that hosts the agent, e.g. 102020 / 102021. */
        masterProject: number;
        /** Agent folder inside <masterProject>/l2; the publish resolves the composer at
         *  mls-<masterProject>/l2/<agentFolder>/nodejsSaveConfigJson.ts */
        agentFolder: string;
        /** Production master referenced in the composed config.json, e.g. 102033 / 102034. */
        runtimeProject: number;
    }
    export interface L5Masters {
        frontend?: L5MasterSignature;
        backend?: L5MasterSignature;
    }
    export interface L5ModuleBackendConfig {
        backendControllers: string;
        persistence: {
            tableDefsDir: string;
        };
        routeKeys: string[];
    }
    export interface L5Module {
        moduleName: string;
        backend?: L5ModuleBackendConfig;
    }
    export interface L5Dependency {
        projectId: string;
        kind?: string;
    }
    export interface L5Language {
        language: string;
        name?: string;
        path?: string;
    }
    export interface L5Layout {
        name?: string;
        [key: string]: unknown;
    }
    /** Manual customization carried by the client project; composers translate these
     *  fields into the generated config.json instead of hand-editing it (the composed
     *  file is overwritten on every publish). */
    export interface L5RuntimeCustomize {
        clientShell?: ProjectClientShellConfig;
        publication?: PublicationConfig;
        shellTemplates?: {
            spa: string;
            pwa: string;
        };
        navigationLabels?: Record<string, string>;
    }
    export interface L5ProjectJson {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
        orgName?: string;
        designSystems?: Array<Record<string, unknown>>;
        languages?: L5Language[];
        layouts?: Record<string, L5Layout>;
        plugins?: Record<string, unknown>;
        reasons?: Record<string, unknown>;
        services?: unknown[];
        links?: unknown[];
        servicesConfigEnabled?: boolean;
        masters?: L5Masters;
        modules?: L5Module[];
        dependencies?: L5Dependency[];
        customize?: L5RuntimeCustomize;
    }
    export type L4ContextSource = 'userInput' | 'actorSession' | 'businessContext' | 'currentWorkspace' | 'selectedEntity' | 'activeLifecycleInstance' | 'workflowState' | 'routeParam' | 'previousStepOutput' | 'systemDefault';
    export const L4_CONTEXT_ORIGIN_CATALOG: {
        readonly actorSession: readonly ["actorSession.actorId", "actorSession.scope"];
        readonly businessContext: readonly ["businessContext.activeCompanyId", "businessContext.activeUnitId"];
        readonly currentWorkspace: readonly ["currentWorkspace.workspaceId"];
        readonly systemDefault: readonly ["systemDefault.now", "systemDefault.uuid", "systemDefault.locale"];
    };
    export interface L4ContextResolution {
        inputId?: string;
        /** Entity.field, input.<inputId>, filter.<name>, or a catalogued runtime context attribute. */
        targetRef: string;
        source: L4ContextSource;
        originRef: string;
        description: string;
    }
    export type L5GenerationTodoLayer = 'frontend' | 'backend';
    export type L5GenerationTodoStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export type L5GenerationTodoOwnerType = 'workflow' | 'operation';
    export interface L5GenerationTodoOwner {
        ownerType: L5GenerationTodoOwnerType;
        ownerId: string;
        title: string;
        status: L5GenerationTodoStatus;
        defPath: string;
        pageId?: string;
        commandName?: string;
        bffName?: string;
        capabilityId?: string;
    }
    export interface L5GenerationTodo {
        schemaVersion: string;
        moduleName: string;
        layer: L5GenerationTodoLayer;
        updatedAt: string;
        owners: L5GenerationTodoOwner[];
    }
}
declare module "_102029_/l2/contracts/bootstrap" {
    import type { ProjectNavigationEntry } from "_102029_/l2/runtimeConfigTypes";
    export type MasterFrontendShellMode = 'spa' | 'pwa';
    export type MasterFrontendDeviceKind = 'desktop' | 'mobile';
    export type MasterFrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export type Platform = "web" | "mobile";
    export type ISkillConfig = "layer1" | "layer2" | "layer3" | "layer4" | "contract" | "architecture" | "definition";
    export type PathConfig = {
        sharedPath: string;
        sharedSkill: string;
    };
    export type ISkill = Partial<Record<ISkillConfig, {
        skillPath: string[];
    }>>;
    export type IPaths = Partial<Record<Platform, PathConfig>>;
    export interface IGenomeConfig {
        device: MasterFrontendDeviceKind;
        designSystem: string;
        layout: string;
    }
    export interface MasterFrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export type MasterFrontendRegionName = 'header' | 'aside' | 'content';
    export interface MasterFrontendLayoutConfig {
        regions: {
            desktop: MasterFrontendRegionVisibility;
            mobile: MasterFrontendRegionVisibility;
        };
        asideMode: {
            desktop: MasterFrontendAsideMode;
            mobile: MasterFrontendAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface MasterFrontendRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export interface MasterFrontendDynamicRegionConfig {
        renderer: MasterFrontendRegionRendererConfig;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface MasterFrontendShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, MasterFrontendDynamicRegionConfig>;
    }
    export interface MasterFrontendClientShellConfig {
        mode: MasterFrontendShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: MasterFrontendShellRegionProfiles;
            aside?: MasterFrontendShellRegionProfiles;
        };
    }
    export type MasterFrontendRouteMatchMode = 'exact' | 'prefix';
    export interface MasterFrontendRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: MasterFrontendRouteMatchMode;
    }
    export interface MasterFrontendModuleFrontendDefinition {
        pageTitle?: string;
        device?: MasterFrontendDeviceKind;
        navigation?: ProjectNavigationEntry[];
        routes: MasterFrontendRouteDefinition[];
        headerRenderer?: MasterFrontendRegionRendererConfig;
        asideRenderer?: MasterFrontendRegionRendererConfig;
    }
    export interface MasterFrontendModuleShellPreferences {
        layout?: Partial<MasterFrontendLayoutConfig>;
    }
    export interface MasterFrontendBootConfig {
        projectId: string;
        moduleId: string;
        basePath: string;
        shellMode: MasterFrontendShellMode;
        device: MasterFrontendDeviceKind;
        routes: MasterFrontendRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: ProjectNavigationEntry[];
        moduleLinks?: ProjectNavigationEntry[];
        layout: MasterFrontendLayoutConfig;
        clientShell?: MasterFrontendClientShellConfig;
    }
    export type MasterFrontendInteractionMode = 'blocking' | 'silent';
    export type MasterFrontendBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface MasterFrontendNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface MasterFrontendBlockingErrorState {
        title: string;
        error: MasterFrontendNormalizedError;
        canRetry: boolean;
    }
    export interface MasterFrontendInteractionState {
        busy: boolean;
        busyPhase: MasterFrontendBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: MasterFrontendBlockingErrorState;
    }
    global {
        interface Window {
            collabMasterFrontendShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
                setHeaderRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setAsideRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setShellProfile: (profileName: string) => Promise<void>;
            };
        }
        interface Window {
            collabBoot?: MasterFrontendBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabMasterFrontendInteractionState?: MasterFrontendInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102029_/l2/telemetry" {
    export interface ClientTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    class TelemetryQueue {
        private queue;
        private userId;
        private errorCounts;
        private errorEventsPushed;
        constructor();
        /**
         * Error-specific push: dedupes repeats (same message/source) bumping a
         * repeatCount instead of flooding, skips browser-extension noise, caps the
         * session volume, and never throws (an error handler must not error).
         */
        private pushError;
        private errorFlushTimer;
        /** Coalesce error bursts: wait 1s before the beacon so repeats dedupe into the queued event. */
        private scheduleErrorFlush;
        setUserId(id: string): void;
        push(event: ClientTelemetryEvent): void;
        flush(): ClientTelemetryEvent[];
        measureAsync<T>(label: string, fn: () => Promise<T>): Promise<T>;
        private sendBeacon;
    }
    export const telemetryQueue: TelemetryQueue;
}
declare module "_102029_/l2/bffClient" {
    import type { MasterFrontendInteractionMode, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    import { type ClientTelemetryEvent } from "_102029_/l2/telemetry";
    export type { ClientTelemetryEvent };
    export interface BffClientOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        signal?: AbortSignal;
    }
    export interface BffClientResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: MasterFrontendNormalizedError | null;
        telemetryReceived?: number;
    }
    export interface BffClientRequest {
        routine: string;
        params: unknown;
        meta: {
            source: 'http' | 'test';
            userId: string;
            telemetry: ClientTelemetryEvent[];
        };
    }
    export type BffDirectResult<TData = unknown> = BffClientResponse<TData> | {
        response: BffClientResponse<TData>;
        statusCode?: number;
    };
    export interface BffDirectTransport {
        execBff<TData = unknown>(request: BffClientRequest, options?: BffClientOptions): Promise<BffDirectResult<TData>>;
    }
    global {
        interface Window {
            collabBffTransport?: BffDirectTransport;
            collabBffTransportModule?: string;
        }
    }
    export function setUserId(id: string): void;
    export function pushTelemetry(event: ClientTelemetryEvent): void;
    export function execBff<TData = unknown>(routine: string, params: unknown, options?: BffClientOptions): Promise<BffClientResponse<TData>>;
}
declare module "_102029_/l2/interactionRuntime" {
    import type { MasterFrontendInteractionMode, MasterFrontendInteractionState, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    type InteractionListener = (state: MasterFrontendInteractionState) => void;
    interface BlockingActionOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): MasterFrontendInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): MasterFrontendNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102049_/l2/petShop/web/shared/catalog" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { FeaturedProductsOutput } from "_102049_/l2/petShop/web/contracts/catalog.featuredProducts";
    import type { BrowseCatalogOutput } from "_102049_/l2/petShop/web/contracts/catalog.browseCatalog";
    import type { ProductDetailsOutput } from "_102049_/l2/petShop/web/contracts/catalog.productDetails";
    import type { ReserveProductOutput } from "_102049_/l2/petShop/web/contracts/catalog.reserveProduct";
    export type { FeaturedProductsInput, FeaturedProductsOutput } from "_102049_/l2/petShop/web/contracts/catalog.featuredProducts";
    export type { BrowseCatalogInput, BrowseCatalogOutput } from "_102049_/l2/petShop/web/contracts/catalog.browseCatalog";
    export type { ProductDetailsInput, ProductDetailsOutput } from "_102049_/l2/petShop/web/contracts/catalog.productDetails";
    export type { ReserveProductInput, ReserveProductOutput } from "_102049_/l2/petShop/web/contracts/catalog.reserveProduct";
    const message_pt: {
        "org.vitrine.cards.title": string;
        "int.vitrine.list.title": string;
        "int.vitrine.list.empty": string;
        "org.vitrine.filters.title": string;
        "int.vitrine.filters.title": string;
        "int.vitrine.filters.empty": string;
        "org.catalogo.cards.title": string;
        "int.catalogo.list.title": string;
        "int.catalogo.list.empty": string;
        "org.catalogo.filters.title": string;
        "int.catalogo.filters.title": string;
        "int.catalogo.filters.empty": string;
        "org.detalhe.card.title": string;
        "int.detalhe.view.title": string;
        "int.detalhe.view.empty": string;
        "org.reserva.form.title": string;
        "int.reserva.form.title": string;
        "int.reserva.form.empty": string;
        "field.name": string;
        "field.price": string;
        "field.isFeatured": string;
        "field.categoryId": string;
        "field.petTypeId": string;
        "field.priceMin": string;
        "field.priceMax": string;
        "field.page": string;
        "field.pageSize": string;
        "field.items": string;
        "field.searchName": string;
        "field.minPrice": string;
        "field.maxPrice": string;
        "field.categoryName": string;
        "field.petTypeName": string;
        "field.createdAt": string;
        "field.updatedAt": string;
        "field.productId": string;
        "field.quantity": string;
        "field.customerName": string;
        "field.customerPhone": string;
        "action.productDetails": string;
        "action.applyFilters": string;
        "action.reserveProduct": string;
        "action.reserveProduct.success": string;
        "action.reserveProduct.error": string;
        "sec.vitrine.title": string;
        "sec.catalogo.title": string;
        "sec.detalhe.reserva.title": string;
        "section.vitrine.title": string;
        "section.vitrine.featured.title": string;
        "section.vitrine.featured.empty": string;
        "organism.vitrine.featured.title": string;
        "section.catalogo.title": string;
        "section.catalogo.browse.title": string;
        "section.catalogo.browse.empty": string;
        "organism.catalogo.browse.title": string;
        "section.detalheReserva.title": string;
        "section.detalhe.product.title": string;
        "section.detalhe.product.empty": string;
        "organism.detalhe.product.title": string;
        "section.detalhe.reserve.title": string;
        "section.detalhe.reserve.empty": string;
        "organism.detalhe.reserve.title": string;
        "field.product.name": string;
        "field.product.price": string;
        "field.product.isFeatured": string;
        "field.product.categoryId": string;
        "field.product.petTypeId": string;
        "field.product.categoryName": string;
        "field.product.petTypeName": string;
        "field.reserve.quantity": string;
        "field.reserve.customerName": string;
        "field.reserve.customerPhone": string;
        "filter.featured.categoryId": string;
        "filter.featured.petTypeId": string;
        "filter.featured.name": string;
        "filter.featured.priceMin": string;
        "filter.featured.priceMax": string;
        "filter.browse.searchName": string;
        "filter.browse.petTypeId": string;
        "filter.browse.categoryId": string;
        "filter.browse.minPrice": string;
        "filter.browse.maxPrice": string;
    };
    type MessageType = typeof message_pt;
    type ActionStatus = "idle" | "loading" | "success" | "error";
    export class PetShopCatalogBase extends CollabLitElement {
        /** state ui.catalog.status — pageStatus */
        status: string;
        /** state ui.catalog.action.featuredProducts.status — actionStatus, values: idle|loading|success|error */
        featuredProductsState: ActionStatus;
        /** state ui.catalog.input.featuredProducts.categoryId — input */
        featuredProductsCategoryId: string;
        /** state ui.catalog.input.featuredProducts.petTypeId — input */
        featuredProductsPetTypeId: string;
        /** state ui.catalog.input.featuredProducts.name — input */
        featuredProductsName: string;
        /** state ui.catalog.input.featuredProducts.priceMin — input */
        featuredProductsPriceMin: string;
        /** state ui.catalog.input.featuredProducts.priceMax — input */
        featuredProductsPriceMax: string;
        /** state ui.catalog.input.featuredProducts.page — input */
        featuredProductsPage: string;
        /** state ui.catalog.input.featuredProducts.pageSize — input */
        featuredProductsPageSize: string;
        /** state ui.catalog.data.featuredProducts — queryResult, outputShape: array */
        featuredProductsData: FeaturedProductsOutput[];
        /** state ui.catalog.action.browseCatalog.status — actionStatus, values: idle|loading|success|error */
        browseCatalogState: ActionStatus;
        /** state ui.catalog.input.browseCatalog.searchName — input */
        browseCatalogSearchName: string;
        /** state ui.catalog.input.browseCatalog.petTypeId — input */
        browseCatalogPetTypeId: string;
        /** state ui.catalog.input.browseCatalog.categoryId — input */
        browseCatalogCategoryId: string;
        /** state ui.catalog.input.browseCatalog.minPrice — input */
        browseCatalogMinPrice: string;
        /** state ui.catalog.input.browseCatalog.maxPrice — input */
        browseCatalogMaxPrice: string;
        /** state ui.catalog.input.browseCatalog.page — input */
        browseCatalogPage: string;
        /** state ui.catalog.input.browseCatalog.pageSize — input */
        browseCatalogPageSize: string;
        /** state ui.catalog.data.browseCatalog — queryResult, outputShape: paginated */
        browseCatalogData: BrowseCatalogOutput;
        /** state ui.catalog.action.productDetails.status — actionStatus, values: idle|loading|success|error */
        productDetailsState: ActionStatus;
        /** state ui.catalog.input.productDetails.productId — input */
        productDetailsProductId: string;
        /** state ui.catalog.data.productDetails — queryResult, outputShape: object */
        productDetailsData: ProductDetailsOutput | null;
        /** state ui.catalog.action.reserveProduct.status — actionStatus, values: idle|loading|success|error */
        reserveProductState: ActionStatus;
        /** state ui.catalog.input.reserveProduct.customerName — input */
        reserveProductCustomerName: string;
        /** state ui.catalog.input.reserveProduct.customerPhone — input */
        reserveProductCustomerPhone: string;
        /** state ui.catalog.input.reserveProduct.productId — input */
        reserveProductProductId: string;
        /** state ui.catalog.input.reserveProduct.quantity — input */
        reserveProductQuantity: string;
        /** state ui.catalog.output.reserveProduct — commandOutput */
        reserveProductOutput: ReserveProductOutput | null;
        /** state ui.catalog.action.reserveProduct.error — actionError */
        reserveProductError: string;
        private readonly subscribedKeys;
        /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: unknown): void;
        private initStateValue;
        private applyRouteParams;
        private optionalNumber;
        private optionalString;
        /** action featuredProducts (query) — route petShop.catalog.featuredProducts; inputs: categoryId, petTypeId, name, priceMin, priceMax, page, pageSize; writes ui.catalog.data.featuredProducts; status ui.catalog.action.featuredProducts.status */
        loadFeaturedProducts(): Promise<void>;
        /** handler for action featuredProducts — bind UI events here */
        handleFeaturedProductsClick(event?: Event): void;
        /** action browseCatalog (query) — route petShop.catalog.browseCatalog; inputs: searchName, petTypeId, categoryId, minPrice, maxPrice, page, pageSize; writes ui.catalog.data.browseCatalog; status ui.catalog.action.browseCatalog.status */
        loadBrowseCatalog(): Promise<void>;
        /** handler for action browseCatalog — bind UI events here */
        handleBrowseCatalogClick(event?: Event): void;
        /** action productDetails (query) — route petShop.catalog.productDetails; inputs: productId; writes ui.catalog.data.productDetails; status ui.catalog.action.productDetails.status */
        loadProductDetails(): Promise<void>;
        /** handler for action productDetails — bind UI events here */
        handleProductDetailsClick(event?: Event): void;
        /** action reserveProduct (command) — route petShop.catalog.reserveProduct; inputs: customerName, customerPhone, productId, quantity; writes ui.catalog.output.reserveProduct; status ui.catalog.action.reserveProduct.status; feedback keys action.reserveProduct.success / action.reserveProduct.error */
        reserveProduct(signal?: AbortSignal): Promise<void>;
        /** handler for action reserveProduct — bind UI events here */
        handleReserveProductClick(event?: Event): void;
        /** setter for state ui.catalog.input.featuredProducts.categoryId */
        setFeaturedProductsCategoryId(value: string): void;
        /** handler for action set.featuredProductsCategoryId — bind UI events here */
        handleFeaturedProductsCategoryIdChange(event: Event): void;
        /** setter for state ui.catalog.input.featuredProducts.petTypeId */
        setFeaturedProductsPetTypeId(value: string): void;
        /** handler for action set.featuredProductsPetTypeId — bind UI events here */
        handleFeaturedProductsPetTypeIdChange(event: Event): void;
        /** setter for state ui.catalog.input.featuredProducts.name */
        setFeaturedProductsName(value: string): void;
        /** handler for action set.featuredProductsName — bind UI events here */
        handleFeaturedProductsNameChange(event: Event): void;
        /** setter for state ui.catalog.input.featuredProducts.priceMin */
        setFeaturedProductsPriceMin(value: string): void;
        /** handler for action set.featuredProductsPriceMin — bind UI events here */
        handleFeaturedProductsPriceMinChange(event: Event): void;
        /** setter for state ui.catalog.input.featuredProducts.priceMax */
        setFeaturedProductsPriceMax(value: string): void;
        /** handler for action set.featuredProductsPriceMax — bind UI events here */
        handleFeaturedProductsPriceMaxChange(event: Event): void;
        /** setter for state ui.catalog.input.featuredProducts.page */
        setFeaturedProductsPage(value: string): void;
        /** handler for action set.featuredProductsPage — bind UI events here */
        handleFeaturedProductsPageChange(event: Event): void;
        /** setter for state ui.catalog.input.featuredProducts.pageSize */
        setFeaturedProductsPageSize(value: string): void;
        /** handler for action set.featuredProductsPageSize — bind UI events here */
        handleFeaturedProductsPageSizeChange(event: Event): void;
        /** setter for state ui.catalog.input.browseCatalog.searchName */
        setBrowseCatalogSearchName(value: string): void;
        /** handler for action set.browseCatalogSearchName — bind UI events here */
        handleBrowseCatalogSearchNameChange(event: Event): void;
        /** setter for state ui.catalog.input.browseCatalog.petTypeId */
        setBrowseCatalogPetTypeId(value: string): void;
        /** handler for action set.browseCatalogPetTypeId — bind UI events here */
        handleBrowseCatalogPetTypeIdChange(event: Event): void;
        /** setter for state ui.catalog.input.browseCatalog.categoryId */
        setBrowseCatalogCategoryId(value: string): void;
        /** handler for action set.browseCatalogCategoryId — bind UI events here */
        handleBrowseCatalogCategoryIdChange(event: Event): void;
        /** setter for state ui.catalog.input.browseCatalog.minPrice */
        setBrowseCatalogMinPrice(value: string): void;
        /** handler for action set.browseCatalogMinPrice — bind UI events here */
        handleBrowseCatalogMinPriceChange(event: Event): void;
        /** setter for state ui.catalog.input.browseCatalog.maxPrice */
        setBrowseCatalogMaxPrice(value: string): void;
        /** handler for action set.browseCatalogMaxPrice — bind UI events here */
        handleBrowseCatalogMaxPriceChange(event: Event): void;
        /** setter for state ui.catalog.input.browseCatalog.page */
        setBrowseCatalogPage(value: string): void;
        /** handler for action set.browseCatalogPage — bind UI events here */
        handleBrowseCatalogPageChange(event: Event): void;
        /** setter for state ui.catalog.input.browseCatalog.pageSize */
        setBrowseCatalogPageSize(value: string): void;
        /** handler for action set.browseCatalogPageSize — bind UI events here */
        handleBrowseCatalogPageSizeChange(event: Event): void;
        /** setter for state ui.catalog.input.productDetails.productId */
        setProductDetailsProductId(value: string): void;
        /** handler for action set.productDetailsProductId — bind UI events here */
        handleProductDetailsProductIdChange(event: Event): void;
        /** setter for state ui.catalog.input.reserveProduct.customerName */
        setReserveProductCustomerName(value: string): void;
        /** handler for action set.reserveProductCustomerName — bind UI events here */
        handleReserveProductCustomerNameChange(event: Event): void;
        /** setter for state ui.catalog.input.reserveProduct.customerPhone */
        setReserveProductCustomerPhone(value: string): void;
        /** handler for action set.reserveProductCustomerPhone — bind UI events here */
        handleReserveProductCustomerPhoneChange(event: Event): void;
        /** setter for state ui.catalog.input.reserveProduct.productId */
        setReserveProductProductId(value: string): void;
        /** handler for action set.reserveProductProductId — bind UI events here */
        handleReserveProductProductIdChange(event: Event): void;
        /** setter for state ui.catalog.input.reserveProduct.quantity */
        setReserveProductQuantity(value: string): void;
        /** handler for action set.reserveProductQuantity — bind UI events here */
        handleReserveProductQuantityChange(event: Event): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/catalog" {
    import { PetShopCatalogBase } from "_102049_/l2/petShop/web/shared/catalog";
    export class PetShopDesktopPage11CatalogPage extends PetShopCatalogBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/reservationManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            }[];
        };
        dataBindings: ({
            id: string;
            source: string;
            entity: string;
            description: string;
            stateKey: string;
            command?: undefined;
            inputStateKeys?: undefined;
        } | {
            id: string;
            source: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
            entity?: undefined;
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "reservationManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page11/reservationManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page11/reservationManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/reservationManagement.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["reservationManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Storefront-first, catálogo limpo com busca e filtros, fluxo de reserva simples, UI de gestão do atendente orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/desktop/page11/reservationManagement.test" {
    export const pageTests: {
        readonly moduleName: "petShop";
        readonly page: "reservationManagement";
        readonly variant: "page11";
        readonly cases: readonly [{
            readonly id: "browseReservationsQuery.ok";
            readonly routine: "petShop.reservationManagement.browseReservationsQuery";
            readonly params: {};
            readonly expect: {
                readonly ok: true;
                readonly shape: "array";
                readonly minItems: 1;
            };
        }, {
            readonly id: "updateReservationStatusCommand.ok";
            readonly routine: "petShop.reservationManagement.updateReservationStatusCommand";
            readonly params: {
                readonly reservationId: "<seedRef>";
                readonly newStatus: "<seedRef>";
            };
            readonly expect: {
                readonly ok: true;
                readonly shape: "object";
            };
            readonly mutating: true;
        }, {
            readonly id: "updateReservationStatusCommand.newStatus.required";
            readonly routine: "petShop.reservationManagement.updateReservationStatusCommand";
            readonly params: {
                readonly reservationId: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }, {
            readonly id: "processPaymentCommand.ok";
            readonly routine: "petShop.reservationManagement.processPaymentCommand";
            readonly params: {
                readonly reservationId: "<seedRef>";
                readonly method: "<seedRef>";
            };
            readonly expect: {
                readonly ok: true;
                readonly shape: "object";
            };
            readonly mutating: true;
        }, {
            readonly id: "processPaymentCommand.method.required";
            readonly routine: "petShop.reservationManagement.processPaymentCommand";
            readonly params: {
                readonly reservationId: "<seedRef>";
            };
            readonly expect: {
                readonly ok: false;
                readonly errorCode: "VALIDATION_ERROR";
            };
        }];
    };
}
declare module "_102049_/l2/petShop/web/shared/reservationManagement" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { BrowseReservationsQueryOutput } from "_102049_/l2/petShop/web/contracts/reservationManagement.browseReservationsQuery";
    import type { UpdateReservationStatusCommandOutput } from "_102049_/l2/petShop/web/contracts/reservationManagement.updateReservationStatusCommand";
    import type { ProcessPaymentCommandOutput } from "_102049_/l2/petShop/web/contracts/reservationManagement.processPaymentCommand";
    export type { BrowseReservationsQueryInput, BrowseReservationsQueryOutput, } from "_102049_/l2/petShop/web/contracts/reservationManagement.browseReservationsQuery";
    export type { UpdateReservationStatusCommandInput, UpdateReservationStatusCommandOutput, } from "_102049_/l2/petShop/web/contracts/reservationManagement.updateReservationStatusCommand";
    export type { ProcessPaymentCommandInput, ProcessPaymentCommandOutput, } from "_102049_/l2/petShop/web/contracts/reservationManagement.processPaymentCommand";
    const message_pt: {
        "section.reservationList.title": string;
        "organism.reservationKanbanBoard.title": string;
        "intent.reservationKanban.title": string;
        "field.reservationId": string;
        "field.customerName": string;
        "field.customerPhone": string;
        "field.status": string;
        "field.expiresAt": string;
        "filter.searchTerm": string;
        "filter.statusFilter": string;
        "filter.page": string;
        "filter.pageSize": string;
        "action.refresh": string;
        "action.updateStatus": string;
        "action.processPayment": string;
        "empty.reservations": string;
        "organism.updateReservationStatusPanel.title": string;
        "intent.updateReservationStatus.title": string;
        "field.newStatus": string;
        "field.cancellationReason": string;
        "field.paymentId": string;
        "action.confirmUpdate": string;
        "organism.processPaymentPanel.title": string;
        "intent.processPayment.title": string;
        "field.method": string;
        "action.receivePayment": string;
        "action.updateReservationStatusCommand.success": string;
        "action.updateReservationStatusCommand.error": string;
        "action.processPaymentCommand.success": string;
        "action.processPaymentCommand.error": string;
        "reservation.queue.title": string;
        "reservation.list.title": string;
        "reservation.list.empty": string;
        "reservation.transition.title": string;
        "reservation.payment.title": string;
        "field.createdAt": string;
        "action.confirmReservation": string;
        "action.cancelReservation": string;
        "action.fulfillReservation": string;
    };
    type MessageType = typeof message_pt;
    export class PetShopReservationManagementBase extends CollabLitElement {
        /** state status — pageStatus */
        status: string;
        /** state browseReservationsQueryState — actionStatus, values: idle, loading, success, error */
        browseReservationsQueryState: "idle" | "loading" | "success" | "error";
        /** state browseReservationsQuerySearchTerm — input */
        browseReservationsQuerySearchTerm: string;
        /** state browseReservationsQueryStatusFilter — input */
        browseReservationsQueryStatusFilter: string;
        /** state browseReservationsQueryPage — input */
        browseReservationsQueryPage: string;
        /** state browseReservationsQueryPageSize — input */
        browseReservationsQueryPageSize: string;
        /** state browseReservationsQueryData — queryResult, outputShape: array */
        browseReservationsQueryData: BrowseReservationsQueryOutput[];
        /** state updateReservationStatusCommandState — actionStatus, values: idle, loading, success, error */
        updateReservationStatusCommandState: "idle" | "loading" | "success" | "error";
        /** state updateReservationStatusCommandReservationId — input */
        updateReservationStatusCommandReservationId: string;
        /** state updateReservationStatusCommandNewStatus — input */
        updateReservationStatusCommandNewStatus: string;
        /** state updateReservationStatusCommandCancellationReason — input */
        updateReservationStatusCommandCancellationReason: string;
        /** state updateReservationStatusCommandPaymentId — input */
        updateReservationStatusCommandPaymentId: string;
        /** state updateReservationStatusCommandOutput — commandOutput */
        updateReservationStatusCommandOutput: UpdateReservationStatusCommandOutput | null;
        /** state updateReservationStatusCommandError — actionError */
        updateReservationStatusCommandError: string;
        /** state processPaymentCommandState — actionStatus, values: idle, loading, success, error */
        processPaymentCommandState: "idle" | "loading" | "success" | "error";
        /** state processPaymentCommandReservationId — input */
        processPaymentCommandReservationId: string;
        /** state processPaymentCommandMethod — input */
        processPaymentCommandMethod: string;
        /** state processPaymentCommandOutput — commandOutput */
        processPaymentCommandOutput: ProcessPaymentCommandOutput | null;
        /** state processPaymentCommandError — actionError */
        processPaymentCommandError: string;
        private readonly subscribedKeys;
        /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: unknown): void;
        private initStateValue;
        private applyRouteParams;
        /** action browseReservationsQuery (query) — route petShop.reservationManagement.browseReservationsQuery; inputs: searchTerm, statusFilter, page, pageSize; writes ui.reservationManagement.data.browseReservationsQuery; status ui.reservationManagement.action.browseReservationsQuery.status */
        loadBrowseReservationsQuery(): Promise<void>;
        /** handler for action browseReservationsQuery — bind UI events here */
        handleBrowseReservationsQueryClick(event?: Event): void;
        /** action updateReservationStatusCommand (command) — route petShop.reservationManagement.updateReservationStatusCommand; inputs: reservationId, newStatus, cancellationReason, paymentId; writes ui.reservationManagement.output.updateReservationStatusCommand; status ui.reservationManagement.action.updateReservationStatusCommand.status; feedback keys action.updateReservationStatusCommand.success / action.updateReservationStatusCommand.error */
        updateReservationStatusCommand(): Promise<void>;
        /** handler for action updateReservationStatusCommand — bind UI events here */
        handleUpdateReservationStatusCommandClick(event?: Event): void;
        /** action processPaymentCommand (command) — route petShop.reservationManagement.processPaymentCommand; inputs: reservationId, method; writes ui.reservationManagement.output.processPaymentCommand; status ui.reservationManagement.action.processPaymentCommand.status; feedback keys action.processPaymentCommand.success / action.processPaymentCommand.error */
        processPaymentCommand(): Promise<void>;
        /** handler for action processPaymentCommand — bind UI events here */
        handleProcessPaymentCommandClick(event?: Event): void;
        /** setter for state ui.reservationManagement.input.browseReservationsQuery.searchTerm */
        setBrowseReservationsQuerySearchTerm(value: string): void;
        /** handler for action set.browseReservationsQuerySearchTerm — bind UI events here */
        handleBrowseReservationsQuerySearchTermChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.browseReservationsQuery.statusFilter */
        setBrowseReservationsQueryStatusFilter(value: string): void;
        /** handler for action set.browseReservationsQueryStatusFilter — bind UI events here */
        handleBrowseReservationsQueryStatusFilterChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.browseReservationsQuery.page */
        setBrowseReservationsQueryPage(value: string): void;
        /** handler for action set.browseReservationsQueryPage — bind UI events here */
        handleBrowseReservationsQueryPageChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.browseReservationsQuery.pageSize */
        setBrowseReservationsQueryPageSize(value: string): void;
        /** handler for action set.browseReservationsQueryPageSize — bind UI events here */
        handleBrowseReservationsQueryPageSizeChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.updateReservationStatusCommand.reservationId */
        setUpdateReservationStatusCommandReservationId(value: string): void;
        /** handler for action set.updateReservationStatusCommandReservationId — bind UI events here */
        handleUpdateReservationStatusCommandReservationIdChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.updateReservationStatusCommand.newStatus */
        setUpdateReservationStatusCommandNewStatus(value: string): void;
        /** handler for action set.updateReservationStatusCommandNewStatus — bind UI events here */
        handleUpdateReservationStatusCommandNewStatusChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.updateReservationStatusCommand.cancellationReason */
        setUpdateReservationStatusCommandCancellationReason(value: string): void;
        /** handler for action set.updateReservationStatusCommandCancellationReason — bind UI events here */
        handleUpdateReservationStatusCommandCancellationReasonChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.updateReservationStatusCommand.paymentId */
        setUpdateReservationStatusCommandPaymentId(value: string): void;
        /** handler for action set.updateReservationStatusCommandPaymentId — bind UI events here */
        handleUpdateReservationStatusCommandPaymentIdChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.processPaymentCommand.reservationId */
        setProcessPaymentCommandReservationId(value: string): void;
        /** handler for action set.processPaymentCommandReservationId — bind UI events here */
        handleProcessPaymentCommandReservationIdChange(event: Event): void;
        /** setter for state ui.reservationManagement.input.processPaymentCommand.method */
        setProcessPaymentCommandMethod(value: string): void;
        /** handler for action set.processPaymentCommandMethod — bind UI events here */
        handleProcessPaymentCommandMethodChange(event: Event): void;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page11/reservationManagement" {
    import { PetShopReservationManagementBase } from "_102049_/l2/petShop/web/shared/reservationManagement";
    export class PetShopDesktopPage11ReservationManagementPage extends PetShopReservationManagementBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page21/catalog.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            })[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format?: undefined;
                            stateKey?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                })[];
            })[];
        };
        dataBindings: ({
            id: string;
            source: string;
            entity: string;
            description: string;
            stateKey: string;
            inputStateKeys?: undefined;
            command?: undefined;
        } | {
            id: string;
            source: string;
            entity: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
            command?: undefined;
        } | {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "catalog__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page21/catalog.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page21/catalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/catalog.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["catalog__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Storefront-first, catálogo limpo com busca e filtros, fluxo de reserva simples, UI de gestão do atendente orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/desktop/page21/catalog" {
    import { PetShopCatalogBase } from "_102049_/l2/petShop/web/shared/catalog";
    export class PetShopDesktopPage21CatalogPage extends PetShopCatalogBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102049_/l2/petShop/web/desktop/page21/reservationManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                    submitAction?: undefined;
                } | {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                    stateKey?: undefined;
                    action?: undefined;
                })[];
            }[];
        }[];
        templateId: string;
        visualStyle: string;
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                        submitAction?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        displayHint: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        source?: undefined;
                        binding?: undefined;
                        action?: undefined;
                        emptyKey?: undefined;
                        stateKey?: undefined;
                    })[];
                }[];
            }[];
        };
        dataBindings: ({
            id: string;
            source: string;
            entity: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
            command?: undefined;
        } | {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "reservationManagement__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102049_/l2/petShop/web/desktop/page21/reservationManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/desktop/page21/reservationManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/shared/reservationManagement.ts", "_102049_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["reservationManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "Storefront-first, catálogo limpo com busca e filtros, fluxo de reserva simples, UI de gestão do atendente orientada por status";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/desktop/page21/reservationManagement" {
    import { PetShopReservationManagementBase } from "_102049_/l2/petShop/web/shared/reservationManagement";
    export class PetShopDesktopPage21ReservationManagementPage extends PetShopReservationManagementBase {
        render(): import("lit").TemplateResult<1>;
    }
}
declare module "_102049_/l2/petShop/web/shared/catalog.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            contracts: {
                commandName: string;
                tsPath: string;
                routeConst: string;
            }[];
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "org.vitrine.cards.title": string;
            "int.vitrine.list.title": string;
            "int.vitrine.list.empty": string;
            "org.vitrine.filters.title": string;
            "int.vitrine.filters.title": string;
            "int.vitrine.filters.empty": string;
            "org.catalogo.cards.title": string;
            "int.catalogo.list.title": string;
            "int.catalogo.list.empty": string;
            "org.catalogo.filters.title": string;
            "int.catalogo.filters.title": string;
            "int.catalogo.filters.empty": string;
            "org.detalhe.card.title": string;
            "int.detalhe.view.title": string;
            "int.detalhe.view.empty": string;
            "org.reserva.form.title": string;
            "int.reserva.form.title": string;
            "int.reserva.form.empty": string;
            "field.name": string;
            "field.price": string;
            "field.isFeatured": string;
            "field.categoryId": string;
            "field.petTypeId": string;
            "field.priceMin": string;
            "field.priceMax": string;
            "field.page": string;
            "field.pageSize": string;
            "field.items": string;
            "field.searchName": string;
            "field.minPrice": string;
            "field.maxPrice": string;
            "field.categoryName": string;
            "field.petTypeName": string;
            "field.createdAt": string;
            "field.updatedAt": string;
            "field.productId": string;
            "field.quantity": string;
            "field.customerName": string;
            "field.customerPhone": string;
            "action.productDetails": string;
            "action.applyFilters": string;
            "action.reserveProduct": string;
            "action.reserveProduct.success": string;
            "action.reserveProduct.error": string;
            "sec.vitrine.title": string;
            "sec.catalogo.title": string;
            "sec.detalhe.reserva.title": string;
            "section.vitrine.title": string;
            "section.vitrine.featured.title": string;
            "section.vitrine.featured.empty": string;
            "organism.vitrine.featured.title": string;
            "section.catalogo.title": string;
            "section.catalogo.browse.title": string;
            "section.catalogo.browse.empty": string;
            "organism.catalogo.browse.title": string;
            "section.detalheReserva.title": string;
            "section.detalhe.product.title": string;
            "section.detalhe.product.empty": string;
            "organism.detalhe.product.title": string;
            "section.detalhe.reserve.title": string;
            "section.detalhe.reserve.empty": string;
            "organism.detalhe.reserve.title": string;
            "field.product.name": string;
            "field.product.price": string;
            "field.product.isFeatured": string;
            "field.product.categoryId": string;
            "field.product.petTypeId": string;
            "field.product.categoryName": string;
            "field.product.petTypeName": string;
            "field.reserve.quantity": string;
            "field.reserve.customerName": string;
            "field.reserve.customerPhone": string;
            "filter.featured.categoryId": string;
            "filter.featured.petTypeId": string;
            "filter.featured.name": string;
            "filter.featured.priceMin": string;
            "filter.featured.priceMax": string;
            "filter.browse.searchName": string;
            "filter.browse.petTypeId": string;
            "filter.browse.categoryId": string;
            "filter.browse.minPrice": string;
            "filter.browse.maxPrice": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "catalog__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/catalog.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/catalog.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/catalog.featuredProducts.ts", "_102049_/l2/petShop/web/contracts/catalog.browseCatalog.ts", "_102049_/l2/petShop/web/contracts/catalog.productDetails.ts", "_102049_/l2/petShop/web/contracts/catalog.reserveProduct.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly ["featuredProductsOnly", "featuredOrderFlexible", "combinedFilters", "caseInsensitiveSearch", "catalogShowsAll", "reservationRequiresContact", "reservationValidity24h", "reservationStatuses"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/catalog.test" {
    export {};
}
declare module "_102049_/l2/petShop/web/shared/reservationManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            contracts: {
                commandName: string;
                tsPath: string;
                routeConst: string;
            }[];
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "section.reservationList.title": string;
            "organism.reservationKanbanBoard.title": string;
            "intent.reservationKanban.title": string;
            "field.reservationId": string;
            "field.customerName": string;
            "field.customerPhone": string;
            "field.status": string;
            "field.expiresAt": string;
            "filter.searchTerm": string;
            "filter.statusFilter": string;
            "filter.page": string;
            "filter.pageSize": string;
            "action.refresh": string;
            "action.updateStatus": string;
            "action.processPayment": string;
            "empty.reservations": string;
            "organism.updateReservationStatusPanel.title": string;
            "intent.updateReservationStatus.title": string;
            "field.newStatus": string;
            "field.cancellationReason": string;
            "field.paymentId": string;
            "action.confirmUpdate": string;
            "organism.processPaymentPanel.title": string;
            "intent.processPayment.title": string;
            "field.method": string;
            "action.receivePayment": string;
            "action.updateReservationStatusCommand.success": string;
            "action.updateReservationStatusCommand.error": string;
            "action.processPaymentCommand.success": string;
            "action.processPaymentCommand.error": string;
            "reservation.queue.title": string;
            "reservation.list.title": string;
            "reservation.list.empty": string;
            "reservation.transition.title": string;
            "reservation.payment.title": string;
            "field.createdAt": string;
            "action.confirmReservation": string;
            "action.cancelReservation": string;
            "action.fulfillReservation": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "reservationManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102049_/l2/petShop/web/shared/reservationManagement.ts";
        readonly defPath: "_102049_/l2/petShop/web/shared/reservationManagement.defs.ts";
        readonly dependsFiles: readonly ["_102049_/l2/petShop/web/contracts/reservationManagement.browseReservationsQuery.ts", "_102049_/l2/petShop/web/contracts/reservationManagement.updateReservationStatusCommand.ts", "_102049_/l2/petShop/web/contracts/reservationManagement.processPaymentCommand.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly ["reservationStatuses", "reservationValidity24h", "inStorePaymentOnly", "totalFromPricesAndQuantities", "paymentRequiresReceipt"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102049_/l2/petShop/web/shared/reservationManagement.test" {
    export {};
}
declare module "_102049_/l4/petShop/actors.defs" {
    export const petShopActors: {
        readonly moduleName: "petShop";
        readonly actors: readonly [{
            readonly actorId: "cliente";
            readonly title: "Cliente";
            readonly description: "Navega no site, pesquisa produtos, faz reservas e retira os itens na loja pagando presencialmente.";
            readonly roleScope: "petShop:cliente";
        }, {
            readonly actorId: "atendente";
            readonly title: "Atendente/Loja";
            readonly description: "Confirma reservas recebidas, prepara os produtos e recebe o pagamento na loja no momento da retirada.";
            readonly roleScope: "petShop:atendente";
        }];
    };
    export default petShopActors;
}
declare module "_102049_/l4/petShop/module.defs" {
    export const petShopModule: {
        readonly module: {
            readonly moduleName: "petShop";
            readonly title: "Pet Shop — Catálogo e Reserva de Produtos";
            readonly purpose: "Este módulo oferece uma vitrine digital e catálogo completo de produtos do pet shop, permitindo que clientes pesquisem, filtrem e reservem produtos para retirada presencial na loja. O atendente gerencia as reservas recebidas, confirma a disponibilidade e registra o pagamento presencial no momento da retirada, encerrando o ciclo da reserva.";
            readonly businessDomain: "Pet Retail";
            readonly languages: readonly ["pt-BR"];
            readonly visualStyle: "Storefront-first, catálogo limpo com busca e filtros, fluxo de reserva simples, UI de gestão do atendente orientada por status";
        };
        readonly designContext: {
            readonly initialPrompt: "criar um site petShop , em portugues , com vendas de produtos , o cliente reserva e busca e paga na loja , mostrar produtos em destaques, e lista completa de produtos com pesquisa por tipo pet , categoria , nome e filtro por valor";
            readonly userLanguage: "pt-BR";
            readonly openDetails: readonly [{
                readonly title: "Como o cliente se identifica para fazer uma reserva?";
                readonly description: "Define se é necessário login ou apenas dados básicos como nome e telefone.";
            }, {
                readonly title: "Qual o prazo de validade para retirada de uma reserva?";
                readonly description: "Impacta a regra de negócio para expiração ou cancelamento automático.";
            }, {
                readonly title: "A reserva deve bloquear ou reduzir a quantidade disponível no estoque?";
                readonly description: "Define se o sistema precisa controlar saldo reservado.";
            }];
            readonly decisions: readonly [];
        };
        readonly ontology: {
            readonly entities: {
                readonly Product: {
                    readonly title: "Produto";
                    readonly description: "Produto do catálogo do pet shop, mantido por processo administrativo externo, com nome, preço, tipo de pet, categoria e flag de destaque para vitrine.";
                    readonly kind: "mdm";
                    readonly ownership: "external";
                };
                readonly ProductCategory: {
                    readonly title: "Categoria de Produto";
                    readonly description: "Categoria de produtos do pet shop, como ração, acessórios, higiene e brinquedos, usada como filtro no catálogo.";
                    readonly kind: "mdm";
                    readonly ownership: "external";
                };
                readonly PetType: {
                    readonly title: "Tipo de Pet";
                    readonly description: "Tipo de pet (cão, gato, pássaro, etc.) associado aos produtos do catálogo, usado como filtro na busca.";
                    readonly kind: "mdm";
                    readonly ownership: "external";
                };
                readonly Reservation: {
                    readonly title: "Reserva";
                    readonly description: "Reserva de produtos feita pelo cliente para retirada presencial na loja, contendo dados de contato (nome e telefone), prazo de validade de 24 horas e status de atendimento controlado pelo atendente.";
                    readonly kind: "core";
                    readonly ownership: "moduleOwned";
                    readonly statusEnum: readonly ["pending", "confirmed", "fulfilled", "cancelled"];
                    readonly lifecycleStates: readonly ["pending", "confirmed", "fulfilled", "cancelled"];
                };
                readonly ReservationItem: {
                    readonly title: "Item de Reserva";
                    readonly description: "Item de linha de uma reserva, contendo a referência ao produto e a quantidade reservada pelo cliente.";
                    readonly kind: "supporting";
                    readonly ownership: "moduleOwned";
                };
                readonly Payment: {
                    readonly title: "Pagamento Presencial";
                    readonly description: "Registro do pagamento recebido presencialmente na loja no momento da retirada da reserva, informando método e valor total.";
                    readonly kind: "event";
                    readonly ownership: "moduleOwned";
                    readonly statusEnum: readonly ["posted", "voided"];
                };
            };
        };
        readonly journey: {
            readonly defPath: "l4/petShop/siteMap.defs.ts";
        };
        readonly relationships: readonly [{
            readonly relationshipId: "productBelongsToCategory";
            readonly fromEntity: "Product";
            readonly toEntity: "ProductCategory";
            readonly type: "manyToOne";
            readonly description: "Cada produto pertence a uma categoria de produto.";
        }, {
            readonly relationshipId: "productTargetsPetType";
            readonly fromEntity: "Product";
            readonly toEntity: "PetType";
            readonly type: "manyToOne";
            readonly description: "Cada produto é associado a um tipo de pet para filtragem no catálogo.";
        }, {
            readonly relationshipId: "reservationHasItems";
            readonly fromEntity: "Reservation";
            readonly toEntity: "ReservationItem";
            readonly type: "oneToMany";
            readonly description: "Uma reserva contém um ou mais itens de reserva com produtos e quantidades.";
        }, {
            readonly relationshipId: "reservationItemRefersToProduct";
            readonly fromEntity: "ReservationItem";
            readonly toEntity: "Product";
            readonly type: "manyToOne";
            readonly description: "Cada item de reserva referencia um produto do catálogo.";
        }, {
            readonly relationshipId: "reservationHasPayment";
            readonly fromEntity: "Reservation";
            readonly toEntity: "Payment";
            readonly type: "oneToOne";
            readonly description: "Uma reserva atendida possui um registro de pagamento presencial associado.";
        }];
        readonly approvedArtifacts: {
            readonly mdm: readonly [{
                readonly title: "Catálogo de Produtos";
                readonly reason: "Os produtos exibidos no catálogo e na vitrine são gerenciados por processo administrativo externo; o módulo apenas consome os dados de produto, incluindo flag de destaque e preço.";
            }, {
                readonly title: "Categorias de Produto";
                readonly reason: "As categorias utilizadas nos filtros de catálogo são dados mestros externos, gerenciados fora do módulo.";
            }, {
                readonly title: "Tipos de Pet";
                readonly reason: "Os tipos de pet usados para filtragem no catálogo são dados mestros externos, gerenciados fora do módulo.";
            }];
            readonly horizontals: readonly [];
            readonly plugins: readonly [];
            readonly agents: readonly [];
        };
    };
    export default petShopModule;
}
declare module "_102049_/l4/petShop/siteMap.defs" {
    export const petShopSiteMap: {
        readonly moduleName: "petShop";
        readonly note: "Site map (permanent page index) — workspaces, landings and advisory edges. Detail (sections/organisms/bffCalls) lives per-workspace under workspaces/.";
        readonly workspaces: readonly [{
            readonly workspaceId: "catalog";
            readonly title: "Catálogo de produtos";
            readonly actors: readonly ["cliente"];
            readonly kind: "workflow";
            readonly entity: "Product";
            readonly operationIds: readonly ["browseFeaturedProducts", "browseProducts", "viewProductDetails", "createReservation"];
            readonly purpose: "O cliente navega pela vitrine e pelo catálogo, visualiza detalhes dos produtos e reserva itens para retirada na loja";
            readonly workflowId: "reservationLifecycle";
        }, {
            readonly workspaceId: "reservationManagement";
            readonly title: "Gestão de reservas";
            readonly actors: readonly ["atendente"];
            readonly kind: "workflow";
            readonly entity: "Reservation";
            readonly operationIds: readonly ["browseReservations", "updateReservationStatus", "processPayment"];
            readonly purpose: "O atendente visualiza reservas pendentes, confirma ou cancela e recebe o pagamento presencial na retirada";
            readonly workflowId: "reservationLifecycle";
        }];
        readonly landings: readonly [{
            readonly actorId: "cliente";
            readonly workspaceId: "catalog";
            readonly reason: "O cliente começa navegando pela vitrine de produtos em destaque na página inicial";
        }, {
            readonly actorId: "atendente";
            readonly workspaceId: "reservationManagement";
            readonly reason: "O atendente inicia o dia visualizando a lista de reservas pendentes";
        }];
        readonly navigationEdges: readonly [{
            readonly from: "catalog";
            readonly to: "reservationManagement";
            readonly operationId: "createReservation";
            readonly description: "A reserva criada pelo cliente aparece na lista de reservas do atendente para confirmação e preparo";
        }];
        readonly workspaceIds: readonly ["catalog", "reservationManagement"];
    };
    export default petShopSiteMap;
}
declare module "_102049_/l4/petShop/journeys/browseFeaturedProducts.defs" {
    export const browseFeaturedProductsJourney: {
        readonly journeyId: "browseFeaturedProducts";
        readonly actorId: "cliente";
        readonly title: "Visualizar produtos em destaque na vitrine";
        readonly goal: "Descobrir rapidamente quais produtos o pet shop está destacando como promoções ou novidades";
        readonly steps: readonly ["Acessar a página inicial do pet shop", "Visualizar a vitrine de produtos em destaque", "Selecionar um produto em destaque para ver detalhes"];
        readonly outcome: "O cliente conhece os produtos em destaque e pode aprofundar nos detalhes ou partir para o catálogo completo.";
        readonly operationIds: readonly ["browseFeaturedProducts", "viewProductDetails"];
        readonly workspaceId: "catalog";
    };
    export default browseFeaturedProductsJourney;
}
declare module "_102049_/l4/petShop/journeys/manageReservations.defs" {
    export const manageReservationsJourney: {
        readonly journeyId: "manageReservations";
        readonly actorId: "atendente";
        readonly title: "Confirmar e atender reservas de clientes";
        readonly goal: "Garantir que cada reserva recebida seja confirmada, preparada e entregue ao cliente na retirada";
        readonly steps: readonly ["Visualizar reservas pendentes", "Confirmar uma reserva", "Preparar os produtos da reserva", "Identificar o cliente na chegada à loja", "Cancelar reservas não retiradas dentro do prazo"];
        readonly outcome: "As reservas confirmadas são preparadas e entregues aos clientes na retirada; reservas expiradas são canceladas.";
        readonly operationIds: readonly ["browseReservations", "updateReservationStatus", "processPayment"];
        readonly workspaceId: "reservationManagement";
    };
    export default manageReservationsJourney;
}
declare module "_102049_/l4/petShop/journeys/processInStorePayment.defs" {
    export const processInStorePaymentJourney: {
        readonly journeyId: "processInStorePayment";
        readonly actorId: "atendente";
        readonly title: "Receber pagamento presencial na retirada";
        readonly goal: "Registrar que o cliente pagou os produtos reservados no momento da retirada na loja";
        readonly steps: readonly ["Revisar os itens da reserva com o cliente", "Calcular o valor total da reserva", "Receber o pagamento do cliente", "Marcar a reserva como paga e entregue"];
        readonly outcome: "A reserva é marcada como paga e entregue, encerrando o ciclo de reserva com o cliente saindo da loja com os produtos.";
        readonly operationIds: readonly ["browseReservations", "updateReservationStatus", "processPayment"];
        readonly workspaceId: "reservationManagement";
    };
    export default processInStorePaymentJourney;
}
declare module "_102049_/l4/petShop/journeys/reserveProducts.defs" {
    export const reserveProductsJourney: {
        readonly journeyId: "reserveProducts";
        readonly actorId: "cliente";
        readonly title: "Reservar produtos para retirada na loja";
        readonly goal: "Garantir que os produtos desejados fiquem separados para retirada presencial na loja";
        readonly steps: readonly ["Escolher um produto para reservar a partir dos detalhes", "Definir a quantidade desejada do produto", "Informar dados de contato para a reserva", "Confirmar a reserva", "Receber a confirmação da reserva"];
        readonly outcome: "A reserva é registrada no sistema com os dados do cliente e os itens solicitados, pronta para o atendente confirmar e preparar.";
        readonly operationIds: readonly ["viewProductDetails", "createReservation"];
        readonly workspaceId: "catalog";
    };
    export default reserveProductsJourney;
}
declare module "_102049_/l4/petShop/journeys/searchAndFilterCatalog.defs" {
    export const searchAndFilterCatalogJourney: {
        readonly journeyId: "searchAndFilterCatalog";
        readonly actorId: "cliente";
        readonly title: "Pesquisar e filtrar produtos no catálogo";
        readonly goal: "Encontrar produtos específicos no catálogo completo usando critérios relevantes para o seu pet";
        readonly steps: readonly ["Abrir o catálogo completo de produtos", "Pesquisar produtos por nome", "Filtrar produtos por tipo de pet", "Filtrar produtos por categoria", "Filtrar produtos por faixa de valor", "Selecionar um produto da lista filtrada"];
        readonly outcome: "O cliente encontra produtos relevantes para o seu pet dentro do seu orçamento e pode ver os detalhes ou iniciar uma reserva.";
        readonly operationIds: readonly ["browseProducts", "viewProductDetails"];
        readonly workspaceId: "catalog";
    };
    export default searchAndFilterCatalogJourney;
}
declare module "_102049_/l4/petShop/ontology/Payment.defs" {
    export const petShopEntityPayment: {
        readonly entityId: "Payment";
        readonly title: "Pagamento Presencial";
        readonly description: "Registro do pagamento recebido presencialmente na loja no momento da retirada da reserva, informando método e valor total.";
        readonly kind: "event";
        readonly ownership: "moduleOwned";
        readonly fields: readonly [{
            readonly fieldId: "paymentId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do registro de pagamento.";
        }, {
            readonly fieldId: "reservationId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência à reserva associada a este pagamento presencial.";
        }, {
            readonly fieldId: "amount";
            readonly type: "money";
            readonly required: true;
            readonly description: "Valor total recebido, calculado a partir dos preços dos produtos e quantidades reservadas.";
        }, {
            readonly fieldId: "method";
            readonly type: "string";
            readonly required: true;
            readonly description: "Método de pagamento utilizado pelo cliente na loja.";
            readonly enum: readonly ["cash", "creditCard", "debitCard", "pix"];
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Situação atual do registro de pagamento.";
            readonly enum: readonly ["posted", "voided"];
        }, {
            readonly fieldId: "receivedBy";
            readonly type: "string";
            readonly required: true;
            readonly description: "Identificador do atendente que confirmou o recebimento do pagamento.";
        }, {
            readonly fieldId: "voidedAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora em que o pagamento foi cancelado ou estornado.";
        }, {
            readonly fieldId: "voidReason";
            readonly type: "text";
            readonly required: false;
            readonly description: "Motivo do cancelamento ou estorno do pagamento.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora em que o pagamento foi registrado no sistema.";
        }];
        readonly statusEnum: readonly ["posted", "voided"];
        readonly eventPolicy: {
            readonly purpose: "audit";
            readonly retentionDays: 365;
        };
    };
    export default petShopEntityPayment;
}
declare module "_102049_/l4/petShop/ontology/PetType.defs" {
    export const petShopEntityPetType: {
        readonly entityId: "PetType";
        readonly title: "Tipo de Pet";
        readonly description: "Tipo de pet (cão, gato, pássaro, etc.) associado aos produtos do catálogo, usado como filtro na busca.";
        readonly kind: "mdm";
        readonly ownership: "external";
        readonly fields: readonly [{
            readonly fieldId: "petTypeId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do tipo de pet.";
        }, {
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nome do tipo de pet exibido nos filtros do catálogo (ex.: cão, gato, pássaro).";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro do tipo de pet.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro do tipo de pet.";
        }];
    };
    export default petShopEntityPetType;
}
declare module "_102049_/l4/petShop/ontology/Product.defs" {
    export const petShopEntityProduct: {
        readonly entityId: "Product";
        readonly title: "Produto";
        readonly description: "Produto do catálogo do pet shop, mantido por processo administrativo externo, com nome, preço, tipo de pet, categoria e flag de destaque para vitrine.";
        readonly kind: "mdm";
        readonly ownership: "external";
        readonly fields: readonly [{
            readonly fieldId: "productId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do produto no catálogo.";
        }, {
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nome do produto utilizado para exibição e pesquisa no catálogo.";
        }, {
            readonly fieldId: "price";
            readonly type: "money";
            readonly required: true;
            readonly description: "Preço do produto utilizado no filtro de faixa de valor e no cálculo da reserva.";
        }, {
            readonly fieldId: "isFeatured";
            readonly type: "boolean";
            readonly required: true;
            readonly description: "Indica se o produto deve ser exibido na vitrine de destaques, definido pelo processo administrativo externo.";
        }, {
            readonly fieldId: "categoryId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência à categoria do produto à qual pertence, usada no filtro de categoria.";
        }, {
            readonly fieldId: "petTypeId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao tipo de pet associado ao produto, usada no filtro de tipo de pet.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de cadastro do produto no catálogo.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do produto pelo processo administrativo externo.";
        }];
    };
    export default petShopEntityProduct;
}
declare module "_102049_/l4/petShop/ontology/ProductCategory.defs" {
    export const petShopEntityProductCategory: {
        readonly entityId: "ProductCategory";
        readonly title: "Categoria de Produto";
        readonly description: "Categoria de produtos do pet shop, como ração, acessórios, higiene e brinquedos, usada como filtro no catálogo.";
        readonly kind: "mdm";
        readonly ownership: "external";
        readonly fields: readonly [{
            readonly fieldId: "productCategoryId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da categoria de produto.";
        }, {
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nome da categoria usado como filtro no catálogo (ex.: ração, acessórios, higiene, brinquedos).";
        }, {
            readonly fieldId: "description";
            readonly type: "text";
            readonly required: false;
            readonly description: "Descrição detalhada da categoria de produto.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro da categoria.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro da categoria.";
        }];
    };
    export default petShopEntityProductCategory;
}
declare module "_102049_/l4/petShop/ontology/Reservation.defs" {
    export const petShopEntityReservation: {
        readonly entityId: "Reservation";
        readonly title: "Reserva";
        readonly description: "Reserva de produtos feita pelo cliente para retirada presencial na loja, contendo dados de contato (nome e telefone), prazo de validade de 24 horas e status de atendimento controlado pelo atendente.";
        readonly kind: "core";
        readonly ownership: "moduleOwned";
        readonly fields: readonly [{
            readonly fieldId: "reservationId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da reserva";
        }, {
            readonly fieldId: "customerName";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nome do cliente que fez a reserva";
        }, {
            readonly fieldId: "customerPhone";
            readonly type: "string";
            readonly required: true;
            readonly description: "Telefone de contato do cliente";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status de atendimento da reserva controlado pelo atendente";
            readonly enum: readonly ["pending", "confirmed", "fulfilled", "cancelled"];
        }, {
            readonly fieldId: "expiresAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de validade da reserva, 24 horas após o registro";
        }, {
            readonly fieldId: "confirmedAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora em que a reserva foi confirmada pelo atendente";
        }, {
            readonly fieldId: "fulfilledAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora em que a reserva foi atendida com retirada e pagamento confirmado";
        }, {
            readonly fieldId: "cancelledAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora em que a reserva foi cancelada";
        }, {
            readonly fieldId: "cancellationReason";
            readonly type: "text";
            readonly required: false;
            readonly description: "Motivo do cancelamento da reserva registrado pelo atendente";
        }, {
            readonly fieldId: "paymentId";
            readonly type: "uuid";
            readonly required: false;
            readonly description: "Referência ao pagamento presencial associado quando a reserva é atendida";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação da reserva";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização da reserva";
        }];
        readonly statusEnum: readonly ["pending", "confirmed", "fulfilled", "cancelled"];
        readonly lifecycleStates: readonly ["pending", "confirmed", "fulfilled", "cancelled"];
    };
    export default petShopEntityReservation;
}
declare module "_102049_/l4/petShop/ontology/ReservationItem.defs" {
    export const petShopEntityReservationItem: {
        readonly entityId: "ReservationItem";
        readonly title: "Item de Reserva";
        readonly description: "Item de linha de uma reserva, contendo a referência ao produto e a quantidade reservada pelo cliente.";
        readonly kind: "supporting";
        readonly ownership: "moduleOwned";
        readonly fields: readonly [{
            readonly fieldId: "reservationItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do item de reserva.";
        }, {
            readonly fieldId: "reservationId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência à reserva à qual este item pertence.";
        }, {
            readonly fieldId: "productId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao produto do catálogo que foi reservado.";
        }, {
            readonly fieldId: "quantity";
            readonly type: "number";
            readonly required: true;
            readonly description: "Quantidade do produto reservada pelo cliente.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do item de reserva.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do item de reserva.";
        }];
    };
    export default petShopEntityReservationItem;
}
declare module "_102049_/l4/petShop/operations/browseFeaturedProducts.defs" {
    export const operationBrowseFeaturedProducts: {
        readonly operationId: "browseFeaturedProducts";
        readonly title: "Visualizar produtos em destaque na vitrine";
        readonly actors: readonly ["cliente"];
        readonly entity: "Product";
        readonly kind: "query";
        readonly reads: readonly ["Product"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly ["featuredProductsOnly", "featuredOrderFlexible", "combinedFilters", "caseInsensitiveSearch"];
        readonly story: {
            readonly actor: "cliente";
            readonly goal: "Ver os produtos em destaque na vitrine do pet shop ao acessar a página inicial";
            readonly steps: readonly ["O cliente acessa a página inicial do pet shop", "O sistema exibe a vitrine com produtos marcados como destaque pelo processo administrativo externo", "O cliente pode aplicar filtros opcionais de categoria, tipo de pet, nome e faixa de preço para refinar a visualização", "O cliente seleciona um produto em destaque para ver seus detalhes"];
            readonly outcome: "O cliente visualiza a lista de produtos em destaque na vitrine, podendo filtrá-los para identificar promoções, novidades ou itens recomendados antes de acessar os detalhes de um produto";
        };
        readonly accessPattern: {
            readonly kind: "list";
            readonly entity: "Product";
            readonly keyField: "Product.productId";
            readonly pagination: "optional";
            readonly selection: "none";
            readonly output: readonly ["Product.productId", "Product.name", "Product.price", "Product.isFeatured", "Product.categoryId", "Product.petTypeId"];
        };
        readonly outputShape: {
            readonly kind: "list";
            readonly fields: readonly [{
                readonly name: "productId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Product.productId";
            }, {
                readonly name: "name";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Product.name";
            }, {
                readonly name: "price";
                readonly type: "number";
                readonly required: true;
                readonly fieldRef: "Product.price";
            }, {
                readonly name: "isFeatured";
                readonly type: "boolean";
                readonly required: true;
                readonly fieldRef: "Product.isFeatured";
            }, {
                readonly name: "categoryId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Product.categoryId";
            }, {
                readonly name: "petTypeId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Product.petTypeId";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "categoryId";
            readonly fieldRef: "Product.categoryId";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Filtro opcional por categoria do produto";
        }, {
            readonly inputId: "petTypeId";
            readonly fieldRef: "Product.petTypeId";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Filtro opcional por tipo de pet associado ao produto";
        }, {
            readonly inputId: "name";
            readonly fieldRef: "Product.name";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Termo de pesquisa opcional para filtrar produtos por nome (insensível a caixa)";
        }, {
            readonly inputId: "priceMin";
            readonly fieldRef: "Product.price";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Valor mínimo opcional para filtrar produtos por faixa de preço";
        }, {
            readonly inputId: "priceMax";
            readonly fieldRef: "Product.price";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Valor máximo opcional para filtrar produtos por faixa de preço";
        }, {
            readonly inputId: "page";
            readonly type: "number";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Número da página para paginação opcional dos resultados";
        }, {
            readonly inputId: "pageSize";
            readonly type: "number";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Quantidade de itens por página para paginação opcional dos resultados";
        }];
        readonly contextResolution: readonly [];
        readonly acceptanceAssertions: readonly ["A vitrine retorna apenas produtos com isFeatured igual a true", "Produtos não marcados como destaque nunca aparecem nos resultados da vitrine", "Os filtros de categoria, tipo de pet, nome e faixa de valor funcionam simultaneamente quando aplicados", "A pesquisa por nome retorna resultados correspondentes independente da capitalização informada", "Cada item retornado inclui productId, name, price, categoryId e petTypeId para permitir a navegação aos detalhes do produto"];
        readonly pageId: "browseFeaturedProducts";
        readonly commandName: "browseFeaturedProducts";
        readonly bffName: "petShop.browseFeaturedProducts.browseFeaturedProducts";
        readonly capability: {
            readonly capabilityId: "browseFeaturedProducts";
            readonly title: "Visualizar produtos em destaque na vitrine";
            readonly actor: "cliente";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationBrowseFeaturedProducts;
}
declare module "_102049_/l4/petShop/operations/browseProducts.defs" {
    export const operationBrowseProducts: {
        readonly operationId: "browseProducts";
        readonly title: "Pesquisar e filtrar produtos no catálogo";
        readonly actors: readonly ["cliente"];
        readonly entity: "Product";
        readonly kind: "query";
        readonly reads: readonly ["Product", "ProductCategory", "PetType"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly ["catalogShowsAll", "combinedFilters", "caseInsensitiveSearch"];
        readonly story: {
            readonly actor: "cliente";
            readonly goal: "Pesquisar e filtrar produtos no catálogo para encontrar produtos adequados ao seu pet e orçamento";
            readonly steps: readonly ["Acessa a listagem completa de produtos do catálogo", "Digita um nome ou parte do nome para pesquisar produtos", "Seleciona tipo de pet e/ou categoria para filtrar os resultados", "Define uma faixa de preço para refinar a busca", "Visualiza a lista paginada de produtos que atendem a todos os critérios aplicados"];
            readonly outcome: "O cliente recebe uma lista paginada de produtos que atendem simultaneamente a todos os filtros de nome, tipo de pet, categoria e faixa de valor";
        };
        readonly accessPattern: {
            readonly kind: "list";
            readonly entity: "Product";
            readonly keyField: "Product.productId";
            readonly pagination: "required";
            readonly selection: "none";
            readonly output: readonly ["Product.productId", "Product.name", "Product.price", "Product.isFeatured", "Product.categoryId", "Product.petTypeId", "Product.createdAt", "Product.updatedAt"];
        };
        readonly outputShape: {
            readonly kind: "paginated";
            readonly fields: readonly [{
                readonly name: "items";
                readonly type: "array";
                readonly required: true;
                readonly item: {
                    readonly fields: readonly [{
                        readonly name: "productId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.productId";
                    }, {
                        readonly name: "name";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.name";
                    }, {
                        readonly name: "price";
                        readonly type: "number";
                        readonly required: true;
                        readonly fieldRef: "Product.price";
                    }, {
                        readonly name: "isFeatured";
                        readonly type: "boolean";
                        readonly required: true;
                        readonly fieldRef: "Product.isFeatured";
                    }, {
                        readonly name: "categoryId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.categoryId";
                    }, {
                        readonly name: "categoryName";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "ProductCategory.name";
                    }, {
                        readonly name: "petTypeId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.petTypeId";
                    }, {
                        readonly name: "petTypeName";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "PetType.name";
                    }, {
                        readonly name: "createdAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.createdAt";
                    }, {
                        readonly name: "updatedAt";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.updatedAt";
                    }];
                };
            }, {
                readonly name: "total";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "page";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "pageSize";
                readonly type: "number";
                readonly required: true;
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "searchName";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Texto parcial do nome do produto para pesquisa insensível a caixa";
            readonly type: "string";
        }, {
            readonly inputId: "petTypeId";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Identificador do tipo de pet para filtrar produtos adequados";
            readonly type: "string";
        }, {
            readonly inputId: "categoryId";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Identificador da categoria para filtrar produtos";
            readonly type: "string";
        }, {
            readonly inputId: "minPrice";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Valor mínimo da faixa de preço para filtrar produtos dentro do orçamento";
            readonly type: "string";
        }, {
            readonly inputId: "maxPrice";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Valor máximo da faixa de preço para filtrar produtos dentro do orçamento";
            readonly type: "string";
        }, {
            readonly inputId: "page";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Número da página atual para paginação dos resultados";
            readonly type: "number";
        }, {
            readonly inputId: "pageSize";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Quantidade de itens por página";
            readonly type: "number";
        }];
        readonly contextResolution: readonly [];
        readonly acceptanceAssertions: readonly ["A listagem retorna todos os produtos cadastrados, independentemente de estarem marcados como destaque ou não", "A pesquisa por nome é insensível a maiúsculas e minúsculas, retornando resultados correspondentes independente da capitalização informada", "Os filtros de tipo de pet, categoria, nome e faixa de valor funcionam simultaneamente, permitindo combinação de múltiplos critérios", "O resultado é paginado e contém o total de produtos que atendem aos critérios aplicados", "Cada produto retornado inclui productId, name, price, isFeatured, categoryId, petTypeId, categoryName e petTypeName"];
        readonly pageId: "browseProducts";
        readonly commandName: "browseProducts";
        readonly bffName: "petShop.browseProducts.browseProducts";
        readonly capability: {
            readonly capabilityId: "browseProducts";
            readonly title: "Pesquisar e filtrar produtos no catálogo";
            readonly actor: "cliente";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationBrowseProducts;
}
declare module "_102049_/l4/petShop/operations/browseReservations.defs" {
    export const operationBrowseReservations: {
        readonly operationId: "browseReservations";
        readonly title: "Visualizar reservas pendentes e localizar cliente";
        readonly actors: readonly ["atendente"];
        readonly entity: "Reservation";
        readonly kind: "query";
        readonly reads: readonly ["Reservation"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly ["reservationStatuses", "reservationValidity24h"];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Visualizar a lista de reservas recebidas para saber quais precisam ser confirmadas e localizar um cliente pelo nome, telefone ou número da reserva quando ele chega à loja.";
            readonly steps: readonly ["O atendente abre a tela de reservas e visualiza a lista de reservas pendentes ordenadas pela data de criação", "O atendente pode filtrar por status (pendente, confirmada, atendida, cancelada) para focar em um grupo específico", "O atendente digita um termo de busca (nome, telefone ou número da reserva) para localizar rapidamente um cliente que chegou à loja", "O sistema retorna as reservas correspondentes com dados do cliente, status e prazo de validade"];
            readonly outcome: "O atendente tem uma visão clara das reservas pendentes e consegue localizar rapidamente a reserva de um cliente que chegou para retirada.";
        };
        readonly accessPattern: {
            readonly kind: "list";
            readonly entity: "Reservation";
            readonly keyField: "Reservation.reservationId";
            readonly pagination: "optional";
            readonly selection: "single";
            readonly output: readonly ["Reservation.reservationId", "Reservation.customerName", "Reservation.customerPhone", "Reservation.status", "Reservation.expiresAt", "Reservation.createdAt", "Reservation.updatedAt"];
        };
        readonly outputShape: {
            readonly kind: "list";
            readonly fields: readonly [{
                readonly name: "reservationId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.reservationId";
            }, {
                readonly name: "customerName";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.customerName";
            }, {
                readonly name: "customerPhone";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.customerPhone";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.status";
            }, {
                readonly name: "expiresAt";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.expiresAt";
            }, {
                readonly name: "createdAt";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.createdAt";
            }, {
                readonly name: "updatedAt";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.updatedAt";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "searchTerm";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Termo de busca para localizar reserva por nome do cliente, telefone ou número da reserva";
            readonly type: "string";
        }, {
            readonly inputId: "statusFilter";
            readonly fieldRef: "Reservation.status";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Filtro de status da reserva (pendente, confirmada, atendida ou cancelada)";
        }, {
            readonly inputId: "page";
            readonly type: "number";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Número da página para paginação dos resultados";
        }, {
            readonly inputId: "pageSize";
            readonly type: "number";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Quantidade de reservas por página";
        }];
        readonly contextResolution: readonly [{
            readonly targetRef: "atendente.actorId";
            readonly source: "actorSession";
            readonly originRef: "actorSession.actorId";
            readonly description: "Identifica o atendente autenticado que está navegando as reservas, para registro de auditoria";
        }];
        readonly acceptanceAssertions: readonly ["A lista de reservas retorna apenas reservas com status válido (pending, confirmed, fulfilled ou cancelled)", "Quando o atendente filtra por status pending, apenas reservas com status pending aparecem na lista", "Quando o atendente busca por um nome de cliente, apenas reservas cujo customerName contém o termo aparecem na lista", "Quando o atendente busca por um telefone, apenas reservas cujo customerPhone contém o termo aparecem na lista", "Cada reserva na lista exibe reservationId, customerName, customerPhone, status, expiresAt e createdAt", "As reservas são ordenadas pela data de criação (createdAt) em ordem decrescente", "O prazo de validade (expiresAt) de cada reserva pendente reflete a regra de 24 horas após o registro"];
        readonly pageId: "browseReservations";
        readonly commandName: "browseReservations";
        readonly bffName: "petShop.browseReservations.browseReservations";
        readonly capability: {
            readonly capabilityId: "browseReservations";
            readonly title: "Visualizar reservas pendentes e localizar cliente";
            readonly actor: "atendente";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationBrowseReservations;
}
declare module "_102049_/l4/petShop/operations/createReservation.defs" {
    export const operationCreateReservation: {
        readonly operationId: "createReservation";
        readonly title: "Reservar produtos para retirada na loja";
        readonly actors: readonly ["cliente"];
        readonly entity: "Reservation";
        readonly kind: "create";
        readonly reads: readonly ["Product"];
        readonly writes: readonly ["Reservation", "ReservationItem"];
        readonly rulesApplied: readonly ["reservationRequiresContact", "reservationValidity24h", "reservationStatuses"];
        readonly story: {
            readonly actor: "cliente";
            readonly goal: "Reservar um produto para retirada na loja fornecendo dados de contato e quantidade desejada";
            readonly steps: readonly ["O cliente visualiza os detalhes de um produto e decide reservá-lo para retirada presencial", "Informa a quantidade desejada do produto", "Fornece seu nome e telefone de contato para identificação na loja", "Revisa os itens e seus dados e confirma a reserva", "Recebe o número da reserva como comprovante para apresentar na retirada"];
            readonly outcome: "A reserva é criada com status 'pending', validade de 24 horas, contendo o item reservado e os dados de contato do cliente, e o reservationId é retornado como comprovante";
        };
        readonly accessPattern: {
            readonly kind: "commandInput";
            readonly entity: "Reservation";
            readonly keyField: "Reservation.reservationId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["Reservation.reservationId", "Reservation.customerName", "Reservation.customerPhone", "Reservation.status", "Reservation.expiresAt", "Reservation.createdAt"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [{
                readonly name: "reservationId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.reservationId";
            }, {
                readonly name: "customerName";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.customerName";
            }, {
                readonly name: "customerPhone";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.customerPhone";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.status";
            }, {
                readonly name: "expiresAt";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.expiresAt";
            }, {
                readonly name: "createdAt";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.createdAt";
            }, {
                readonly name: "items";
                readonly type: "array";
                readonly required: true;
                readonly item: {
                    readonly fields: readonly [{
                        readonly name: "productId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.productId";
                    }, {
                        readonly name: "productName";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Product.name";
                    }, {
                        readonly name: "quantity";
                        readonly type: "number";
                        readonly required: true;
                        readonly fieldRef: "ReservationItem.quantity";
                    }];
                };
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "customerName";
            readonly fieldRef: "Reservation.customerName";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Nome do cliente que está fazendo a reserva";
        }, {
            readonly inputId: "customerPhone";
            readonly fieldRef: "Reservation.customerPhone";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Telefone de contato do cliente para identificação na loja";
        }, {
            readonly inputId: "productId";
            readonly fieldRef: "Product.productId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Identificador do produto selecionado na tela de detalhes que o cliente deseja reservar";
        }, {
            readonly inputId: "quantity";
            readonly type: "number";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Quantidade de unidades do produto que o cliente deseja reservar";
        }];
        readonly contextResolution: readonly [{
            readonly targetRef: "Reservation.reservationId";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.uuid";
            readonly description: "O backend gera um UUID para o reservationId no momento da criação da reserva";
        }, {
            readonly targetRef: "Reservation.expiresAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "O backend calcula expiresAt como o timestamp atual mais 24 horas, conforme a regra de validade da reserva";
        }, {
            readonly targetRef: "Reservation.createdAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "O backend define createdAt com o timestamp atual no momento da criação";
        }, {
            readonly targetRef: "Reservation.updatedAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "O backend define updatedAt com o timestamp atual no momento da criação";
        }, {
            readonly targetRef: "Reservation.status";
            readonly source: "workflowState";
            readonly originRef: "Reservation.status";
            readonly description: "O backend define o status inicial como 'pending' conforme o estado inicial do lifecycle reservationLifecycle";
        }, {
            readonly targetRef: "Product.productId";
            readonly source: "selectedEntity";
            readonly originRef: "Product.productId";
            readonly description: "O backend obtém o productId do produto atualmente selecionado na tela de detalhes de produto";
        }];
        readonly acceptanceAssertions: readonly ["Após a confirmação, a reserva existe com status 'pending'", "A reserva contém o nome e telefone do cliente informados nos dados de contato", "A data de validade (expiresAt) é definida para 24 horas após o momento da criação", "A reserva contém pelo menos um item com o productId e a quantidade informados pelo cliente", "O reservationId é retornado na resposta para o cliente usar como comprovante de retirada", "A reserva sem nome ou telefone do cliente é rejeitada conforme a regra de contato obrigatório"];
        readonly pageId: "reservationLifecycle";
        readonly commandName: "createReservation";
        readonly bffName: "petShop.reservationLifecycle.createReservation";
        readonly capability: {
            readonly capabilityId: "reservationLifecycle";
            readonly title: "Ciclo de vida da reserva";
            readonly actor: "cliente";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationCreateReservation;
}
declare module "_102049_/l4/petShop/operations/processPayment.defs" {
    export const operationProcessPayment: {
        readonly operationId: "processPayment";
        readonly title: "Receber pagamento presencial e encerrar reserva";
        readonly actors: readonly ["atendente"];
        readonly entity: "Payment";
        readonly kind: "create";
        readonly reads: readonly ["Reservation", "ReservationItem", "Product"];
        readonly writes: readonly ["Payment", "Reservation"];
        readonly rulesApplied: readonly ["inStorePaymentOnly", "totalFromPricesAndQuantities", "paymentRequiresReceipt"];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Receber o pagamento presencial do cliente na loja e encerrar a reserva registrando o pagamento no sistema";
            readonly steps: readonly ["O atendente seleciona a reserva do cliente que chegou para retirada", "O sistema calcula o valor total a partir dos preços dos produtos e das quantidades reservadas nos itens da reserva", "O atendente informa o método de pagamento escolhido pelo cliente (dinheiro, cartão de crédito, cartão de débito ou pix)", "O sistema cria o registro de pagamento com status 'posted' e marca a reserva associada como paga e entregue, encerrando o ciclo da reserva"];
            readonly outcome: "O pagamento é registrado com status posted, a reserva é encerrada como paga e entregue, e o cliente retira os produtos da loja";
        };
        readonly accessPattern: {
            readonly kind: "commandInput";
            readonly entity: "Payment";
            readonly keyField: "Payment.paymentId";
            readonly pagination: "none";
            readonly selection: "single";
            readonly output: readonly ["Payment.paymentId", "Payment.reservationId", "Payment.amount", "Payment.method", "Payment.status", "Payment.receivedBy", "Payment.createdAt"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [{
                readonly name: "paymentId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Payment.paymentId";
            }, {
                readonly name: "reservationId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Payment.reservationId";
            }, {
                readonly name: "amount";
                readonly type: "number";
                readonly required: true;
                readonly fieldRef: "Payment.amount";
            }, {
                readonly name: "method";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Payment.method";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Payment.status";
            }, {
                readonly name: "receivedBy";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Payment.receivedBy";
            }, {
                readonly name: "createdAt";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Payment.createdAt";
            }, {
                readonly name: "reservationStatus";
                readonly type: "string";
                readonly required: true;
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "reservationId";
            readonly fieldRef: "Payment.reservationId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Reserva atualmente selecionada pelo atendente na tela de retirada, associada a este pagamento presencial";
        }, {
            readonly inputId: "method";
            readonly fieldRef: "Payment.method";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Método de pagamento escolhido pelo cliente na loja: dinheiro, cartão de crédito, cartão de débito ou pix";
        }];
        readonly contextResolution: readonly [{
            readonly targetRef: "Payment.reservationId";
            readonly source: "selectedEntity";
            readonly originRef: "Reservation.reservationId";
            readonly description: "A reserva atualmente selecionada pelo atendente na tela de retirada, identificada pelo seu reservationId";
        }, {
            readonly targetRef: "Payment.receivedBy";
            readonly source: "actorSession";
            readonly originRef: "actorSession.actorId";
            readonly description: "O identificador do atendente logado no sistema que está processando o recebimento do pagamento";
        }, {
            readonly targetRef: "Payment.paymentId";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.uuid";
            readonly description: "Identificador único gerado automaticamente pelo sistema ao criar o registro de pagamento";
        }, {
            readonly targetRef: "Payment.createdAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "Data e hora atual do sistema no momento em que o pagamento é registrado";
        }, {
            readonly targetRef: "Payment.amount";
            readonly source: "previousStepOutput";
            readonly originRef: "ReservationItem.quantity";
            readonly description: "O valor total é calculado server-side somando o produto de ReservationItem.quantity pelo preço de cada Product associado aos itens da reserva selecionada";
        }, {
            readonly targetRef: "Payment.status";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "O status do pagamento é definido como 'posted' no momento da criação, indicando recebimento confirmado";
        }];
        readonly acceptanceAssertions: readonly ["Após a confirmação, existe um registro de Payment com status 'posted' associado ao reservationId informado", "O valor do campo amount é calculado a partir dos preços dos produtos (Product) e das quantidades reservadas (ReservationItem) da reserva selecionada", "O campo receivedBy corresponde ao identificador do atendente que processou o pagamento, obtido da sessão ativa", "O método de pagamento informado está entre os valores permitidos: cash, creditCard, debitCard ou pix", "Após o registro do pagamento, a reserva associada é marcada como paga e entregue, encerrando seu ciclo de vida", "Não é possível registrar um pagamento sem a confirmação presencial do recebimento pelo atendente", "O pagamento é sempre presencial na loja; não existe pagamento online nem cobrança remota neste módulo"];
        readonly pageId: "reservationLifecycle";
        readonly commandName: "processPayment";
        readonly bffName: "petShop.reservationLifecycle.processPayment";
        readonly capability: {
            readonly capabilityId: "reservationLifecycle";
            readonly title: "Ciclo de vida da reserva";
            readonly actor: "atendente";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationProcessPayment;
}
declare module "_102049_/l4/petShop/operations/updateReservationStatus.defs" {
    export const operationUpdateReservationStatus: {
        readonly operationId: "updateReservationStatus";
        readonly title: "Confirmar ou cancelar reserva";
        readonly actors: readonly ["atendente"];
        readonly entity: "Reservation";
        readonly kind: "update";
        readonly reads: readonly ["Reservation", "ReservationItem"];
        readonly writes: readonly ["Reservation"];
        readonly rulesApplied: readonly ["reservationStatuses", "reservationValidity24h"];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Atualizar o status de uma reserva para confirmada, atendida ou cancelada conforme o fluxo de atendimento.";
            readonly steps: readonly ["O atendente localiza a reserva pendente na lista de reservas.", "O atendente revisa os itens e dados do cliente da reserva.", "O atendente escolhe o novo status (confirmada, atendida ou cancelada).", "Se cancelando, o atendente registra o motivo do cancelamento.", "Se atendendo, o atendente associa o pagamento presencial realizado.", "O sistema valida o status permitido e atualiza a reserva com os timestamps correspondentes."];
            readonly outcome: "A reserva é atualizada com o novo status, os timestamps apropriados são registrados e a reserva reflete o estado correto no fluxo de atendimento.";
        };
        readonly accessPattern: {
            readonly kind: "commandInput";
            readonly entity: "Reservation";
            readonly keyField: "Reservation.reservationId";
            readonly pagination: "none";
            readonly selection: "single";
            readonly output: readonly ["Reservation.reservationId", "Reservation.customerName", "Reservation.customerPhone", "Reservation.status", "Reservation.expiresAt", "Reservation.confirmedAt", "Reservation.fulfilledAt", "Reservation.cancelledAt", "Reservation.cancellationReason", "Reservation.paymentId", "Reservation.updatedAt"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [{
                readonly name: "reservationId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.reservationId";
            }, {
                readonly name: "customerName";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.customerName";
            }, {
                readonly name: "customerPhone";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.customerPhone";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.status";
            }, {
                readonly name: "expiresAt";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.expiresAt";
            }, {
                readonly name: "confirmedAt";
                readonly type: "string";
                readonly required: false;
                readonly fieldRef: "Reservation.confirmedAt";
            }, {
                readonly name: "fulfilledAt";
                readonly type: "string";
                readonly required: false;
                readonly fieldRef: "Reservation.fulfilledAt";
            }, {
                readonly name: "cancelledAt";
                readonly type: "string";
                readonly required: false;
                readonly fieldRef: "Reservation.cancelledAt";
            }, {
                readonly name: "cancellationReason";
                readonly type: "string";
                readonly required: false;
                readonly fieldRef: "Reservation.cancellationReason";
            }, {
                readonly name: "paymentId";
                readonly type: "string";
                readonly required: false;
                readonly fieldRef: "Reservation.paymentId";
            }, {
                readonly name: "updatedAt";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Reservation.updatedAt";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "reservationId";
            readonly fieldRef: "Reservation.reservationId";
            readonly required: true;
            readonly source: "routeParam";
            readonly description: "Identificador da reserva a ser atualizada";
        }, {
            readonly inputId: "newStatus";
            readonly fieldRef: "Reservation.status";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Novo status da reserva: confirmed, fulfilled ou cancelled";
        }, {
            readonly inputId: "cancellationReason";
            readonly fieldRef: "Reservation.cancellationReason";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Motivo do cancelamento, obrigatório apenas quando o novo status for cancelled";
        }, {
            readonly inputId: "paymentId";
            readonly fieldRef: "Reservation.paymentId";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Referência ao pagamento presencial associado, obrigatório apenas quando o novo status for fulfilled";
        }];
        readonly contextResolution: readonly [{
            readonly targetRef: "Reservation.reservationId";
            readonly source: "routeParam";
            readonly originRef: "routeParam.reservationId";
            readonly description: "O ID da reserva é obtido do parâmetro de rota da tela de detalhe da reserva selecionada.";
        }, {
            readonly targetRef: "Reservation.confirmedAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "Ao confirmar, o sistema registra a data e hora atual automaticamente no campo confirmedAt.";
        }, {
            readonly targetRef: "Reservation.fulfilledAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "Ao marcar como atendida, o sistema registra a data e hora atual automaticamente no campo fulfilledAt.";
        }, {
            readonly targetRef: "Reservation.cancelledAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "Ao cancelar, o sistema registra a data e hora atual automaticamente no campo cancelledAt.";
        }, {
            readonly targetRef: "Reservation.updatedAt";
            readonly source: "systemDefault";
            readonly originRef: "systemDefault.now";
            readonly description: "O sistema atualiza o campo updatedAt com a data e hora atual a cada modificação da reserva.";
        }];
        readonly acceptanceAssertions: readonly ["Ao confirmar, a reserva existe com status 'confirmed' e o campo confirmedAt é preenchido com a data e hora da confirmação.", "Ao cancelar, a reserva existe com status 'cancelled', o campo cancelledAt é preenchido e o cancellationReason contém o motivo informado.", "Ao marcar como atendida, a reserva existe com status 'fulfilled', o campo fulfilledAt é preenchido e o paymentId referencia o pagamento presencial associado.", "O status da reserva após a atualização deve ser um dos valores permitidos: pending, confirmed, fulfilled ou cancelled.", "Uma reserva cuja validade de 24 horas expirou pode ser cancelada pelo atendente.", "O campo updatedAt é sempre atualizado com a data e hora da última modificação."];
        readonly pageId: "reservationLifecycle";
        readonly commandName: "updateReservationStatus";
        readonly bffName: "petShop.reservationLifecycle.updateReservationStatus";
        readonly capability: {
            readonly capabilityId: "reservationLifecycle";
            readonly title: "Ciclo de vida da reserva";
            readonly actor: "atendente";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationUpdateReservationStatus;
}
declare module "_102049_/l4/petShop/operations/viewProductDetails.defs" {
    export const operationViewProductDetails: {
        readonly operationId: "viewProductDetails";
        readonly title: "Visualizar detalhes do produto";
        readonly actors: readonly ["cliente"];
        readonly entity: "Product";
        readonly kind: "view";
        readonly reads: readonly ["Product", "ProductCategory", "PetType"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly [];
        readonly story: {
            readonly actor: "cliente";
            readonly goal: "Ver os detalhes completos de um produto do catálogo para decidir se deve reservá-lo";
            readonly steps: readonly ["O cliente seleciona um produto na vitrine de destaques ou na lista filtrada do catálogo", "O sistema recupera o produto pelo seu identificador junto com o nome da categoria e do tipo de pet associados", "O sistema retorna os detalhes completos do produto incluindo nome, preço, flag de destaque, categoria, tipo de pet e datas de cadastro e atualização"];
            readonly outcome: "O cliente visualiza todos os detalhes do produto e pode decidir se deseja reservá-lo para retirada na loja";
        };
        readonly accessPattern: {
            readonly kind: "getById";
            readonly entity: "Product";
            readonly keyField: "Product.productId";
            readonly pagination: "none";
            readonly selection: "single";
            readonly output: readonly ["Product.productId", "Product.name", "Product.price", "Product.isFeatured", "Product.categoryId", "ProductCategory.name", "Product.petTypeId", "PetType.name", "Product.createdAt", "Product.updatedAt"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [{
                readonly name: "productId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Product.productId";
            }, {
                readonly name: "name";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Product.name";
            }, {
                readonly name: "price";
                readonly type: "number";
                readonly required: true;
                readonly fieldRef: "Product.price";
            }, {
                readonly name: "isFeatured";
                readonly type: "boolean";
                readonly required: true;
                readonly fieldRef: "Product.isFeatured";
            }, {
                readonly name: "categoryId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Product.categoryId";
            }, {
                readonly name: "categoryName";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "ProductCategory.name";
            }, {
                readonly name: "petTypeId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Product.petTypeId";
            }, {
                readonly name: "petTypeName";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "PetType.name";
            }, {
                readonly name: "createdAt";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Product.createdAt";
            }, {
                readonly name: "updatedAt";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Product.updatedAt";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "productId";
            readonly fieldRef: "Product.productId";
            readonly required: true;
            readonly source: "routeParam";
            readonly description: "Identificador do produto selecionado pelo cliente na vitrine ou na lista do catálogo";
        }];
        readonly contextResolution: readonly [{
            readonly targetRef: "Product.productId";
            readonly source: "routeParam";
            readonly originRef: "routeParam.productId";
            readonly description: "O identificador do produto é obtido do parâmetro de rota da URL quando o cliente clica em um produto na vitrine ou na lista filtrada do catálogo";
        }];
        readonly acceptanceAssertions: readonly ["O sistema retorna o produto correspondente ao productId informado com nome, preço e flag de destaque", "O sistema retorna o nome da categoria (categoryName) associada ao produto consultando ProductCategory pelo categoryId", "O sistema retorna o nome do tipo de pet (petTypeName) associado ao produto consultando PetType pelo petTypeId", "O sistema retorna as datas de cadastro (createdAt) e última atualização (updatedAt) do produto", "Quando o productId não corresponde a nenhum produto cadastrado, o sistema retorna erro indicando produto não encontrado"];
        readonly pageId: "viewProductDetails";
        readonly commandName: "viewProductDetails";
        readonly bffName: "petShop.viewProductDetails.viewProductDetails";
        readonly capability: {
            readonly capabilityId: "viewProductDetails";
            readonly title: "Visualizar detalhes do produto";
            readonly actor: "cliente";
            readonly priority: "now";
        };
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default operationViewProductDetails;
}
declare module "_102049_/l4/petShop/rules/petShopRules.defs" {
    export const petShopRules: {
        readonly ruleSetId: "petShopRules";
        readonly rules: readonly [{
            readonly ruleId: "featuredProductsOnly";
            readonly title: "Vitrine apenas com produtos em destaque";
            readonly description: "A vitrine deve exibir exclusivamente produtos marcados como destaque por processo administrativo externo; produtos não destacados nunca aparecem na vitrine.";
            readonly appliesTo: readonly ["Product"];
            readonly layer: "domain";
        }, {
            readonly ruleId: "featuredOrderFlexible";
            readonly title: "Ordem dos destaques é flexível";
            readonly description: "A ordem de exibição dos produtos em destaque na vitrine pode variar conforme critérios definidos pela loja, sem ordem fixa obrigatória.";
            readonly appliesTo: readonly ["Product"];
            readonly layer: "application";
        }, {
            readonly ruleId: "combinedFilters";
            readonly title: "Filtros de catálogo combináveis";
            readonly description: "Os filtros de tipo de pet, categoria, nome e faixa de valor devem funcionar simultaneamente, permitindo combinação de múltiplos critérios na pesquisa do catálogo.";
            readonly appliesTo: readonly ["Product"];
            readonly layer: "application";
        }, {
            readonly ruleId: "catalogShowsAll";
            readonly title: "Catálogo lista todos os produtos";
            readonly description: "A listagem do catálogo deve mostrar todos os produtos cadastrados, independentemente de estarem marcados como destaque ou não.";
            readonly appliesTo: readonly ["Product"];
            readonly layer: "domain";
        }, {
            readonly ruleId: "caseInsensitiveSearch";
            readonly title: "Pesquisa por nome insensível a caixa";
            readonly description: "A pesquisa de produtos por nome deve ser insensível a maiúsculas e minúsculas, retornando resultados correspondentes independente da capitalização informada.";
            readonly appliesTo: readonly ["Product"];
            readonly layer: "application";
        }, {
            readonly ruleId: "reservationRequiresContact";
            readonly title: "Reserva exige nome e telefone";
            readonly description: "Uma reserva só pode ser registrada se contiver no mínimo o nome e o telefone do cliente; reservas sem esses dados são rejeitadas.";
            readonly appliesTo: readonly ["Reservation"];
            readonly layer: "domain";
        }, {
            readonly ruleId: "reservationValidity24h";
            readonly title: "Validade da reserva de 24 horas";
            readonly description: "Cada reserva tem validade de 24 horas a partir do registro; após esse prazo o atendente pode cancelá-la, não havendo renovação automática.";
            readonly appliesTo: readonly ["Reservation"];
            readonly layer: "domain";
        }, {
            readonly ruleId: "noAutomaticStockBlock";
            readonly title: "Sem bloqueio automático de estoque";
            readonly description: "Não há bloqueio automático de estoque no momento da reserva; a disponibilidade real do produto é verificada pelo atendente na preparação ou retirada.";
            readonly appliesTo: readonly ["ReservationItem"];
            readonly layer: "domain";
        }, {
            readonly ruleId: "multipleProductsPerReservation";
            readonly title: "Múltiplos produtos por reserva";
            readonly description: "O cliente pode reservar mais de um produto na mesma reserva, cada um com sua própria quantidade, formando múltiplos itens de reserva.";
            readonly appliesTo: readonly ["ReservationItem"];
            readonly layer: "domain";
        }, {
            readonly ruleId: "reservationStatuses";
            readonly title: "Status permitidos da reserva";
            readonly description: "Uma reserva pode assumir apenas os status: pendente, confirmada, atendida (retirada e paga) ou cancelada; nenhum outro status é válido no domínio.";
            readonly appliesTo: readonly ["Reservation"];
            readonly layer: "domain";
        }, {
            readonly ruleId: "inStorePaymentOnly";
            readonly title: "Pagamento exclusivamente presencial";
            readonly description: "O pagamento é sempre presencial na loja; não existe pagamento online nem qualquer forma de cobrança remota neste módulo.";
            readonly appliesTo: readonly ["Payment"];
            readonly layer: "domain";
        }, {
            readonly ruleId: "totalFromPricesAndQuantities";
            readonly title: "Total calculado por preços e quantidades";
            readonly description: "O valor total do pagamento deve ser calculado a partir dos preços dos produtos e das quantidades reservadas em cada item da reserva.";
            readonly appliesTo: readonly ["Payment"];
            readonly layer: "domain";
        }, {
            readonly ruleId: "paymentRequiresReceipt";
            readonly title: "Pagamento exige recebimento efetivo";
            readonly description: "A reserva só pode ser marcada como paga após o recebimento efetivo do pagamento pelo atendente; não é possível marcar como paga sem confirmação do pagamento presencial.";
            readonly appliesTo: readonly ["Payment"];
            readonly layer: "application";
        }];
    };
    export default petShopRules;
}
declare module "_102049_/l4/petShop/workflows/reservationLifecycle.defs" {
    export const workflowReservationLifecycle: {
        readonly workflowId: "reservationLifecycle";
        readonly title: "Ciclo de vida da reserva";
        readonly executionMode: "sequential";
        readonly trigger: "Cliente cria uma reserva de produtos para retirada presencial na loja, gerando uma reserva com status pendente.";
        readonly actors: readonly ["atendente", "cliente"];
        readonly states: readonly ["pending", "confirmed", "fulfilled", "cancelled"];
        readonly transitions: readonly [{
            readonly from: "pending";
            readonly to: "confirmed";
            readonly on: "updateReservationStatus";
            readonly by: "atendente";
            readonly guard: "Reserva contém nome e telefone do cliente e está dentro do prazo de 24h";
        }, {
            readonly from: "pending";
            readonly to: "cancelled";
            readonly on: "updateReservationStatus";
            readonly by: "atendente";
            readonly guard: "Reserva expirada após 24h ou cancelada pelo atendente";
        }, {
            readonly from: "confirmed";
            readonly to: "cancelled";
            readonly on: "updateReservationStatus";
            readonly by: "atendente";
            readonly guard: "Reserva não retirada dentro do prazo ou cancelada pelo atendente";
        }, {
            readonly from: "confirmed";
            readonly to: "fulfilled";
            readonly on: "processPayment";
            readonly by: "atendente";
            readonly guard: "Pagamento presencial recebido efetivamente pelo atendente";
        }];
        readonly operationIds: readonly ["createReservation", "updateReservationStatus", "processPayment"];
        readonly entities: readonly ["Reservation", "ReservationItem", "Product", "Payment"];
        readonly rulesApplied: readonly ["reservationRequiresContact", "reservationValidity24h", "reservationStatuses", "inStorePaymentOnly", "totalFromPricesAndQuantities", "paymentRequiresReceipt"];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Confirmar, preparar e entregar a reserva ao cliente na retirada presencial, processando o pagamento na loja.";
            readonly steps: readonly ["O atendente visualiza as reservas pendentes recebidas dos clientes para saber quais precisam ser confirmadas.", "O atendente revisa os itens e os dados de contato do cliente e confirma a reserva, sinalizando que a loja aceitou e vai preparar os produtos.", "O atendente separa fisicamente os produtos reservados e verifica a disponibilidade real no estoque.", "O cliente chega à loja para retirada e o atendente localiza a reserva pelo número ou pelo nome e telefone do cliente.", "O atendente revisa os itens com o cliente, calcula o valor total e processa o pagamento presencial, marcando a reserva como paga e entregue."];
            readonly outcome: "A reserva é marcada como atendida com o pagamento presencial confirmado e os produtos entregues ao cliente, encerrando o ciclo de vida da reserva.";
        };
        readonly pageId: "reservationLifecycle";
        readonly capabilities: readonly [{
            readonly capabilityId: "reservationLifecycle";
            readonly title: "Ciclo de vida da reserva";
            readonly actor: "atendente";
            readonly priority: "now";
        }];
        readonly statusFrontend: "toCreate";
        readonly statusBackend: "toCreate";
    };
    export default workflowReservationLifecycle;
}
declare module "_102049_/l4/petShop/workspaces/catalog.defs" {
    export const catalogWorkspace: {
        readonly workspaceId: "catalog";
        readonly title: "Catálogo de produtos";
        readonly actors: readonly ["cliente"];
        readonly kind: "workflow";
        readonly entity: "Product";
        readonly workflowId: "reservationLifecycle";
        readonly bffCalls: readonly [{
            readonly bffId: "featuredProducts";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "browseFeaturedProducts";
            }];
            readonly input: readonly [{
                readonly name: "categoryId";
                readonly from: "browseFeaturedProducts.categoryId";
                readonly type: "string";
            }, {
                readonly name: "petTypeId";
                readonly from: "browseFeaturedProducts.petTypeId";
                readonly type: "string";
            }, {
                readonly name: "name";
                readonly from: "browseFeaturedProducts.name";
                readonly type: "string";
            }, {
                readonly name: "priceMin";
                readonly from: "browseFeaturedProducts.priceMin";
                readonly type: "number";
            }, {
                readonly name: "priceMax";
                readonly from: "browseFeaturedProducts.priceMax";
                readonly type: "number";
            }, {
                readonly name: "page";
                readonly type: "number";
            }, {
                readonly name: "pageSize";
                readonly type: "number";
            }];
            readonly output: {
                readonly kind: "list";
                readonly fields: readonly [{
                    readonly name: "productId";
                    readonly from: "browseFeaturedProducts.$items.productId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly from: "browseFeaturedProducts.$items.name";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "price";
                    readonly from: "browseFeaturedProducts.$items.price";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "isFeatured";
                    readonly from: "browseFeaturedProducts.$items.isFeatured";
                    readonly type: "boolean";
                    readonly required: true;
                }, {
                    readonly name: "categoryId";
                    readonly from: "browseFeaturedProducts.$items.categoryId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "petTypeId";
                    readonly from: "browseFeaturedProducts.$items.petTypeId";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "petShop.catalog.featuredProducts";
        }, {
            readonly bffId: "browseCatalog";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "browseProducts";
            }];
            readonly input: readonly [{
                readonly name: "searchName";
                readonly from: "browseProducts.searchName";
                readonly type: "string";
            }, {
                readonly name: "petTypeId";
                readonly from: "browseProducts.petTypeId";
                readonly type: "string";
            }, {
                readonly name: "categoryId";
                readonly from: "browseProducts.categoryId";
                readonly type: "string";
            }, {
                readonly name: "minPrice";
                readonly from: "browseProducts.minPrice";
                readonly type: "number";
            }, {
                readonly name: "maxPrice";
                readonly from: "browseProducts.maxPrice";
                readonly type: "number";
            }, {
                readonly name: "page";
                readonly type: "number";
            }, {
                readonly name: "pageSize";
                readonly type: "number";
            }];
            readonly output: {
                readonly kind: "paginated";
                readonly fields: readonly [{
                    readonly name: "items";
                    readonly from: "browseProducts.$items";
                    readonly type: "array";
                    readonly required: true;
                    readonly item: {
                        readonly fields: readonly [{
                            readonly name: "productId";
                            readonly from: "browseProducts.$items.productId";
                            readonly type: "string";
                            readonly required: true;
                        }, {
                            readonly name: "name";
                            readonly from: "browseProducts.$items.name";
                            readonly type: "string";
                            readonly required: true;
                        }, {
                            readonly name: "price";
                            readonly from: "browseProducts.$items.price";
                            readonly type: "number";
                            readonly required: true;
                        }, {
                            readonly name: "isFeatured";
                            readonly from: "browseProducts.$items.isFeatured";
                            readonly type: "boolean";
                            readonly required: true;
                        }, {
                            readonly name: "categoryId";
                            readonly from: "browseProducts.$items.categoryId";
                            readonly type: "string";
                            readonly required: true;
                        }, {
                            readonly name: "categoryName";
                            readonly from: "browseProducts.$items.categoryName";
                            readonly type: "string";
                            readonly required: true;
                        }, {
                            readonly name: "petTypeId";
                            readonly from: "browseProducts.$items.petTypeId";
                            readonly type: "string";
                            readonly required: true;
                        }, {
                            readonly name: "petTypeName";
                            readonly from: "browseProducts.$items.petTypeName";
                            readonly type: "string";
                            readonly required: true;
                        }, {
                            readonly name: "createdAt";
                            readonly from: "browseProducts.$items.createdAt";
                            readonly type: "string";
                            readonly required: true;
                        }, {
                            readonly name: "updatedAt";
                            readonly from: "browseProducts.$items.updatedAt";
                            readonly type: "string";
                            readonly required: true;
                        }];
                    };
                }, {
                    readonly name: "total";
                    readonly from: "browseProducts.total";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "page";
                    readonly from: "browseProducts.page";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "pageSize";
                    readonly from: "browseProducts.pageSize";
                    readonly type: "number";
                    readonly required: true;
                }];
            };
            readonly route: "petShop.catalog.browseCatalog";
        }, {
            readonly bffId: "productDetails";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "viewProductDetails";
            }];
            readonly input: readonly [{
                readonly name: "productId";
                readonly from: "viewProductDetails.productId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "productId";
                    readonly from: "viewProductDetails.productId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "name";
                    readonly from: "viewProductDetails.name";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "price";
                    readonly from: "viewProductDetails.price";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "isFeatured";
                    readonly from: "viewProductDetails.isFeatured";
                    readonly type: "boolean";
                    readonly required: true;
                }, {
                    readonly name: "categoryId";
                    readonly from: "viewProductDetails.categoryId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "categoryName";
                    readonly from: "viewProductDetails.categoryName";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "petTypeId";
                    readonly from: "viewProductDetails.petTypeId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "petTypeName";
                    readonly from: "viewProductDetails.petTypeName";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "createdAt";
                    readonly from: "viewProductDetails.createdAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "updatedAt";
                    readonly from: "viewProductDetails.updatedAt";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "petShop.catalog.productDetails";
        }, {
            readonly bffId: "reserveProduct";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "createReservation";
            }];
            readonly input: readonly [{
                readonly name: "customerName";
                readonly from: "createReservation.customerName";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "customerPhone";
                readonly from: "createReservation.customerPhone";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "productId";
                readonly from: "createReservation.productId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "quantity";
                readonly from: "createReservation.quantity";
                readonly type: "number";
                readonly required: true;
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "reservationId";
                    readonly from: "createReservation.reservationId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "customerName";
                    readonly from: "createReservation.customerName";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "customerPhone";
                    readonly from: "createReservation.customerPhone";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "createReservation.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "expiresAt";
                    readonly from: "createReservation.expiresAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "createdAt";
                    readonly from: "createReservation.createdAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "items";
                    readonly from: "createReservation.items";
                    readonly type: "array";
                    readonly required: true;
                    readonly item: {
                        readonly fields: readonly [{
                            readonly name: "productId";
                            readonly from: "createReservation.$items.productId";
                            readonly type: "string";
                            readonly required: true;
                        }, {
                            readonly name: "productName";
                            readonly from: "createReservation.$items.productName";
                            readonly type: "string";
                            readonly required: true;
                        }, {
                            readonly name: "quantity";
                            readonly from: "createReservation.$items.quantity";
                            readonly type: "number";
                            readonly required: true;
                        }];
                    };
                }];
            };
            readonly route: "petShop.catalog.reserveProduct";
        }];
        readonly sections: readonly [{
            readonly sectionId: "vitrine";
            readonly intent: "O cliente visualiza produtos em destaque na vitrine inicial do pet shop";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly dataSource: "featuredProducts";
            }, {
                readonly role: "filterControl";
                readonly attachTo: "featuredProducts";
            }];
        }, {
            readonly sectionId: "catalogo";
            readonly intent: "O cliente pesquisa e filtra todos os produtos disponíveis no catálogo completo";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly dataSource: "browseCatalog";
            }, {
                readonly role: "filterControl";
                readonly attachTo: "browseCatalog";
            }];
        }, {
            readonly sectionId: "detalheReserva";
            readonly intent: "O cliente visualiza os detalhes do produto selecionado e reserva para retirada na loja";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly dataSource: "productDetails";
            }, {
                readonly role: "contextualAction";
                readonly action: "reserveProduct";
            }];
        }];
        readonly operationIds: readonly ["browseFeaturedProducts", "browseProducts", "viewProductDetails", "createReservation"];
        readonly purpose: "O cliente navega pela vitrine e pelo catálogo, visualiza detalhes dos produtos e reserva itens para retirada na loja";
        readonly sliceHash: "djb2:0f1ce64b";
    };
    export default catalogWorkspace;
}
declare module "_102049_/l4/petShop/workspaces/reservationManagement.defs" {
    export const reservationManagementWorkspace: {
        readonly workspaceId: "reservationManagement";
        readonly title: "Gestão de reservas";
        readonly actors: readonly ["atendente"];
        readonly kind: "workflow";
        readonly entity: "Reservation";
        readonly workflowId: "reservationLifecycle";
        readonly bffCalls: readonly [{
            readonly bffId: "browseReservationsQuery";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "browseReservations";
            }];
            readonly input: readonly [{
                readonly name: "searchTerm";
                readonly from: "browseReservations.searchTerm";
                readonly type: "string";
            }, {
                readonly name: "statusFilter";
                readonly from: "browseReservations.statusFilter";
                readonly type: "string";
            }, {
                readonly name: "page";
                readonly type: "number";
            }, {
                readonly name: "pageSize";
                readonly type: "number";
            }];
            readonly output: {
                readonly kind: "list";
                readonly fields: readonly [{
                    readonly name: "reservationId";
                    readonly from: "browseReservations.$items.reservationId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "customerName";
                    readonly from: "browseReservations.$items.customerName";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "customerPhone";
                    readonly from: "browseReservations.$items.customerPhone";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "browseReservations.$items.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "expiresAt";
                    readonly from: "browseReservations.$items.expiresAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "createdAt";
                    readonly from: "browseReservations.$items.createdAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "updatedAt";
                    readonly from: "browseReservations.$items.updatedAt";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "petShop.reservationManagement.browseReservationsQuery";
        }, {
            readonly bffId: "updateReservationStatusCommand";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "updateReservationStatus";
            }];
            readonly input: readonly [{
                readonly name: "reservationId";
                readonly from: "updateReservationStatus.reservationId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "newStatus";
                readonly from: "updateReservationStatus.newStatus";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "cancellationReason";
                readonly from: "updateReservationStatus.cancellationReason";
                readonly type: "string";
            }, {
                readonly name: "paymentId";
                readonly from: "updateReservationStatus.paymentId";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "reservationId";
                    readonly from: "updateReservationStatus.reservationId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "customerName";
                    readonly from: "updateReservationStatus.customerName";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "customerPhone";
                    readonly from: "updateReservationStatus.customerPhone";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "updateReservationStatus.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "expiresAt";
                    readonly from: "updateReservationStatus.expiresAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "confirmedAt";
                    readonly from: "updateReservationStatus.confirmedAt";
                    readonly type: "string";
                }, {
                    readonly name: "fulfilledAt";
                    readonly from: "updateReservationStatus.fulfilledAt";
                    readonly type: "string";
                }, {
                    readonly name: "cancelledAt";
                    readonly from: "updateReservationStatus.cancelledAt";
                    readonly type: "string";
                }, {
                    readonly name: "cancellationReason";
                    readonly from: "updateReservationStatus.cancellationReason";
                    readonly type: "string";
                }, {
                    readonly name: "paymentId";
                    readonly from: "updateReservationStatus.paymentId";
                    readonly type: "string";
                }, {
                    readonly name: "updatedAt";
                    readonly from: "updateReservationStatus.updatedAt";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "petShop.reservationManagement.updateReservationStatusCommand";
        }, {
            readonly bffId: "processPaymentCommand";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "processPayment";
            }];
            readonly input: readonly [{
                readonly name: "reservationId";
                readonly from: "processPayment.reservationId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "method";
                readonly from: "processPayment.method";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "paymentId";
                    readonly from: "processPayment.paymentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "reservationId";
                    readonly from: "processPayment.reservationId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "amount";
                    readonly from: "processPayment.amount";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "method";
                    readonly from: "processPayment.method";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "processPayment.status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "receivedBy";
                    readonly from: "processPayment.receivedBy";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "createdAt";
                    readonly from: "processPayment.createdAt";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "reservationStatus";
                    readonly from: "processPayment.reservationStatus";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "petShop.reservationManagement.processPaymentCommand";
        }];
        readonly sections: readonly [{
            readonly sectionId: "reservationList";
            readonly intent: "O atendente visualiza, filtra e atua sobre as reservas pendentes dos clientes";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly dataSource: "browseReservationsQuery";
            }, {
                readonly role: "filterControl";
                readonly attachTo: "browseReservationsQuery";
            }, {
                readonly role: "contextualAction";
                readonly action: "updateReservationStatusCommand";
            }, {
                readonly role: "contextualAction";
                readonly action: "processPaymentCommand";
            }];
        }];
        readonly operationIds: readonly ["browseReservations", "updateReservationStatus", "processPayment"];
        readonly purpose: "O atendente visualiza reservas pendentes, confirma ou cancela e recebe o pagamento presencial na retirada";
        readonly sliceHash: "djb2:758a66f8";
    };
    export default reservationManagementWorkspace;
}
declare module "_102049_/l5/petShop/process.defs" {
    export const petShopProcess: {
        readonly schemaVersion: "2026-06-25";
        readonly moduleName: "petShop";
        readonly runs: readonly [{
            readonly runId: "ns-1784491648869";
            readonly kind: "newSolution-behavior";
            readonly startedAt: "2026-07-19T20:07:28.867Z";
            readonly finishedAt: "2026-07-19T20:07:28.869Z";
            readonly sourceRefs: {
                readonly module: "l4/petShop/module.defs.ts";
                readonly health: "l4/petShop/trace/behavior-health-report.json";
                readonly journeys: "l4/petShop/siteMap.defs.ts";
                readonly todoFrontend: "l5/petShop/todoFrontend.defs.ts";
                readonly todoBackend: "l5/petShop/todoBackend.defs.ts";
            };
            readonly handoffNotes: readonly ["capability.multiowned: capability 'reservationLifecycle' is owned by 2 workspaces (catalog, reservationManagement)"];
            readonly nextSteps: readonly [{
                readonly id: "stage2-experience";
                readonly kind: "workflowExperience";
                readonly title: "Generate frontend experience (@@changeFrontend)";
                readonly description: "Materialize l2 pages from the l4 behavior model.";
                readonly status: "pending";
            }, {
                readonly id: "stage3-backend";
                readonly kind: "backendImplementation";
                readonly title: "Generate backend (@@changeBackend)";
                readonly description: "Materialize l1 hexagonal backend from the l4 behavior model.";
                readonly status: "pending";
            }];
        }];
    };
    export default petShopProcess;
}
declare module "_102049_/l5/petShop/todoBackend.defs" {
    export const petShopTodoBackend: {
        readonly schemaVersion: "2026-07-02-layer-todo";
        readonly moduleName: "petShop";
        readonly layer: "backend";
        readonly updatedAt: "2026-07-20T00:35:44.287Z";
        readonly owners: readonly [{
            readonly ownerType: "workflow";
            readonly ownerId: "reservationLifecycle";
            readonly title: "Ciclo de vida da reserva";
            readonly status: "done";
            readonly defPath: "l4/petShop/workflows/reservationLifecycle.defs.ts";
            readonly pageId: "reservationLifecycle";
            readonly capabilityId: "reservationLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "browseFeaturedProducts";
            readonly title: "Visualizar produtos em destaque na vitrine";
            readonly status: "done";
            readonly defPath: "l4/petShop/operations/browseFeaturedProducts.defs.ts";
            readonly pageId: "browseFeaturedProducts";
            readonly commandName: "browseFeaturedProducts";
            readonly bffName: "petShop.browseFeaturedProducts.browseFeaturedProducts";
            readonly capabilityId: "browseFeaturedProducts";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "browseProducts";
            readonly title: "Pesquisar e filtrar produtos no catálogo";
            readonly status: "done";
            readonly defPath: "l4/petShop/operations/browseProducts.defs.ts";
            readonly pageId: "browseProducts";
            readonly commandName: "browseProducts";
            readonly bffName: "petShop.browseProducts.browseProducts";
            readonly capabilityId: "browseProducts";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "viewProductDetails";
            readonly title: "Visualizar detalhes do produto";
            readonly status: "done";
            readonly defPath: "l4/petShop/operations/viewProductDetails.defs.ts";
            readonly pageId: "viewProductDetails";
            readonly commandName: "viewProductDetails";
            readonly bffName: "petShop.viewProductDetails.viewProductDetails";
            readonly capabilityId: "viewProductDetails";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "browseReservations";
            readonly title: "Visualizar reservas pendentes e localizar cliente";
            readonly status: "done";
            readonly defPath: "l4/petShop/operations/browseReservations.defs.ts";
            readonly pageId: "browseReservations";
            readonly commandName: "browseReservations";
            readonly bffName: "petShop.browseReservations.browseReservations";
            readonly capabilityId: "browseReservations";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "createReservation";
            readonly title: "Reservar produtos para retirada na loja";
            readonly status: "done";
            readonly defPath: "l4/petShop/operations/createReservation.defs.ts";
            readonly pageId: "reservationLifecycle";
            readonly commandName: "createReservation";
            readonly bffName: "petShop.reservationLifecycle.createReservation";
            readonly capabilityId: "reservationLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "updateReservationStatus";
            readonly title: "Confirmar ou cancelar reserva";
            readonly status: "done";
            readonly defPath: "l4/petShop/operations/updateReservationStatus.defs.ts";
            readonly pageId: "reservationLifecycle";
            readonly commandName: "updateReservationStatus";
            readonly bffName: "petShop.reservationLifecycle.updateReservationStatus";
            readonly capabilityId: "reservationLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "processPayment";
            readonly title: "Receber pagamento presencial e encerrar reserva";
            readonly status: "done";
            readonly defPath: "l4/petShop/operations/processPayment.defs.ts";
            readonly pageId: "reservationLifecycle";
            readonly commandName: "processPayment";
            readonly bffName: "petShop.reservationLifecycle.processPayment";
            readonly capabilityId: "reservationLifecycle";
        }];
    };
    export default petShopTodoBackend;
}
declare module "_102049_/l5/petShop/todoFrontend.defs" {
    export const petShopTodoFrontend: {
        readonly schemaVersion: "2026-07-02-layer-todo";
        readonly moduleName: "petShop";
        readonly layer: "frontend";
        readonly updatedAt: "2026-07-19T20:07:28.867Z";
        readonly owners: readonly [{
            readonly ownerType: "workflow";
            readonly ownerId: "reservationLifecycle";
            readonly title: "Ciclo de vida da reserva";
            readonly status: "toCreate";
            readonly defPath: "l4/petShop/workflows/reservationLifecycle.defs.ts";
            readonly pageId: "reservationLifecycle";
            readonly capabilityId: "reservationLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "browseFeaturedProducts";
            readonly title: "Visualizar produtos em destaque na vitrine";
            readonly status: "toCreate";
            readonly defPath: "l4/petShop/operations/browseFeaturedProducts.defs.ts";
            readonly pageId: "browseFeaturedProducts";
            readonly commandName: "browseFeaturedProducts";
            readonly bffName: "petShop.browseFeaturedProducts.browseFeaturedProducts";
            readonly capabilityId: "browseFeaturedProducts";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "browseProducts";
            readonly title: "Pesquisar e filtrar produtos no catálogo";
            readonly status: "toCreate";
            readonly defPath: "l4/petShop/operations/browseProducts.defs.ts";
            readonly pageId: "browseProducts";
            readonly commandName: "browseProducts";
            readonly bffName: "petShop.browseProducts.browseProducts";
            readonly capabilityId: "browseProducts";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "viewProductDetails";
            readonly title: "Visualizar detalhes do produto";
            readonly status: "toCreate";
            readonly defPath: "l4/petShop/operations/viewProductDetails.defs.ts";
            readonly pageId: "viewProductDetails";
            readonly commandName: "viewProductDetails";
            readonly bffName: "petShop.viewProductDetails.viewProductDetails";
            readonly capabilityId: "viewProductDetails";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "browseReservations";
            readonly title: "Visualizar reservas pendentes e localizar cliente";
            readonly status: "toCreate";
            readonly defPath: "l4/petShop/operations/browseReservations.defs.ts";
            readonly pageId: "browseReservations";
            readonly commandName: "browseReservations";
            readonly bffName: "petShop.browseReservations.browseReservations";
            readonly capabilityId: "browseReservations";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "createReservation";
            readonly title: "Reservar produtos para retirada na loja";
            readonly status: "toCreate";
            readonly defPath: "l4/petShop/operations/createReservation.defs.ts";
            readonly pageId: "reservationLifecycle";
            readonly commandName: "createReservation";
            readonly bffName: "petShop.reservationLifecycle.createReservation";
            readonly capabilityId: "reservationLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "updateReservationStatus";
            readonly title: "Confirmar ou cancelar reserva";
            readonly status: "toCreate";
            readonly defPath: "l4/petShop/operations/updateReservationStatus.defs.ts";
            readonly pageId: "reservationLifecycle";
            readonly commandName: "updateReservationStatus";
            readonly bffName: "petShop.reservationLifecycle.updateReservationStatus";
            readonly capabilityId: "reservationLifecycle";
        }, {
            readonly ownerType: "operation";
            readonly ownerId: "processPayment";
            readonly title: "Receber pagamento presencial e encerrar reserva";
            readonly status: "toCreate";
            readonly defPath: "l4/petShop/operations/processPayment.defs.ts";
            readonly pageId: "reservationLifecycle";
            readonly commandName: "processPayment";
            readonly bffName: "petShop.reservationLifecycle.processPayment";
            readonly capabilityId: "reservationLifecycle";
        }];
    };
    export default petShopTodoFrontend;
}
